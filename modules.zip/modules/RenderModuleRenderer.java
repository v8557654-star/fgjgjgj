package winvi.noxiumvisuals.modules;

import com.google.common.collect.Lists;
import java.util.Arrays;
import java.util.List;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.utils.render.RenderModuleAccess;
public class RenderModuleRenderer implements RenderModuleAccess {
      private final List<ModuleSetting> eajr = Lists.newArrayList();

      @Override
   public final void setup(ModuleSetting... setting) {
      this.eajr.addAll(Arrays.asList(setting));
      if (this instanceof Module module) {
         String text = module.getTranslationPrefix();

         for (ModuleSetting moduleProvider3 : setting) {
            this.bg(moduleProvider3, text);
         }
      }
   }

      public ModuleSetting get(String name) {
      for (int index = 0; index < this.eajr.size(); index++) {
         ModuleSetting moduleProvider3 = this.eajr.get(index);
         if (moduleProvider3.getName().equalsIgnoreCase(name)) {
            return moduleProvider3;
         }
      }

      return null;
   }

      public List<ModuleSetting> settings() {
      return this.eajr;
   }

      private void bg(ModuleSetting setting, String translationPrefix) {
      setting.setAutoTranslationPrefix(translationPrefix);
      if (setting instanceof SettingGroup moduleSettingProvider3 && moduleSettingProvider3.getSubSettings() != null) {
         for (ModuleSetting moduleProvider3 : moduleSettingProvider3.getSubSettings()) {
            this.bg(moduleProvider3, translationPrefix);
         }
      }
   }

   static {
      int index = 0;
   }
}
