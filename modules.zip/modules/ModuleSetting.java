package winvi.noxiumvisuals.modules;

import java.util.function.Supplier;
import winvi.noxiumvisuals.utils.JsonFileRenderer;
public class ModuleSetting {
      private final String name;
      private String description;
      private String translationKey;
      private String t;
      private String autoTranslationPrefix;
      private String normalizedName;
      private String[] cachedNameKeys;
      private String[] cachedDescriptionKeys;
      private Supplier<Boolean> visible;
      private Supplier<Boolean> visibleInModule;

   public ModuleSetting(String name) {
      this.name = name;
   }

   public ModuleSetting(String name, String description) {
      this.name = name;
      this.description = description;
   }

      public <T extends ModuleSetting> T withTranslation(String translationKey, String descriptionKey) {
      this.translationKey = translationKey;
      this.t = descriptionKey;
      this.cachedNameKeys = null;
      this.cachedDescriptionKeys = null;
      return (T)this;
   }

      public String getLocalizedName() {
      for (String text : this.resolveNameKeys()) {
         if (JsonFileRenderer.has(text)) {
            return JsonFileRenderer.get(text);
         }
      }

      return this.name;
   }

      public String getLocalizedDescription() {
      for (String text : this.resolveDescriptionKeys()) {
         if (JsonFileRenderer.has(text)) {
            return JsonFileRenderer.get(text);
         }
      }

      return this.description != null ? this.description : "";
   }

      protected String getLocalizedOption(String value) {
      if (value != null && !value.isBlank()) {
         String text = Module.normalizeTranslationKey(value);

         for (String text2 : this.resolveNameKeys()) {
            String text3 = text2 + "." + text;
            if (JsonFileRenderer.has(text3)) {
               return JsonFileRenderer.get(text3);
            }
         }

         String text4 = "common." + text;
         return JsonFileRenderer.has(text4) ? JsonFileRenderer.get(text4) : value;
      } else {
         return value;
      }
   }

      public boolean isVisible() {
      return this.visible == null || this.visible.get();
   }

      public boolean isVisibleInModule() {
      return this.visibleInModule == null || this.visibleInModule.get();
   }

      void setAutoTranslationPrefix(String autoTranslationPrefix) {
      this.autoTranslationPrefix = autoTranslationPrefix;
      this.cachedNameKeys = null;
      this.cachedDescriptionKeys = null;
   }

      private String[] resolveNameKeys() {
      if (this.cachedNameKeys != null) {
         return this.cachedNameKeys;
      } else {
         String text = null;
         String text2 = null;
         if (this.translationKey != null && !this.translationKey.isEmpty()) {
            text = this.translationKey;
         }

         if (this.autoTranslationPrefix != null && !this.autoTranslationPrefix.isEmpty()) {
            text2 = this.autoTranslationPrefix + "." + this.getNormalizedName();
         }

         this.cachedNameKeys = combineKeys(text, text2);
         return this.cachedNameKeys;
      }
   }

      private String[] resolveDescriptionKeys() {
      if (this.cachedDescriptionKeys != null) {
         return this.cachedDescriptionKeys;
      } else {
         String text = null;
         String text2 = null;
         if (this.t != null && !this.t.isEmpty()) {
            text = this.t;
         }

         if (this.autoTranslationPrefix != null && !this.autoTranslationPrefix.isEmpty()) {
            text2 = this.autoTranslationPrefix + "." + this.getNormalizedName() + ".desc";
         }

         this.cachedDescriptionKeys = combineKeys(text, text2);
         return this.cachedDescriptionKeys;
      }
   }

      private String getNormalizedName() {
      if (this.normalizedName == null) {
         this.normalizedName = Module.normalizeTranslationKey(this.name);
      }

      return this.normalizedName;
   }

      private static String[] combineKeys(String first, String second) {
      if (first == null) {
         return second == null ? new String[0] : new String[]{second};
      } else {
         return second != null && !first.equals(second) ? new String[]{first, second} : new String[]{first};
      }
   }

      public String getName() {
      return this.name;
   }

      public String getDescription() {
      return this.description;
   }

      public String getTranslationKey() {
      return this.translationKey;
   }

      public String getDescriptionKey() {
      return this.t;
   }

      public String getAutoTranslationPrefix() {
      return this.autoTranslationPrefix;
   }

      public Supplier<Boolean> getVisible() {
      return this.visible;
   }

      public Supplier<Boolean> getVisibleInModule() {
      return this.visibleInModule;
   }

      public void setVisible(Supplier<Boolean> visible) {
      this.visible = visible;
   }

      public void setVisibleInModule(Supplier<Boolean> visibleInModule) {
      this.visibleInModule = visibleInModule;
   }

}
