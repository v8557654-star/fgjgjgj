package winvi.noxiumvisuals.modules;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import winvi.noxiumvisuals.systems.events.RenderEventData;
import winvi.noxiumvisuals.systems.events.EventBus;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.utils.NoxiumLogger;
import winvi.noxiumvisuals.utils.render.RenderWindowAccess;
public class ModuleEventBinder implements RenderWindowAccess {
      private final List<Module> yorla;

   public ModuleEventBinder(List<Module> modules, EventBus eventManager) {
      this.yorla = modules;
      eventManager.register(this);
   }

   @EventHandler
      public void onKey(RenderEventData event) {
      if (event.key() >= 0) {
         for (Module module : this.yorla) {
            if (module.getKey() >= 0 && event.key() == module.getKey() && MinecraftClient.getInstance().currentScreen == null) {
               try {
                  this.initMethod85(module, event.action());
               } catch (Exception exception) {
                  this.bbho(module.getName(), exception);
               }
            }
         }
      }
   }

      private void initMethod85(Module module, int action) {
      if (module.getType() == 0) {
         if (action == 1) {
            module.setState(true);
         } else if (action == 0) {
            module.setState(false);
         }
      } else {
         if (module.getType() == 1 && action == 1) {
            module.switchState();
         }
      }
   }

      private void bbho(String moduleName, Exception e) {
      NoxiumLogger textProvider2 = new NoxiumLogger();
      textProvider2.log("Error in module " + moduleName + ": " + e.getMessage());
   }

   static {
      int index = 0;
   }
}
