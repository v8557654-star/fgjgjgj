package winvi.noxiumvisuals.modules.manager;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.ItemPickupAnimationS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.ContainerNotification;
import winvi.noxiumvisuals.modules.visuals.ModuleType;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.PacketEventProvider;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.EventDirection;
import winvi.noxiumvisuals.ui.hud.elements.DynamicIslandHud;
import winvi.noxiumvisuals.ui.hud.elements.NotificationsHud;
import winvi.noxiumvisuals.utils.JsonFileRenderer;
import winvi.noxiumvisuals.utils.render.MinecraftUtils;
public class NotificationsModule extends Module {
      private static final String vwrym = "Notifications";
      private static final String destroyField96 = "Island";
      public final MultiSelectSetting notificationSettings;
      public final ChoiceSetting notificationTarget;
      private final List<ContainerNotification> dqh;

   public NotificationsModule() {
      super("Notifications", ModuleCategory.MANAGER);
      this.dqh = new ArrayList<>();
      this.notificationTarget = new ChoiceSetting(
            "Notification Target",
            "Where notifications should be shown"
         )
         .value(
            "Notifications",
            "Island"
         )
         .selected("Notifications")
         .withTranslation("notifications.target", "notifications.target.desc");
      this.notificationSettings = new MultiSelectSetting(
            "Notifications",
            "Choose when the notification will appear"
         )
         .value(
            "Module Switch",
            "Item Pick Up"
         );
      this.notificationSettings.withTranslation("notifications.settings", "notifications.settings.desc");
      this.notificationSettings
         .selected(
            "Module Switch",
            "Item Pick Up"
         );
      this.setup(new ModuleSetting[]{this.notificationTarget, this.notificationSettings});
   }

      public boolean isIslandTarget() {
      return this.notificationTarget != null
         && this.notificationTarget.isSelected("Island");
   }

      public void pushModuleNotification(String moduleName, boolean enabled, ModuleCategory category) {
      String text = JsonFileRenderer.get(enabled ? "hud.notifications.enabled" : "hud.notifications.disabled");
      if (this.isIslandTarget()) {
         DynamicIslandHud.pushIslandNotification(moduleName + " " + text);
      } else {
         NotificationsHud.pushModule(moduleName, enabled, category);
      }
   }

      public void pushCustomNotification(String text) {
      this.pushCustomNotification(text, ':');
   }

      public void pushCustomNotification(String text, char infoIcon) {
      if (this.isIslandTarget()) {
         DynamicIslandHud.pushIslandNotification(text);
      } else {
         NotificationsHud.pushCustomInfo(text, infoIcon);
      }
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (this.isState()) {
         while (!this.dqh.isEmpty()) {
            this.yzlllv(ModuleType.INVENTORY, JsonFileRenderer.get("hud.notifications.items_picked"));
            this.yzlllv(ModuleType.SHULKER_INVENTORY, JsonFileRenderer.get("hud.notifications.items_shulker"));
            this.yzlllv(ModuleType.SHULKER, JsonFileRenderer.get("hud.notifications.shulker_picked"));
         }
      }
   }

   @EventHandler
      public void onPacket(PacketEventProvider event) {
      if (this.isState()
         && event.getType() == EventDirection.RECEIVE
         && this.notificationSettings.isSelected("Item Pick Up")
         && !MinecraftUtils.nullCheck()) {
         if (event.getPacket() instanceof ItemPickupAnimationS2CPacket itemPickupAnimationS2CPacket
            && itemPickupAnimationS2CPacket.getCollectorEntityId() == Objects.requireNonNull(MinecraftClient.getInstance().player).getId()
            && Objects.requireNonNull(MinecraftClient.getInstance().world).getEntityById(itemPickupAnimationS2CPacket.getEntityId()) instanceof ItemEntity itemEntity) {
            ItemStack itemStack = itemEntity.getStack();
            ContainerComponent containerComponent = (ContainerComponent)itemStack.get(DataComponentTypes.CONTAINER);
            if (containerComponent == null) {
               if (!itemStack.isEmpty()) {
                  MutableText name = Text.empty().append(itemStack.getName());
                  if (itemStack.getCount() > 1) {
                     name.append(" [" + itemStack.getCount() + "x]");
                  }

                  this.dqh.add(new ContainerNotification(ModuleType.INVENTORY, name));
               }
            } else {
               List list = this.convertMethod37(containerComponent);

               for (int index = 0; index < list.size(); index++) {
                  ItemStack itemStack2 = (ItemStack)list.get(index);
                  if (!itemStack2.isEmpty()) {
                     MutableText name2 = Text.empty().append(itemStack2.getName());
                     if (itemStack2.getCount() > 1) {
                        name2.append(" [" + itemStack2.getCount() + "x]");
                     }

                     this.dqh.add(new ContainerNotification(ModuleType.SHULKER, name2));
                  }
               }
            }
         }

         if (event.getPacket() instanceof ScreenHandlerSlotUpdateS2CPacket screenHandlerSlotUpdateS2CPacket) {
            int index2 = screenHandlerSlotUpdateS2CPacket.getSlot();
            ContainerComponent containerComponent2 = (ContainerComponent)screenHandlerSlotUpdateS2CPacket.getStack().get(DataComponentTypes.CONTAINER);
            if (containerComponent2 != null
               && screenHandlerSlotUpdateS2CPacket.getSyncId() == 0
               && index2 < Objects.requireNonNull(MinecraftClient.getInstance().player).currentScreenHandler.slots.size()) {
               ContainerComponent client = (ContainerComponent)MinecraftClient.getInstance()
                  .player
                  .currentScreenHandler
                  .getSlot(index2)
                  .getStack()
                  .get(DataComponentTypes.CONTAINER);
               if (client != null) {
                  List list2 = this.convertMethod37(client);
                  List list3 = this.convertMethod37(containerComponent2);

                  for (int index3 = 0; index3 < list3.size(); index3++) {
                     ItemStack itemStack3 = (ItemStack)list3.get(index3);
                     if (!itemStack3.isEmpty() && !this.setMethod55(list2, itemStack3)) {
                        this.dqh.add(new ContainerNotification(ModuleType.SHULKER_INVENTORY, Text.empty().append(itemStack3.getName())));
                     }
                  }
               }
            }
         }
      }
   }

      private List<ItemStack> convertMethod37(ContainerComponent container) {
      ArrayList arrayList = new ArrayList(container.stacks.size());

      for (int index = 0; index < container.stacks.size(); index++) {
         arrayList.add((ItemStack)container.stacks.get(index));
      }

      return arrayList;
   }

      private boolean setMethod55(List<ItemStack> currentStacks, ItemStack stack) {
      for (int index = 0; index < currentStacks.size(); index++) {
         ItemStack itemStack = (ItemStack)currentStacks.get(index);
         if (Objects.equals(itemStack.getComponents(), stack.getComponents()) && itemStack.toString().equals(stack.toString())) {
            return true;
         }
      }

      return false;
   }

      private void yzlllv(ModuleType type, String prefix) {
      MutableText textComponent = Text.empty();
      boolean enabled = false;
      Iterator iterator2 = this.dqh.iterator();

      while (iterator2.hasNext()) {
         ContainerNotification textModuleData2 = (ContainerNotification)iterator2.next();
         if (textModuleData2.type() == type) {
            if (enabled) {
               textComponent.append(" ,  ");
            }

            textComponent.append(textModuleData2.text());
            iterator2.remove();
            enabled = true;
            if (textComponent.getString().length() > 150) {
               break;
            }
         }
      }

      if (enabled) {
         this.pushCustomNotification(Text.empty().append(prefix).append(textComponent).getString(), '7');
      }
   }

}
