package winvi.noxiumvisuals.modules.manager;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.List;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class InformationHUDModule extends Module {
      public static final String SECTION_TPS = "TPS";
      public static final String SECTION_PING = "Ping";
      public static final String SECTION_SERVER = "Server";
      private final BooleanSetting qn;
      private final MultiSelectSetting rlult;

   public InformationHUDModule() {
      super("Information HUD", ModuleCategory.MANAGER);
      this.qn = new BooleanSetting(
            "Transparent Background",
            "Remove background"
         )
         .setValue(false);
      this.rlult = new MultiSelectSetting(
            "Sections",
            "Choose displayed information blocks"
         )
         .value(
            "TPS",
            "Ping",
            "Server"
         )
         .selected(
            "TPS",
            "Ping",
            "Server"
         );
      this.qn.withTranslation("hud.common.transparentbg", "hud.common.transparentbg.desc");
      this.rlult.withTranslation("information.sections", "information.sections.desc");
      this.rlult.onChange(selected -> {
         this.cmo();
      });
      this.setup(new ModuleSetting[]{this.qn, this.rlult});
      this.setState(true);
   }

      public boolean isTpsSectionEnabled() {
      this.cmo();
      return this.rlult.isSelected("TPS");
   }

      public boolean isPingSectionEnabled() {
      this.cmo();
      return this.rlult.isSelected("Ping");
   }

      public boolean isServerSectionEnabled() {
      this.cmo();
      return this.rlult.isSelected("Server");
   }

      private void cmo() {
      boolean enabled = this.rlult.isSelected("TPS")
         || this.rlult.isSelected("Ping")
         || this.rlult.isSelected("Server");
      if (!enabled) {
         this.rlult.setSelected(new ArrayList<>(List.of("TPS")));
      }
   }

      public BooleanSetting getTransparentBackground() {
      return this.qn;
   }

      public MultiSelectSetting getSections() {
      return this.rlult;
   }

   static {
      int index = 0;
   }
}
