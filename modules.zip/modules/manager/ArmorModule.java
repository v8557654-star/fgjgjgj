package winvi.noxiumvisuals.modules.manager;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class ArmorModule extends Module {
      private final BooleanSetting removeField50;
      private final BooleanSetting handleField150;
      private final BooleanSetting zjntc;
      private final BooleanSetting updateField790;
      private final ChoiceSetting destroyField750;

   public ArmorModule() {
      super("Armor", ModuleCategory.MANAGER);
      this.removeField50 = new BooleanSetting(
            "Auto Position",
            "Automatically position near hotbar"
         )
         .setValue(false);
      this.handleField150 = new BooleanSetting(
            "Transparent Background",
            "Remove background"
         )
         .setValue(false);
      this.zjntc = new BooleanSetting(
            "Durability Bar",
            "Show custom durability bar"
         )
         .setValue(true);
      this.updateField790 = new BooleanSetting(
            "Durability Percent",
            "Show armor durability percent"
         )
         .setValue(false);
      this.destroyField750 = new ChoiceSetting(
            "Layout",
            "Armor display orientation"
         )
         .value(
            "Horizontal",
            "Vertical"
         )
         .selected("Horizontal");
      this.removeField50.withTranslation("armor.autoposition", "armor.autoposition.desc");
      this.handleField150.withTranslation("hud.common.transparentbg", "hud.common.transparentbg.desc");
      this.zjntc.withTranslation("armor.durabilitybar", "armor.durabilitybar.desc");
      this.updateField790.withTranslation("armor.durabilitypercent", "armor.durabilitypercent.desc");
      this.destroyField750.withTranslation("armor.layout", "armor.layout.desc");
      this.setup(new ModuleSetting[]{this.removeField50, this.handleField150, this.zjntc, this.updateField790, this.destroyField750});
      this.setState(true);
   }

      public BooleanSetting getAutoPosition() {
      return this.removeField50;
   }

      public BooleanSetting getTransparentBackground() {
      return this.handleField150;
   }

      public BooleanSetting getDurabilityBar() {
      return this.zjntc;
   }

      public BooleanSetting getDurabilityPercent() {
      return this.updateField790;
   }

      public ChoiceSetting getLayout() {
      return this.destroyField750;
   }

}
