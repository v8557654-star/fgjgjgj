package winvi.noxiumvisuals.modules.manager;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class ScoreBoardModule extends Module {
      private final BooleanSetting qk0;
      private final BooleanSetting egzpm;
      private final BooleanSetting calculateField14;

   public ScoreBoardModule() {
      super("Score Board", ModuleCategory.MANAGER);
      this.qk0 = new BooleanSetting(
            "Transparent Background",
            "Remove background"
         )
         .setValue(false);
      this.egzpm = new BooleanSetting(
            "Sub Background",
            "Show sub background"
         )
         .setValue(true);
      this.calculateField14 = new BooleanSetting(
            "Vanilla Text",
            "Use vanilla text instead of MSDF"
         )
         .setValue(true);
      this.qk0.withTranslation("hud.common.transparentbg", "hud.common.transparentbg.desc");
      this.egzpm.withTranslation("hud.common.subbg", "hud.common.subbg.desc");
      this.calculateField14.withTranslation("scoreboard.vanillatext", "scoreboard.vanillatext.desc");
      this.setup(new ModuleSetting[]{this.qk0, this.egzpm, this.calculateField14});
      this.setState(true);
   }

      public BooleanSetting getTransparentBackground() {
      return this.qk0;
   }

      public BooleanSetting getSubBackground() {
      return this.egzpm;
   }

      public BooleanSetting getVanillaText() {
      return this.calculateField14;
   }

}
