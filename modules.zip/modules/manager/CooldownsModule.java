package winvi.noxiumvisuals.modules.manager;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class CooldownsModule extends Module {
      private final BooleanSetting convertField65;

   public CooldownsModule() {
      super("Cooldowns", ModuleCategory.MANAGER);
      this.convertField65 = new BooleanSetting(
            "Transparent Background",
            "Remove background"
         )
         .setValue(false);
      this.convertField65.withTranslation("hud.common.transparentbg", "hud.common.transparentbg.desc");
      this.setup(new ModuleSetting[]{this.convertField65});
      this.setState(true);
   }

      public BooleanSetting getTransparentBackground() {
      return this.convertField65;
   }

}
