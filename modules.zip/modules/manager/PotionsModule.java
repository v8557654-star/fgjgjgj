package winvi.noxiumvisuals.modules.manager;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class PotionsModule extends Module {
      private final BooleanSetting dqi;
      private final BooleanSetting qj;

   public PotionsModule() {
      super("Potions", ModuleCategory.MANAGER);
      this.dqi = new BooleanSetting(
            "Transparent Background",
            "Remove background"
         )
         .setValue(false);
      this.qj = new BooleanSetting(
            "Sort Effects",
            "Good effects on top, bad on bottom"
         )
         .setValue(false);
      this.dqi.withTranslation("hud.common.transparentbg", "hud.common.transparentbg.desc");
      this.qj.withTranslation("hud.potions.sort", "hud.potions.sort.desc");
      this.setup(new ModuleSetting[]{this.dqi, this.qj});
      this.setState(true);
   }

      public BooleanSetting getTransparentBackground() {
      return this.dqi;
   }

      public BooleanSetting getSortEffects() {
      return this.qj;
   }

   static {
      int index = 0;
   }
}
