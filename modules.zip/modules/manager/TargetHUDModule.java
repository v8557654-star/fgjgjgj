package winvi.noxiumvisuals.modules.manager;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class TargetHUDModule extends Module {
      public final BooleanSetting follow;
      public final NumberSetting displayTime;
      public final BooleanSetting particles;
      public final BooleanSetting transparentBackground;

   public TargetHUDModule() {
      super("Target HUD", ModuleCategory.MANAGER);
      this.follow = new BooleanSetting(
         "Follow Target",
         "Follow the target with TargetHUD"
      );
      this.follow.withTranslation("targethud.follow", "targethud.follow.desc");
      this.displayTime = new NumberSetting(
            "Display Time",
            "How long TargetHUD is displayed"
         )
         .range(1F, 20.0F);
      this.displayTime.withTranslation("targethud.displaytime", "targethud.displaytime.desc");
      this.particles = new BooleanSetting(
         "Particles",
         "Enable particles on hit"
      );
      this.particles.withTranslation("targethud.particles", "targethud.particles.desc");
      this.transparentBackground = new BooleanSetting(
         "Transparent Background",
         "Remove background"
      );
      this.transparentBackground.withTranslation("targethud.transparentbg", "targethud.transparentbg.desc");
      this.setState(true);
      this.follow.setValue(false);
      this.displayTime.setValue(5.0F);
      this.particles.setValue(true);
      this.transparentBackground.setValue(false);
      this.setup(new ModuleSetting[]{this.follow, this.displayTime, this.particles, this.transparentBackground});
   }

}
