package winvi.noxiumvisuals.modules.manager;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.brigadier.suggestion.Suggestion;
import com.mojang.brigadier.suggestion.Suggestions;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHudLine;
import net.minecraft.client.gui.screen.ChatInputSuggestor;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.message.ChatVisibility;
import net.minecraft.text.MutableText;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.mixins.ChatInputSuggestorMixin;
import winvi.noxiumvisuals.mixins.SuggestionWindowMixin;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.TextModuleBounds;
import winvi.noxiumvisuals.modules.visuals.TextModuleData;
import winvi.noxiumvisuals.modules.visuals.ModuleSupport;
import winvi.noxiumvisuals.modules.visuals.TextModuleSupport;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.modules.client.ThemeModule;
import winvi.noxiumvisuals.ui.gui.FontTextProvider;
import winvi.noxiumvisuals.utils.RenderRenderer;
import winvi.noxiumvisuals.utils.ClientTransformer;
import winvi.noxiumvisuals.utils.MsdfFont;
import winvi.noxiumvisuals.utils.TextureFontFactory;
import winvi.noxiumvisuals.utils.render.MsdfTextRenderer;
import winvi.noxiumvisuals.utils.RoundedRectStyle;
import winvi.noxiumvisuals.utils.RoundedRectShader;
import winvi.noxiumvisuals.utils.render.RoundedRectBatcher;
import winvi.noxiumvisuals.utils.ClientType;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.BlurRenderer;
import winvi.noxiumvisuals.utils.render.ScissorStack;
public class CustomChatModule extends Module {
      private static final Vector4f ol = new Vector4f();
      private static final float runField770 = 170.0F;
      private static final float updateField57 = 4.0F;
      private static final float tmusv = 6.0F;
      private static final float p14 = 20.0F;
      private static final float q19 = 10.0F;
      private static final float convertField32 = 11.0F;
      private static final float stopField59 = 5.0F;
      private static final float fiokl = 36.0F;
      private static final float xyovo = 7.0F;
      private static final float processField10 = 14.0F;
      private static final float dlexb = 4.0F;
      private static final float x15 = 6.6F;
      private static final float doy = 18.0F;
      private static final float dozj = 8.0F;
      private static final float dpan = 0F;
      private static final float createField280 = 1F;
      private static final float c22 = 7.0F;
      private static final float wucdw = 8.0F;
      private static final float zzfqr = 7.0F;
      private static final float dpfd = 4.0F;
      private static final int dvnpk = 5;
      private final BooleanSetting ph;
      private final BooleanSetting computeField29;
      private final NumberSetting nysnm;
      private final NumberSetting dpk;
      private final RoundedRectShader setField38;
      private final FontTextProvider dpmf;
      private final List<TextModuleData> rufdd;
      private final List<TextModuleSupport> calculateField96;
      private final Map<ChatHudLine, ModuleSupport> convertField56;
      private final RenderRenderer dpq;
      private float dprx;
      private float lkenu;
      private float parseField520;
      private float createField2;
      private boolean dpvm;
      private String qukjg;
      private int cciex;

   public CustomChatModule() {
      super(
         "Custom Chat",
         "Custom Chat",
         ModuleCategory.MANAGER
      );
      this.ph = new BooleanSetting(
            "Custom Suggestions",
            "Show custom command suggestions"
         )
         .setValue(true);
      this.computeField29 = new BooleanSetting(
            "Replace History",
            "Render custom chat history"
         )
         .setValue(false);
      this.nysnm = new NumberSetting(
            "Chat Width",
            "Width of custom chat"
         )
         .range(120, 420)
         .setValue(170.0F)
         .displayFormatter(value -> {
            return Math.round(value) + "px";
         });
      this.dpk = new NumberSetting(
            "Message Lifetime",
            "Message lifetime in chat"
         )
         .range(1, 30)
         .setValue(10.0F)
         .displayFormatter(value -> {
            return Math.round(value) + "s";
         });
      this.setField38 = new RoundedRectShader(2.0F);
      this.dpmf = new FontTextProvider();
      this.rufdd = new ArrayList<>(5);
      this.calculateField96 = new ArrayList<>();
      this.convertField56 = new IdentityHashMap<>();
      this.dpq = new ClientTransformer().setMs(360).setValue(1);
      this.dprx = -1F;
      this.lkenu = 0F;
      this.parseField520 = 0F;
      this.createField2 = 0F;
      this.dpvm = false;
      this.qukjg = "";
      this.cciex = 0;
      this.setup(new ModuleSetting[]{this.ph, this.computeField29, this.nysnm, this.dpk});
   }

      public boolean shouldReplaceHistory() {
      return this.computeField29.isValue();
   }

      public void beginOpening(TextFieldWidget chatField) {
      this.dpvm = false;
      this.parseField520 = 0F;
      this.createField2 = 0F;
      this.dpq.reset();
      this.dpq.setDirection(ClientType.FORWARDS);
      this.lkenu = 0F;
      this.dprx = -1F;
      this.rufdd.clear();
      String text = chatField != null ? chatField.getText() : "";
      this.dpmf.reset(text, TextureFontFactory.getRegular(), 7.0F);
   }

      public void applyLayout(TextFieldWidget chatField, int screenWidth, int screenHeight) {
      if (chatField != null) {
         this.removeMethod4();
         TextModuleBounds width = this.processMethod78(chatField.getText(), screenWidth, screenHeight);
         chatField.setDrawsBackground(false);
         chatField.setEditableColor(16777215);
         chatField.setUneditableColor(16777215);
         chatField.setSuggestion(null);
         chatField.setX(Math.round(width.textX()));
         chatField.setY(Math.round(width.fieldY()));
         chatField.setWidth(Math.max(20, Math.round(width.textWidth())));
      }
   }

      public void renderInputBackground(DrawContext context, TextFieldWidget chatField, int screenWidth, int screenHeight) {
      if (context != null && chatField != null) {
         this.executeMethod99(context, chatField.getText(), screenWidth, screenHeight, this.parseField520);
      }
   }

      public void renderClosing(DrawContext context, int screenWidth, int screenHeight) {
      if (context != null && this.dpvm) {
         MinecraftClient client = MinecraftClient.getInstance();
         if (!(client.currentScreen instanceof ChatScreen)) {
            this.dpq.setDirection(ClientType.BACKWARDS);
            this.createField2 = this.dpq.getOutput().floatValue();
            if (!this.dpq.isFinished(ClientType.BACKWARDS) && !(this.createField2 <= 0.025F)) {
               this.executeMethod99(context, this.qukjg, screenWidth, screenHeight, this.createField2);
               this.clbp(context, this.qukjg, this.cciex, screenWidth, screenHeight, this.createField2);
               this.uytfde(context, this.qukjg, screenWidth, screenHeight, this.createField2, this.createField2);
            } else {
               this.dpvm = false;
               this.createField2 = 0F;
            }
         }
      }
   }

      public void beginClosing(TextFieldWidget chatField, int screenWidth, int screenHeight) {
      if (chatField != null) {
         this.qukjg = chatField.getText();
         this.cciex = Math.max(0, Math.min(chatField.getCursor(), this.qukjg.length()));
         this.dpq.setDirection(ClientType.BACKWARDS);
         this.createField2 = Math.max(0.2F, this.dpq.getOutput().floatValue());
         this.dpvm = true;
      }
   }

      private void executeMethod99(DrawContext context, String text, int screenWidth, int screenHeight, float progress) {
      boolean enabled = Boolean.TRUE.equals(ColorUtils.UI_CONTEXT.get());
      ColorUtils.UI_CONTEXT.set(true);

      try {
         TextModuleBounds width2 = this.usovzt(text, screenWidth, screenHeight, progress);
         Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();
         float value = this.mj0(progress);
         this.removeMethod300(context, width2.x(), width2.y(), width2.width(), width2.height(), 10.0F, value);
         this.lghmju(
            RoundedRectStyle.create(context.getMatrices(), width2.x(), width2.y(), width2.width(), width2.height())
               .round(10.0F)
               .softness(1F)
               .thickness(0F)
               .color(ColorUtils.multAlpha(ColorUtils.getMainGuiColor(), value))
               .build()
         );
         if (text == null || text.isEmpty()) {
            this.updateMethod80(
               context,
               matrix,
               this.f20(),
               6.6F,
               ColorUtils.multAlpha(ColorUtils.getText(), 0.52F * value),
               width2.textX(),
               this.lwfxsd(width2.y(), width2.height(), 6.6F)
            );
         }
      } finally {
         ColorUtils.UI_CONTEXT.set(enabled);
         this.cmcb();
      }
   }

      public void renderInputText(DrawContext context, TextFieldWidget chatField, int screenWidth, int screenHeight) {
      if (context != null && chatField != null && !chatField.getText().isEmpty()) {
         boolean enabled = Boolean.TRUE.equals(ColorUtils.UI_CONTEXT.get());
         ColorUtils.UI_CONTEXT.set(true);

         try {
            String text = chatField.getText();
            TextModuleBounds width = this.usovzt(text, screenWidth, screenHeight, this.parseField520);
            MsdfFont textureVertexRenderer6 = TextureFontFactory.getRegular();
            if (textureVertexRenderer6 != null) {
               this.dpmf.update(text, textureVertexRenderer6, 7.0F);
            }

            Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();
            ScissorStack matrixVectorRenderer9 = NoxiumVisuals.getInstance().getScissorManager();
            float height2 = this.lwfxsd(width.y(), width.height(), 7.0F) + 0.05F;
            float width2 = textureVertexRenderer6 != null ? this.dpmf.getAnimatedWidth() : this.apseud(text, 7.0F);
            float width3 = Math.max(4.0F, Math.min(width.textWidth(), width2 + 5.0F));
            float value = this.mj0(this.parseField520);
            matrixVectorRenderer9.push(matrix, width.textX(), width.y() + 1F, width3, width.height() - 2.0F);

            try {
               this.updateMethod80(context, matrix, text, 7.0F, ColorUtils.multAlpha(ColorUtils.getText(), value), width.textX(), height2);
            } finally {
               matrixVectorRenderer9.pop();
            }

            this.createMethod1(context, chatField, width, height2, text);
         } finally {
            ColorUtils.UI_CONTEXT.set(enabled);
            this.cmcb();
         }
      }
   }

      private void clbp(DrawContext context, String text, int cursor, int screenWidth, int screenHeight, float progress) {
      if (context != null && text != null && !text.isEmpty()) {
         boolean enabled = Boolean.TRUE.equals(ColorUtils.UI_CONTEXT.get());
         ColorUtils.UI_CONTEXT.set(true);

         try {
            TextModuleBounds width = this.usovzt(text, screenWidth, screenHeight, progress);
            Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();
            ScissorStack matrixVectorRenderer9 = NoxiumVisuals.getInstance().getScissorManager();
            float height2 = this.lwfxsd(width.y(), width.height(), 7.0F) + 0.05F;
            float value = this.mj0(progress);
            matrixVectorRenderer9.push(matrix, width.textX(), width.y() + 1F, width.textWidth(), width.height() - 2.0F);

            try {
               this.updateMethod80(context, matrix, text, 7.0F, ColorUtils.multAlpha(ColorUtils.getText(), value), width.textX(), height2);
            } finally {
               matrixVectorRenderer9.pop();
            }
         } finally {
            ColorUtils.UI_CONTEXT.set(enabled);
            this.cmcb();
         }
      }
   }

      public void renderSuggestions(DrawContext context, TextFieldWidget chatField, ChatInputSuggestor suggestor, int screenWidth, int screenHeight) {
      if (context != null && chatField != null) {
         String text = chatField.getText();
         if (text != null && text.startsWith("/")) {
            List list = this.ph.isValue() ? this.transformMethod20(suggestor) : List.of();
            if (!list.isEmpty()) {
               this.rufdd.clear();
               this.rufdd.addAll(list);
            }

            float value = list.isEmpty() ? 0F : 1F;
            this.lkenu = this.lkenu + (value - this.lkenu) * 0.16F;
            if (!(this.lkenu <= 0.025F) && !this.rufdd.isEmpty()) {
               this.uytfde(context, text, screenWidth, screenHeight, this.lkenu, this.parseField520);
            } else {
               if (this.lkenu <= 0.025F) {
                  this.rufdd.clear();
                  this.lkenu = 0F;
               }
            }
         } else {
            this.rufdd.clear();
            this.lkenu = 0F;
         }
      }
   }

      public boolean isMouseOverInput(double mouseX, double mouseY, TextFieldWidget chatField, int screenWidth, int screenHeight) {
      String text = chatField != null ? chatField.getText() : "";
      TextModuleBounds width2 = this.usovzt(text, screenWidth, screenHeight, this.parseField520);
      return mouseX >= width2.x() && mouseX <= width2.x() + width2.width() && mouseY >= width2.y() && mouseY <= width2.y() + width2.height();
   }

      public void renderHistory(
      DrawContext context,
      List<ChatHudLine> messages,
      int currentTick,
      boolean focused,
      int screenWidth,
      int screenHeight,
      int visibleLineCount,
      int scrolledLines,
      int chatWidth
   ) {
      if (context != null && messages != null && !messages.isEmpty() && !this.convertMethod65()) {
         boolean enabled = Boolean.TRUE.equals(ColorUtils.UI_CONTEXT.get());
         ColorUtils.UI_CONTEXT.set(true);

         try {
            MatrixStack matrices = context.getMatrices();
            Matrix4f matrix = matrices.peek().getPositionMatrix();
            TextModuleBounds width = this.c23(screenWidth, screenHeight);
            float width2 = this.clg(screenWidth);
            float value = Math.max(4.0F, width2 - 14.0F);
            List list = this.kywzok(messages, currentTick, focused, value);
            if (!list.isEmpty()) {
               int index = Math.max(0, Math.min(scrolledLines, list.size() - 1));
               int index2 = Math.max(1, Math.min(visibleLineCount, list.size() - index));
               List list2 = list.subList(index, index + index2);
               float value2 = 0F;

               for (TextModuleSupport textModuleSupport : (Iterable<TextModuleSupport>)(Iterable<?>) (list2)) {
                  value2 = Math.max(value2, textModuleSupport.otnxbt());
               }

               float value3 = 8.0F + list2.size() * 8.0F + Math.max(0, list2.size() - 1) * 0F;
               float value4 = 4.0F;
               float value5 = width.y() - 1F - value3 - this.h14();
               this.removeMethod300(context, value4, value5, width2, value3, 8.0F, value2);
               this.lghmju(
                  RoundedRectStyle.create(matrices, value4, value5, width2, value3)
                     .round(8.0F)
                     .softness(1F)
                     .thickness(0F)
                     .color(ColorUtils.multAlpha(ColorUtils.getMainGuiColor(), 0.82F * value2))
                     .build()
               );
               ScissorStack matrixVectorRenderer9 = NoxiumVisuals.getInstance().getScissorManager();
               float value6 = value4 + 7.0F;
               float value7 = Math.max(4.0F, width2 - 14.0F);
               matrixVectorRenderer9.push(matrix, value6, value5 + 1F, value7, value3 - 2.0F);

               try {
                  for (int index3 = 0; index3 < list2.size(); index3++) {
                     TextModuleSupport textModuleSupport2 = (TextModuleSupport)list2.get(index3);
                     float value8 = value5 + 4.0F + (list2.size() - 1 - index3) * 8.0F;
                     float value9 = this.lwfxsd(value8, 8.0F, 7.0F) + 0.05F;
                     this.clph(context, textModuleSupport2.convertMethod38(), 7.0F, value6, value9, textModuleSupport2.otnxbt());
                  }

                  return;
               } finally {
                  matrixVectorRenderer9.pop();
               }
            }
         } finally {
            ColorUtils.UI_CONTEXT.set(enabled);
            this.cmcb();
         }
      }
   }

      private TextModuleBounds c23(int screenWidth, int screenHeight) {
      float value = this.dprx;

      TextModuleBounds textModuleBounds;
      try {
         textModuleBounds = this.usovzt("", screenWidth, screenHeight, 1F);
      } finally {
         this.dprx = value;
      }

      return textModuleBounds;
   }

      private List<TextModuleSupport> kywzok(List<ChatHudLine> messages, int currentTick, boolean focused, float contentWidth) {
      MinecraftClient client = MinecraftClient.getInstance();
      int width = Math.max(1, Math.round(contentWidth / this.clyo(7.0F)));
      this.calculateField96.clear();
      if (this.convertField56.size() > messages.size() + 32) {
         this.convertField56.clear();
      }

      for (ChatHudLine chatHudLine : messages) {
         if (chatHudLine != null && chatHudLine.content() != null) {
            float value = this.getMethod46(chatHudLine, currentTick, focused);
            if (!(value <= 0.025F)) {
               ModuleSupport moduleSupport = this.convertField56.get(chatHudLine);
               if (moduleSupport == null || moduleSupport.wgxkv != width) {
                  List list = client.textRenderer.wrapLines(chatHudLine.content(), width);
                  ArrayList arrayList = new ArrayList(Math.max(1, list.size()));
                  if (list.isEmpty()) {
                     arrayList.add(new TextModuleSupport(chatHudLine.content().asOrderedText()));
                  } else {
                     for (OrderedText orderedText : (Iterable<OrderedText>)(Iterable<?>) (list)) {
                        arrayList.add(new TextModuleSupport(orderedText));
                     }
                  }

                  moduleSupport = new ModuleSupport(width, arrayList);
                  this.convertField56.put(chatHudLine, moduleSupport);
               }

               for (TextModuleSupport textModuleSupport : moduleSupport.parseField9) {
                  textModuleSupport.executeField550 = value;
                  this.calculateField96.add(textModuleSupport);
               }
            }
         }
      }

      return this.calculateField96;
   }

      private TextModuleBounds processMethod78(String text, int screenWidth, int screenHeight) {
      return this.usovzt(text, screenWidth, screenHeight, this.parseField520);
   }

      private TextModuleBounds usovzt(String text, int screenWidth, int screenHeight, float progress) {
      float width = Math.max(120.0F, screenWidth - 8.0F);
      float width2 = Math.min(this.clg(screenWidth), width);
      float value = this.apseud(text, 7.0F);
      float value2 = Math.min(width, Math.max(width2, value + 36.0F));
      if (this.dprx < 0F) {
         this.dprx = value2;
      }

      this.dprx = this.dprx + (value2 - this.dprx) * 0.24F;
      float value3 = Math.min(width, Math.max(width2, this.dprx));
      float value4 = 4.0F;
      float height = screenHeight - 20.0F - 6.0F;
      float value5 = this.mk0(progress);
      float value6 = height + 18.0F * (1F - value5);
      float value7 = Math.max(20.0F, value3 - 22.0F);
      return new TextModuleBounds(value4, value6, value3, 20.0F, value4 + 11.0F, value6 + 5.0F, value7);
   }

      private float clg(int screenWidth) {
      float width = Math.max(120.0F, screenWidth - 8.0F);
      return Math.max(120.0F, Math.min(width, this.nysnm.getValue()));
   }

      private float h14() {
      return !this.rufdd.isEmpty() && !(this.lkenu <= 0.025F) ? this.mj0(this.lkenu) * 18.0F : 0F;
   }

      private void uytfde(DrawContext context, String text, int screenWidth, int screenHeight, float animationProgress, float parentProgress) {
      if (context != null && !this.rufdd.isEmpty()) {
         boolean enabled = Boolean.TRUE.equals(ColorUtils.UI_CONTEXT.get());
         ColorUtils.UI_CONTEXT.set(true);

         try {
            TextModuleBounds width2 = this.usovzt(text, screenWidth, screenHeight, parentProgress);
            Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();
            float value = this.mj0(animationProgress);
            float value2 = value * this.mj0(parentProgress);
            float x2 = width2.x();
            float value3 = width2.y() - 14.0F - 4.0F;
            float value4 = value3 + (1F - value) * 6.0F;
            float width3 = Math.min(screenWidth - 4.0F, width2.x() + width2.width());

            for (TextModuleData textModuleData : this.rufdd) {
               float value5 = this.apseud(textModuleData.text(), 6.6F);
               float value6 = value5 + 13.0F;
               if (x2 + value6 > width3) {
                  break;
               }

               this.removeMethod300(context, x2, value4, value6, 14.0F, 4.0F, value2);
               this.lghmju(
                  RoundedRectStyle.create(context.getMatrices(), x2, value4, value6, 14.0)
                     .round(4.0F)
                     .softness(1F)
                     .thickness(0F)
                     .color(ColorUtils.multAlpha(ColorUtils.getMainGuiColor(), textModuleData.selected() ? value2 : 0.82F * value2))
                     .build()
               );
               this.updateMethod80(
                  context,
                  matrix,
                  textModuleData.text(),
                  6.6F,
                  ColorUtils.multAlpha(textModuleData.selected() ? ColorUtils.getText() : ColorUtils.getClientColor(), 0.9F * value2),
                  x2 + 6.5F,
                  this.lwfxsd(value4, 14.0F, 6.6F) + 0.1F
               );
               x2 += value6 + 4.0F;
            }
         } finally {
            ColorUtils.UI_CONTEXT.set(enabled);
            this.cmcb();
         }
      }
   }

      private List<TextModuleData> transformMethod20(ChatInputSuggestor suggestor) {
      ArrayList arrayList = new ArrayList(5);
      if (suggestor == null) {
         return arrayList;
      } else {
         try {
            ChatInputSuggestorMixin chatInputSuggestorMixin = (ChatInputSuggestorMixin)suggestor;
            if (chatInputSuggestorMixin.noxiumvisual$getWindow() instanceof SuggestionWindowMixin suggestionWindowMixin) {
               List list = suggestionWindowMixin.noxiumvisual$getSuggestions();
               int index = Math.max(0, suggestionWindowMixin.noxiumvisual$getInWindowIndex());
               int index2 = suggestionWindowMixin.noxiumvisual$getSelection();
               int index3 = Math.max(1, Math.min(chatInputSuggestorMixin.noxiumvisual$getMaxSuggestionSize(), 5));
               int index4 = Math.min(list.size(), index + index3);

               for (int index5 = index; index5 < index4; index5++) {
                  Suggestion suggestion = (Suggestion)list.get(index5);
                  if (suggestion != null && !suggestion.getText().isEmpty()) {
                     arrayList.add(new TextModuleData(suggestion.getText(), index5 == index2));
                  }
               }

               return arrayList;
            }

            CompletableFuture completableFuture = chatInputSuggestorMixin.noxiumvisual$getPendingSuggestions();
            if (completableFuture != null && completableFuture.isDone()) {
               Suggestions suggestions = (Suggestions)completableFuture.join();
               if (suggestions != null && !suggestions.isEmpty()) {
                  int index6 = Math.min(suggestions.getList().size(), 5);

                  for (int index7 = 0; index7 < index6; index7++) {
                     Suggestion suggestion2 = (Suggestion)suggestions.getList().get(index7);
                     if (suggestion2 != null && !suggestion2.getText().isEmpty()) {
                        arrayList.add(new TextModuleData(suggestion2.getText(), index7 == 0));
                     }
                  }
               }
            }
         } catch (Exception exception) {
         }

         return arrayList;
      }
   }

      private float apseud(String text, float size) {
      return this.lr0(text, Style.EMPTY, size);
   }

      private float lwfxsd(float y, float height, float size) {
      MsdfFont textureVertexRenderer6 = TextureFontFactory.getRegular();
      float height2 = textureVertexRenderer6 != null ? MsdfTextRenderer.getHeight(textureVertexRenderer6, size) : this.manageMethod95(size);
      return y + (height - height2) * 0.5F + 0.35F;
   }

      private void updateMethod80(DrawContext context, Matrix4f matrix, String text, float size, int color, float x, float y) {
      if (context != null && text != null && !text.isEmpty()) {
         this.clsa(context, matrix, text, Style.EMPTY.withColor(color & 16777215), size, color, x, y);
      }
   }

      private void createMethod1(DrawContext context, TextFieldWidget chatField, TextModuleBounds layout, float textY, String text) {
      if (this.parseMethod60()) {
         int index = Math.max(0, Math.min(chatField.getCursor(), text.length()));
         float value = layout.textX() + this.apseud(text.substring(0, index), 7.0F) + 0.8F;
         if (!(value > layout.textX() + layout.textWidth() + 1F)) {
            this.lghmju(
               RoundedRectStyle.create(context.getMatrices(), value, textY - 1.3F, 0.75, 7.400000095367432)
                  .round(0.4F)
                  .softness(0.6F)
                  .thickness(0F)
                  .color(ColorUtils.multAlpha(ColorUtils.getText(), 0.9F * this.mj0(this.parseField520)))
                  .build()
            );
         }
      }
   }

      private float controlMethod97(OrderedText orderedText, float size) {
      if (orderedText == null) {
         return 0F;
      } else {
         float[] floatArray = new float[]{0F};
         StringBuilder stringBuilder = new StringBuilder();
         Style[] styleArray = new Style[]{null};
         orderedText.accept((index, style, codePoint) -> {
            Style style2 = style == null ? Style.EMPTY : style;
            if (styleArray[0] != null && !styleArray[0].equals(style2)) {
               floatArray[0] += this.lr0(stringBuilder.toString(), styleArray[0], size);
               stringBuilder.setLength(0);
            }

            styleArray[0] = style2;
            stringBuilder.appendCodePoint(codePoint);
            return true;
         });
         if (!stringBuilder.isEmpty()) {
            floatArray[0] += this.lr0(stringBuilder.toString(), styleArray[0], size);
         }

         return floatArray[0];
      }
   }

      private void clph(DrawContext context, OrderedText orderedText, float size, float x, float y, float alpha) {
      if (context != null && orderedText != null) {
         float[] floatArray = new float[]{x};
         StringBuilder stringBuilder = new StringBuilder();
         Style[] styleArray = new Style[]{null};
         orderedText.accept((index, style, codePoint) -> {
            Style style2 = style == null ? Style.EMPTY : style;
            if (styleArray[0] != null && !styleArray[0].equals(style2)) {
               int text = ColorUtils.multAlpha(this.gactar(styleArray[0], ColorUtils.getText()), alpha);
               floatArray[0] = this.clsa(context, context.getMatrices().peek().getPositionMatrix(), stringBuilder.toString(), styleArray[0], size, text, floatArray[0], y);
               stringBuilder.setLength(0);
            }

            styleArray[0] = style2;
            stringBuilder.appendCodePoint(codePoint);
            return true;
         });
         if (!stringBuilder.isEmpty()) {
            int text2 = ColorUtils.multAlpha(this.gactar(styleArray[0], ColorUtils.getText()), alpha);
            this.clsa(context, context.getMatrices().peek().getPositionMatrix(), stringBuilder.toString(), styleArray[0], size, text2, floatArray[0], y);
         }
      }
   }

      private int gactar(Style style, int fallback) {
      return style != null && style.getColor() != null ? 0xFF000000 | style.getColor().getRgb() : fallback;
   }

      private float lr0(String text, Style style, float size) {
      if (text != null && !text.isEmpty()) {
         MsdfFont textureVertexRenderer6 = TextureFontFactory.getRegular();
         MinecraftClient client = MinecraftClient.getInstance();
         float value = 0F;
         int index = 0;
         Boolean boolean2 = null;
         int index2 = 0;

         while (index2 < text.length()) {
            int index3 = text.codePointAt(index2);
            boolean enabled = this.calculateMethod26(style, textureVertexRenderer6, index3);
            if (boolean2 == null) {
               boolean2 = enabled;
            } else if (boolean2 != enabled) {
               String text2 = text.substring(index, index2);
               value += boolean2 ? MsdfTextRenderer.getWidth(textureVertexRenderer6, size, text2) : client.textRenderer.getWidth(text2) * this.clyo(size);
               index = index2;
               boolean2 = enabled;
            }

            index2 += Character.charCount(index3);
         }

         if (boolean2 != null && index < text.length()) {
            String text3 = text.substring(index);
            value += boolean2 ? MsdfTextRenderer.getWidth(textureVertexRenderer6, size, text3) : client.textRenderer.getWidth(text3) * this.clyo(size);
         }

         return value;
      } else {
         return 0F;
      }
   }

      private float clsa(DrawContext context, Matrix4f matrix, String text, Style style, float size, int color, float x, float y) {
      if (context != null && text != null && !text.isEmpty()) {
         MsdfFont textureVertexRenderer6 = TextureFontFactory.getRegular();
         MinecraftClient client = MinecraftClient.getInstance();
         float value = x;
         int index = 0;
         Boolean boolean2 = null;
         int index2 = 0;

         while (index2 < text.length()) {
            int index3 = text.codePointAt(index2);
            boolean enabled = this.calculateMethod26(style, textureVertexRenderer6, index3);
            if (boolean2 == null) {
               boolean2 = enabled;
            } else if (boolean2 != enabled) {
               value = this.initMethod110(context, matrix, text.substring(index, index2), style, boolean2, textureVertexRenderer6, size, color, value, y);
               index = index2;
               boolean2 = enabled;
            }

            index2 += Character.charCount(index3);
         }

         if (boolean2 != null && index < text.length()) {
            value = this.initMethod110(context, matrix, text.substring(index), style, boolean2, textureVertexRenderer6, size, color, value, y);
         }

         return value;
      } else {
         return x;
      }
   }

      private float initMethod110(
      DrawContext context, Matrix4f matrix, String text, Style style, boolean useMsdf, MsdfFont font, float size, int color, float x, float y
   ) {
      if (text == null || text.isEmpty()) {
         return x;
      } else if (useMsdf && font != null) {
         MsdfTextRenderer.renderText(font, text, size, color, matrix, x, y, 0F);
         return x + MsdfTextRenderer.getWidth(font, size, text);
      } else {
         MutableText textComponent = Text.literal(text).setStyle(this.fiagxl(style, color));
         this.lx0(context, textComponent, x, y, color, size);
         return x + MinecraftClient.getInstance().textRenderer.getWidth(textComponent) * this.clyo(size);
      }
   }

      private Style fiagxl(Style source, int color) {
      Style style = source == null ? Style.EMPTY : source;
      return style.withColor(TextColor.fromRgb(color & 16777215));
   }

      private boolean calculateMethod26(Style style, MsdfFont font, int codePoint) {
      return font != null && this.w20(style) ? Character.isWhitespace(codePoint) || Character.isISOControl(codePoint) || font.hasGlyph(codePoint) : false;
   }

      private boolean w20(Style style) {
      return style == null || Style.DEFAULT_FONT_ID.equals(style.getFont());
   }

      private void lx0(DrawContext context, Text text, float x, float y, int color, float size) {
      if (context != null && text != null) {
         float value = this.clyo(size);
         context.getMatrices().push();
         context.getMatrices().translate(x, y, 0F);
         context.getMatrices().scale(value, value, 1F);
         context.drawText(MinecraftClient.getInstance().textRenderer, text, 0, 0, color, false);
         context.getMatrices().pop();
      }
   }

      private float clyo(float size) {
      int index = Math.max(1, 9);
      return Math.max(0.5F, size / index);
   }

      private float manageMethod95(float size) {
      return 9.0F * this.clyo(size);
   }

      private float getMethod46(ChatHudLine line, int currentTick, boolean focused) {
      if (focused) {
         return 1F;
      } else {
         int index = currentTick - line.creationTick();
         int index2 = Math.max(1, Math.round(this.dpk.getValue() * 20.0F));
         if (index >= index2) {
            return 0F;
         } else {
            float value = 1F - (float)index / index2;
            value = Math.max(0F, Math.min(1F, value));
            return value * value * 0.9F;
         }
      }
   }

      private boolean convertMethod65() {
      MinecraftClient client = MinecraftClient.getInstance();
      return client.options.getChatVisibility().getValue() == ChatVisibility.HIDDEN;
   }

      private void cmcb() {
      RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
      RenderSystem.defaultBlendFunc();
   }

      private void lghmju(RoundedRectStyle shape) {
      RoundedRectBatcher.flushRoundedRects();
      this.setField38.render(shape);
      RoundedRectBatcher.flushRoundedRects();
   }

      private void removeMethod4() {
      this.dpvm = false;
      this.dpq.setDirection(ClientType.FORWARDS);
      this.parseField520 = this.dpq.getOutput().floatValue();
   }

      private String f20() {
      int index = (int)(System.currentTimeMillis() / 360L % 3L) + 1;
      return ".".repeat(index);
   }

      private boolean parseMethod60() {
      return System.currentTimeMillis() / 500L % 2L == 0L;
   }

      private void removeMethod300(DrawContext context, float x, float y, float width, float height, float round, float alpha) {
      if (this.rgkezv()) {
         try {
            ol.set(round, round, round, round);
            RoundedRectBatcher.flushRoundedRects();
            BlurRenderer.drawBlur(
               context.getMatrices(), x, y, width, height, 45.0F, ol, 0F, 2.0F, ColorUtils.replAlpha(-1, Math.round(255.0F * alpha))
            );
            RoundedRectBatcher.flushRoundedRects();
         } catch (Exception exception) {
         }
      }
   }

      private boolean rgkezv() {
      try {
         if (NoxiumVisuals.getInstance() != null && NoxiumVisuals.getInstance().getModuleProvider() != null) {
            ThemeModule themeModule = NoxiumVisuals.getInstance().getModuleProvider().get(ThemeModule.class);
            return themeModule == null || themeModule.getEnableBlur().isValue();
         } else {
            return true;
         }
      } catch (Exception exception) {
         return true;
      }
   }

      private float mj0(float value) {
      float value2 = Math.max(0F, Math.min(1F, value));
      return value2 * value2 * (3.0F - 2.0F * value2);
   }

      private float mk0(float value) {
      return Math.max(-0.25F, Math.min(1.18F, value));
   }

   static {
      int index = 0;
   }
}
