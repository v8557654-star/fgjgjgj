package winvi.noxiumvisuals.modules.manager;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.List;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class CoordinatesInfoModule extends Module {
      public static final String SECTION_XYZ = "XYZ";
      public static final String SECTION_BPS = "BPS";
      private final BooleanSetting dojn;
      private final MultiSelectSetting k9;

   public CoordinatesInfoModule() {
      super("Coordinates Info", ModuleCategory.MANAGER);
      this.dojn = new BooleanSetting(
            "Transparent Background",
            "Remove background"
         )
         .setValue(false);
      this.k9 = new MultiSelectSetting(
            "Sections",
            "Choose displayed coordinate blocks"
         )
         .value(
            "XYZ", "BPS"
         )
         .selected(
            "XYZ", "BPS"
         );
      this.dojn.withTranslation("hud.common.transparentbg", "hud.common.transparentbg.desc");
      this.k9.withTranslation("coordinates.sections", "coordinates.sections.desc");
      this.k9.onChange(selected -> {
         this.ckz();
      });
      this.setup(new ModuleSetting[]{this.dojn, this.k9});
      this.setState(true);
   }

      public boolean isXyzSectionEnabled() {
      this.ckz();
      return this.k9.isSelected("XYZ");
   }

      public boolean isBpsSectionEnabled() {
      this.ckz();
      return this.k9.isSelected("BPS");
   }

      private void ckz() {
      boolean enabled = this.k9.isSelected("XYZ")
         || this.k9.isSelected("BPS");
      if (!enabled) {
         this.k9.setSelected(new ArrayList<>(List.of("XYZ")));
      }
   }

      public BooleanSetting getTransparentBackground() {
      return this.dojn;
   }

      public MultiSelectSetting getSections() {
      return this.k9;
   }

   static {
      int index = 0;
   }
}
