package winvi.noxiumvisuals.modules.manager;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class HotBarModule extends Module {
      private final BooleanSetting ijccz;
      private final BooleanSetting jjqoi;
      private final ChoiceSetting qa;

   public HotBarModule() {
      super("HotBar", ModuleCategory.MANAGER);
      this.ijccz = new BooleanSetting(
            "Transparent Background",
            "Remove background"
         )
         .setValue(false);
      this.jjqoi = new BooleanSetting(
            "Custom Overlay",
            "Use rectangles instead of icons for HP/hunger/armor"
         )
         .setValue(false);
      this.qa = new ChoiceSetting(
            "Overlay Style",
            "Custom overlay render style"
         )
         .value(
            "Bars",
            "Squares"
         )
         .selected("Bars")
         .visible(() -> {
            return this.jjqoi.isValue();
         });
      this.ijccz.withTranslation("hud.common.transparentbg", "hud.common.transparentbg.desc");
      this.jjqoi.withTranslation("hotbar.customoverlay", "hotbar.customoverlay.desc");
      this.qa.withTranslation("hotbar.customoverlay.style", "hotbar.customoverlay.style.desc");
      this.setup(new ModuleSetting[]{this.ijccz, this.jjqoi, this.qa});
      this.setState(true);
   }

      public BooleanSetting getTransparentBackground() {
      return this.ijccz;
   }

      public BooleanSetting getCustomOverlay() {
      return this.jjqoi;
   }

      public ChoiceSetting getCustomOverlayStyle() {
      return this.qa;
   }

}
