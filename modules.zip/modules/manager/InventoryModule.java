package winvi.noxiumvisuals.modules.manager;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class InventoryModule extends Module {
      private final BooleanSetting setField64;
      private final BooleanSetting dqcd;

   public InventoryModule() {
      super("Inventory", ModuleCategory.MANAGER);
      this.setField64 = new BooleanSetting(
            "Transparent Background",
            "Remove background"
         )
         .setValue(false);
      this.dqcd = new BooleanSetting(
            "Hide Header",
            "Hide title and icon"
         )
         .setValue(false);
      this.setField64.withTranslation("hud.common.transparentbg", "hud.common.transparentbg.desc");
      this.dqcd.withTranslation("inventory.hideheader", "inventory.hideheader.desc");
      this.setup(new ModuleSetting[]{this.setField64, this.dqcd});
      this.setState(true);
   }

      public BooleanSetting getTransparentBackground() {
      return this.setField64;
   }

      public BooleanSetting getHideHeader() {
      return this.dqcd;
   }

   static {
      int index = 0;
   }
}
