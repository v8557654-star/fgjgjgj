package winvi.noxiumvisuals.modules.manager;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class HotkeysModule extends Module {
      private final BooleanSetting dqdg;
      private final BooleanSetting createField96;

   public HotkeysModule() {
      super("Hotkeys", ModuleCategory.MANAGER);
      this.dqdg = new BooleanSetting(
            "Transparent Background",
            "Remove background"
         )
         .setValue(false);
      this.createField96 = new BooleanSetting(
            "Show All Hotkeys",
            "Display all bound modules instead of only active ones"
         )
         .setValue(false);
      this.dqdg.withTranslation("hud.common.transparentbg", "hud.common.transparentbg.desc");
      this.createField96.withTranslation("hud.keybinds.showall", "hud.keybinds.showall.desc");
      this.setup(new ModuleSetting[]{this.dqdg, this.createField96});
      this.setState(true);
   }

      public BooleanSetting getTransparentBackground() {
      return this.dqdg;
   }

      public BooleanSetting getShowAllBinds() {
      return this.createField96;
   }

}
