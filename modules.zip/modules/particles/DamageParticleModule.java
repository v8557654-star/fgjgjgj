package winvi.noxiumvisuals.modules.particles;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.DamageIndicatorParticle;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.TextSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.ParticleManager;
import winvi.noxiumvisuals.utils.render.RenderMath;
public class DamageParticleModule extends Module {
      public static final Random transformField67 = new Random();
      public String[] drc;
      public final BooleanSetting drd;
      public final ChoiceSetting ippxi;
      public final ChoiceSetting getField70;
      public final ChoiceSetting dsfzj;
      public final BooleanSetting manageField80;
      public final TextSetting eiyov;
      public final NumberSetting runField17;
      public final NumberSetting lvmsk;
      public final NumberSetting skxal;
      public final NumberSetting m19;
      public final NumberSetting validateField94;
      public final SettingGroup niflg;
      public final SettingGroup p16;
      public static final List<DamageIndicatorParticle> particles = new ArrayList<>();

      public static DamageParticleModule getInstance() {
      return ModuleLookup.get(DamageParticleModule.class);
   }

   public DamageParticleModule() {
      super("Damage Particle", ModuleCategory.PARTICLES);
      this.drc = new String[0];
      this.ippxi = new ChoiceSetting(
            "Mode",
            "Particle mode"
         )
         .value(
            "Damage",
            "Text",
            "Both"
         )
         .selected("Damage");
      this.ippxi.withTranslation("damageparticle.mode", "damageparticle.mode.desc");
      this.drd = new BooleanSetting(
            "Crit Only",
            "Only show on critical hits"
         )
         .setValue(false);
      this.drd.withTranslation("damageparticle.critonly", "damageparticle.critonly.desc");
      this.manageField80 = new BooleanSetting(
            "Vanilla Font",
            "Use vanilla Minecraft font"
         )
         .setValue(true);
      this.manageField80.withTranslation("damageparticle.vanillafont", "damageparticle.vanillafont.desc");
      this.eiyov = new TextSetting(
            "Custom Text",
            "Enter words separated by spaces"
         )
         .setText("");
      this.eiyov.withTranslation("damageparticle.customtext", "damageparticle.customtext.desc");
      this.getField70 = new ChoiceSetting(
            "Disappear",
            "Disappear mode"
         )
         .value(
            "ALPHA",
            "SCALE"
         )
         .selected("ALPHA");
      this.getField70.withTranslation("damageparticle.disappear", "damageparticle.disappear.desc");
      this.dsfzj = new ChoiceSetting(
            "Spawn Position",
            "Where to spawn text"
         )
         .value(
            "Head",
            "Body",
            "Legs"
         )
         .selected("Head");
      this.dsfzj.withTranslation("damageparticle.spawnposition", "damageparticle.spawnposition.desc");
      this.runField17 = new NumberSetting(
            "Count",
            "Number of particles per hit (Text mode)"
         )
         .setValue(3.0F)
         .range(1F, 10.0F);
      this.runField17.withTranslation("damageparticle.count", "damageparticle.count.desc");
      this.lvmsk = new NumberSetting(
            "Render Time",
            "How long text lasts"
         )
         .setValue(2.0F)
         .range(0.5F, 5.0F);
      this.lvmsk.withTranslation("damageparticle.rendertime", "damageparticle.rendertime.desc");
      this.skxal = new NumberSetting(
            "Scale",
            "Text size"
         )
         .setValue(1F)
         .range(0.5F, 3.0F);
      this.skxal.withTranslation("damageparticle.scale", "damageparticle.scale.desc");
      this.m19 = new NumberSetting(
            "Speed",
            "Movement speed"
         )
         .setValue(1F)
         .range(0.5F, 6.0F);
      this.m19.withTranslation("damageparticle.speed", "damageparticle.speed.desc");
      this.validateField94 = new NumberSetting(
            "Glow Alpha",
            "Glow texture transparency"
         )
         .setValue(0.12F)
         .range(0F, 1F);
      this.validateField94.withTranslation("damageparticle.glowalpha", "damageparticle.glowalpha.desc");
      this.niflg = new SettingGroup(
            "Damage Settings",
            "Damage particle settings"
         )
         .settings(this.ippxi, this.runField17, this.lvmsk, this.skxal, this.m19, this.dsfzj, this.eiyov)
         .setValue(true);
      this.niflg.withTranslation("damageparticle.damagesettings", "damageparticle.damagesettings.desc");
      this.p16 = new SettingGroup(
            "Advanced Settings",
            "Advanced settings"
         )
         .settings(this.drd, this.manageField80, this.getField70, this.validateField94)
         .setValue(false);
      this.p16.withTranslation("damageparticle.advancedsettings", "damageparticle.advancedsettings.desc");
      this.runField17.visible(() -> {
         return !this.ippxi.getSelected().equals("Damage");
      });
      this.eiyov.visible(() -> {
         return !this.ippxi.getSelected().equals("Damage");
      });
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{this.niflg, this.p16});
   }

      @Override
   public void deactivate() {
      super.deactivate();
      particles.clear();
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState()) {
         this.render(event.getStack(), event.getPartialTicks());
      }
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (MinecraftClient.getInstance().player != null && this.isState()) {
         long timestamp = System.currentTimeMillis();
         ParticleManager.updateParticlesInPlace(particles, timestamp);
      }
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         for (DamageIndicatorParticle textureMatrixRenderer3 : particles) {
            textureMatrixRenderer3.render(matrixStack, tickDelta);
         }
      }
   }

      public static void onDamage(LivingEntity target, float damage, boolean isCrit) {
      DamageParticleModule damageParticleModule = getInstance();
      if (damageParticleModule != null && damageParticleModule.isState()) {
         if (!damageParticleModule.drd.isValue() || isCrit) {
            String text = damageParticleModule.ippxi.getSelected();
            String text2 = damageParticleModule.dsfzj.getSelected();

            float height = switch (text2) {
               case "Head" -> target.getHeight() + 0.5F;
               case "Body" -> target.getHeight() / 2.0F;
               case "Legs" -> 0.3F;
               default -> target.getHeight() + 0.5F;
            };
            if (text.equals("Damage")
               || text.equals("Both")) {
               List list = particles;
               Objects.requireNonNull(damageParticleModule);
               list.add(
                  new DamageIndicatorParticle(damageParticleModule, (float)target.getX(), (float)target.getY() + height, (float)target.getZ(), damage, false)
               );
            }

            if (text.equals("Text")
               || text.equals("Both")) {
               damageParticleModule.cmq();
               int index = (int)damageParticleModule.runField17.getValue();

               for (int index2 = 0; index2 < index; index2++) {
                  float value = RenderMath.random(-0.3F, 0.3F);
                  float value2 = RenderMath.random(-0.2F, 0.2F);
                  float value3 = RenderMath.random(-0.3F, 0.3F);
                  List list2 = particles;
                  Objects.requireNonNull(damageParticleModule);
                  list2.add(
                     new DamageIndicatorParticle(
                        damageParticleModule, (float)target.getX() + value, (float)target.getY() + height + value2, (float)target.getZ() + value3, 0F, true
                     )
                  );
               }
            }
         }
      }
   }

      public void cmq() {
      String text = this.eiyov.getText().trim();
      if (!text.isEmpty()) {
         this.drc = text.split("\\s+");
      } else {
         this.drc = new String[0];
      }
   }

   static {
      int index = 0;
   }
}
