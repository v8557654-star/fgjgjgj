package winvi.noxiumvisuals.modules.particles;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.MatrixColorRenderer;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.ParticleManager;
import winvi.noxiumvisuals.utils.render.RenderMath;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public class ExperienceParticleModule extends Module {
      public static final int VANILLA_EXPERIENCE_SPLASH_COLOR = -13083194;
      public static final long isField27 = 2000L;
      public static final long drrp = 1200L;
      public static final double srymu = 4.0;
      public static final long tiyhk = 6000L;
      public static final double xfbch = 36.0;
      public static final List<MatrixColorRenderer> runField351 = new ArrayList<>();
      public static final List<Identifier> computeField47 = new ArrayList<>();
      public static final Random createField8 = new Random();
      public static Vec3d mutck;
      public static long ltdvo;
      public static long handleField45;
      public final NumberSetting deleteField16;
      public final NumberSetting updateField38;
      public final NumberSetting initField63;
      public final MultiSelectSetting dse;
      public final BooleanSetting dsf;
      public final ChoiceSetting handleField751;
      public final ChoiceSetting removeField300;
      public final SettingGroup si0;
      public final SettingGroup nuhoq;
      public final SettingGroup sk0;

   public ExperienceParticleModule() {
      super("Experience Particle", ModuleCategory.PARTICLES);
      this.deleteField16 = new NumberSetting(
            "Particles Count",
            "Number of experience particles"
         )
         .setValue(15.0F)
         .range(5.0F, 25.0F);
      this.updateField38 = new NumberSetting(
            "Particles Speed",
            "Experience particle movement speed"
         )
         .setValue(3.0F)
         .range(1F, 10.0F);
      this.initField63 = new NumberSetting(
            "Particles Scale",
            "Experience particle size"
         )
         .setValue(4.0F)
         .range(1F, 5.0F);
      this.dse = new MultiSelectSetting(
            "Texture Types",
            "Select particle texture types"
         )
         .value(ParticleTextures.getAvailableParticleTextureNames())
         .selected(
            "Bloom",
            "Star"
         );
      this.dsf = new BooleanSetting(
            "Default Colors",
            "Use experience green-turquoise colors"
         )
         .setValue(true);
      this.handleField751 = new ChoiceSetting(
            "Physic",
            "Particle physics"
         )
         .value(
            "FLY",
            "BOUNCE"
         )
         .selected("FLY");
      this.removeField300 = new ChoiceSetting(
            "Disappear",
            "How particles disappear"
         )
         .value(
            "ALPHA",
            "SCALE"
         )
         .selected("ALPHA");
      this.si0 = new SettingGroup(
            "Experience Settings",
            "Experience particle settings"
         )
         .settings(this.deleteField16, this.updateField38, this.initField63)
         .setValue(true);
      this.nuhoq = new SettingGroup(
            "Advanced Settings",
            "Advanced particle settings"
         )
         .settings(this.handleField751, this.removeField300, this.dsf)
         .setValue(false);
      this.sk0 = new SettingGroup(
            "Texture Settings",
            "Particle texture settings"
         )
         .settings(this.dse)
         .setValue(true);
      this.showVisualColorSettings(() -> {
         return !this.dsf.isValue();
      });
      this.setup(new ModuleSetting[]{this.si0, this.nuhoq, this.sk0});
   }

      @Override
   public void deactivate() {
      super.deactivate();
      runField351.clear();
      mutck = null;
      ltdvo = 0L;
      handleField45 = 0L;
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null && this.isState()) {
         xnfpfv();
         ParticleManager.updateParticlesInPlace(runField351, System.currentTimeMillis());
      }
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null && this.isState()) {
         vwhmhn(event.getStack(), event.getPartialTicks());
      }
   }

      public static boolean shouldReplaceVanilla(int eventId, int data) {
      ExperienceParticleModule experienceParticleModule = formatMethod29();
      return experienceParticleModule != null && experienceParticleModule.isState() && eventId == 2002 && data == -13083194;
   }

      public static boolean shouldSuppressVanillaParticle(ParticleEffect effect, double x, double y, double z) {
      ExperienceParticleModule experienceParticleModule = formatMethod29();
      if (experienceParticleModule != null && experienceParticleModule.isState()) {
         if (mutck != null && System.currentTimeMillis() <= ltdvo) {
            double x2 = x - mutck.x;
            double y2 = y - mutck.y;
            double z2 = z - mutck.z;
            if (x2 * x2 + y2 * y2 + z2 * z2 > 4.0) {
               return false;
            } else {
               return effect instanceof ItemStackParticleEffect itemStackParticleEffect
                  ? itemStackParticleEffect.getItemStack().isOf(Items.EXPERIENCE_BOTTLE) || itemStackParticleEffect.getItemStack().isOf(Items.SPLASH_POTION)
                  : effect.getType() == ParticleTypes.EFFECT || effect.getType() == ParticleTypes.INSTANT_EFFECT;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

      public static boolean shouldSuppressVanillaParticleRendering() {
      ExperienceParticleModule experienceParticleModule = formatMethod29();
      return experienceParticleModule != null && experienceParticleModule.isState() && mutck != null && System.currentTimeMillis() <= ltdvo;
   }

      public static boolean shouldSuppressVanillaExperienceOrb(double x, double y, double z) {
      ExperienceParticleModule experienceParticleModule = formatMethod29();
      if (experienceParticleModule != null && experienceParticleModule.isState()) {
         if (mutck != null && System.currentTimeMillis() <= handleField45) {
            double x2 = x - mutck.x;
            double y2 = y - mutck.y;
            double z2 = z - mutck.z;
            return x2 * x2 + y2 * y2 + z2 * z2 <= 36.0;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

      public static void onExperienceBottleSplash(Vec3d position) {
      ExperienceParticleModule experienceParticleModule = formatMethod29();
      if (experienceParticleModule != null && experienceParticleModule.isState()) {
         mutck = position;
         ltdvo = System.currentTimeMillis() + 1200L;
         handleField45 = System.currentTimeMillis() + 6000L;
         xnfpfv();
         int index = (int)experienceParticleModule.deleteField16.getValue();

         for (int index2 = 0; index2 < index; index2++) {
            float value = RenderMath.random(-0.12F, 0.12F);
            float value2 = RenderMath.random(0F, 0.18F);
            float value3 = RenderMath.random(-0.12F, 0.12F);
            runField351.add(
               new MatrixColorRenderer(
                  (float)position.x + value,
                  (float)position.y + value2,
                  (float)position.z + value3,
                  manageMethod35(0F, 360.0F),
                  manageMethod35(25.0F, 110.0F),
                  experienceParticleModule
               )
            );
         }
      }
   }

      public static ExperienceParticleModule formatMethod29() {
      return NoxiumVisuals.getInstance().getModuleProvider().get(ExperienceParticleModule.class);
   }

      public static void vwhmhn(MatrixStack matrixStack, float tickDelta) {
      for (MatrixColorRenderer matrixColorRenderer : runField351) {
         matrixColorRenderer.render(matrixStack, tickDelta);
      }
   }

      public static void xnfpfv() {
      computeField47.clear();
      ExperienceParticleModule experienceParticleModule = formatMethod29();
      if (experienceParticleModule != null) {
         for (String text : experienceParticleModule.dse.getSelected()) {
            computeField47.add(ParticleTextures.getParticleTexture(text));
         }

         if (computeField47.isEmpty()) {
            computeField47.add(ParticleTextures.BLOOM);
         }
      }
   }

      public static float manageMethod35(float min, float max) {
      return min + createField8.nextFloat() * (max - min);
   }

   static {
      int index = 0;
   }
}
