package winvi.noxiumvisuals.modules.particles;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.HitParticle;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.ParticleManager;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public class HitParticlesModule extends Module {
      public final BooleanSetting checkField582;
      public final BooleanSetting critOnly;
      public final MultiSelectSetting dsmy;
      public final ChoiceSetting opmng;
      public final ChoiceSetting convertField74;
      public final NumberSetting count;
      public final NumberSetting ddyzb;
      public final NumberSetting q20;
      public final NumberSetting updateField311;
      public final BooleanSetting distanceHit;
      public final SettingGroup nmclo;
      public final SettingGroup kwbtw;
      public final SettingGroup isField16;
      public static final List<HitParticle> particles = new ArrayList<>();
      public static final List<HitParticle> distanceHitParticles = new ArrayList<>();
      public final List<Identifier> dsv;
      public static final Random dswf = new Random();

   public HitParticlesModule() {
      super("Hit Particles", ModuleCategory.PARTICLES);
      this.checkField582 = new BooleanSetting(
            "Self",
            "Show for self"
         )
         .setValue(false);
      this.checkField582.withTranslation("hitparticles.self", "hitparticles.self.desc");
      this.critOnly = new BooleanSetting(
            "Crit Only",
            "Only crits"
         )
         .setValue(false);
      this.critOnly.withTranslation("hitparticles.critonly", "hitparticles.critonly.desc");
      this.dsmy = new MultiSelectSetting(
            "Texture Types",
            "Select particle texture types"
         )
         .value(ParticleTextures.getAvailableParticleTextureNames())
         .selected("Star");
      this.dsmy.withTranslation("hitparticles.texturetypes", "hitparticles.texturetypes.desc");
      this.opmng = new ChoiceSetting(
            "Disappear",
            "Disappear"
         )
         .value(
            "ALPHA",
            "SCALE"
         )
         .selected("ALPHA");
      this.opmng.withTranslation("hitparticles.disappear", "hitparticles.disappear.desc");
      this.convertField74 = new ChoiceSetting(
            "Physic",
            "Physics"
         )
         .value(
            "BOUNCE",
            "FLY"
         )
         .selected("BOUNCE");
      this.convertField74.withTranslation("hitparticles.physic", "hitparticles.physic.desc");
      this.count = new NumberSetting(
            "Count",
            "Count"
         )
         .setValue(20.0F)
         .range(1F, 20.0F);
      this.count.withTranslation("hitparticles.count", "hitparticles.count.desc");
      this.ddyzb = new NumberSetting(
            "Speed",
            "Speed"
         )
         .setValue(3.0F)
         .range(1F, 10.0F);
      this.ddyzb.withTranslation("hitparticles.speed", "hitparticles.speed.desc");
      this.q20 = new NumberSetting(
            "Live Time",
            "Particle lifetime"
         )
         .setValue(3.0F)
         .range(1F, 5.0F);
      this.q20.withTranslation("hitparticles.rendertime", "hitparticles.rendertime.desc");
      this.updateField311 = new NumberSetting(
            "Scale",
            "Scale"
         )
         .setValue(4.0F)
         .range(1F, 5.0F);
      this.updateField311.withTranslation("hitparticles.scale", "hitparticles.scale.desc");
      this.nmclo = new SettingGroup(
            "Hit Settings",
            "Hit particle settings"
         )
         .settings(this.count, this.ddyzb, this.q20, this.updateField311)
         .setValue(true);
      this.nmclo.withTranslation("hitparticles.hitsettings", "hitparticles.hitsettings.desc");
      this.kwbtw = new SettingGroup(
            "Advanced Settings",
            "Advanced particle settings"
         )
         .settings(this.critOnly, this.opmng, this.convertField74)
         .setValue(false);
      this.kwbtw.withTranslation("hitparticles.advancedsettings", "hitparticles.advancedsettings.desc");
      this.isField16 = new SettingGroup(
            "Texture Settings",
            "Particle texture settings"
         )
         .settings(this.dsmy)
         .setValue(true);
      this.isField16.withTranslation("hitparticles.texturesettings", "hitparticles.texturesettings.desc");
      this.distanceHit = new BooleanSetting(
            "Distance Hit",
            "Show particles on arrow/snowball/trident hit"
         )
         .setValue(false);
      this.distanceHit.withTranslation("hitparticles.distancehit", "hitparticles.distancehit.desc");
      this.dsv = new ArrayList<>();
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{this.nmclo, this.kwbtw, this.isField16, this.distanceHit});
   }

      @Override
   public void deactivate() {
      super.deactivate();
      particles.clear();
      distanceHitParticles.clear();
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState()) {
         this.render(event.getStack(), event.getPartialTicks());
      }
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (MinecraftClient.getInstance().player != null && this.isState()) {
         long timestamp = System.currentTimeMillis();
         this.mv1();
         ParticleManager.updateParticlesInPlace(particles, timestamp);
         if (this.distanceHit.isValue()) {
            ParticleManager.updateParticlesInPlace(distanceHitParticles, timestamp);
         }
      }
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         for (HitParticle textureMatrixRenderer2 : particles) {
            textureMatrixRenderer2.render(matrixStack, tickDelta);
         }

         if (this.distanceHit.isValue()) {
            for (HitParticle textureMatrixRenderer22 : distanceHitParticles) {
               textureMatrixRenderer22.render(matrixStack, tickDelta);
            }
         }
      }
   }

      public void mv1() {
      this.dsv.clear();

      for (String text : this.dsmy.getSelected()) {
         this.dsv.add(ParticleTextures.getParticleTexture(text));
      }

      if (this.dsv.isEmpty()) {
         this.dsv.add(ParticleTextures.STAR);
      }
   }

}
