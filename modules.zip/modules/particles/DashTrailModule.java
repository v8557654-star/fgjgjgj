package winvi.noxiumvisuals.modules.particles;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.DashTrailSegment;
import winvi.noxiumvisuals.modules.visuals.TrailEntityManager;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.MatrixEntityProvider;
import winvi.noxiumvisuals.utils.render.SmoothFloat;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public final class DashTrailModule extends Module {
      public static final int eeiy = 512;
      public static final Identifier[] j21;
      public static final Identifier[] yzmwr = setMethod84();
      public final ChoiceSetting el1;
      public final ChoiceSetting m20;
      public final BooleanSetting n15;
      public final BooleanSetting gvxtb;
      public final BooleanSetting eepu;
      public final BooleanSetting transformField71;
      public final NumberSetting eer;
      public final NumberSetting jvtku;
      public final NumberSetting eet;
      public final NumberSetting handleField70;
      public final NumberSetting ev0;
      public final NumberSetting ew0;
      public final SettingGroup arzbi;
      public final SettingGroup isField5;
      public final Random validateField0;
      public final List<DashTrailSegment> a10;
      public final SmoothFloat efb;
      public final SmoothFloat convertField20;
      public final MatrixStack efd;
      public Vec3d isField520;
      public boolean prswb;
      public boolean pqknt;

   public DashTrailModule() {
      super("Dash Trail", ModuleCategory.PARTICLES);
      this.el1 = new ChoiceSetting(
            "Shape",
            "Dash particle shape"
         )
         .value(
            "Vega",
            "Glyph"
         )
         .selected("Vega");
      this.m20 = new ChoiceSetting(
            "Physics",
            "Dash particle motion"
         )
         .value(
            "Default",
            "Fall",
            "Fly"
         )
         .selected("Default");
      this.n15 = new BooleanSetting(
            "Motion Smoothing",
            "Connect nearby dash motion"
         )
         .setValue(false);
      this.gvxtb = new BooleanSetting(
            "Segments",
            "Render short spark segments"
         )
         .setValue(false);
      this.eepu = new BooleanSetting(
            "Dots",
            "Render bright spark dots"
         )
         .setValue(true);
      this.transformField71 = new BooleanSetting(
            "Lighting",
            "Render soft light around dashes"
         )
         .setValue(true);
      this.eer = new NumberSetting(
            "Dash Length",
            "Dash lifetime multiplier"
         )
         .setValue(0.75F)
         .range(0.5F, 1.5F);
      this.jvtku = new NumberSetting(
            "Count",
            "Maximum particles per movement"
         )
         .setValue(8.0F)
         .range(1F, 24.0F);
      this.eet = new NumberSetting(
            "Lifetime",
            "Particle lifetime in seconds"
         )
         .setValue(0.8F)
         .range(0.2F, 5.0F);
      this.handleField70 = new NumberSetting(
            "Size",
            "Dash particle size"
         )
         .setValue(1F)
         .range(0.5F, 3.0F);
      this.ev0 = new NumberSetting(
            "Spread",
            "Spawn spread"
         )
         .setValue(5.0F)
         .range(0F, 20.0F);
      this.ew0 = new NumberSetting(
            "Gravity",
            "Default physics gravity"
         )
         .setValue(5.0F)
         .range(0F, 20.0F);
      this.arzbi = new SettingGroup(
            "Particle Settings",
            "Dash particle settings"
         )
         .settings(this.el1, this.jvtku, this.eet, this.handleField70, this.ev0, this.ew0)
         .setValue(true);
      this.isField5 = new SettingGroup(
            "Advanced Settings",
            "Dash trail physics"
         )
         .settings(this.m20, this.n15, this.gvxtb, this.eepu, this.transformField71, this.eer)
         .setValue(false);
      this.validateField0 = new Random(1234567891L);
      this.a10 = new ArrayList<>();
      this.efb = new SmoothFloat(0F, 0F, 0.08F);
      this.convertField20 = new SmoothFloat(0F, 1F, 0.08F);
      this.efd = new MatrixStack();
      this.showVisualColorSettings();
      this.ev0.visible(() -> {
         return this.m20.isSelected("Default");
      });
      this.ew0.visible(() -> {
         return this.m20.isSelected("Default");
      });
      this.setup(new ModuleSetting[]{this.arzbi, this.isField5});
   }

      @Override
   public void activate() {
      this.bnzhmk();
      this.a10.clear();
      this.isField520 = null;
      this.efb.setAnim(0F);
      this.efb.to = 1F;
      super.activate();
   }

      @Override
   public void deactivate() {
      this.a10.clear();
      this.isField520 = null;
      this.efb.to = 0F;
      super.deactivate();
   }

      @Override
   public void onTick() {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         ClientPlayerEntity client = MinecraftClient.getInstance().player;
         Vec3d position = client.getPos();
         Vec3d position2 = this.isField520;
         this.isField520 = position;
         if (position2 != null) {
            this.initMethod61(client, position2, position);
         }

         this.uzwcjp();
      }
   }

      public void initMethod61(PlayerEntity entity, Vec3d previous, Vec3d current) {
      double x2 = current.x - previous.x;
      double y2 = current.y - previous.y;
      double z2 = current.z - previous.z;
      double value = Math.sqrt(x2 * x2 + y2 * y2 + z2 * z2);
      if (!(Math.sqrt(x2 * x2 + z2 * z2) < 0.08)) {
         int index = MathHelper.clamp((int)Math.ceil(value / 0.08), 1, this.jvtku.getInt());
         int index2 = this.si1();

         for (int index3 = 0; index3 < index; index3++) {
            this.a10
               .add(
                  new DashTrailSegment(
                     this, new TrailEntityManager(this, entity, previous, 0.04F, (float)index3 / index, this.j22()), index2, this.jehpts()
                  )
               );
         }

         int index4 = this.a10.size() - 512;
         if (index4 > 0) {
            this.a10.subList(0, index4).clear();
         }
      }
   }

      public void uzwcjp() {
      this.efb.to = 1F;
      this.convertField20.to = this.transformField71.isValue() ? 1F : 0F;

      for (DashTrailSegment textureColorRenderer2 : this.a10) {
         if (textureColorRenderer2.formatMethod36() >= 1F && textureColorRenderer2.manageField8.to != 0F) {
            textureColorRenderer2.manageField8.to = 0F;
         }
      }

      this.a10.removeIf(cubic -> {
         return cubic.formatMethod36() >= 1F && cubic.manageField8.to == 0F && cubic.manageField8.getAnim() < 0.02F;
      });

      for (int index = 0; index < this.a10.size(); index++) {
         DashTrailSegment textureColorRenderer22 = this.a10.get(index);
         if (textureColorRenderer22.manageField8.getAnim() > 0.05F) {
            DashTrailSegment textureColorRenderer23 = this.n15.isValue() && index + 1 < this.a10.size() ? this.a10.get(index + 1) : null;
            textureColorRenderer22.sqrshd(textureColorRenderer23);
         }
      }
   }

      @Override
   public boolean hasWorldRenderWork() {
      return !this.a10.isEmpty();
   }

      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null && !this.a10.isEmpty()) {
         float value = this.efb.getAnim();
         if (!(value < 0.05F)) {
            float value2 = event.getPartialTicks();
            float value3 = this.convertField20.getAnim();
            Camera client = MinecraftClient.getInstance().gameRenderer.getCamera();

            for (DashTrailSegment textureColorRenderer2 : this.a10) {
               if (!(textureColorRenderer2.manageField8.getAnim() <= 0.05F)) {
                  if (this.gvxtb.isValue() || this.eepu.isValue()) {
                     textureColorRenderer2.addMethod93(value, value2);
                  }

                  textureColorRenderer2.dzox(client, value, value3, value2);
               }
            }
         }
      }
   }

      public int si1() {
      return this.getVisualColor();
   }

      public int j22() {
      int index = Math.max(200, (int)(this.eet.getValue() * this.eer.getValue() * 1000.0F));
      int index2 = Math.max(1, (int)(index * 0.18F));
      return index - index2 + this.validateField0.nextInt(index2 * 2 + 1);
   }

      public Identifier jehpts() {
      Identifier[] identifierArray = this.el1.isSelected("Vega") ? yzmwr : j21;
      return identifierArray[this.validateField0.nextInt(identifierArray.length)];
   }

      public void bnzhmk() {
      if (!this.prswb) {
         if (!RenderSystem.isOnRenderThread()) {
            if (!this.pqknt) {
               this.pqknt = true;
               RenderSystem.recordRenderCall(this::bnzhmk);
            }
         } else {
            this.pqknt = false;

            for (Identifier identifier : yzmwr) {
               MinecraftClient.getInstance().getTextureManager().getTexture(identifier).setFilter(true, false);
            }

            for (Identifier identifier2 : j21) {
               MinecraftClient.getInstance().getTextureManager().getTexture(identifier2).setFilter(true, false);
            }

            MinecraftClient.getInstance().getTextureManager().getTexture(ParticleTextures.BLOOM).setFilter(true, false);
            this.prswb = true;
         }
      }
   }

      public static Identifier[] setMethod84() {
      Identifier[] identifierArray = new Identifier[21];

      for (int index = 0; index < identifierArray.length; index++) {
         identifierArray[index] = Identifier.of("noxiumvisual", "textures/effects/dashtrail/dashcubic" + (index + 1) + ".png");
      }

      return identifierArray;
   }

      public Matrix4f jqqfrc(Camera camera, double x, double y, double z, float yaw, float pitch, boolean faceCamera) {
      Vec3d position = camera.getPos();
      this.efd.loadIdentity();
      this.efd.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
      this.efd.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
      this.efd.translate(x - position.x, y - position.y, z - position.z);
      if (faceCamera) {
         this.efd.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
         this.efd.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
      } else {
         this.efd.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
         this.efd.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
      }

      return MatrixEntityProvider.acquire(this.efd.peek().getPositionMatrix());
   }

      public static int transformMethod81(int color, int over, float progress) {
      float value = MathHelper.clamp(progress, 0F, 1F);
      int index = (int)((color >> 16 & 0xFF) + ((over >> 16 & 0xFF) - (color >> 16 & 0xFF)) * value);
      int index2 = (int)((color >> 8 & 0xFF) + ((over >> 8 & 0xFF) - (color >> 8 & 0xFF)) * value);
      int index3 = (int)((color & 0xFF) + ((over & 0xFF) - (color & 0xFF)) * value);
      return color & 0xFF000000 | index << 16 | index2 << 8 | index3;
   }

      public static int lgwnqo(int color, float factor) {
      float value = MathHelper.clamp(factor, 0F, 1F);
      int index = (int)((color >> 16 & 0xFF) * value);
      int index2 = (int)((color >> 8 & 0xFF) * value);
      int index3 = (int)((color & 0xFF) * value);
      return index << 16 | index2 << 8 | index3;
   }

      public static double sq0(double value) {
      double value2 = value < 0.5 ? value * 2.0 : (1 - value) * 2.0;
      return value2 < 0.5 ? 2.0 * value2 * value2 : 1 - Math.pow(-2.0F * value2 + 2.0, 2.0) / 2.0;
   }

   static {
      int index = 0;
      Identifier[] identifierArray = new Identifier[12];
      int index2 = 0;
      identifierArray[index2] = Identifier.of("noxiumvisual", "textures/o163c9wkg/glyph/ihj0uxn.png");
      index2 = 1;
      identifierArray[index2] = Identifier.of("noxiumvisual", "textures/o163c9wkg/glyph/4osw_v.png");
      index2 = 2;
      identifierArray[index2] = Identifier.of("noxiumvisual", "textures/o163c9wkg/glyph/s686g_iyoi6s.png");
      index2 = 3;
      identifierArray[index2] = Identifier.of("noxiumvisual", "textures/o163c9wkg/glyph/n1wmcc7l9we.png");
      index2 = 4;
      identifierArray[index2] = Identifier.of("noxiumvisual", "textures/o163c9wkg/glyph/9i2tn2202oc1.png");
      index2 = 5;
      identifierArray[index2] = Identifier.of("noxiumvisual", "textures/o163c9wkg/glyph/x3ncmv.png");
      index2 = 6;
      identifierArray[index2] = Identifier.of("noxiumvisual", "textures/o163c9wkg/glyph/z6xhta3r.png");
      index2 = 7;
      identifierArray[index2] = Identifier.of("noxiumvisual", "textures/o163c9wkg/glyph/9g89mtd5h8a7.png");
      index2 = 8;
      identifierArray[index2] = Identifier.of("noxiumvisual", "textures/o163c9wkg/glyph/2xc08pqma_ib.png");
      index2 = 9;
      identifierArray[index2] = Identifier.of("noxiumvisual", "textures/o163c9wkg/glyph/wi3jhyhyk483.png");
      index2 = 10;
      identifierArray[index2] = Identifier.of("noxiumvisual", "textures/o163c9wkg/glyph/bo68obbwmvau.png");
      index2 = 11;
      identifierArray[index2] = Identifier.of("noxiumvisual", "textures/o163c9wkg/glyph/i8gvqy.png");
      j21 = identifierArray;
   }
}
