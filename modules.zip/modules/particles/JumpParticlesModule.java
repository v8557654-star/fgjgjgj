package winvi.noxiumvisuals.modules.particles;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.JumpParticle;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.ParticleManager;
import winvi.noxiumvisuals.utils.render.RenderMath;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public class JumpParticlesModule extends Module {
      public final MultiSelectSetting dsx;
      public final ChoiceSetting stopField41;
      public final ChoiceSetting dsz;
      public final NumberSetting dta;
      public final NumberSetting dtb;
      public final NumberSetting manageField89;
      public final NumberSetting ntccm;
      public final SettingGroup jhibr;
      public final SettingGroup setField97;
      public final SettingGroup inted;
      public static final List<JumpParticle> particles = new ArrayList<>();
      public final List<Identifier> getField5;
      public static final Random executeField95 = new Random();
      public static boolean tj = false;

   public JumpParticlesModule() {
      super("Jump Particles", ModuleCategory.PARTICLES);
      this.dsx = new MultiSelectSetting(
            "Texture Types",
            "Select particle texture types"
         )
         .value(ParticleTextures.getAvailableParticleTextureNames())
         .selected("Star");
      this.dsx.withTranslation("jumpparticles.texturetypes", "jumpparticles.texturetypes.desc");
      this.stopField41 = new ChoiceSetting(
            "Physic",
            "Particle physics"
         )
         .value(
            "BOUNCE", "FLY"
         )
         .selected("BOUNCE");
      this.stopField41.withTranslation("jumpparticles.physic", "jumpparticles.physic.desc");
      this.dsz = new ChoiceSetting(
            "Disappear",
            "Disappear type"
         )
         .value(
            "ALPHA",
            "SCALE"
         )
         .selected("ALPHA");
      this.dsz.withTranslation("jumpparticles.disappear", "jumpparticles.disappear.desc");
      this.dta = new NumberSetting(
            "Count",
            "Number of particles"
         )
         .setValue(20.0F)
         .range(1F, 20.0F);
      this.dta.withTranslation("jumpparticles.count", "jumpparticles.count.desc");
      this.dtb = new NumberSetting(
            "Speed",
            "Particle speed"
         )
         .setValue(3.0F)
         .range(1F, 10.0F);
      this.dtb.withTranslation("jumpparticles.speed", "jumpparticles.speed.desc");
      this.manageField89 = new NumberSetting(
            "Live Time",
            "Particle lifetime"
         )
         .setValue(3.0F)
         .range(1F, 5.0F);
      this.manageField89.withTranslation("jumpparticles.livetime", "jumpparticles.livetime.desc");
      this.ntccm = new NumberSetting(
            "Scale",
            "Particle size"
         )
         .setValue(4.0F)
         .range(1F, 5.0F);
      this.ntccm.withTranslation("jumpparticles.scale", "jumpparticles.scale.desc");
      this.jhibr = new SettingGroup(
            "Jump Settings",
            "Jump particle settings"
         )
         .settings(this.dta, this.dtb, this.manageField89, this.ntccm)
         .setValue(true);
      this.jhibr.withTranslation("jumpparticles.jumpsettings", "jumpparticles.jumpsettings.desc");
      this.setField97 = new SettingGroup(
            "Advanced Settings",
            "Advanced particle settings"
         )
         .settings(this.stopField41, this.dsz)
         .setValue(false);
      this.setField97.withTranslation("jumpparticles.advancedsettings", "jumpparticles.advancedsettings.desc");
      this.inted = new SettingGroup(
            "Texture Settings",
            "Particle texture settings"
         )
         .settings(this.dsx)
         .setValue(true);
      this.inted.withTranslation("jumpparticles.texturesettings", "jumpparticles.texturesettings.desc");
      this.getField5 = new ArrayList<>();
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{this.jhibr, this.setField97, this.inted});
   }

      @Override
   public void deactivate() {
      super.deactivate();
      particles.clear();
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState()) {
         this.render(event.getStack(), event.getPartialTicks());
      }
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (MinecraftClient.getInstance().player != null && this.isState()) {
         long timestamp = System.currentTimeMillis();
         this.cmwp();
         boolean client = !MinecraftClient.getInstance().player.isOnGround();
         if (client && !tj && MinecraftClient.getInstance().options.jumpKey.isPressed()) {
            this.x16();
         }

         tj = client;
         ParticleManager.updateParticlesInPlace(particles, timestamp);
      }
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         for (JumpParticle textureMatrixRenderer5 : particles) {
            textureMatrixRenderer5.render(matrixStack, tickDelta);
         }
      }
   }

      public void cmwp() {
      this.getField5.clear();

      for (String text : this.dsx.getSelected()) {
         this.getField5.add(ParticleTextures.getParticleTexture(text));
      }

      if (this.getField5.isEmpty()) {
         this.getField5.add(ParticleTextures.STAR);
      }
   }

      public void x16() {
      if (MinecraftClient.getInstance().player != null) {
         for (int index = 0; index < (int)this.dta.getValue(); index++) {
            particles.add(
               new JumpParticle(
                  this,
                  (float)MinecraftClient.getInstance().player.getX(),
                  (float)MinecraftClient.getInstance().player.getY(),
                  (float)MinecraftClient.getInstance().player.getZ(),
                  null,
                  RenderMath.random(0, 180),
                  RenderMath.random(10.0F, 60.0F)
               )
            );
         }
      }
   }

}
