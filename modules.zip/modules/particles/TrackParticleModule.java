package winvi.noxiumvisuals.modules.particles;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.TrackParticle;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.ParticleManager;
import winvi.noxiumvisuals.utils.render.RenderMath;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public class TrackParticleModule extends Module {
      public static final int j17 = 1200;
      public static final int fbebh = 240;
      public static final int ffwje = 18;
      public static final double pkmcp = 1E-5;
      public final MultiSelectSetting elrjw;
      public final ChoiceSetting lxqns;
      public final ChoiceSetting addField57;
      public final NumberSetting duq;
      public final NumberSetting duri;
      public final NumberSetting okoxi;
      public final SettingGroup bsrqf;
      public final SettingGroup duu;
      public final SettingGroup v26;
      public static final List<TrackParticle> particles = new ArrayList<>();
      public final List<Identifier> gftnv;
      public static final Random vnkpm = new Random();
      public final Map<Integer, Vec3d> y23;
      public final Map<Integer, Integer> executeField180;
      public final Set<Integer> createField42;
      public final int[] dvb;
      public int fobli;

   public TrackParticleModule() {
      super("Track Particle", ModuleCategory.PARTICLES);
      this.duq = new NumberSetting(
            "Spawn Rate",
            "Particles per tick"
         )
         .setValue(3.0F)
         .range(1F, 10.0F);
      this.duq.withTranslation("trackparticle.spawnrate", "trackparticle.spawnrate.desc");
      this.duri = new NumberSetting(
            "Render Time",
            "Particle lifetime"
         )
         .setValue(2.0F)
         .range(0.5F, 5.0F);
      this.duri.withTranslation("trackparticle.rendertime", "trackparticle.rendertime.desc");
      this.okoxi = new NumberSetting(
            "Scale",
            "Particle size"
         )
         .setValue(8.0F)
         .range(1F, 15.0F);
      this.okoxi.withTranslation("trackparticle.scale", "trackparticle.scale.desc");
      this.lxqns = new ChoiceSetting(
            "Disappear",
            "Disappear mode"
         )
         .value(
            "ALPHA",
            "SCALE"
         )
         .selected("ALPHA");
      this.lxqns.withTranslation("trackparticle.disappear", "trackparticle.disappear.desc");
      this.addField57 = new ChoiceSetting(
            "Trail Mode",
            "Trail style"
         )
         .value(
            "STATIC",
            "SPIRAL",
            "WAVE"
         )
         .selected("STATIC");
      this.addField57.withTranslation("trackparticle.trailmode", "trackparticle.trailmode.desc");
      this.elrjw = new MultiSelectSetting(
            "Texture Types",
            "Select particle textures"
         )
         .value(ParticleTextures.getAvailableParticleTextureNames())
         .selected("Star");
      this.elrjw.withTranslation("trackparticle.texturetypes", "trackparticle.texturetypes.desc");
      this.bsrqf = new SettingGroup(
            "Track Settings",
            "Track particle settings"
         )
         .settings(this.duq, this.duri, this.okoxi)
         .setValue(true);
      this.bsrqf.withTranslation("trackparticle.tracksettings", "trackparticle.tracksettings.desc");
      this.duu = new SettingGroup(
            "Advanced Settings",
            "Advanced particle settings"
         )
         .settings(this.lxqns, this.addField57)
         .setValue(false);
      this.duu.withTranslation("trackparticle.advancedsettings", "trackparticle.advancedsettings.desc");
      this.v26 = new SettingGroup(
            "Texture Settings",
            "Particle texture settings"
         )
         .settings(this.elrjw)
         .setValue(true);
      this.v26.withTranslation("trackparticle.texturesettings", "trackparticle.texturesettings.desc");
      this.gftnv = new ArrayList<>();
      this.y23 = new HashMap<>();
      this.executeField180 = new HashMap<>();
      this.createField42 = new HashSet<>();
      this.dvb = new int[4];
      this.fobli = 0;
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{this.bsrqf, this.duu, this.v26});
   }

      @Override
   public void deactivate() {
      super.deactivate();
      particles.clear();
      this.y23.clear();
      this.executeField180.clear();
      this.createField42.clear();
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState()) {
         this.render(event.getStack(), event.getPartialTicks());
      }
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null && this.isState()) {
         this.fobli++;
         long timestamp = System.currentTimeMillis();
         this.bcczzu();
         this.wbibgh();
         int index = Math.max(0, 1200 - particles.size());
         this.createField42.clear();
         int index2 = 0;

         for (Entity entity : MinecraftClient.getInstance().world.getEntities()) {
            if (entity instanceof ProjectileEntity projectileEntity && this.fxqgbo(projectileEntity)) {
               int index3 = projectileEntity.getId();
               this.createField42.add(index3);
               Vec3d position = this.stopMethod37(projectileEntity);
               Vec3d position2 = this.y23.put(index3, position);
               if (position2 == null) {
                  this.executeField180.put(index3, 0);
               } else {
                  Vec3d position3 = position.subtract(position2);
                  double value = position3.lengthSquared();
                  int index4 = value < 1E-5 ? this.executeField180.getOrDefault(index3, 0) + 1 : 0;
                  this.executeField180.put(index3, index4);
                  if (!this.destroyMethod480(projectileEntity, value) && index4 < 2 && index > 0 && index2 < 240) {
                     int index5 = this.getMethod91(position3.length(), index, index2);
                     if (index5 > 0) {
                        Vec3d position4 = this.parseMethod89(projectileEntity, position3);

                        for (int index6 = 0; index6 < index5; index6++) {
                           double value2 = (index6 + vnkpm.nextDouble()) / index5;
                           Vec3d position5 = position2.lerp(position, value2);
                           this.controlMethod530(position5, position4, index3, index6, value2);
                        }

                        index -= index5;
                        index2 += index5;
                     }
                  }
               }
            }
         }

         this.computeMethod62(this.createField42);
         ParticleManager.updateParticlesInPlace(particles, timestamp);
         deleteMethod47(1200);
      }
   }

      public boolean fxqgbo(ProjectileEntity projectile) {
      if (projectile != null && !projectile.isRemoved() && projectile.isAlive()) {
         return !MinecraftClient.getInstance().player.equals(projectile.getOwner())
            ? false
            : !(projectile instanceof PersistentProjectileEntity persistentProjectileEntity && persistentProjectileEntity.isOnGround());
      } else {
         return false;
      }
   }

      public boolean destroyMethod480(ProjectileEntity projectile, double travelSq) {
      if (!(projectile instanceof PersistentProjectileEntity)) {
         return false;
      } else {
         double value = projectile.getVelocity().lengthSquared();
         return travelSq < 1E-5 && value < 4.0E-4;
      }
   }

      public static void deleteMethod47(int maxParticles) {
      int index = particles.size() - maxParticles;
      if (index > 0) {
         particles.subList(0, index).clear();
      }
   }

      public void controlMethod530(Vec3d samplePos, Vec3d direction, int projectileId, int spawnIndex, double progress) {
      Vec3d position = this.handleMethod17(direction);
      Vec3d position2 = direction.crossProduct(position).normalize();
      double value = vnkpm.nextDouble() * 3.141592653589793 * 2.0;
      double value2 = this.fobli * 0.35 + projectileId * 0.41 + spawnIndex * 0.73 + progress * 8.0 + value;
      Vec3d position3 = position.multiply(Math.cos(value)).add(position2.multiply(Math.sin(value)));
      Vec3d position4 = Vec3d.ZERO;
      Vec3d position5 = direction.multiply(-0.0105F);
      float value3 = 0.91F;
      float value4 = 3.5E-4F;
      String text = this.addField57.getSelected();
      if (text.equals("SPIRAL")) {
         double value5 = 0.045 + 0.008 * Math.sin(value2 * 0.5);
         Vec3d position6 = position.multiply(Math.cos(value2) * value5).add(position2.multiply(Math.sin(value2) * value5));
         Vec3d position7 = position.multiply(-Math.sin(value2) * 0.012).add(position2.multiply(Math.cos(value2) * 0.012));
         position4 = position6;
         position5 = position5.add(position7).add(position6.multiply(0.08)).add(position3.multiply(0.006 + vnkpm.nextDouble() * 0.009));
         value3 = 0.925F;
         value4 = 1.8E-4F;
      } else if (text.equals("WAVE")) {
         double value6 = Math.sin(value2);
         double value7 = Math.cos(value2 * 0.65 + spawnIndex * 0.35);
         Vec3d position8 = position.multiply(value6 * 0.065).add(position2.multiply(value7 * 0.026));
         position4 = position8;
         position5 = position5.add(position.multiply(value6 * 0.011))
            .add(position2.multiply(value7 * 0.0045))
            .add(position3.multiply(0.005 + vnkpm.nextDouble() * 0.008));
         value3 = 0.905F;
         value4 = 3.0E-4F;
      } else {
         double value8 = 0.02 + vnkpm.nextDouble() * 0.016;
         Vec3d position9 = position.multiply(Math.cos(value2) * value8).add(position2.multiply(Math.sin(value2) * value8 * 0.6));
         position4 = position9;
         position5 = position5.add(position9.multiply(0.14)).add(position3.multiply(0.008 + vnkpm.nextDouble() * 0.012));
      }

      position5 = position5.add(this.yduqlx(0.0025));
      Vec3d position10 = samplePos.add(position4);
      particles.add(
         new TrackParticle(
            this,
            (float)position10.x,
            (float)position10.y,
            (float)position10.z,
            (float)position5.x,
            (float)position5.y,
            (float)position5.z,
            RenderMath.random(0, 360),
            RenderMath.random(-90.0F, 90.0F),
            value3,
            value4
         )
      );
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         long timestamp = System.currentTimeMillis();
         float client = 1F / Math.max(30, MinecraftClient.getInstance().getCurrentFps());

         for (TrackParticle textureMatrixRenderer6 : particles) {
            textureMatrixRenderer6.render(matrixStack, tickDelta, timestamp, client);
         }
      }
   }

      public void bcczzu() {
      this.gftnv.clear();

      for (String text : this.elrjw.getSelected()) {
         this.gftnv.add(ParticleTextures.getParticleTexture(text));
      }

      if (this.gftnv.isEmpty()) {
         this.gftnv.add(ParticleTextures.STAR);
      }
   }

      public void wbibgh() {
      Arrays.fill(this.dvb, this.getVisualColor());
   }

      public int getMethod91(double distance, int remainingCapacity, int spawnedThisTick) {
      int index = Math.max(1, this.duq.getInt());
      int index2 = Math.max(1, (int)Math.ceil(distance * 16.0));
      int index3 = Math.max(index, index2);
      index3 = Math.min(index3, 18);
      index3 = Math.min(index3, remainingCapacity);
      index3 = Math.min(index3, 240 - spawnedThisTick);
      return Math.max(0, index3);
   }

      public Vec3d parseMethod89(ProjectileEntity projectile, Vec3d travel) {
      if (travel.lengthSquared() > 1E-5) {
         return travel.normalize();
      } else {
         Vec3d position = projectile.getVelocity();
         return position.lengthSquared() > 1E-6 ? position.normalize() : new Vec3d(0, 1, 0);
      }
   }

      public Vec3d handleMethod17(Vec3d direction) {
      Vec3d position = Math.abs(direction.y) > 0.82 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
      Vec3d position2 = direction.crossProduct(position);
      if (position2.lengthSquared() < 1E-6) {
         position2 = direction.crossProduct(new Vec3d(0, 0, 1));
      }

      return position2.normalize();
   }

      public Vec3d yduqlx(double amplitude) {
      return new Vec3d((vnkpm.nextDouble() - 0.5) * amplitude, (vnkpm.nextDouble() - 0.5) * amplitude, (vnkpm.nextDouble() - 0.5) * amplitude);
   }

      public Vec3d stopMethod37(ProjectileEntity projectile) {
      return projectile.getPos();
   }

      public void computeMethod62(Set<Integer> activeProjectileIds) {
      this.y23.keySet().removeIf(id -> {
         return !activeProjectileIds.contains(id);
      });
      this.executeField180.keySet().removeIf(id -> {
         return !activeProjectileIds.contains(id);
      });
   }

}
