package winvi.noxiumvisuals.modules.particles;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.KillParticle;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.ParticleCameraRenderer;
public class KillParticleModule extends Module {
      public static final float mbfgm = 10.0F;
      public final ChoiceSetting transformField2;
      public final ChoiceSetting processField79;
      public final NumberSetting startField94;
      public final NumberSetting dtod;
      public final NumberSetting qezcs;
      public final SettingGroup dtqo;
      public final SettingGroup pbzas;
      public static final List<KillParticle> particles = Collections.synchronizedList(new ArrayList<>());

   public KillParticleModule() {
      super("Kill Particle", ModuleCategory.PARTICLES);
      this.startField94 = new NumberSetting(
            "Height",
            "Lightning height"
         )
         .setValue(10.0F)
         .range(1F, 30.0F);
      this.startField94.withTranslation("killparticle.height", "killparticle.height.desc");
      this.dtod = new NumberSetting(
            "Density",
            "Particle density"
         )
         .setValue(50.0F)
         .range(10.0F, 100.0F);
      this.dtod.withTranslation("killparticle.density", "killparticle.density.desc");
      this.qezcs = new NumberSetting(
            "Live Time",
            "Effect duration"
         )
         .setValue(3.0F)
         .range(0.5F, 5.0F);
      this.qezcs.withTranslation("killparticle.livetime", "killparticle.livetime.desc");
      this.transformField2 = new ChoiceSetting(
            "Physic",
            "Physics"
         )
         .value(
            "None",
            "FLY",
            "FALL"
         )
         .selected("None");
      this.transformField2.withTranslation("killparticle.physic", "killparticle.physic.desc");
      this.processField79 = new ChoiceSetting(
            "Disappear",
            "Disappear"
         )
         .value(
            "ALPHA",
            "SCALE"
         )
         .selected("ALPHA");
      this.processField79.withTranslation("killparticle.disappear", "killparticle.disappear.desc");
      this.dtqo = new SettingGroup(
            "Kill Settings",
            "Kill effect settings"
         )
         .settings(this.startField94, this.dtod, this.qezcs)
         .setValue(true);
      this.dtqo.withTranslation("killparticle.killsettings", "killparticle.killsettings.desc");
      this.pbzas = new SettingGroup(
            "Advanced Settings",
            "Advanced effect settings"
         )
         .settings(this.transformField2, this.processField79)
         .setValue(false);
      this.pbzas.withTranslation("killparticle.advancedsettings", "killparticle.advancedsettings.desc");
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{this.dtqo, this.pbzas});
   }

      @Override
   public void deactivate() {
      super.deactivate();
      particles.clear();
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState()) {
         this.render(event.getStack(), event.getPartialTicks());
      }
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (MinecraftClient.getInstance().player != null && this.isState()) {
         long timestamp = System.currentTimeMillis();
         synchronized (particles) {
            for (int index = particles.size() - 1; index >= 0; index--) {
               KillParticle textureMatrixRenderer4 = particles.get(index);
               boolean x = ParticleCameraRenderer.isParticleVisible(textureMatrixRenderer4.getX(), textureMatrixRenderer4.getY(), textureMatrixRenderer4.getZ(), textureMatrixRenderer4.xtujh * 0.07F);
               if (textureMatrixRenderer4.update(timestamp, x)) {
                  particles.remove(index);
               }
            }
         }
      }
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         synchronized (particles) {
            int index = 0;

            for (int index2 = particles.size(); index < index2; index++) {
               particles.get(index).render(matrixStack, tickDelta);
            }
         }
      }
   }

      public static void spawnLightning(LivingEntity entity) {
      KillParticleModule killParticleModule = NoxiumVisuals.getInstance().getModuleProvider().get(KillParticleModule.class);
      if (killParticleModule != null && killParticleModule.isState()) {
         MinecraftClient client = MinecraftClient.getInstance();
         if (client.player != null && client.world != null) {
            float x = (float)entity.getX();
            float y = (float)entity.getY();
            float z = (float)entity.getZ();
            updateMethod49(x, y, z, killParticleModule);
         }
      }
   }

      public static void updateMethod49(float x, float y, float z, KillParticleModule module) {
      float value = module.startField94.getValue();
      int index = (int)module.dtod.getValue();
      float value2 = x;
      float value3 = z;
      float value4 = value / index;

      for (int index2 = 0; index2 < index; index2++) {
         float value5 = y + value - index2 * value4;
         if (index2 > 0) {
            value2 += (float)(Math.random() - 0.5) * 0.3F;
            value3 += (float)(Math.random() - 0.5) * 0.3F;
         }

         particles.add(new KillParticle(value2, value5, value3, module));
      }
   }

   static {
      int index = 0;
   }
}
