package winvi.noxiumvisuals.modules.particles;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.TextureColorRenderer;
import winvi.noxiumvisuals.modules.visuals.ColorEntityManager;
import winvi.noxiumvisuals.modules.visuals.ParticleTrailBatcher;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.systems.internal.ParticleTrailAccess;
import winvi.noxiumvisuals.utils.MatrixEntityProvider;
import winvi.noxiumvisuals.utils.render.WorldParticleBatcher;
import winvi.noxiumvisuals.utils.render.RenderGeometry;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public class ParticleTrailModule extends Module {
      public static final MinecraftClient s23 = MinecraftClient.getInstance();
      public static final int removeField51 = 300;
      public static final int dtuc = 500;
      public static final long getField26 = 16L;
      public final List<TextureColorRenderer> jqssk;
      public final List<TextureColorRenderer> destroyField87;
      public final Random startField4;
      public Vec3d dtzo;
      public long a8;
      public static ChoiceSetting trailStyle;
      public static BooleanSetting trailsFirstPerson = new BooleanSetting(
         "First Person",
         "Show trails in first person"
      )
      .setValue(false);
      public static MultiSelectSetting particleTextures;
      public static ChoiceSetting particlePhysics;
      public static NumberSetting particleCount = new NumberSetting(
         "Count",
         "Number of particles per spawn"
      )
      .setValue(5.0F)
      .range(1F, 15.0F);
      public static NumberSetting particleLifetime = new NumberSetting(
         "Lifetime",
         "Particle lifetime in seconds"
      )
      .setValue(2.0F)
      .range(0.5F, 5.0F);
      public static NumberSetting particleSize = new NumberSetting(
         "Size",
         "Particle size multiplier"
      )
      .setValue(1F)
      .range(0.5F, 3.0F);
      public static NumberSetting particleSpread = new NumberSetting(
         "Spread Strength",
         "Particle spread strength"
      )
      .setValue(5.0F)
      .range(0F, 20.0F)
      .visible(() -> {
         return particlePhysics.isSelected("Default");
      });
      public static NumberSetting particleGravity = new NumberSetting(
         "Gravity Strength",
         "Particle gravity strength"
      )
      .setValue(5.0F)
      .range(0F, 20.0F)
      .visible(() -> {
         return particlePhysics.isSelected("Default");
      });
      public static SettingGroup particleSettings;
      public static SettingGroup advancedSettings;
      public static NumberSetting kaguneSize = new NumberSetting(
         "Size",
         "Kagune particle size"
      )
      .setValue(0.15F)
      .range(0.05F, 0.5F);
      public static NumberSetting kaguneDelay = new NumberSetting(
         "Length",
         "Kagune trail length"
      )
      .setValue(1F)
      .range(0.5F, 3.0F);
      public static MultiSelectSetting kaguneTextures;
      public static SettingGroup kaguneSettings;
      public static NumberSetting trailsStripSize = new NumberSetting(
         "Size",
         "Trails strip particle size"
      )
      .setValue(1F)
      .range(0.1F, 3.0F);
      public static NumberSetting trailsStripLength = new NumberSetting(
         "Length",
         "Trails strip trail length"
      )
      .setValue(0.3F)
      .range(0.1F, 1.5F);
      public static NumberSetting trailsStripLifetime = new NumberSetting(
         "Lifetime",
         "Particle lifetime in seconds"
      )
      .setValue(2.0F)
      .range(0.5F, 5.0F);
      public static NumberSetting trailsStripAmount = new NumberSetting(
         "Amount",
         "Particle spawn rate"
      )
      .setValue(0.7F)
      .range(0.1F, 1F);
      public static MultiSelectSetting trailsStripTextures;
      public static SettingGroup trailsStripSettings;
      public static final MatrixStack executeField77 = new MatrixStack();

   public ParticleTrailModule() {
      super("Particle Trail", ModuleCategory.PARTICLES);
      this.jqssk = new ArrayList<>();
      this.destroyField87 = new ArrayList<>();
      this.startField4 = new Random();
      this.a8 = 0L;
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{trailStyle, particleSettings, advancedSettings, kaguneSettings, trailsStripSettings});
   }

      @Override
   public void deactivate() {
      this.jqssk.clear();
      this.dtzo = null;
      if (s23.world != null) {
         for (PlayerEntity player : s23.world.getPlayers()) {
            ((ParticleTrailAccess)player).noxium$clearPositionHistory();
         }
      }

      super.deactivate();
   }

      @Override
   public void activate() {
      super.activate();
      if (s23.world != null) {
         for (PlayerEntity player : s23.world.getPlayers()) {
            ((ParticleTrailAccess)player).noxium$clearPositionHistory();
         }
      }
   }

      @Override
   public void onTick() {
      if (this.isState()) {
         if (s23.world != null && s23.player != null) {
            String text = trailStyle.getSelected();
            if (text.equals("Particle")) {
               this.cne();
            }

            if (text.equals("Kagune")
               || text.equals("Trails")) {
               this.c24();
            }

            if (text.equals("Trails")) {
               this.ndzojc();
            }
         }
      }
   }

      public void mz() {
      String text = trailStyle.getSelected();
      Color color = new Color(this.getVisualColor(), true);
      long timestamp = System.currentTimeMillis();
      long timestamp2 = text.equals("Trails")
         ? (long)(trailsStripLength.getValue() * 1000.0F)
         : (long)(kaguneDelay.getValue() * 1000.0F);
      double value = text.equals("Trails") ? 0.005 : 0.015;

      for (PlayerEntity player2 : s23.world.getPlayers()) {
         List list = ((ParticleTrailAccess)player2).noxium$getParticleTrails();
         boolean enabled = false;
         if (player2 != s23.player && (player2.getPos().x != player2.prevX || player2.getPos().z != player2.prevZ)) {
            enabled = true;
         }

         if (player2 == s23.player
            && (s23.player.getVelocity().x != 0 || s23.player.getVelocity().z != 0)
            && (trailsFirstPerson.isValue() || !s23.options.getPerspective().isFirstPerson())) {
            enabled = true;
         }

         if (enabled) {
            Vec3d position = RenderGeometry.interpolate(player2);
            if (list.isEmpty()) {
               Vec3d position2 = new Vec3d(player2.prevX, player2.prevY, player2.prevZ);
               list.add(new ColorEntityManager(position2, position, color, player2.getHeight(), timestamp2));
            } else {
               ColorEntityManager colorEntityManager = (ColorEntityManager)list.get(list.size() - 1);
               double value2 = colorEntityManager.currentPos.distanceTo(position);
               if (value2 >= value) {
                  list.add(new ColorEntityManager(colorEntityManager.currentPos, position, color, player2.getHeight(), timestamp2));
               }
            }
         }
      }
   }

      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState()) {
         if (s23.world != null && s23.player != null) {
            String text = trailStyle.getSelected();
            MatrixStack matrices = event.getStack();
            float value = event.getPartialTicks();
            if (text.equals("Particle")) {
               this.setMethod300(value);
            } else if (text.equals("Kagune")) {
               this.cna0();
               this.convertMethod29(matrices);
               ParticleTrailBatcher.renderBatches(value);
            } else if (text.equals("Trails")) {
               this.cna0();
               this.oohpdd(value);
            }
         }
      }
   }

      public void cna0() {
      long timestamp = System.currentTimeMillis();
      if (timestamp - this.a8 >= 16L) {
         this.a8 = timestamp;
         this.mz();
      }
   }

      public void ndzojc() {
      if (s23.world != null) {
         List list = trailsStripTextures.getSelected();
         int index = list.size();
         if (index != 0) {
            float value = trailsStripLifetime.getValue();
            float value2 = trailsStripAmount.getValue();
            long timestamp = System.currentTimeMillis();

            for (PlayerEntity player2 : s23.world.getPlayers()) {
               if (player2 != null) {
                  boolean enabled = false;
                  if (player2 != s23.player) {
                     enabled = true;
                  } else {
                     enabled = trailsFirstPerson.isValue() || !s23.options.getPerspective().isFirstPerson();
                  }

                  if (enabled) {
                     List list2 = ((ParticleTrailAccess)player2).noxium$getParticleTrails();
                     if (!list2.isEmpty()) {
                        for (int index2 = 0; index2 < list2.size(); index2++) {
                           ColorEntityManager colorEntityManager = (ColorEntityManager)list2.get(index2);
                           if (this.startField4.nextFloat() < value2) {
                              String text = (String)list.get(this.startField4.nextInt(index));
                              Identifier identifier = ParticleTextures.getParticleTexture(text);
                              this.destroyField87
                                 .add(
                                    new TextureColorRenderer(
                                       this,
                                       colorEntityManager.currentPos,
                                       identifier,
                                       "Default",
                                       0.05F,
                                       timestamp
                                    )
                                 );
                           }
                        }
                     }
                  }
               }
            }

            this.updateMethod710(this.destroyField87, 500);
            this.computeMethod38(this.destroyField87, value, timestamp);
         }
      }
   }

      public void c24() {
      long timestamp = System.currentTimeMillis();

      for (PlayerEntity player : s23.world.getPlayers()) {
         List list = ((ParticleTrailAccess)player).noxium$getParticleTrails();

         for (int index = list.size() - 1; index >= 0; index--) {
            if (((ColorEntityManager)list.get(index)).shouldRemove(timestamp)) {
               list.remove(index);
            }
         }
      }
   }

      public void convertMethod29(MatrixStack stack) {
      Vec3d camera = s23.gameRenderer.getCamera().getPos();
      double value = 4096.0;

      for (PlayerEntity player2 : s23.world.getPlayers()) {
         boolean enabled = false;
         if (player2 == s23.player) {
            enabled = trailsFirstPerson.isValue() || !s23.options.getPerspective().isFirstPerson();
         } else {
            enabled = true;
         }

         if (enabled) {
            double value2 = player2.squaredDistanceTo(camera);
            if (!(value2 > value)) {
               List list = ((ParticleTrailAccess)player2).noxium$getParticleTrails();
               if (!list.isEmpty()) {
                  ParticleTrailBatcher.queueKagune(stack, list);
               }
            }
         }
      }
   }

      public void cne() {
      if (s23.player != null) {
         Vec3d position = s23.player.getPos();
         long timestamp = System.currentTimeMillis();
         if (this.dtzo == null) {
            this.dtzo = position;
         } else {
            if (position.distanceTo(this.dtzo) >= 0.10000000149011612) {
               List list = particleTextures.getSelected();
               int index = list.size();
               if (index == 0) {
                  this.dtzo = position;
                  return;
               }

               int index2 = (int)particleCount.getValue();
               String text = particlePhysics.getSelected();

               for (int index3 = 0; index3 < index2; index3++) {
                  String text2 = (String)list.get(this.startField4.nextInt(index));
                  Identifier identifier = ParticleTextures.getParticleTexture(text2);
                  this.jqssk.add(new TextureColorRenderer(this, this.dtzo, identifier, text, 1F, timestamp));
               }

               this.dtzo = position;
            }

            this.updateMethod710(this.jqssk, 300);
            float value = particleLifetime.getValue();
            this.computeMethod38(this.jqssk, value, timestamp);
         }
      }
   }

      public void oohpdd(float tickDelta) {
      if (!this.destroyField87.isEmpty()) {
         Camera camera = s23.gameRenderer.getCamera();
         Vec3d position = camera.getPos();

         for (TextureColorRenderer textureColorRenderer : this.destroyField87) {
            this.cnvkzb(textureColorRenderer, tickDelta, camera, position, trailsStripSize.getValue());
         }
      }
   }

      public void setMethod300(float tickDelta) {
      if (!this.jqssk.isEmpty()) {
         Camera camera = s23.gameRenderer.getCamera();
         Vec3d position = camera.getPos();

         for (TextureColorRenderer textureColorRenderer : this.jqssk) {
            this.cnvkzb(textureColorRenderer, tickDelta, camera, position, 4.0F);
         }
      }
   }

      public void cnvkzb(TextureColorRenderer particle, float tickDelta, Camera camera, Vec3d cameraPos, float sizeMultiplier) {
      if (particle.textureId != null) {
         float value = particle.size * sizeMultiplier;
         if (!(value <= 0F)) {
            double value2 = particle.px + (particle.x - particle.px) * tickDelta;
            double value3 = particle.py + (particle.y - particle.py) * tickDelta;
            double value4 = particle.pz + (particle.z - particle.pz) * tickDelta;
            executeField77.loadIdentity();
            executeField77.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
            executeField77.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
            executeField77.translate(value2 - cameraPos.x, value3 - cameraPos.y, value4 - cameraPos.z);
            executeField77.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
            executeField77.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
            Matrix4f matrix = MatrixEntityProvider.acquire(executeField77.peek().getPositionMatrix());
            WorldParticleBatcher.queueOwnedGhostParticle(
               matrix, particle.textureId, value * 2.0F, 1F, particle.gradientColors[0], true, particle.gradientColors
            );
         }
      }
   }

      public void updateMethod710(List<TextureColorRenderer> points, int maxSize) {
      int index = points.size() - maxSize;
      if (index > 0) {
         points.subList(0, index).clear();
      }
   }

      public void computeMethod38(List<TextureColorRenderer> points, float lifetime, long currentTimeMs) {
      for (int index = points.size() - 1; index >= 0; index--) {
         TextureColorRenderer textureColorRenderer = (TextureColorRenderer)points.get(index);
         float value = (float)(currentTimeMs - textureColorRenderer.creationTime) / 1000.0F;
         if (value > lifetime && textureColorRenderer.size < 0.001F) {
            points.remove(index);
         } else {
            textureColorRenderer.update();
            textureColorRenderer.updateSize(value, lifetime);
         }
      }
   }

   static {
      int index = 0;
      ChoiceSetting moduleSettingHandler2 = new ChoiceSetting(
         "Mode",
         "Choose trail mode"
      );
      String[] stringArray = new String[3];
      stringArray[0] = "Particle";
      stringArray[1] = "Kagune";
      stringArray[2] = "Trails";
      trailStyle = moduleSettingHandler2.value(stringArray).selected("Particle");
      trailStyle.withTranslation("particletrail.trailstyle", "particletrail.trailstyle.desc");
      trailsFirstPerson.withTranslation("particletrail.firstperson", "particletrail.firstperson.desc");
      MultiSelectSetting moduleSettingHandler = new MultiSelectSetting(
            "Textures",
            "Select particle textures"
         )
         .value(ParticleTextures.getAvailableParticleTextureNames());
      String[] stringArray2 = new String[1];
      stringArray2[0] = "Star";
      particleTextures = moduleSettingHandler.selected(stringArray2);
      particleTextures.withTranslation("particletrail.particletextures", "particletrail.particletextures.desc");
      ChoiceSetting moduleSettingHandler22 = new ChoiceSetting(
         "Physics",
         "Particle physics mode"
      );
      String[] stringArray3 = new String[3];
      stringArray3[0] = "Default";
      stringArray3[1] = "Fall";
      stringArray3[2] = "Fly";
      particlePhysics = moduleSettingHandler22.value(stringArray3).selected("Default");
      particlePhysics.withTranslation("particletrail.particlephysics", "particletrail.particlephysics.desc");
      particleCount.withTranslation("particletrail.particlecount", "particletrail.particlecount.desc");
      particleLifetime.withTranslation("particletrail.particlelifetime", "particletrail.particlelifetime.desc");
      particleSize.withTranslation("particletrail.particlesize", "particletrail.particlesize.desc");
      particleSpread.withTranslation("particletrail.particlespread", "particletrail.particlespread.desc");
      particleGravity.withTranslation("particletrail.particlegravity", "particletrail.particlegravity.desc");
      SettingGroup moduleSettingProvider3 = new SettingGroup(
         "Particle Settings",
         "Particle trail settings"
      );
      ModuleSetting[] moduleProvider3Array = new ModuleSetting[6];
      moduleProvider3Array[0] = particleTextures;
      moduleProvider3Array[1] = particleCount;
      moduleProvider3Array[2] = particleLifetime;
      moduleProvider3Array[3] = particleSize;
      moduleProvider3Array[4] = particleSpread;
      moduleProvider3Array[5] = particleGravity;
      particleSettings = moduleSettingProvider3.settings(moduleProvider3Array).setValue(true).visible(() -> {
         return trailStyle.isSelected("Particle");
      });
      particleSettings.withTranslation("particletrail.particlesettings", "particletrail.particlesettings.desc");
      SettingGroup moduleSettingProvider32 = new SettingGroup(
         "Advanced Settings",
         "Advanced trail settings"
      );
      ModuleSetting[] moduleProvider3Array2 = new ModuleSetting[2];
      moduleProvider3Array2[0] = trailsFirstPerson;
      moduleProvider3Array2[1] = particlePhysics;
      advancedSettings = moduleSettingProvider32.settings(moduleProvider3Array2)
         .setValue(false)
         .visible(() -> {
            return trailStyle.isSelected("Particle");
         });
      advancedSettings.withTranslation("particletrail.advancedsettings", "particletrail.advancedsettings.desc");
      kaguneSize.withTranslation("particletrail.kagunesize", "particletrail.kagunesize.desc");
      kaguneDelay.withTranslation("particletrail.kagunedelay", "particletrail.kagunedelay.desc");
      MultiSelectSetting moduleSettingHandler3 = new MultiSelectSetting(
            "Textures",
            "Select particle textures for kagune"
         )
         .value(ParticleTextures.getAvailableParticleTextureNames());
      String[] stringArray4 = new String[1];
      stringArray4[0] = "Bloom";
      kaguneTextures = moduleSettingHandler3.selected(stringArray4);
      kaguneTextures.withTranslation("particletrail.kagunetextures", "particletrail.kagunetextures.desc");
      SettingGroup moduleSettingProvider33 = new SettingGroup(
         "Kagune Settings",
         "Kagune trail settings"
      );
      ModuleSetting[] moduleProvider3Array3 = new ModuleSetting[3];
      moduleProvider3Array3[0] = kaguneSize;
      moduleProvider3Array3[1] = kaguneDelay;
      moduleProvider3Array3[2] = kaguneTextures;
      kaguneSettings = moduleSettingProvider33.settings(moduleProvider3Array3).setValue(true).visible(() -> {
         return trailStyle.isSelected("Kagune");
      });
      kaguneSettings.withTranslation("particletrail.kagunesettings", "particletrail.kagunesettings.desc");
      trailsStripSize.withTranslation("particletrail.trailsstripsize", "particletrail.trailsstripsize.desc");
      trailsStripLength.withTranslation("particletrail.trailsstriplength", "particletrail.trailsstriplength.desc");
      trailsStripLifetime.withTranslation("particletrail.trailsstriplifetime", "particletrail.trailsstriplifetime.desc");
      trailsStripAmount.withTranslation("particletrail.trailsstripamount", "particletrail.trailsstripamount.desc");
      MultiSelectSetting moduleSettingHandler4 = new MultiSelectSetting(
            "Textures",
            "Select particle textures for trails"
         )
         .value(ParticleTextures.getAvailableParticleTextureNames());
      String[] stringArray5 = new String[3];
      stringArray5[0] = "Star";
      stringArray5[1] = "Heart";
      stringArray5[2] = "Snowflake";
      trailsStripTextures = moduleSettingHandler4.selected(stringArray5);
      trailsStripTextures.withTranslation("particletrail.trailsstriptextures", "particletrail.trailsstriptextures.desc");
      SettingGroup moduleSettingProvider34 = new SettingGroup(
         "Trails Settings",
         "Trails strip settings"
      );
      ModuleSetting[] moduleProvider3Array4 = new ModuleSetting[5];
      moduleProvider3Array4[0] = trailsStripSize;
      moduleProvider3Array4[1] = trailsStripLength;
      moduleProvider3Array4[2] = trailsStripLifetime;
      moduleProvider3Array4[3] = trailsStripAmount;
      moduleProvider3Array4[4] = trailsStripTextures;
      trailsStripSettings = moduleSettingProvider34.settings(moduleProvider3Array4).setValue(true).visible(() -> {
         return trailStyle.isSelected("Trails");
      });
      trailsStripSettings.withTranslation("particletrail.trailsstripsettings", "particletrail.trailsstripsettings.desc");
   }
}
