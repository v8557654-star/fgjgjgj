package winvi.noxiumvisuals.modules.particles;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.TotemParticle;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.ParticleManager;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public class TotemParticleModule extends Module {
      public static final List<TotemParticle> particles = new ArrayList<>();
      public static final List<Identifier> h15 = new ArrayList<>();
      public static final Random ui1 = new Random();
      public NumberSetting particlesCount;
      public NumberSetting particlesSpeed;
      public NumberSetting particlesScale;
      public NumberSetting renderTime;
      public MultiSelectSetting textureTypes;
      public BooleanSetting defaultColors;
      public ChoiceSetting physic;
      public ChoiceSetting disappear;
      public final SettingGroup totemSettings;
      public final SettingGroup advancedSettings;
      public final SettingGroup textureSettings;

   public TotemParticleModule() {
      super("Totem Particle", ModuleCategory.PARTICLES);
      this.particlesCount = new NumberSetting(
            "Particles Count",
            "Number of particles"
         )
         .setValue(25.0F)
         .range(5.0F, 45.0F);
      this.particlesCount.withTranslation("totemparticle.particlescount", "totemparticle.particlescount.desc");
      this.particlesSpeed = new NumberSetting(
            "Particles Speed",
            "Particle movement speed"
         )
         .setValue(5.0F)
         .range(1F, 20.0F);
      this.particlesSpeed.withTranslation("totemparticle.particlesspeed", "totemparticle.particlesspeed.desc");
      this.particlesScale = new NumberSetting(
            "Particles Scale",
            "Particle size"
         )
         .setValue(5.0F)
         .range(1F, 10.0F);
      this.particlesScale.withTranslation("totemparticle.particlesscale", "totemparticle.particlesscale.desc");
      this.renderTime = new NumberSetting(
            "Render Time",
            "How long particles last"
         )
         .setValue(1F)
         .range(1F, 10.0F);
      this.renderTime.withTranslation("totemparticle.rendertime", "totemparticle.rendertime.desc");
      this.textureTypes = new MultiSelectSetting(
            "Texture Types",
            "Select particle texture types"
         )
         .value(ParticleTextures.getAvailableParticleTextureNames())
         .selected("Star");
      this.textureTypes.withTranslation("totemparticle.texturetypes", "totemparticle.texturetypes.desc");
      this.defaultColors = new BooleanSetting(
            "Default Colors",
            "Use default totem colors"
         )
         .setValue(true);
      this.defaultColors.withTranslation("totemparticle.defaultcolors", "totemparticle.defaultcolors.desc");
      this.physic = new ChoiceSetting(
            "Physic",
            "Particle physics"
         )
         .value(
            "FLY",
            "BOUNCE"
         )
         .selected("FLY");
      this.physic.withTranslation("totemparticle.physic", "totemparticle.physic.desc");
      this.disappear = new ChoiceSetting(
            "Disappear",
            "How particles disappear"
         )
         .value(
            "ALPHA",
            "SCALE"
         )
         .selected("ALPHA");
      this.disappear.withTranslation("totemparticle.disappear", "totemparticle.disappear.desc");
      this.totemSettings = new SettingGroup(
            "Totem Settings",
            "Totem particle settings"
         )
         .settings(this.particlesCount, this.particlesSpeed, this.particlesScale, this.renderTime)
         .setValue(true);
      this.totemSettings.withTranslation("totemparticle.totemsettings", "totemparticle.totemsettings.desc");
      this.advancedSettings = new SettingGroup(
            "Advanced Settings",
            "Advanced particle settings"
         )
         .settings(this.physic, this.disappear, this.defaultColors)
         .setValue(false);
      this.advancedSettings.withTranslation("totemparticle.advancedsettings", "totemparticle.advancedsettings.desc");
      this.textureSettings = new SettingGroup(
            "Texture Settings",
            "Particle texture settings"
         )
         .settings(this.textureTypes)
         .setValue(true);
      this.textureSettings.withTranslation("totemparticle.texturesettings", "totemparticle.texturesettings.desc");
      this.showVisualColorSettings(() -> {
         return !this.defaultColors.isValue();
      });
      this.setup(new ModuleSetting[]{this.totemSettings, this.advancedSettings, this.textureSettings});
   }

   @EventHandler
      public void onTick(ClientTickEvent e) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null && this.isState()) {
         cnon();
      }
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null && this.isState()) {
         handleMethod55(event.getStack(), event.getPartialTicks());
      }
   }

      public static void cnon() {
      long timestamp = System.currentTimeMillis();
      ParticleManager.updateParticlesInPlace(particles, timestamp);
      byekhc();
   }

      public static void onTotemPop(Entity entity) {
      MinecraftClient client = MinecraftClient.getInstance();
      TotemParticleModule totemParticleModule = NoxiumVisuals.getInstance().getModuleProvider().get(TotemParticleModule.class);
      if (client.player != null && totemParticleModule != null && totemParticleModule.isState() && entity instanceof PlayerEntity) {
         byekhc();
         int index = (int)totemParticleModule.particlesCount.getValue();

         for (int index2 = 0; index2 < index; index2++) {
            particles.add(
               new TotemParticle(
                  (float)entity.getX(),
                  (float)(entity.getY() + entity.getHeight() / 2.0F),
                  (float)entity.getZ(),
                  jpbdkj(0F, 360.0F),
                  jpbdkj(10.0F, 60.0F),
                  totemParticleModule
               )
            );
         }
      }
   }

      public static void handleMethod55(MatrixStack matrixStack, float tickDelta) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null && client.world != null) {
         for (TotemParticle textureMatrixRenderer8 : particles) {
            textureMatrixRenderer8.render(matrixStack, tickDelta);
         }
      }
   }

      public static void byekhc() {
      h15.clear();
      TotemParticleModule totemParticleModule = NoxiumVisuals.getInstance().getModuleProvider().get(TotemParticleModule.class);
      if (totemParticleModule != null) {
         for (String text : totemParticleModule.textureTypes.getSelected()) {
            h15.add(ParticleTextures.getParticleTexture(text));
         }

         if (h15.isEmpty()) {
            h15.add(ParticleTextures.STAR);
         }
      }
   }

      public static float jpbdkj(float min, float max) {
      return min + ui1.nextFloat() * (max - min);
   }

}
