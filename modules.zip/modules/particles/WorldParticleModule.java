package winvi.noxiumvisuals.modules.particles;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.ParticleSpawnData;
import winvi.noxiumvisuals.modules.visuals.ColorRenderRenderer;
import winvi.noxiumvisuals.modules.visuals.WorldParticleSprite;
import winvi.noxiumvisuals.modules.visuals.ParticleModuleType;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.ParticleManager;
import winvi.noxiumvisuals.utils.render.WorldParticleBatcher;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.RenderMath;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public class WorldParticleModule extends Module {
      public static WorldParticleModule oqkjp;
      public static final MinecraftClient manageField91 = MinecraftClient.getInstance();
      public static final float mbxgm = 8.0F;
      public static final float wpmpr = 0.35F;
      public static final float bd = 0.6F;
      public static final float calculateField80 = 0.5F;
      public static final long mlvso = 35L;
      public static final long fbg = 50L;
      public static final long hnsrb = 90L;
      public static final long bcvjm = 50L;
      public static final int fbjm = 4;
      public static final int k14 = 3;
      public static final int zshvs = 2;
      public static final int fbmw = 4;
      public static final List<Identifier> AVAILABLE_TEXTURES = new ArrayList<>();
      public static final ArrayList<WorldParticleSprite> uyung = new ArrayList<>();
      public static final List<WorldParticleSprite> fbob = new ArrayList<>();
      public static final ArrayList<ColorRenderRenderer> fbpp = new ArrayList<>();
      public static boolean q26 = true;
      public static String gmbli = "";
      public static String mprie = "";
      public final Random t19;
      public long u27;
      public long fbvm;
      public long calculateField75;
      public long vekmh;
      public float jnmwc;
      public static final MultiSelectSetting ambientTextureTypes;
      public static final BooleanSetting advancedSettings = new BooleanSetting(
         "Advanced Settings",
         "Show advanced settings"
      )
      .setValue(true);
      public static final BooleanSetting removeOutOfView = new BooleanSetting(
         "Remove Out of View",
         "Remove particles when they are not in field of view"
      )
      .setValue(false);
      public static final NumberSetting removeDelay = new NumberSetting(
         "Remove Delay",
         "Delay in seconds before removing particles out of view"
      )
      .setValue(0.5F)
      .range(0F, 10.0F);
      public static final MultiSelectSetting style;
      public static final ChoiceSetting direction;
      public static final NumberSetting speed = new NumberSetting(
         "Speed",
         "Particle speed multiplier (all particles)"
      )
      .setValue(0.88F)
      .range(0.1F, 5.0F);
      public static final NumberSetting cubeScale = new NumberSetting(
         "Cube Scale",
         "Cube particle scale"
      )
      .setValue(30.0F)
      .range(10.0F, 200.0F);
      public static final NumberSetting cubeGlowAlpha = new NumberSetting(
         "Cube Glow Alpha",
         "Glow texture transparency for cubes"
      )
      .setValue(50.0F)
      .range(0F, 100.0F);
      public static final BooleanSetting cubeDiagonals = new BooleanSetting(
         "Cube Diagonals",
         "Draw diagonal lines on cube faces"
      )
      .setValue(
         true
      );
      public static final BooleanSetting cubeFill = new BooleanSetting(
         "Cube Fill",
         "Fill cubes with color"
      )
      .setValue(false);
      public static final NumberSetting cubeFillAlpha = new NumberSetting(
         "Cube Fill Alpha",
         "Fill transparency"
      )
      .setValue(10.0F)
      .range(0F, 100.0F);
      public static final NumberSetting spawnDistance = new NumberSetting(
         "Spawn Distance",
         "Distance from player to spawn particles"
      )
      .setValue(50.0F)
      .range(5.0F, 50.0F);
      public static final NumberSetting wispScale = new NumberSetting(
         "Wisp Scale",
         "Wisp head and ribbon scale"
      )
      .setValue(70.0F)
      .range(20.0F, 160.0F);
      public static final NumberSetting wispLength = new NumberSetting(
         "Wisp Length",
         "Wisp ribbon length"
      )
      .setValue(10.0F)
      .range(4.0F, 20.0F);
      public static final NumberSetting wispCount = new NumberSetting(
         "Wisp Count",
         "Number of wisp particles"
      )
      .setValue(120.0F)
      .range(10.0F, 300.0F);
      public static final NumberSetting lineCount = new NumberSetting(
         "Line Count",
         "Number of line glyph particles"
      )
      .setValue(300.0F)
      .range(10.0F, 300.0F);
      public static final NumberSetting lineSpeed = new NumberSetting(
         "Line Speed",
         "Line construction speed"
      )
      .setValue(0.88F)
      .range(0.1F, 5.0F);
      public static final NumberSetting particleScale = new NumberSetting(
         "Particle Scale",
         "Particle scale"
      )
      .setValue(120.0F)
      .range(10.0F, 200.0F);
      public static final NumberSetting particleCount = new NumberSetting(
         "Particle Count",
         "Number of regular particles"
      )
      .setValue(300.0F)
      .range(10.0F, 300.0F);
      public static final NumberSetting cubeCount = new NumberSetting(
         "Cube Count",
         "Number of cube particles"
      )
      .setValue(300.0F)
      .range(10.0F, 300.0F);
      public static final NumberSetting particleLifetime = new NumberSetting(
         "Particle Lifetime",
         "Particle lifetime in seconds"
      )
      .setValue(5.0F)
      .range(5.0F, 60.0F);
      public static final NumberSetting maxRenderDistance = new NumberSetting(
         "Render Distance",
         "Maximum distance to render particles"
      )
      .setValue(64.0F)
      .range(16.0F, 64.0F);
      public static final NumberSetting performanceMode = new NumberSetting(
         "Performance",
         "Performance optimization level"
      )
      .setValue(3.0F)
      .range(0F, 3.0F);
      final SettingGroup worldSettings;

   public WorldParticleModule() {
      super("World Particle", ModuleCategory.PARTICLES);
      this.t19 = new Random(93882L);
      this.jnmwc = Float.NaN;
      this.worldSettings = new SettingGroup(
            "World Particle Settings",
            "World particle settings"
         )
         .settings(
            advancedSettings,
            removeOutOfView,
            removeDelay,
            style,
            ambientTextureTypes,
            spawnDistance,
            direction,
            speed,
            maxRenderDistance,
            particleScale,
            particleCount,
            particleLifetime,
            cubeCount,
            cubeScale,
            cubeGlowAlpha,
            cubeDiagonals,
            cubeFill,
            cubeFillAlpha,
            wispScale,
            wispLength,
            wispCount,
            lineCount,
            lineSpeed
         )
         .setValue(true);
      this.showVisualColorSettings();
      oqkjp = this;
      this.setup(new ModuleSetting[]{this.worldSettings});
   }

      @Override
   public String getTranslationPrefix() {
      return "ambientparticles";
   }

      @Override
   public void activate() {
      uyung.clear();
      fbob.clear();
      fbpp.clear();
      q26 = true;
      this.u27 = 0L;
      this.fbvm = 0L;
      this.calculateField75 = 0L;
      this.vekmh = 0L;
      this.jnmwc = Float.NaN;
   }

      @Override
   public void deactivate() {
      uyung.clear();
      fbob.clear();
      fbpp.clear();
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (manageField91.player != null && manageField91.world != null && this.isState()) {
         long timestamp = System.currentTimeMillis();
         ParticleManager.updateParticlesInPlace(uyung, timestamp, WorldParticleSprite::isFrustumVisible);
         String text = ambientTextureTypes.getSelected().toString();
         String text2 = style.getSelected().toString();
         if (q26 || !text.equals(gmbli) || !text2.equals(mprie)) {
            updateAvailableTextures();
            gmbli = text;
            mprie = text2;
            q26 = false;
         }

         if (!style.getSelected().isEmpty()) {
            String text3 = direction.getSelected();
            if (style.isSelected("PARTICLE")) {
               this.gjseak(timestamp, ParticleModuleType.PARTICLE, (int)particleCount.getValue(), 35L, 4, text3);
            }

            if (style.isSelected("CUBE")) {
               this.gjseak(timestamp, ParticleModuleType.CUBE, (int)cubeCount.getValue(), 50L, 3, text3);
            }

            if (style.isSelected("WISP")) {
               this.gjseak(timestamp, ParticleModuleType.WISP, (int)wispCount.getValue(), 90L, 2, text3);
            }

            this.vnddsh(timestamp);
         }
      }
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      iethzl(event);
   }

      public static void render(VertexMatrixRenderer event) {
      WorldParticleModule worldParticleModule = NoxiumVisuals.getInstance().getModuleProvider().get(WorldParticleModule.class);
      if (worldParticleModule != null && worldParticleModule.isState()) {
         iethzl(event);
      }
   }

      public static void iethzl(VertexMatrixRenderer event) {
      if (manageField91.player != null && manageField91.world != null && !style.getSelected().isEmpty()) {
         Vec3d camera = manageField91.gameRenderer.getCamera().getPos();
         float value = votnda(maxRenderDistance.getValue() + 8.0F);
         if (style.isSelected("WISP")
            || style.isSelected("LINES")) {
            WorldParticleBatcher.setLineGlyphMatrix(event.getStack().peek().getPositionMatrix());
            WorldParticleBatcher.setLineGlyphCamera(camera);
         }

         fbob.clear();
         int index = 0;

         for (int index2 = uyung.size(); index < index2; index++) {
            WorldParticleSprite textureMatrixRenderer11 = uyung.get(index);
            if (style.isSelected(textureMatrixRenderer11.getStyle().name()) && textureMatrixRenderer11.shouldRender(camera, value)) {
               fbob.add(textureMatrixRenderer11);
            }
         }

         index = 0;

         for (int index3 = fbob.size(); index < index3; index++) {
            fbob.get(index).queueRender(event);
         }

         jy1(event, camera, value);
      }
   }

      public void gjseak(long currentTime, ParticleModuleType particleStyle, int maxCount, long intervalMs, int burstLimit, String directionValue) {
      if (this.djkt(currentTime, particleStyle, intervalMs)) {
         int index = createMethod3(particleStyle);
         int index2 = Math.min(burstLimit, Math.max(0, maxCount - index));

         for (int index3 = 0; index3 < index2; index3++) {
            uyung.add(parseMethod110(particleStyle, directionValue));
         }
      }
   }

      public boolean djkt(long currentTime, ParticleModuleType particleStyle, long intervalMs) {
      long timestamp = this.createMethod49(particleStyle);
      if (currentTime - timestamp < intervalMs) {
         return false;
      } else {
         this.stopMethod82(particleStyle, currentTime);
         return true;
      }
   }

      public long createMethod49(ParticleModuleType particleStyle) {
      return switch (particleStyle) {
         case PARTICLE -> this.u27;
         case CUBE -> this.fbvm;
         case WISP -> this.calculateField75;
      };
   }

      public void stopMethod82(ParticleModuleType particleStyle, long currentTime) {
      switch (particleStyle) {
         case PARTICLE:
            this.u27 = currentTime;
            break;
         case CUBE:
            this.fbvm = currentTime;
            break;
         case WISP:
            this.calculateField75 = currentTime;
      }
   }

      public static int createMethod3(ParticleModuleType particleStyle) {
      int index = 0;
      int index2 = 0;

      for (int index3 = uyung.size(); index2 < index3; index2++) {
         if (uyung.get(index2).getStyle() == particleStyle) {
            index++;
         }
      }

      return index;
   }

      public static WorldParticleSprite parseMethod110(ParticleModuleType particleStyle, String directionValue) {
      ParticleSpawnData moduleData8 = vparxv(particleStyle, directionValue);
      return new WorldParticleSprite(
         particleStyle,
         (float)moduleData8.position().x,
         (float)moduleData8.position().y,
         (float)moduleData8.position().z,
         moduleData8.velocityX(),
         moduleData8.velocityY(),
         moduleData8.velocityZ()
      );
   }

      public static ParticleSpawnData vparxv(ParticleModuleType particleStyle, String directionValue) {
      return switch (particleStyle) {
         case PARTICLE -> cfkmyk(directionValue);
         case CUBE -> xkxdaj(directionValue);
         case WISP -> removeMethod241();
      };
   }

      public static float jq(float magnitude) {
      return (RenderMath.random(0F, 1F) * 2.0F - 1F) * magnitude;
   }

      public static ParticleSpawnData cfkmyk(String directionValue) {
      Vec3d position = convertMethod10(0.9, 0.35F);
      float value = jq(0.00875F);
      float value2 = qthuuq(directionValue, 0.0175F);
      float value3 = jq(0.00875F);
      return new ParticleSpawnData(position, value, value2, value3);
   }

      public static ParticleSpawnData xkxdaj(String directionValue) {
      Vec3d position = convertMethod10(1, 0.6F);
      float value = jq(0.0045F);
      float value2 = qthuuq(directionValue, 0.0105F);
      float value3 = jq(0.0045F);
      return new ParticleSpawnData(position, value, value2, value3);
   }

      public static ParticleSpawnData removeMethod241() {
      Vec3d position = convertMethod10(1.35, 0.5F);
      double value = RenderMath.random(0F, 1F) * 3.141592653589793 * 2.0;
      double value2 = (RenderMath.random(0F, 1F) - 0.5) * 3.141592653589793 * 0.22;
      float value3 = 0.07F;
      float value4 = (float)(Math.cos(value) * Math.cos(value2) * value3);
      float value5 = (float)(Math.sin(value2) * value3 * 0.44999998807907104);
      float value6 = (float)(Math.sin(value) * Math.cos(value2) * value3);
      return new ParticleSpawnData(position, value4, value5, value6);
   }

      public static Vec3d convertMethod10(double baseYOffset, float heightScale) {
      double value = spawnDistance.getValue();
      double value2 = RenderMath.random(0F, 1F) * 3.141592653589793 * 2.0;
      double value3 = RenderMath.random(0F, 1F) * value;
      double height = (RenderMath.random(0F, 1F) - 0.5) * value * heightScale;
      double x = manageField91.player.getX() + Math.cos(value2) * value3;
      double y = manageField91.player.getY() + baseYOffset + height;
      double z = manageField91.player.getZ() + Math.sin(value2) * value3;
      return new Vec3d(x, y, z);
   }

      public static float qthuuq(String directionValue, float maxMagnitude) {
      if ("UP".equals(directionValue)) {
         return (0.35F + RenderMath.random(0F, 1F) * 0.65F) * maxMagnitude;
      } else {
         return "DOWN".equals(directionValue)
            ? -(0.35F + RenderMath.random(0F, 1F) * 0.65F) * maxMagnitude
            : 0F;
      }
   }

      public static float votnda(float value) {
      return value * value;
   }

      public void vnddsh(long currentTime) {
      if (!style.isSelected("LINES")) {
         fbpp.clear();
         this.vekmh = 0L;
      } else {
         float value = spawnDistance.getValue();
         if (!Float.isNaN(this.jnmwc) && Math.abs(value - this.jnmwc) > 0.001F) {
            fbpp.clear();
         }

         this.jnmwc = value;
         float value2 = Math.max(0.1F, lineSpeed.getValue());
         String text = direction.getSelected();
         int index = 0;
         int index2 = 0;

         for (int index3 = fbpp.size(); index2 < index3; index2++) {
            ColorRenderRenderer colorRenderRenderer = fbpp.get(index2);
            colorRenderRenderer.tick(value2, text);
            if (!colorRenderRenderer.isDead()) {
               fbpp.set(index++, colorRenderRenderer);
            }
         }

         if (index < fbpp.size()) {
            fbpp.subList(index, fbpp.size()).clear();
         }

         index2 = Math.max(1, (int)lineCount.getValue());
         if (fbpp.size() > index2) {
            fbpp.subList(0, fbpp.size() - index2).clear();
         }

         if (currentTime - this.vekmh >= 50L) {
            this.vekmh = currentTime;
            int index4 = Math.min(4, index2 - fbpp.size());

            for (int index5 = 0; index5 < index4; index5++) {
               fbpp.add(this.d21());
            }
         }
      }
   }

      public static void jy1(VertexMatrixRenderer event, Vec3d cameraPos, float extendedMaxDistanceSquared) {
      if (style.isSelected("LINES") && !fbpp.isEmpty()) {
         float value = maxRenderDistance.getValue();
         int index = 0;

         for (int index2 = fbpp.size(); index < index2; index++) {
            ColorRenderRenderer colorRenderRenderer = fbpp.get(index);
            double value2 = colorRenderRenderer.squaredDistanceTo(cameraPos);
            if (!(value2 > extendedMaxDistanceSquared)) {
               int index3 = colorRenderRenderer.fillRenderVertices(event.getPartialTicks());
               if (index3 >= 2) {
                  double value3 = Math.sqrt(value2);
                  float value4 = kc(value3, value);
                  if (!(value4 <= 0F)) {
                     float value5 = dkbt(value3, value);
                     if (!(value5 <= 0F)) {
                        float value6 = colorRenderRenderer.alpha() * value4;
                        goyhwd(colorRenderRenderer.getRenderColors(), index3, value6, index);
                        WorldParticleBatcher.queueLineGlyph(colorRenderRenderer.getRenderVertices(), colorRenderRenderer.getRenderColors(), index3, value5);
                     }
                  }
               }
            }
         }
      }
   }

      public static void goyhwd(int[] colors, int pointCount, float alpha, int seedIndex) {
      int index = seedIndex;

      for (int index2 = 0; index2 < pointCount; index2++) {
         float value = alpha * (0.25F + (float)index2 / pointCount / 1.75F);
         colors[index2] = dka(index, value);
         index += 180;
      }
   }

      public static int dka(int index, float alpha) {
      int index2 = Math.max(0, Math.min(255, (int)(alpha * 255.0F)));
      return index2 <= 0 ? 0 : ColorUtils.replAlpha(isMethod25(), index2);
   }

      public static float dkbt(double distance, float maxDistance) {
      float value = RenderMath.clamp((float)(distance / Math.max(8.0F, maxDistance)), 0F, 1F);
      return 0.018F + 0.045F * value;
   }

      public static float kc(double distance, float maxDistance) {
      float value = Math.max(4.0F, maxDistance - 8.0F);
      if (distance <= value) {
         return 1F;
      } else {
         float value2 = 1F - (float)((distance - value) / Math.max(0.001F, 8.0F));
         return RenderMath.clamp(value2, 0F, 1F);
      }
   }

      public ColorRenderRenderer d21() {
      Vec3d position = convertMethod10(1, 0.35F);
      return new ColorRenderRenderer(
         (int)Math.floor(position.x), (int)Math.floor(position.y), (int)Math.floor(position.z), this.t19.nextInt(6) + 7, this.t19
      );
   }

      public static void updateAvailableTextures() {
      AVAILABLE_TEXTURES.clear();

      for (String text : ambientTextureTypes.getSelected()) {
         AVAILABLE_TEXTURES.add(ParticleTextures.getParticleTexture(text));
      }

      if (AVAILABLE_TEXTURES.isEmpty()) {
         AVAILABLE_TEXTURES.add(ParticleTextures.BLOOM);
      }
   }

      public static int isMethod25() {
      return oqkjp != null ? oqkjp.getVisualColor() : ColorUtils.getVisualColor();
   }

   static {
      int index = 0;
      MultiSelectSetting moduleSettingHandler = new MultiSelectSetting(
            "Texture Types",
            "Select ambient particle texture types"
         )
         .value(ParticleTextures.getAvailableParticleTextureNames());
      String[] stringArray = new String[7];
      stringArray[0] = "Dollar";
      stringArray[1] = "Snowflake";
      stringArray[2] = "Heart";
      stringArray[3] = "Star";
      stringArray[4] = "Lightning";
      stringArray[5] = "Rhombus";
      stringArray[6] = "Crown";
      ambientTextureTypes = moduleSettingHandler.selected(stringArray);
      MultiSelectSetting moduleSettingHandler2 = new MultiSelectSetting(
         "Style",
         "Particle style"
      );
      String[] stringArray2 = new String[4];
      stringArray2[0] = "CUBE";
      stringArray2[1] = "WISP";
      stringArray2[2] = "PARTICLE";
      stringArray2[3] = "LINES";
      MultiSelectSetting moduleSettingHandler3 = moduleSettingHandler2.value(stringArray2);
      String[] stringArray3 = new String[1];
      stringArray3[0] = "PARTICLE";
      style = moduleSettingHandler3.selected(stringArray3);
      ChoiceSetting moduleSettingHandler22 = new ChoiceSetting(
         "Direction",
         "Particle direction (all particles)"
      );
      String[] stringArray4 = new String[3];
      stringArray4[0] = "UP";
      stringArray4[1] = "DOWN";
      stringArray4[2] = "STATIC";
      direction = moduleSettingHandler22.value(stringArray4).selected("STATIC");
      removeOutOfView.visible(() -> {
         return advancedSettings.isValue();
      });
      removeDelay.visible(() -> {
         return advancedSettings.isValue() && removeOutOfView.isValue();
      });
      direction.visible(() -> {
         return !style.getSelected().isEmpty();
      });
      speed.visible(
         () -> {
            return style.isSelected("PARTICLE")
               || style.isSelected("CUBE")
               || style.isSelected("WISP");
         }
      );
      ambientTextureTypes.visible(() -> {
         return style.isSelected("PARTICLE");
      });
      particleScale.visible(() -> {
         return style.isSelected("PARTICLE");
      });
      particleCount.visible(() -> {
         return style.isSelected("PARTICLE");
      });
      cubeCount.visible(() -> {
         return style.isSelected("CUBE");
      });
      cubeScale.visible(() -> {
         return style.isSelected("CUBE") && advancedSettings.isValue();
      });
      cubeGlowAlpha.visible(() -> {
         return style.isSelected("CUBE");
      });
      cubeDiagonals.visible(() -> {
         return style.isSelected("CUBE") && advancedSettings.isValue();
      });
      cubeFill.visible(() -> {
         return false;
      });
      cubeFillAlpha.visible(() -> {
         return false;
      });
      wispScale.visible(() -> {
         return style.isSelected("WISP");
      });
      wispLength.visible(() -> {
         return style.isSelected("WISP");
      });
      wispCount.visible(() -> {
         return style.isSelected("WISP");
      });
      lineCount.visible(() -> {
         return style.isSelected("LINES");
      });
      lineSpeed.visible(() -> {
         return style.isSelected("LINES");
      });
      maxRenderDistance.visible(() -> {
         return advancedSettings.isValue();
      });
   }
}
