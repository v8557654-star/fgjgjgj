package winvi.noxiumvisuals.modules.particles;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.TextureMatrixRenderer;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.ParticleManager;
import winvi.noxiumvisuals.utils.render.RenderMath;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public class BlockParticleModule extends Module {
      public final MultiSelectSetting cvcta;
      public final ChoiceSetting updateField34;
      public final ChoiceSetting deleteField590;
      public final NumberSetting qs0;
      public final NumberSetting qt;
      public final NumberSetting fjnjt;
      public final NumberSetting mcpkx;
      public final SettingGroup dqw;
      public final SettingGroup calculateField81;
      public final SettingGroup handleField42;
      public static final List<TextureMatrixRenderer> particles = new ArrayList<>();
      public final List<Identifier> convertField35;
      public static final Random calculateField350 = new Random();

   public BlockParticleModule() {
      super("Block Particle", ModuleCategory.PARTICLES);
      this.qs0 = new NumberSetting(
            "Count",
            "Particle count"
         )
         .setValue(15.0F)
         .range(5.0F, 25.0F);
      this.qs0.withTranslation("blockparticle.count", "blockparticle.count.desc");
      this.qt = new NumberSetting(
            "Speed",
            "Particle speed"
         )
         .setValue(3.0F)
         .range(1F, 10.0F);
      this.qt.withTranslation("blockparticle.speed", "blockparticle.speed.desc");
      this.fjnjt = new NumberSetting(
            "Live Time",
            "Particle lifetime"
         )
         .setValue(3.0F)
         .range(1F, 5.0F);
      this.fjnjt.withTranslation("blockparticle.rendertime", "blockparticle.rendertime.desc");
      this.mcpkx = new NumberSetting(
            "Scale",
            "Particle size"
         )
         .setValue(4.0F)
         .range(1F, 5.0F);
      this.mcpkx.withTranslation("blockparticle.scale", "blockparticle.scale.desc");
      this.cvcta = new MultiSelectSetting(
            "Texture Types",
            "Select particle texture types"
         )
         .value(ParticleTextures.getAvailableParticleTextureNames())
         .selected("Star");
      this.cvcta.withTranslation("blockparticle.texturetypes", "blockparticle.texturetypes.desc");
      this.updateField34 = new ChoiceSetting(
            "Disappear",
            "Disappear mode"
         )
         .value(
            "ALPHA",
            "SCALE"
         )
         .selected("ALPHA");
      this.updateField34.withTranslation("blockparticle.disappear", "blockparticle.disappear.desc");
      this.deleteField590 = new ChoiceSetting(
            "Physic",
            "Physics mode"
         )
         .value(
            "BOUNCE",
            "FLY"
         )
         .selected("BOUNCE");
      this.deleteField590.withTranslation("blockparticle.physic", "blockparticle.physic.desc");
      this.dqw = new SettingGroup(
            "Particle Settings",
            "Basic particle settings"
         )
         .settings(this.qs0, this.qt, this.fjnjt, this.mcpkx)
         .setValue(true);
      this.dqw.withTranslation("blockparticle.particlesettings", "blockparticle.particlesettings.desc");
      this.calculateField81 = new SettingGroup(
            "Advanced Settings",
            "Advanced particle settings"
         )
         .settings(this.updateField34, this.deleteField590)
         .setValue(false);
      this.calculateField81.withTranslation("blockparticle.advancedsettings", "blockparticle.advancedsettings.desc");
      this.handleField42 = new SettingGroup(
            "Texture Settings",
            "Particle texture settings"
         )
         .settings(this.cvcta)
         .setValue(true);
      this.handleField42.withTranslation("blockparticle.texturesettings", "blockparticle.texturesettings.desc");
      this.convertField35 = new ArrayList<>();
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{this.dqw, this.calculateField81, this.handleField42});
   }

      @Override
   public void deactivate() {
      super.deactivate();
      particles.clear();
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState()) {
         this.render(event.getStack(), event.getPartialTicks());
      }
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (MinecraftClient.getInstance().player != null && this.isState()) {
         long timestamp = System.currentTimeMillis();
         this.cmp();
         ParticleManager.updateParticlesInPlace(particles, timestamp);
      }
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         for (TextureMatrixRenderer textureMatrixRenderer : particles) {
            textureMatrixRenderer.render(matrixStack, tickDelta);
         }
      }
   }

      public void cmp() {
      this.convertField35.clear();

      for (String text : this.cvcta.getSelected()) {
         this.convertField35.add(ParticleTextures.getParticleTexture(text));
      }

      if (this.convertField35.isEmpty()) {
         this.convertField35.add(ParticleTextures.STAR);
      }
   }

      public static void spawnParticles(BlockPos pos) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null && client.world != null) {
         NoxiumVisuals noxiumVisuals = NoxiumVisuals.getInstance();
         if (noxiumVisuals != null) {
            BlockParticleModule blockParticleModule = noxiumVisuals.getModuleProvider().get(BlockParticleModule.class);
            if (blockParticleModule != null && blockParticleModule.isState()) {
               int index = (int)blockParticleModule.qs0.getValue();
               float x = pos.getX() + 0.5F;
               float y = pos.getY() + 1F;
               float z = pos.getZ() + 0.5F;

               for (int index2 = 0; index2 < index; index2++) {
                  List list = particles;
                  Objects.requireNonNull(blockParticleModule);
                  list.add(new TextureMatrixRenderer(blockParticleModule, x, y, z, RenderMath.random(0, 360), RenderMath.random(10.0F, 60.0F)));
               }
            }
         }
      }
   }

   static {
      int index = 0;
   }
}
