package winvi.noxiumvisuals.modules.world;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.BlockPositionModuleManager;
import winvi.noxiumvisuals.modules.visuals.GpsMarkerRenderer;
import winvi.noxiumvisuals.modules.visuals.BlockPositionHandRenderer;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.KeybindSetting;
import winvi.noxiumvisuals.modules.settings.ActionSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.RenderEventData;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.PacketEventProvider;
import winvi.noxiumvisuals.systems.events.TextEventRenderer;
import winvi.noxiumvisuals.systems.events.EventDirection;
import winvi.noxiumvisuals.ui.gui.ClickGuiScreen;
import winvi.noxiumvisuals.utils.JsonFileRenderer;
import winvi.noxiumvisuals.utils.render.PacketRenderRenderer;
public class GPSModule extends Module {
      private static final double computeField23 = 256.0;
      private static final String eyny = World.OVERWORLD.getValue().toString();
      private static final String kvehu = "FT: ";
      private static final Pattern cpwti = Pattern.compile(
      "Метеоритный дождь.*?\\[(-?\\d+)\\s+(\\d+)\\s+(-?\\d+)\\]"
   );
      private static final Pattern parseField630 = Pattern.compile(
      "Вулкан.*?(-?\\d+)\\s+(\\d+)\\s+(-?\\d+)"
   );
      private static final Pattern deleteField330 = Pattern.compile(
      "Маяк убийца.*?(-?\\d+)\\s+(\\d+)\\s+(-?\\d+)"
   );
      private static final Pattern controlField241 = Pattern.compile(
      "Сундук Смерти.*?Появится уже через (\\d+) минут"
   );
      private static final Pattern controlField74 = Pattern.compile(
      "(Портал на резню активирован|Идёт страшный бой)"
   );
      private static BlockPositionHandRenderer eyu;
      public final NumberSetting markerSize;
      public final BooleanSetting showDistance;
      public final BooleanSetting funTimeEvents;
      public final KeybindSetting placeMarkerBind;

   public GPSModule() {
      super("GPS", ModuleCategory.WORLD);
      this.markerSize = new NumberSetting(
            "Marker Size",
            "Size of world marker icons"
         )
         .range(10, 30)
         .setValue(18.0F);
      this.showDistance = new BooleanSetting(
            "Show Distance",
            "Show block distance under markers"
         )
         .setValue(true);
      this.funTimeEvents = new BooleanSetting(
            "FunTime Events",
            "Automatically create GPS markers for FunTime events"
         )
         .setValue(false);
      this.placeMarkerBind = new KeybindSetting(
         "Place Marker",
         "Place GPS marker where you are looking"
      );
      this.showVisualColorSettings();
      this.markerSize.withTranslation("gps.markersize", "gps.markersize.desc");
      this.showDistance.withTranslation("gps.showdistance", "gps.showdistance.desc");
      this.funTimeEvents.withTranslation("gps.funtimeevents", "gps.funtimeevents.desc");
      this.placeMarkerBind.withTranslation("gps.placemarker", "gps.placemarker.desc");
      ActionSetting moduleSettingProvider6 = new ActionSetting(
            "Markers",
            "Open GPS markers in the World tab"
         )
         .setButtonName("Markers")
         .setRunnable(() -> {
            ClickGuiScreen.INSTANCE.openWorldGpsTab();
         });
      moduleSettingProvider6.withTranslation("gps.opengps", "gps.opengps.desc");
      this.setup(new ModuleSetting[]{this.markerSize, this.showDistance, this.funTimeEvents, this.placeMarkerBind, moduleSettingProvider6});
      this.setKey(-1);
   }

   @EventHandler
      public void onDraw(TextEventRenderer event) {
      GpsMarkerRenderer.render(event.getDrawContext(), event.getPartialTicks(), this);
   }

      @Override
   public void onTick() {
      if (eyu != null && (!this.funTimeEvents.isValue() || !PacketRenderRenderer.isFunTime())) {
         this.naouww();
      }
   }

   @EventHandler
      public void onKey(RenderEventData event) {
      if (this.isState() && MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         if (event.isBindDown(this.placeMarkerBind)) {
            BlockPos blockPos = this.isMethod5();
            if (blockPos == null) {
               return;
            }

            String client = MinecraftClient.getInstance().world.getRegistryKey().getValue().toString();
            BlockPositionModuleManager.addMarkerAndSave("", blockPos, client);
         }
      }
   }

   @EventHandler
      public void onPacket(PacketEventProvider event) {
      if (this.isState()
         && event.getType() == EventDirection.RECEIVE
         && this.funTimeEvents.isValue()
         && PacketRenderRenderer.isFunTime()
         && event.getPacket() instanceof GameMessageS2CPacket gameMessageS2CPacket) {
         this.dhx0(gameMessageS2CPacket.content().getString());
      }
   }

      @Override
   public void deactivate() {
      this.naouww();
   }

      private BlockPos isMethod5() {
      HitResult client = MinecraftClient.getInstance().player.raycast(256.0, 1F, false);
      if (client instanceof BlockHitResult blockHitResult && client.getType() == Type.BLOCK) {
         return blockHitResult.getBlockPos();
      } else {
         client = MinecraftClient.getInstance().crosshairTarget;
         return client instanceof BlockHitResult blockHitResult2 && client.getType() == Type.BLOCK ? blockHitResult2.getBlockPos() : null;
      }
   }

      private void dhx0(String message) {
      if (message != null && !message.isBlank()) {
         String text = this.checkMethod80(message);
         Matcher matcher2 = controlField74.matcher(text);
         if (matcher2.find()) {
            this.getMethod640(JsonFileRenderer.get("gps.feedback.eventstarted"));
         } else {
            Matcher matcher3 = controlField241.matcher(text);
            if (matcher3.find()) {
               try {
                  int index = Integer.parseInt(matcher3.group(1));
                  if (index == 3) {
                     this.getMethod640(JsonFileRenderer.get("gps.feedback.deathchest"));
                  }
               } catch (NumberFormatException numberFormatException) {
               }
            } else if (!this.startMethod71(
               text, cpwti, "Метеоритный дождь"
            )) {
               if (!this.startMethod71(text, parseField630, "Вулкан")) {
                  this.startMethod71(text, deleteField330, "Маяк убийца");
               }
            }
         }
      }
   }

      private boolean startMethod71(String message, Pattern pattern, String eventName) {
      Matcher matcher2 = pattern.matcher(message);
      if (!matcher2.find()) {
         return false;
      } else {
         try {
            int index = Integer.parseInt(matcher2.group(1));
            int index2 = Integer.parseInt(matcher2.group(2));
            int index3 = Integer.parseInt(matcher2.group(3));
            this.updateMethod1(index, index2, index3, eventName);
            this.kwmpjz(JsonFileRenderer.get("gps.feedback.markeradded", index, index2, index3, eventName));
         } catch (NumberFormatException numberFormatException) {
         }

         return true;
      }
   }

      private void updateMethod1(int x, int y, int z, String eventName) {
      this.naouww();
      eyu = BlockPositionModuleManager.addMarker("FT: " + eventName, new BlockPos(x, y, z), eyny);
   }

      private void getMethod640(String message) {
      if (eyu != null) {
         this.naouww();
         this.kwmpjz(message);
      }
   }

      private void naouww() {
      if (eyu != null) {
         BlockPositionModuleManager.removeMarker(eyu);
         eyu = null;
      }
   }

      private void kwmpjz(String message) {
      if (MinecraftClient.getInstance().player != null && message != null && !message.isBlank()) {
         MinecraftClient.getInstance().player.sendMessage(Text.literal(message), true);
      }
   }

      private String checkMethod80(String message) {
      return message.replaceAll("\u00a7[0-9a-fk-or]", "")
         .replaceAll("&[0-9a-fk-or]", "")
         .replaceAll("[\\x00-\\x1F\\x7F]", "")
         .replaceAll("\\p{C}", "");
   }

}
