package winvi.noxiumvisuals.modules.world;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.awt.Color;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class SkyColorModule extends Module {
      private static SkyColorModule startField620;
      private final BooleanSetting ezum;
      private final BooleanSetting ezv;
      private final ChoiceSetting lqzwt;
      private final ColorSetting zx0;
      private final BooleanSetting bdpbd;
      private final ChoiceSetting transformField65;
      private final NumberSetting yhhry;
      private final NumberSetting lcngk;
      private final SettingGroup convertField82;
      private final SettingGroup d20;
      private final SettingGroup fae;

   public SkyColorModule() {
      super("Sky Color", ModuleCategory.WORLD);
      startField620 = this;
      this.ezum = new BooleanSetting(
            "Custom Sky",
            "Override the sky color in every dimension"
         )
         .setValue(true);
      this.ezum.withTranslation("skycolor.sky", "skycolor.sky.desc");
      this.bdpbd = new BooleanSetting(
            "Sky Shader",
            "Render the integrated sky shader"
         )
         .setValue(false);
      this.bdpbd.withTranslation("skycolor.shader", "skycolor.shader.desc");
      this.transformField65 = new ChoiceSetting(
            "Shader Style",
            "Sky shader style"
         )
         .value(
            "Nebula",
            "Vortex",
            "Veil",
            "Orb",
            "Cosmos",
            "Galaxy",
            "Clouds"
         )
         .selected("Nebula");
      this.transformField65.withTranslation("skycolor.shaderstyle", "skycolor.shaderstyle.desc");
      this.transformField65.visible(() -> {
         return this.bdpbd.isValue();
      });
      this.yhhry = new NumberSetting(
            "Shader Speed",
            "Sky shader animation speed"
         )
         .setValue(1F)
         .range(0.1F, 3.0F);
      this.yhhry.withTranslation("skycolor.shaderspeed", "skycolor.shaderspeed.desc");
      this.yhhry.visible(() -> {
         return this.bdpbd.isValue() && !this.isCosmosShader();
      });
      this.lcngk = new NumberSetting(
            "Shader Opacity",
            "Sky shader opacity"
         )
         .setValue(65.0F)
         .range(0F, 100.0F);
      this.lcngk.withTranslation("skycolor.shaderopacity", "skycolor.shaderopacity.desc");
      this.lcngk.visible(() -> {
         return this.bdpbd.isValue();
      });
      this.ezv = new BooleanSetting(
            "Custom Clouds",
            "Override cloud color"
         )
         .setValue(false);
      this.ezv.withTranslation("skycolor.clouds", "skycolor.clouds.desc");
      this.lqzwt = new ChoiceSetting(
            "Cloud Mode",
            "Color mode for clouds"
         )
         .value(
            "Visual Color",
            "Custom"
         )
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .selected("Custom");
      this.lqzwt.withTranslation("skycolor.cloudmode", "skycolor.cloudmode.desc");
      this.lqzwt.visible(() -> {
         return this.ezv.isValue();
      });
      this.zx0 = new ColorSetting(
            "Cloud Color",
            "Custom color of the clouds"
         )
         .setColor(-1);
      this.zx0.withTranslation("skycolor.cloudcolor", "skycolor.cloudcolor.desc");
      this.zx0.visible(() -> {
         return this.ezv.isValue() && this.lqzwt.isSelected("Custom");
      });
      this.convertField82 = new SettingGroup(
            "Sky Settings",
            "Configure sky colors"
         )
         .settings(this.ezum)
         .setValue(true);
      this.convertField82.withTranslation("skycolor.skysettings", "skycolor.skysettings.desc");
      this.d20 = new SettingGroup(
            "Shader Settings",
            "Configure the integrated sky shader"
         )
         .settings(this.bdpbd, this.transformField65, this.yhhry, this.lcngk)
         .setValue(false);
      this.d20.withTranslation("skycolor.shadersettings", "skycolor.shadersettings.desc");
      this.fae = new SettingGroup(
            "Cloud Settings",
            "Configure cloud colors"
         )
         .settings(this.ezv, this.lqzwt, this.zx0)
         .setValue(false);
      this.fae.withTranslation("skycolor.cloudsettings", "skycolor.cloudsettings.desc");
      this.showVisualColorSettings(() -> {
         return this.ezum.isValue() || this.bdpbd.isValue();
      });
      this.setup(new ModuleSetting[]{this.convertField82, this.d20, this.fae});
   }

      public static SkyColorModule getInstance() {
      return startField620;
   }

      public boolean shouldOverrideSky() {
      return this.ezum.isValue();
   }

      public int getOverrideSkyColor() {
      return this.stopMethod28();
   }

      public boolean shouldOverrideClouds() {
      return this.ezv.isValue();
   }

      public int getCloudColor() {
      return this.resolveVisualOrCustomColor(this.lqzwt, this.zx0);
   }

      public boolean isSkyShaderEnabled() {
      return this.bdpbd.isValue();
   }

      public boolean isOrbShader() {
      return this.transformField65.isSelected("Orb");
   }

      public boolean isCosmosShader() {
      return this.transformField65.isSelected("Cosmos");
   }

      public boolean isGalaxyShader() {
      return this.transformField65.isSelected("Galaxy");
   }

      public boolean isCloudShader() {
      return this.transformField65.isSelected("Clouds");
   }

      public int getShaderStyleIndex() {
      String text = this.transformField65.getSelected();

      return switch (text) {
         case "Vortex" -> 1;
         case "Veil" -> 2;
         case "Clouds" -> 3;
         default -> 0;
      };
   }

      public float getShaderOpacity() {
      return this.lcngk.getValue() / 100.0F;
   }

      public float getShaderSpeed() {
      return 0.1F * this.yhhry.getValue();
   }

      public float getShaderAnimationSpeed() {
      return this.yhhry.getValue();
   }

      public int getShaderBaseColor() {
      return this.digm();
   }

      public int getShaderAccentColor() {
      return this.dii(this.digm(), 0.08F, 0.12F, 0.18F);
   }

      public int getShaderDeepColor() {
      return this.dii(this.digm(), -0.05F, 0.06F, -0.52F);
   }

      private int stopMethod28() {
      return this.getVisualColor();
   }

      private int digm() {
      return this.stopMethod28();
   }

      private boolean h21() {
      return this.bdpbd != null && this.bdpbd.isValue();
   }

      private int dii(int color, float hueShift, float saturationShift, float brightnessShift) {
      Color color2 = new Color(color, true);
      float[] color3 = Color.RGBtoHSB(color2.getRed(), color2.getGreen(), color2.getBlue(), null);
      float value = (color3[0] + hueShift) % 1F;
      if (value < 0F) {
         value++;
      }

      float value2 = this.computeMethod83(color3[1] + saturationShift);
      float value3 = this.computeMethod83(color3[2] + brightnessShift);
      int color4 = Color.HSBtoRGB(value, value2, value3);
      return color2.getAlpha() << 24 | color4 & 16777215;
   }

      private float computeMethod83(float value) {
      return Math.max(0F, Math.min(1F, value));
   }

}
