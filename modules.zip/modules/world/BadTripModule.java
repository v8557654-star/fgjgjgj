package winvi.noxiumvisuals.modules.world;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.ModuleSettingProvider;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.AttackEntityEvent;
import winvi.noxiumvisuals.systems.events.LivingEntityScaleEvent;
public class BadTripModule extends Module {
      private final ChoiceSetting g22;
      private final NumberSetting exht;
      private final NumberSetting exih;
      private final NumberSetting exjq;
      private final BooleanSetting k13;
      private final Map<Integer, ModuleSettingProvider> l13;
      private String xm;

   public BadTripModule() {
      super("Bad Trip", ModuleCategory.WORLD);
      this.l13 = new ConcurrentHashMap<>();
      this.xm = "On Attack";
      this.g22 = new ChoiceSetting(
            "Mode",
            "Effect trigger mode"
         )
         .value(
            "On Attack",
            "Always"
         )
         .selected("On Attack");
      this.g22.withTranslation("badtrip.mode", "badtrip.mode.desc");
      this.exht = new NumberSetting(
            "Effect Intensity",
            "Intensity of the squish effect"
         )
         .setValue(0.8F)
         .range(0.1F, 2.0F);
      this.exht.withTranslation("badtrip.intensity", "badtrip.intensity.desc");
      this.exih = new NumberSetting(
            "Effect Duration",
            "Duration of the effect in ticks"
         )
         .setValue(60.0F)
         .range(20, 200);
      this.exih.withTranslation("badtrip.duration", "badtrip.duration.desc");
      this.exjq = new NumberSetting(
            "Animation Speed",
            "Speed of the animation"
         )
         .setValue(1F)
         .range(0.1F, 5.0F);
      this.exjq.withTranslation("badtrip.speed", "badtrip.speed.desc");
      this.k13 = new BooleanSetting(
            "Only Players",
            "Only apply effect to players"
         )
         .setValue(true);
      this.k13.withTranslation("badtrip.onlyplayers", "badtrip.onlyplayers.desc");
      this.setup(new ModuleSetting[]{this.g22, this.exht, this.exih, this.exjq, this.k13});
   }

      @Override
   public void deactivate() {
      super.deactivate();
      this.l13.clear();
   }

   @EventHandler
      public void onAttack(AttackEntityEvent event) {
      if (!this.kblcyu()) {
         if (this.g22.isSelected("On Attack")) {
            if (MinecraftClient.getInstance().world != null && event.getEntity() != null) {
               if (event.getEntity() instanceof LivingEntity livingEntity && (!this.k13.isValue() || livingEntity instanceof PlayerEntity)) {
                  this.l13.put(livingEntity.getId(), new ModuleSettingProvider((int)this.exih.getValue(), this.exht.getValue(), this.exjq.getValue()));
               }
            }
         }
      }
   }

   @EventHandler
      public void onBadTripRender(LivingEntityScaleEvent event) {
      if (this.kblcyu()) {
         this.l13.clear();
      } else if (MinecraftClient.getInstance().world != null && event.getEntity() != null) {
         if (!this.g22.getSelected().equals(this.xm)) {
            this.l13.clear();
            this.xm = this.g22.getSelected();
         }

         if (this.g22.isSelected("Always")) {
            if (this.k13.isValue() && !(event.getEntity() instanceof PlayerEntity)) {
               return;
            }

            int index = event.getEntity().getId();
            ModuleSettingProvider moduleSettingProvider = this.l13.get(index);
            if (moduleSettingProvider == null || moduleSettingProvider.needsUpdate(this.exht.getValue(), (int)this.exih.getValue(), this.exjq.getValue())) {
               moduleSettingProvider = new ModuleSettingProvider((int)this.exih.getValue(), this.exht.getValue(), this.exjq.getValue(), true);
               this.l13.put(index, moduleSettingProvider);
            }

            moduleSettingProvider.update();
            float value = moduleSettingProvider.getCurrentScale();
            event.setScaleX(2.0F - value);
            event.setScaleY(value);
            event.setScaleZ(2.0F - value);
         } else {
            ModuleSettingProvider moduleSettingProvider2 = this.l13.get(event.getEntity().getId());
            if (moduleSettingProvider2 != null) {
               if (moduleSettingProvider2.needsUpdate(this.exht.getValue(), (int)this.exih.getValue(), this.exjq.getValue())) {
                  moduleSettingProvider2.updateSettings(this.exht.getValue(), (int)this.exih.getValue(), this.exjq.getValue());
               }

               if (!moduleSettingProvider2.isFinished()) {
                  moduleSettingProvider2.update();
                  float value2 = moduleSettingProvider2.getCurrentScale();
                  event.setScaleX(2.0F - value2);
                  event.setScaleY(value2);
                  event.setScaleZ(2.0F - value2);
               }

               if (moduleSettingProvider2.isFinished()) {
                  this.l13.remove(event.getEntity().getId());
               }
            }
         }
      }
   }

      private boolean kblcyu() {
      if (MinecraftClient.getInstance().getNetworkHandler() != null && MinecraftClient.getInstance().getNetworkHandler().getServerInfo() != null) {
         String client = MinecraftClient.getInstance().getNetworkHandler().getServerInfo().address;
         if (client != null && !client.isEmpty()) {
            String text = client.toLowerCase();
            int index = text.indexOf(58);
            if (index >= 0) {
               text = text.substring(0, index);
            }

            for (String text2 : text.split("\\.")) {
               if ("funtime".equals(text2)) {
                  return true;
               }
            }

            return false;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

}
