package winvi.noxiumvisuals.modules.world;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
public class CrystalColorModule extends Module {

   public CrystalColorModule() {
      super("CrystalColor", ModuleCategory.WORLD);
      this.showVisualColorSettings();
   }

      public int getCrystalColor() {
      return this.getVisualColor();
   }

}
