package winvi.noxiumvisuals.modules.world;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ColorEventProvider;
public class CustomFogModule extends Module {
      private final NumberSetting parseField640;
      private final BooleanSetting updateField61;
      private final NumberSetting runField271;
      private final NumberSetting cxsex;
      private final BooleanSetting wjfsg;

   public CustomFogModule() {
      super("Custom Fog", ModuleCategory.WORLD);
      this.showVisualColorSettings();
      this.parseField640 = new NumberSetting(
            "Distance",
            "Fog render distance"
         )
         .setValue(100.0F)
         .range(0F, 200.0F);
      this.parseField640.withTranslation("customfog.distance", "customfog.distance.desc");
      this.updateField61 = new BooleanSetting(
            "Fog Blur",
            "Apply a blur shader to distant fog"
         )
         .setValue(false);
      this.updateField61.withTranslation("customfog.fogblur", "customfog.fogblur.desc");
      this.runField271 = new NumberSetting(
            "Strength",
            "Fog blur strength"
         )
         .setValue(6.0F)
         .range(1F, 20.0F)
         .visible(this.updateField61::isValue);
      this.runField271.withTranslation("customfog.strength", "customfog.strength.desc");
      this.cxsex = new NumberSetting(
            "Opacity",
            "Fog shader opacity"
         )
         .setValue(100.0F)
         .range(0F, 100.0F)
         .visible(this.updateField61::isValue);
      this.cxsex.withTranslation("customfog.opacity", "customfog.opacity.desc");
      this.wjfsg = new BooleanSetting(
            "Linear Sampling",
            "Use linear gaussian sampling"
         )
         .setValue(true)
         .visible(this.updateField61::isValue);
      this.wjfsg.withTranslation("customfog.linearsampling", "customfog.linearsampling.desc");
      this.setup(new ModuleSetting[]{this.parseField640, this.updateField61, this.runField271, this.cxsex, this.wjfsg});
   }

   @EventHandler
      public void onFog(ColorEventProvider e) {
      if (this.isState()) {
         e.setDistance(this.parseField640.getValue());
         e.setColor(this.getVisualColor());
         e.cancel();
      }
   }

      public boolean isFogBlurEnabled() {
      return this.updateField61.isValue();
   }

      public float getFogBlurStrength() {
      return this.runField271.getValue();
   }

      public float getFogBlurDistance() {
      return this.parseField640.getValue();
   }

      public float getFogBlurOpacity() {
      return this.cxsex.getValue() / 100.0F;
   }

      public boolean isFogBlurLinearSampling() {
      return this.wjfsg.isValue();
   }

   static {
      int index = 0;
   }
}
