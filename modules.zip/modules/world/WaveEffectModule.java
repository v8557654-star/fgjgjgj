package winvi.noxiumvisuals.modules.world;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.WavePropagation;
import winvi.noxiumvisuals.modules.visuals.VisibleBlockCell;
import winvi.noxiumvisuals.modules.visuals.BlockPositionRenderRenderer;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.utils.ClientEasing;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.WorldToScreen;
import winvi.noxiumvisuals.utils.render.ShaderRegistry;
import winvi.noxiumvisuals.utils.render.ParticleOutlineShader;
import winvi.noxiumvisuals.utils.render.FractalOutlineShader;
import winvi.noxiumvisuals.utils.render.PlasmaOutlineShader;
import winvi.noxiumvisuals.utils.render.TunnelOutlineShader;
import winvi.noxiumvisuals.utils.render.AudioOutlineShader;
import winvi.noxiumvisuals.utils.render.WaveOutlineShader;
import winvi.noxiumvisuals.utils.render.BaseShaderRenderer;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
import winvi.noxiumvisuals.utils.render.RenderStateGuard;
public class WaveEffectModule extends Module {
      private final List<WavePropagation> abmpb;
      private final List<BlockPositionRenderRenderer> btjvv;
      private final Long2ObjectOpenHashMap<BlockPositionRenderRenderer> computeField381;
      private final Matrix4f controlField170;
      private boolean executeField24;
      private final BooleanSetting alntf;
      private final BooleanSetting createField45;
      private final BooleanSetting manageField14;
      private final NumberSetting fan;
      private final NumberSetting createField560;
      private final NumberSetting fap;
      private final NumberSetting formatField41;
      private final ChoiceSetting far;
      private final BooleanSetting lxwba;
      private final BooleanSetting calculateField280;
      private final ChoiceSetting validateField72;
      private final NumberSetting vkjek;
      private final NumberSetting hbspv;
      static final float WAVE_WIDTH = 1.5F;
      static final int MAX_WAVES = 2;
      static final int MAX_WAVE_CELLS = 6000;
      static final int MAX_COLUMN_DEPTH = 6;
      static final double WAVE_FILL_Y_OFFSET = 0.0035;
      static final double WAVE_FILL_XZ_OFFSET = 0.0025;
      static final double FRUSTUM_CULL_EXPAND = 0.12;
      private float ssqvk;
      private long fayi;

   public WaveEffectModule() {
      super("WaveEffect", ModuleCategory.WORLD);
      this.abmpb = new ArrayList<>();
      this.btjvv = new ArrayList<>();
      this.computeField381 = new Long2ObjectOpenHashMap();
      this.controlField170 = new Matrix4f();
      this.executeField24 = true;
      this.ssqvk = 0F;
      this.fayi = System.nanoTime();
      this.alntf = new BooleanSetting(
            "On GUI Open",
            "Activate wave when opening GUI"
         )
         .setValue(true);
      this.alntf.withTranslation("waveeffect.onguiopen", "waveeffect.onguiopen.desc");
      this.createField45 = new BooleanSetting(
            "On Jump",
            "Activate wave when jumping"
         )
         .setValue(false);
      this.createField45.withTranslation("waveeffect.onjump", "waveeffect.onjump.desc");
      this.manageField14 = new BooleanSetting(
            "On Hit",
            "Activate wave when hitting entity"
         )
         .setValue(false);
      this.manageField14.withTranslation("waveeffect.onhit", "waveeffect.onhit.desc");
      this.fan = new NumberSetting(
            "Wave Radius",
            "Maximum wave radius in blocks"
         )
         .setValue(30.0F)
         .range(10.0F, 50.0F);
      this.fan.withTranslation("waveeffect.waveradius", "waveeffect.waveradius.desc");
      this.createField560 = new NumberSetting(
            "Wave Speed",
            "Wave expansion speed"
         )
         .setValue(1F)
         .range(0.5F, 3.0F);
      this.createField560.withTranslation("waveeffect.wavespeed", "waveeffect.wavespeed.desc");
      this.fap = new NumberSetting(
            "Up Distance",
            "How many blocks to check upwards"
         )
         .setValue(0F)
         .range(0F, 10.0F);
      this.fap.withTranslation("waveeffect.updistance", "waveeffect.updistance.desc");
      this.formatField41 = new NumberSetting(
            "Down Distance",
            "How many blocks to check downwards"
         )
         .setValue(10.0F)
         .range(0F, 20.0F);
      this.formatField41.withTranslation("waveeffect.downdistance", "waveeffect.downdistance.desc");
      this.far = new ChoiceSetting(
            "Fill Mode",
            "Number of filled faces"
         )
         .value(
            "1 Face",
            "4 Faces"
         )
         .selected("1 Face");
      this.far.withTranslation("waveeffect.fillmode", "waveeffect.fillmode.desc");
      this.lxwba = new BooleanSetting(
            "Use Shader",
            "Use shader effect"
         )
         .setValue(false);
      this.lxwba.withTranslation("waveeffect.useshader", "waveeffect.useshader.desc");
      this.calculateField280 = new BooleanSetting(
            "Draw Outline",
            "Draw outline around blocks"
         )
         .setValue(true)
         .visible(() -> {
            return this.lxwba.isValue();
         });
      this.calculateField280.withTranslation("waveeffect.drawoutline", "waveeffect.drawoutline.desc");
      this.validateField72 = new ChoiceSetting(
            "Shader Type",
            "Shader effect type"
         )
         .value(
            "Wave",
            "Plasma",
            "Fractal",
            "Tunnel",
            "Particles"
         )
         .visible(() -> {
            return this.lxwba.isValue();
         });
      this.validateField72.withTranslation("waveeffect.shadertype", "waveeffect.shadertype.desc");
      this.vkjek = new NumberSetting(
            "Shader Speed",
            "Shader animation speed"
         )
         .setValue(1F)
         .range(0.1F, 5.0F)
         .visible(() -> {
            return this.lxwba.isValue();
         });
      this.vkjek.withTranslation("waveeffect.cloudspeed", "waveeffect.cloudspeed.desc");
      this.hbspv = new NumberSetting(
            "Shader Scale",
            "Shader pattern scale"
         )
         .setValue(1F)
         .range(0.1F, 10.0F)
         .visible(() -> {
            return this.lxwba.isValue();
         });
      this.hbspv.withTranslation("waveeffect.cloudscale", "waveeffect.cloudscale.desc");
      this.showVisualColorSettings();
      this.setState(true);
      this.setup(
         new ModuleSetting[]{
            this.alntf,
            this.createField45,
            this.manageField14,
            this.fan,
            this.createField560,
            this.fap,
            this.formatField41,
            this.far,
            this.lxwba,
            this.calculateField280,
            this.validateField72,
            this.vkjek,
            this.hbspv
         }
      );
   }

      public void show() {
      if (this.isState() && this.alntf.isValue() && MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         this.handleMethod480();
      }
   }

      public void checkJump() {
      if (this.isState()
         && this.createField45.isValue()
         && MinecraftClient.getInstance().player != null
         && MinecraftClient.getInstance().world != null) {
         boolean client = MinecraftClient.getInstance().player.isOnGround();
         if (this.executeField24 && !client && MinecraftClient.getInstance().options.jumpKey.isPressed()) {
            this.handleMethod480();
         }

         this.executeField24 = client;
      }
   }

      public void triggerOnHit() {
      if (this.isState()
         && this.manageField14.isValue()
         && MinecraftClient.getInstance().player != null
         && MinecraftClient.getInstance().world != null) {
         this.handleMethod480();
      }
   }

      private void handleMethod480() {
      if (this.abmpb.size() >= 2) {
         int index = this.abmpb.size() - 2 + 1;
         this.abmpb.subList(0, index).clear();
      }

      Vec3d client = MinecraftClient.getInstance().player.getPos();
      List list = this.im(client);
      WavePropagation animationModuleSupport2 = new WavePropagation(client, list);
      double value = this.fan.getValue() / (15.0 * this.createField560.getValue());
      animationModuleSupport2.animation.set(0);
      animationModuleSupport2.animation.run(1, value, ClientEasing.EASE_OUT_CUBIC);
      this.abmpb.add(animationModuleSupport2);
   }

      public void hide() {
      if (this.alntf.isValue()) {
         for (WavePropagation animationModuleSupport2 : this.abmpb) {
            animationModuleSupport2.active = false;
            animationModuleSupport2.animation.run(0, 0.3, ClientEasing.EASE_IN_CUBIC);
         }
      }
   }

      public boolean isWaveActive() {
      return this.isState() && !this.abmpb.isEmpty();
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      this.checkJump();
   }

      public void render(MatrixStack matrices, float tickDelta) {
      if (this.isWaveActive() && MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         long timestamp = System.nanoTime();
         float value = (float)(timestamp - this.fayi) / 1E9F;
         this.fayi = timestamp;
         this.ssqvk += value * 20.0F;
         Iterator iterator2 = this.abmpb.iterator();

         while (iterator2.hasNext()) {
            WavePropagation animationModuleSupport2 = (WavePropagation)iterator2.next();
            animationModuleSupport2.animation.update();
            if (animationModuleSupport2.animation.get() <= 0.01F && !animationModuleSupport2.active) {
               iterator2.remove();
            } else {
               this.l15(animationModuleSupport2, matrices);
            }
         }
      }
   }

      private void l15(WavePropagation wave, MatrixStack matrices) {
      float value = wave.animation.get();
      float value2 = this.fan.getValue();
      float value3 = value2 * value;
      float value4 = 1F;
      if (value > 0.8F) {
         value4 = 1F - (value - 0.8F) / 0.2F;
      }

      Color color = new Color(this.getVisualColor(), true);
      int index = (int)(150.0F * value4);
      int color2 = ColorUtils.getColor(color.getRed(), color.getGreen(), color.getBlue(), index);
      int index2 = ColorUtils.multAlpha(color2, 0.3F);
      boolean enabled = this.far.isSelected("4 Faces");
      float value5 = Math.max(0F, value3 - 1.5F - 0.1F);
      float value6 = value3 + 1.5F + 0.1F;
      double value7 = value5 * value5;
      double value8 = value6 * value6;
      List list = this.iqvbbg(wave, value7, value8);
      if (!list.isEmpty()) {
         Long2ObjectOpenHashMap long2ObjectOpenHashMap = this.disl(list);
         if (this.lxwba.isValue()) {
            this.jdquaz(list, long2ObjectOpenHashMap, color2, matrices, enabled);
            if (this.calculateField280.isValue()) {
               this.getMethod87(list, long2ObjectOpenHashMap, color2, enabled);
            }
         } else {
            this.t18(list, long2ObjectOpenHashMap, index2, enabled);
            this.getMethod87(list, long2ObjectOpenHashMap, color2, enabled);
         }
      }
   }

      private List<VisibleBlockCell> im(Vec3d origin) {
      int index = (int)(this.fan.getValue() + 2.0F);
      double value = this.fan.getValue() + 1.5F + 1F;
      double value2 = value * value;
      int index2 = (int)this.fap.getValue();
      int index3 = (int)this.formatField41.getValue();
      BlockPos blockPos = BlockPos.ofFloored(origin);
      Mutable mutable = new Mutable();
      ArrayList arrayList = new ArrayList();

      for (int index4 = -index; index4 <= index; index4++) {
         for (int index5 = -index; index5 <= index; index5++) {
            double x2 = blockPos.getX() + index4 + 0.5;
            double z2 = blockPos.getZ() + index5 + 0.5;
            double value3 = origin.x - x2;
            double value4 = origin.z - z2;
            if (!(value3 * value3 + value4 * value4 > value2)) {
               BlockPos blockPos2 = this.dino(blockPos, index4, index5, index2, index3, mutable);
               if (blockPos2 != null) {
                  int index6 = this.io1(blockPos2, index3, mutable);
                  BlockPositionRenderRenderer blockPositionRenderRenderer = this.dipj(blockPos2, index6);
                  if (blockPositionRenderRenderer != null) {
                     double value5 = (blockPositionRenderRenderer.outlineBox.minX + blockPositionRenderRenderer.outlineBox.maxX) * 0.5;
                     double value6 = (blockPositionRenderRenderer.outlineBox.minZ + blockPositionRenderRenderer.outlineBox.maxZ) * 0.5;
                     double value7 = origin.x - value5;
                     double value8 = origin.z - value6;
                     arrayList.add(new VisibleBlockCell(blockPositionRenderRenderer, value7 * value7 + value8 * value8));
                     if (arrayList.size() >= 6000) {
                        return arrayList;
                     }
                  }
               }
            }
         }
      }

      return arrayList;
   }

      private BlockPos dino(BlockPos originPos, int offsetX, int offsetZ, int upDist, int downDist, Mutable checkPos) {
      int x = originPos.getX() + offsetX;
      int z = originPos.getZ() + offsetZ;
      int y = originPos.getY();

      for (int index = upDist; index >= -downDist; index--) {
         checkPos.set(x, y + index, z);
         BlockState client = MinecraftClient.getInstance().world.getBlockState(checkPos);
         if (!client.isAir()) {
            VoxelShape client2 = client.getCollisionShape(MinecraftClient.getInstance().world, checkPos);
            if (!client2.isEmpty()) {
               return checkPos.toImmutable();
            }
         }
      }

      return null;
   }

      private int io1(BlockPos topBlock, int downDist, Mutable checkPos) {
      int x = topBlock.getX();
      int z = topBlock.getZ();
      int y = Math.max(MinecraftClient.getInstance().world.getBottomY(), topBlock.getY() - downDist);
      int y2 = topBlock.getY();
      int index = 1;

      for (int y3 = topBlock.getY() - 1; y3 >= y && index < 6; y3--) {
         checkPos.set(x, y3, z);
         BlockState client = MinecraftClient.getInstance().world.getBlockState(checkPos);
         if (client.isAir()) {
            break;
         }

         VoxelShape client2 = client.getCollisionShape(MinecraftClient.getInstance().world, checkPos);
         if (client2.isEmpty()) {
            break;
         }

         y2 = y3;
         index++;
      }

      return y2;
   }

      private BlockPositionRenderRenderer dipj(BlockPos topBlock, int minY) {
      BlockPositionRenderRenderer blockPositionRenderRenderer = this.fmcfcr(topBlock);
      if (blockPositionRenderRenderer == null) {
         return null;
      } else if (minY >= topBlock.getY()) {
         return blockPositionRenderRenderer;
      } else {
         Box box = blockPositionRenderRenderer.outlineBox;
         Box box2 = new Box(box.minX, minY, box.minZ, box.maxX, box.maxY, box.maxZ);
         return new BlockPositionRenderRenderer(blockPositionRenderRenderer.blockPos, box2, blockPositionRenderRenderer.renderBox);
      }
   }

      private List<BlockPositionRenderRenderer> iqvbbg(WavePropagation wave, double innerRadiusSq, double outerRadiusSq) {
      boolean client = MinecraftClient.getInstance().worldRenderer != null && MinecraftClient.getInstance().worldRenderer.frustum != null;
      this.btjvv.clear();
      int index = 0;

      for (int index2 = wave.cachedCells.size(); index < index2; index++) {
         VisibleBlockCell moduleSupport6 = wave.cachedCells.get(index);
         if (!(moduleSupport6.distanceSq < innerRadiusSq) && !(moduleSupport6.distanceSq > outerRadiusSq) && (!client || WorldToScreen.canSee(moduleSupport6.cell.cullBox))) {
            this.btjvv.add(moduleSupport6.cell);
         }
      }

      return this.btjvv;
   }

      private BlockPositionRenderRenderer fmcfcr(BlockPos blockPos) {
      VoxelShape client = MinecraftClient.getInstance().world.getBlockState(blockPos).getOutlineShape(MinecraftClient.getInstance().world, blockPos);
      if (client.isEmpty()) {
         return null;
      } else {
         Box box = client.getBoundingBox().offset(blockPos);
         return !(box.getLengthX() <= 1E-4) && !(box.getLengthY() <= 1E-4) && !(box.getLengthZ() <= 1E-4)
            ? new BlockPositionRenderRenderer(blockPos.toImmutable(), box, box)
            : null;
      }
   }

      private Long2ObjectOpenHashMap<BlockPositionRenderRenderer> disl(List<BlockPositionRenderRenderer> cells) {
      this.computeField381.clear();

      for (BlockPositionRenderRenderer blockPositionRenderRenderer : cells) {
         this.computeField381.put(blockPositionRenderRenderer.blockPos.asLong(), blockPositionRenderRenderer);
      }

      return this.computeField381;
   }

      private void t18(List<BlockPositionRenderRenderer> cells, Long2ObjectOpenHashMap<BlockPositionRenderRenderer> cellMap, int fillColor, boolean renderAllFaces) {
      for (BlockPositionRenderRenderer blockPositionRenderRenderer : cells) {
         this.rxqdse(blockPositionRenderRenderer.renderBox, fillColor);
         if (renderAllFaces) {
            this.eacukb(blockPositionRenderRenderer, cellMap, fillColor);
         }
      }
   }

      private void rxqdse(Box box, int fillColor) {
      double value = box.minX - 0.0025;
      double value2 = box.maxX + 0.0025;
      double value3 = box.minZ - 0.0025;
      double value4 = box.maxZ + 0.0025;
      double value5 = box.maxY + 0.0035;
      WorldShapeRenderer.drawQuad(value, value5, value3, value2, value5, value3, value2, value5, value4, value, value5, value4, fillColor, true);
   }

      private void eacukb(BlockPositionRenderRenderer cell, Long2ObjectOpenHashMap<BlockPositionRenderRenderer> cellMap, int fillColor) {
      Box box = cell.outlineBox;
      this.diw(
         cell, (BlockPositionRenderRenderer)cellMap.get(ppsnbz(cell.blockPos, 0, -1)), fillColor, box.minX, box.maxX, box.minZ, box.minZ
      );
      this.diw(
         cell, (BlockPositionRenderRenderer)cellMap.get(ppsnbz(cell.blockPos, 1, 0)), fillColor, box.maxX, box.maxX, box.minZ, box.maxZ
      );
      this.diw(
         cell, (BlockPositionRenderRenderer)cellMap.get(ppsnbz(cell.blockPos, 0, 1)), fillColor, box.maxX, box.minX, box.maxZ, box.maxZ
      );
      this.diw(
         cell, (BlockPositionRenderRenderer)cellMap.get(ppsnbz(cell.blockPos, -1, 0)), fillColor, box.minX, box.minX, box.maxZ, box.minZ
      );
   }

      private void diw(BlockPositionRenderRenderer current, BlockPositionRenderRenderer neighbor, int fillColor, double x1, double x2, double z1, double z2) {
      if (this.djaq(current, neighbor)) {
         double value = this.hasMethod29(current, neighbor);
         double value2 = current.outlineBox.maxY + 0.0035;
         if (!(value2 - value <= 0.001)) {
            double value3 = (current.outlineBox.minX + current.outlineBox.maxX) * 0.5;
            double value4 = (current.outlineBox.minZ + current.outlineBox.maxZ) * 0.5;
            if (Math.abs(x1 - x2) < 1E-6) {
               double value5 = x1 >= value3 ? 0.0025 : -0.0025F;
               x1 += value5;
               x2 += value5;
               z1 -= 0.0025;
               z2 += 0.0025;
            } else if (Math.abs(z1 - z2) < 1E-6) {
               double value6 = z1 >= value4 ? 0.0025 : -0.0025F;
               z1 += value6;
               z2 += value6;
               x1 -= 0.0025;
               x2 += 0.0025;
            }

            WorldShapeRenderer.drawQuad(x1, value, z1, x2, value, z2, x2, value2, z2, x1, value2, z1, fillColor, true);
         }
      }
   }

      private void getMethod87(List<BlockPositionRenderRenderer> cells, Long2ObjectOpenHashMap<BlockPositionRenderRenderer> cellMap, int color, boolean renderSideOutline) {
      for (BlockPositionRenderRenderer blockPositionRenderRenderer : cells) {
         Box box = blockPositionRenderRenderer.outlineBox;
         this.handleMethod61(
            blockPositionRenderRenderer,
            (BlockPositionRenderRenderer)cellMap.get(ppsnbz(blockPositionRenderRenderer.blockPos, 0, -1)),
            color,
            renderSideOutline,
            box.minX,
            box.minZ,
            box.maxX,
            box.minZ
         );
         this.handleMethod61(
            blockPositionRenderRenderer,
            (BlockPositionRenderRenderer)cellMap.get(ppsnbz(blockPositionRenderRenderer.blockPos, 1, 0)),
            color,
            renderSideOutline,
            box.maxX,
            box.minZ,
            box.maxX,
            box.maxZ
         );
         this.handleMethod61(
            blockPositionRenderRenderer,
            (BlockPositionRenderRenderer)cellMap.get(ppsnbz(blockPositionRenderRenderer.blockPos, 0, 1)),
            color,
            renderSideOutline,
            box.maxX,
            box.maxZ,
            box.minX,
            box.maxZ
         );
         this.handleMethod61(
            blockPositionRenderRenderer,
            (BlockPositionRenderRenderer)cellMap.get(ppsnbz(blockPositionRenderRenderer.blockPos, -1, 0)),
            color,
            renderSideOutline,
            box.minX,
            box.maxZ,
            box.minX,
            box.minZ
         );
      }
   }

      private static long ppsnbz(BlockPos pos, int offsetX, int offsetZ) {
      return BlockPos.asLong(pos.getX() + offsetX, pos.getY(), pos.getZ() + offsetZ);
   }

      private void handleMethod61(
      BlockPositionRenderRenderer current, BlockPositionRenderRenderer neighbor, int color, boolean renderSideOutline, double x1, double z1, double x2, double z2
   ) {
      if (this.djaq(current, neighbor)) {
         double value = (current.outlineBox.minX + current.outlineBox.maxX) * 0.5;
         double value2 = (current.outlineBox.minZ + current.outlineBox.maxZ) * 0.5;
         if (Math.abs(x1 - x2) < 1E-6) {
            double value3 = x1 >= value ? 0.0025 : -0.0025F;
            x1 += value3;
            x2 += value3;
         } else if (Math.abs(z1 - z2) < 1E-6) {
            double value4 = z1 >= value2 ? 0.0025 : -0.0025F;
            z1 += value4;
            z2 += value4;
         }

         double value5 = current.outlineBox.maxY + 0.0035;
         WorldShapeRenderer.drawLine(null, x1, value5, z1, x2, value5, z2, color, 2.0F, true);
         if (renderSideOutline) {
            double value6 = this.hasMethod29(current, neighbor);
            if (!(value5 - value6 <= 0.001)) {
               WorldShapeRenderer.drawLine(null, x1, value6, z1, x1, value5, z1, color, 2.0F, true);
               WorldShapeRenderer.drawLine(null, x2, value6, z2, x2, value5, z2, color, 2.0F, true);
            }
         }
      }
   }

      private boolean djaq(BlockPositionRenderRenderer current, BlockPositionRenderRenderer neighbor) {
      return neighbor == null || neighbor.outlineBox.maxY < current.outlineBox.maxY - 0.001;
   }

      private double hasMethod29(BlockPositionRenderRenderer current, BlockPositionRenderRenderer neighbor) {
      return neighbor == null ? current.outlineBox.minY : Math.max(current.outlineBox.minY, neighbor.outlineBox.maxY);
   }

      private void jdquaz(
      List<BlockPositionRenderRenderer> cells, Long2ObjectOpenHashMap<BlockPositionRenderRenderer> cellMap, int color, MatrixStack matrices, boolean renderAllFaces
   ) {
      BaseShaderRenderer shaderVertexRenderer7 = this.djd0();
      if (shaderVertexRenderer7 == null) {
         this.t18(cells, cellMap, ColorUtils.multAlpha(color, 0.3F), renderAllFaces);
      } else {
         float value = (color >> 24 & 0xFF) / 255.0F;
         this.controlMethod22(shaderVertexRenderer7, value);
         RenderSystem.enableBlend();
         RenderSystem.enableDepthTest();
         RenderSystem.disableCull();
         RenderSystem.depthMask(false);
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
         Matrix4f matrix = RenderStateGuard.pushModelView(matrices.peek().getPositionMatrix());

         try {
            shaderVertexRenderer7.use();
            BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            Matrix4f matrix2 = this.controlField170.identity();

            for (BlockPositionRenderRenderer blockPositionRenderRenderer : cells) {
               this.djfb(bufferBuilder, matrix2, blockPositionRenderRenderer.renderBox, value);
               if (renderAllFaces) {
                  Box box = blockPositionRenderRenderer.outlineBox;
                  this.startMethod13(
                     bufferBuilder,
                     matrix2,
                     blockPositionRenderRenderer,
                     (BlockPositionRenderRenderer)cellMap.get(ppsnbz(blockPositionRenderRenderer.blockPos, 0, -1)),
                     value,
                     box.minX,
                     box.maxX,
                     box.minZ,
                     box.minZ
                  );
                  this.startMethod13(
                     bufferBuilder,
                     matrix2,
                     blockPositionRenderRenderer,
                     (BlockPositionRenderRenderer)cellMap.get(ppsnbz(blockPositionRenderRenderer.blockPos, 1, 0)),
                     value,
                     box.maxX,
                     box.maxX,
                     box.minZ,
                     box.maxZ
                  );
                  this.startMethod13(
                     bufferBuilder,
                     matrix2,
                     blockPositionRenderRenderer,
                     (BlockPositionRenderRenderer)cellMap.get(ppsnbz(blockPositionRenderRenderer.blockPos, 0, 1)),
                     value,
                     box.maxX,
                     box.minX,
                     box.maxZ,
                     box.maxZ
                  );
                  this.startMethod13(
                     bufferBuilder,
                     matrix2,
                     blockPositionRenderRenderer,
                     (BlockPositionRenderRenderer)cellMap.get(ppsnbz(blockPositionRenderRenderer.blockPos, -1, 0)),
                     value,
                     box.minX,
                     box.minX,
                     box.maxZ,
                     box.minZ
                  );
               }
            }

            BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
         } finally {
            RenderStateGuard.popModelView(matrix);
            RenderStateGuard.restoreWorldDefaults();
         }
      }
   }

      private BaseShaderRenderer djd0() {
      String text = this.validateField72.getSelected();

      return (BaseShaderRenderer)(switch (text) {
         case "Wave" -> ShaderRegistry.highlighterShaderWave;
         case "Audio" -> ShaderRegistry.highlighterShaderAudio;
         case "Plasma" -> ShaderRegistry.highlighterShaderPlasma;
         case "Fractal" -> ShaderRegistry.highlighterShaderFractal;
         case "Tunnel" -> ShaderRegistry.highlighterShaderTunnel;
         case "Particles" -> ShaderRegistry.highlighterShaderParticles;
         default -> ShaderRegistry.highlighterShaderWave;
      });
   }

      private void controlMethod22(BaseShaderRenderer program, float alpha) {
      Color color = new Color(this.getVisualColor(), true);
      float value = color.getRed() / 255.0F;
      float value2 = color.getGreen() / 255.0F;
      float value3 = color.getBlue() / 255.0F;
      float value4 = color.getRed() / 255.0F;
      float value5 = color.getGreen() / 255.0F;
      float value6 = color.getBlue() / 255.0F;
      float value7 = color.getRed() / 255.0F;
      float value8 = color.getGreen() / 255.0F;
      float value9 = color.getBlue() / 255.0F;
      float value10 = color.getRed() / 255.0F;
      float value11 = color.getGreen() / 255.0F;
      float value12 = color.getBlue() / 255.0F;
      float value13 = 500.0F / this.vkjek.getValue();
      float value14 = 5.0F / this.hbspv.getValue();
      if (program instanceof WaveOutlineShader vertexColorRenderer9) {
         vertexColorRenderer9.updateUniforms(this.ssqvk, value13, value14, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, alpha);
      } else if (program instanceof AudioOutlineShader vertexColorRenderer8) {
         vertexColorRenderer8.updateUniforms(this.ssqvk, value13, value14, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, alpha);
      } else if (program instanceof PlasmaOutlineShader vertexColorRenderer6) {
         vertexColorRenderer6.updateUniforms(this.ssqvk, value13, value14, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, alpha);
      } else if (program instanceof FractalOutlineShader vertexColorRenderer4) {
         vertexColorRenderer4.updateUniforms(this.ssqvk, value13, value14, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, alpha);
      } else if (program instanceof TunnelOutlineShader vertexColorRenderer7) {
         vertexColorRenderer7.updateUniforms(this.ssqvk, value13, value14, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, alpha);
      } else if (program instanceof ParticleOutlineShader vertexColorRenderer3) {
         vertexColorRenderer3.updateUniforms(this.ssqvk, value13, value14, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, alpha);
      }
   }

      private void djfb(BufferBuilder buffer, Matrix4f matrix, Box box, float alpha) {
      double value = box.minX - 0.0025;
      double value2 = box.maxX + 0.0025;
      double value3 = box.minZ - 0.0025;
      double value4 = box.maxZ + 0.0025;
      double value5 = box.maxY + 0.0035;
      this.aidqqa(buffer, matrix, value, value5, value3, (float)value, (float)value3, alpha);
      this.aidqqa(buffer, matrix, value2, value5, value3, (float)value2, (float)value3, alpha);
      this.aidqqa(buffer, matrix, value2, value5, value4, (float)value2, (float)value4, alpha);
      this.aidqqa(buffer, matrix, value, value5, value4, (float)value, (float)value4, alpha);
   }

      private void startMethod13(
      BufferBuilder buffer,
      Matrix4f matrix,
      BlockPositionRenderRenderer current,
      BlockPositionRenderRenderer neighbor,
      float alpha,
      double x1,
      double x2,
      double z1,
      double z2
   ) {
      if (this.djaq(current, neighbor)) {
         double value = this.hasMethod29(current, neighbor);
         double value2 = current.outlineBox.maxY + 0.0035;
         if (!(value2 - value <= 0.001)) {
            double value3 = (current.outlineBox.minX + current.outlineBox.maxX) * 0.5;
            double value4 = (current.outlineBox.minZ + current.outlineBox.maxZ) * 0.5;
            boolean enabled = Math.abs(x1 - x2) < 1E-6;
            if (enabled) {
               double value5 = x1 >= value3 ? 0.0025 : -0.0025F;
               x1 += value5;
               x2 += value5;
               z1 -= 0.0025;
               z2 += 0.0025;
               this.aidqqa(buffer, matrix, x1, value, z1, (float)z1, (float)value, alpha);
               this.aidqqa(buffer, matrix, x2, value, z2, (float)z2, (float)value, alpha);
               this.aidqqa(buffer, matrix, x2, value2, z2, (float)z2, (float)value2, alpha);
               this.aidqqa(buffer, matrix, x1, value2, z1, (float)z1, (float)value2, alpha);
            } else {
               double value6 = z1 >= value4 ? 0.0025 : -0.0025F;
               z1 += value6;
               z2 += value6;
               x1 -= 0.0025;
               x2 += 0.0025;
               this.aidqqa(buffer, matrix, x1, value, z1, (float)x1, (float)value, alpha);
               this.aidqqa(buffer, matrix, x2, value, z2, (float)x2, (float)value, alpha);
               this.aidqqa(buffer, matrix, x2, value2, z2, (float)x2, (float)value2, alpha);
               this.aidqqa(buffer, matrix, x1, value2, z1, (float)x1, (float)value2, alpha);
            }
         }
      }
   }

      private void aidqqa(BufferBuilder buffer, Matrix4f matrix, double x, double y, double z, float u, float v, float alpha) {
      buffer.vertex(matrix, (float)x, (float)y, (float)z).texture(u, v).color(1F, 1F, 1F, alpha);
   }

   static {
      int index = 0;
   }
}
