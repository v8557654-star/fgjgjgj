package winvi.noxiumvisuals.modules.world;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.ShaderRegistry;
import winvi.noxiumvisuals.utils.render.ParticleOutlineShader;
import winvi.noxiumvisuals.utils.render.FractalOutlineShader;
import winvi.noxiumvisuals.utils.render.PlasmaOutlineShader;
import winvi.noxiumvisuals.utils.render.TunnelOutlineShader;
import winvi.noxiumvisuals.utils.render.WaveOutlineShader;
import winvi.noxiumvisuals.utils.render.BaseShaderRenderer;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
import winvi.noxiumvisuals.utils.render.RenderStateGuard;
public class BlockHighLightModule extends Module {
      private final BooleanSetting deleteField90;
      private final BooleanSetting exoz;
      private final BooleanSetting mpgbi;
      private final BooleanSetting exq;
      private final NumberSetting r20;
      private final BooleanSetting computeField51;
      private final BooleanSetting handleField19;
      private final NumberSetting kokzx;
      private final BooleanSetting exv;
      private final ChoiceSetting wqfbo;
      private final NumberSetting glklj;
      private final NumberSetting pehch;
      private BlockPos xnxvk;
      private BlockPos a17;
      private Vec3d validateField50;
      private long lzdyu;
      private float jmbgs;
      private float kxzil;
      private float yf;
      private long bhvdj;

      public static BlockHighLightModule getInstance() {
      return ModuleLookup.get(BlockHighLightModule.class);
   }

   public BlockHighLightModule() {
      super(
         "BlockHighLight",
         "Block HighLight",
         ModuleCategory.WORLD
      );
      this.xnxvk = null;
      this.a17 = null;
      this.validateField50 = null;
      this.lzdyu = 0L;
      this.jmbgs = 0F;
      this.kxzil = 0F;
      this.yf = 0F;
      this.bhvdj = System.nanoTime();
      this.deleteField90 = new BooleanSetting(
            "Full Block",
            "Highlight entire block instead of just the face"
         )
         .setValue(true);
      this.deleteField90.withTranslation("blockhighlight.fullblock", "blockhighlight.fullblock.desc");
      this.exoz = new BooleanSetting(
            "Use Shader",
            "Use shader effect"
         )
         .setValue(false);
      this.exoz.withTranslation("blockhighlight.useshader", "blockhighlight.useshader.desc");
      this.mpgbi = new BooleanSetting(
            "Draw Outline",
            "Draw outline around block"
         )
         .setValue(true)
         .visible(() -> {
            return this.exoz.isValue();
         });
      this.mpgbi.withTranslation("blockhighlight.drawoutline", "blockhighlight.drawoutline.desc");
      this.exq = new BooleanSetting(
            "Dashed Outline",
            "Use dashed outline"
         )
         .setValue(false)
         .visible(() -> {
            return !this.exoz.isValue();
         });
      this.exq.withTranslation("blockhighlight.dashedoutline", "blockhighlight.dashedoutline.desc");
      this.r20 = new NumberSetting(
            "Dash Density",
            "Dash density (higher = more dashes)"
         )
         .setValue(1F)
         .range(0.5F, 3.0F)
         .visible(() -> {
            return this.exq.isValue();
         });
      this.r20.withTranslation("blockhighlight.dashdensity", "blockhighlight.dashdensity.desc");
      this.computeField51 = new BooleanSetting(
            "Animate Dash",
            "Animate dashed outline"
         )
         .setValue(true)
         .visible(() -> {
            return this.exq.isValue();
         });
      this.computeField51.withTranslation("blockhighlight.animatedash", "blockhighlight.animatedash.desc");
      this.handleField19 = new BooleanSetting(
            "Smooth Transition",
            "Smooth animation between blocks"
         )
         .setValue(false);
      this.handleField19.withTranslation("blockhighlight.smoothtransition", "blockhighlight.smoothtransition.desc");
      this.kokzx = new NumberSetting(
            "Animation Speed",
            "Speed of block transition animation"
         )
         .setValue(8.0F)
         .range(1F, 20.0F)
         .visible(() -> {
            return this.handleField19.isValue();
         });
      this.kokzx.withTranslation("blockhighlight.animationspeed", "blockhighlight.animationspeed.desc");
      this.exv = new BooleanSetting(
            "Stretch Effect",
            "Stretch block during animation"
         )
         .setValue(true)
         .visible(() -> {
            return this.handleField19.isValue();
         });
      this.exv.withTranslation("blockhighlight.stretcheffect", "blockhighlight.stretcheffect.desc");
      this.wqfbo = new ChoiceSetting(
            "Shader Type",
            "Shader effect type"
         )
         .value(
            "Wave",
            "Plasma",
            "Fractal",
            "Tunnel",
            "Particles"
         )
         .visible(() -> {
            return this.exoz.isValue();
         });
      this.wqfbo.withTranslation("blockhighlight.shadertype", "blockhighlight.shadertype.desc");
      this.glklj = new NumberSetting(
            "Shader Speed",
            "Shader animation speed"
         )
         .setValue(1F)
         .range(0.1F, 5.0F)
         .visible(() -> {
            return this.exoz.isValue();
         });
      this.glklj.withTranslation("blockhighlight.cloudspeed", "blockhighlight.cloudspeed.desc");
      this.pehch = new NumberSetting(
            "Shader Scale",
            "Shader pattern scale"
         )
         .setValue(1F)
         .range(0.1F, 10.0F)
         .visible(() -> {
            return this.exoz.isValue();
         });
      this.pehch.withTranslation("blockhighlight.cloudscale", "blockhighlight.cloudscale.desc");
      this.showVisualColorSettings();
      this.setup(
         new ModuleSetting[]{
            this.deleteField90,
            this.exoz,
            this.mpgbi,
            this.exq,
            this.r20,
            this.computeField51,
            this.handleField19,
            this.kokzx,
            this.exv,
            this.wqfbo,
            this.glklj,
            this.pehch
         }
      );
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer e) {
      if (this.isState()) {
         long timestamp = System.nanoTime();
         float value = (float)(timestamp - this.bhvdj) / 1E9F;
         this.bhvdj = timestamp;
         this.kxzil += value * 20.0F;
         if (this.computeField51.isValue()) {
            this.yf += value * 2.0F;
            if (this.yf > 1F) {
               this.yf = 0F;
            }
         }

         if (MinecraftClient.getInstance().crosshairTarget instanceof BlockHitResult blockHitResult && blockHitResult.getType().equals(Type.BLOCK)) {
            BlockPos blockPos = blockHitResult.getBlockPos();
            Direction direction = blockHitResult.getSide();
            if (this.handleField19.isValue()) {
               this.convertMethod36(blockPos);
            } else {
               this.xnxvk = blockPos;
               this.validateField50 = new Vec3d(blockPos.getX(), blockPos.getY(), blockPos.getZ());
            }

            if (this.validateField50 == null) {
               this.validateField50 = new Vec3d(blockPos.getX(), blockPos.getY(), blockPos.getZ());
               this.xnxvk = blockPos;
            }

            int index = this.getVisualColor();
            int index2 = index;
            Direction direction2 = direction;
            Vec3d position = this.validateField50;
            if (this.deleteField90.isValue()) {
               VoxelShape client = MinecraftClient.getInstance().world.getBlockState(blockPos).getOutlineShape(MinecraftClient.getInstance().world, blockPos);

               for (Box box : client.getBoundingBoxes()) {
                  Box box2 = this.xjyitb(box, position.x, position.y, position.z);
                  if (this.exoz.isValue() && this.feqpvh() != null) {
                     this.chseiu(e, box2, index2);
                     if (this.mpgbi.isValue()) {
                        this.bmqjka(e, box2, index2);
                     }
                  } else if (this.exq.isValue()) {
                     this.convertMethod821(e, box2, index2, this.r20.getValue());
                  } else {
                     WorldShapeRenderer.drawBox(box2, index2, 2.0F, true, true, true);
                  }
               }

               return;
            }

            VoxelShape client2 = MinecraftClient.getInstance().world.getBlockState(blockPos).getOutlineShape(MinecraftClient.getInstance().world, blockPos);

            for (Box box3 : client2.getBoundingBoxes()) {
               double x2 = position.x;
               double y2 = position.y;
               double z2 = position.z;
               Box box4 = this.xjyitb(box3, x2, y2, z2);
               double value2 = box4.minX;
               double value3 = box4.minY;
               double value4 = box4.minZ;
               double value5 = box4.maxX;
               double value6 = box4.maxY;
               double value7 = box4.maxZ;
               int index3 = ColorUtils.multAlpha(index2, 0.3F);
               switch (direction2) {
                  case UP:
                     WorldShapeRenderer.drawLine(null, value2, value6, value4, value5, value6, value4, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value5, value6, value4, value5, value6, value7, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value5, value6, value7, value2, value6, value7, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value2, value6, value7, value2, value6, value4, index2, 2.0F, false);
                     WorldShapeRenderer.drawQuad(value2, value6, value4, value5, value6, value4, value5, value6, value7, value2, value6, value7, index3, false);
                     break;
                  case DOWN:
                     WorldShapeRenderer.drawLine(null, value2, value3, value4, value5, value3, value4, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value5, value3, value4, value5, value3, value7, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value5, value3, value7, value2, value3, value7, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value2, value3, value7, value2, value3, value4, index2, 2.0F, false);
                     WorldShapeRenderer.drawQuad(value2, value3, value4, value2, value3, value7, value5, value3, value7, value5, value3, value4, index3, false);
                     break;
                  case NORTH:
                     WorldShapeRenderer.drawLine(null, value2, value3, value4, value5, value3, value4, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value5, value3, value4, value5, value6, value4, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value5, value6, value4, value2, value6, value4, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value2, value6, value4, value2, value3, value4, index2, 2.0F, false);
                     WorldShapeRenderer.drawQuad(value2, value3, value4, value2, value6, value4, value5, value6, value4, value5, value3, value4, index3, false);
                     break;
                  case SOUTH:
                     WorldShapeRenderer.drawLine(null, value2, value3, value7, value5, value3, value7, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value5, value3, value7, value5, value6, value7, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value5, value6, value7, value2, value6, value7, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value2, value6, value7, value2, value3, value7, index2, 2.0F, false);
                     WorldShapeRenderer.drawQuad(value2, value3, value7, value5, value3, value7, value5, value6, value7, value2, value6, value7, index3, false);
                     break;
                  case WEST:
                     WorldShapeRenderer.drawLine(null, value2, value3, value4, value2, value6, value4, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value2, value6, value4, value2, value6, value7, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value2, value6, value7, value2, value3, value7, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value2, value3, value7, value2, value3, value4, index2, 2.0F, false);
                     WorldShapeRenderer.drawQuad(value2, value3, value4, value2, value3, value7, value2, value6, value7, value2, value6, value4, index3, false);
                     break;
                  case EAST:
                     WorldShapeRenderer.drawLine(null, value5, value3, value4, value5, value6, value4, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value5, value6, value4, value5, value6, value7, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value5, value6, value7, value5, value3, value7, index2, 2.0F, false);
                     WorldShapeRenderer.drawLine(null, value5, value3, value7, value5, value3, value4, index2, 2.0F, false);
                     WorldShapeRenderer.drawQuad(value5, value3, value4, value5, value6, value4, value5, value6, value7, value5, value3, value7, index3, false);
               }
            }
         }
      }
   }

      private BaseShaderRenderer feqpvh() {
      String text = this.wqfbo.getSelected();

      return (BaseShaderRenderer)(switch (text) {
         case "Wave" -> ShaderRegistry.highlighterShaderWave;
         case "Plasma" -> ShaderRegistry.highlighterShaderPlasma;
         case "Fractal" -> ShaderRegistry.highlighterShaderFractal;
         case "Tunnel" -> ShaderRegistry.highlighterShaderTunnel;
         case "Particles" -> ShaderRegistry.highlighterShaderParticles;
         default -> ShaderRegistry.highlighterShaderWave;
      });
   }

      private void chseiu(VertexMatrixRenderer e, Box box, int color) {
      BaseShaderRenderer shaderVertexRenderer7 = this.feqpvh();
      if (shaderVertexRenderer7 == null) {
         WorldShapeRenderer.drawBox(box, color, 2.0F, true, true, true);
      } else {
         box = box.expand(0.001);
         Color color2 = new Color(this.getVisualColor(), true);
         float value = color2.getRed() / 255.0F;
         float value2 = color2.getGreen() / 255.0F;
         float value3 = color2.getBlue() / 255.0F;
         float value4 = color2.getRed() / 255.0F;
         float value5 = color2.getGreen() / 255.0F;
         float value6 = color2.getBlue() / 255.0F;
         float value7 = color2.getRed() / 255.0F;
         float value8 = color2.getGreen() / 255.0F;
         float value9 = color2.getBlue() / 255.0F;
         float value10 = color2.getRed() / 255.0F;
         float value11 = color2.getGreen() / 255.0F;
         float value12 = color2.getBlue() / 255.0F;
         float value13 = (color >> 24 & 0xFF) / 255.0F;
         float value14 = 500.0F / this.glklj.getValue();
         float value15 = 5.0F / this.pehch.getValue();
         if (shaderVertexRenderer7 instanceof WaveOutlineShader) {
            ((WaveOutlineShader)shaderVertexRenderer7)
               .updateUniforms(this.kxzil, value14, value15, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13);
         } else if (shaderVertexRenderer7 instanceof PlasmaOutlineShader) {
            ((PlasmaOutlineShader)shaderVertexRenderer7)
               .updateUniforms(this.kxzil, value14, value15, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13);
         } else if (shaderVertexRenderer7 instanceof FractalOutlineShader) {
            ((FractalOutlineShader)shaderVertexRenderer7)
               .updateUniforms(this.kxzil, value14, value15, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13);
         } else if (shaderVertexRenderer7 instanceof TunnelOutlineShader) {
            ((TunnelOutlineShader)shaderVertexRenderer7)
               .updateUniforms(this.kxzil, value14, value15, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13);
         } else if (shaderVertexRenderer7 instanceof ParticleOutlineShader) {
            ((ParticleOutlineShader)shaderVertexRenderer7)
               .updateUniforms(this.kxzil, value14, value15, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13);
         }

         RenderSystem.enableBlend();
         RenderSystem.enableDepthTest();
         RenderSystem.disableCull();
         RenderSystem.depthMask(false);
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
         Matrix4f matrix = RenderStateGuard.pushModelView(e.getStack().peek().getPositionMatrix());

         try {
            shaderVertexRenderer7.use();
            BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            Matrix4f matrix2 = new Matrix4f();
            double value16 = box.minX;
            double value17 = box.minY;
            double value18 = box.minZ;
            double value19 = box.maxX;
            double value20 = box.maxY;
            double value21 = box.maxZ;
            float value22 = 1F;
            float value23 = 1F;
            float value24 = 1F;
            bufferBuilder.vertex(matrix2, (float)value16, (float)value17, (float)value18).texture(0F, 0F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value19, (float)value17, (float)value18).texture(1F, 0F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value19, (float)value17, (float)value21).texture(1F, 1F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value16, (float)value17, (float)value21).texture(0F, 1F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value16, (float)value20, (float)value18).texture(0F, 0F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value16, (float)value20, (float)value21).texture(0F, 1F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value19, (float)value20, (float)value21).texture(1F, 1F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value19, (float)value20, (float)value18).texture(1F, 0F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value16, (float)value17, (float)value18).texture(0F, 0F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value16, (float)value20, (float)value18).texture(0F, 1F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value19, (float)value20, (float)value18).texture(1F, 1F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value19, (float)value17, (float)value18).texture(1F, 0F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value16, (float)value17, (float)value21).texture(0F, 0F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value19, (float)value17, (float)value21).texture(1F, 0F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value19, (float)value20, (float)value21).texture(1F, 1F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value16, (float)value20, (float)value21).texture(0F, 1F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value16, (float)value17, (float)value18).texture(0F, 0F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value16, (float)value17, (float)value21).texture(1F, 0F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value16, (float)value20, (float)value21).texture(1F, 1F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value16, (float)value20, (float)value18).texture(0F, 1F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value19, (float)value17, (float)value18).texture(0F, 0F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value19, (float)value20, (float)value18).texture(0F, 1F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value19, (float)value20, (float)value21).texture(1F, 1F).color(value22, value23, value24, value13);
            bufferBuilder.vertex(matrix2, (float)value19, (float)value17, (float)value21).texture(1F, 0F).color(value22, value23, value24, value13);
            BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
         } finally {
            RenderStateGuard.popModelView(matrix);
            RenderStateGuard.restoreWorldDefaults();
         }
      }
   }

      private void bmqjka(VertexMatrixRenderer e, Box box, int color) {
      Entry entry = e.getStack().peek();
      double value = box.minX;
      double value2 = box.minY;
      double value3 = box.minZ;
      double value4 = box.maxX;
      double value5 = box.maxY;
      double value6 = box.maxZ;
      WorldShapeRenderer.drawLine(entry, value, value2, value3, value4, value2, value3, color, 2.0F, false);
      WorldShapeRenderer.drawLine(entry, value4, value2, value3, value4, value2, value6, color, 2.0F, false);
      WorldShapeRenderer.drawLine(entry, value4, value2, value6, value, value2, value6, color, 2.0F, false);
      WorldShapeRenderer.drawLine(entry, value, value2, value6, value, value2, value3, color, 2.0F, false);
      WorldShapeRenderer.drawLine(entry, value, value5, value3, value4, value5, value3, color, 2.0F, false);
      WorldShapeRenderer.drawLine(entry, value4, value5, value3, value4, value5, value6, color, 2.0F, false);
      WorldShapeRenderer.drawLine(entry, value4, value5, value6, value, value5, value6, color, 2.0F, false);
      WorldShapeRenderer.drawLine(entry, value, value5, value6, value, value5, value3, color, 2.0F, false);
      WorldShapeRenderer.drawLine(entry, value, value2, value3, value, value5, value3, color, 2.0F, false);
      WorldShapeRenderer.drawLine(entry, value4, value2, value3, value4, value5, value3, color, 2.0F, false);
      WorldShapeRenderer.drawLine(entry, value4, value2, value6, value4, value5, value6, color, 2.0F, false);
      WorldShapeRenderer.drawLine(entry, value, value2, value6, value, value5, value6, color, 2.0F, false);
   }

      private void convertMethod821(VertexMatrixRenderer e, Box box, int color, float density) {
      float value = 0.1F / density;
      float value2 = 0.05F / density;
      Entry entry = e.getStack().peek();
      double value3 = box.minX;
      double value4 = box.minY;
      double value5 = box.minZ;
      double value6 = box.maxX;
      double value7 = box.maxY;
      double value8 = box.maxZ;
      this.dhtc(entry, value3, value4, value5, value6, value4, value5, color, value, value2);
      this.dhtc(entry, value6, value4, value5, value6, value4, value8, color, value, value2);
      this.dhtc(entry, value6, value4, value8, value3, value4, value8, color, value, value2);
      this.dhtc(entry, value3, value4, value8, value3, value4, value5, color, value, value2);
      this.dhtc(entry, value3, value7, value5, value6, value7, value5, color, value, value2);
      this.dhtc(entry, value6, value7, value5, value6, value7, value8, color, value, value2);
      this.dhtc(entry, value6, value7, value8, value3, value7, value8, color, value, value2);
      this.dhtc(entry, value3, value7, value8, value3, value7, value5, color, value, value2);
      this.dhtc(entry, value3, value4, value5, value3, value7, value5, color, value, value2);
      this.dhtc(entry, value6, value4, value5, value6, value7, value5, color, value, value2);
      this.dhtc(entry, value6, value4, value8, value6, value7, value8, color, value, value2);
      this.dhtc(entry, value3, value4, value8, value3, value7, value8, color, value, value2);
   }

      private void dhtc(Entry entry, double x1, double y1, double z1, double x2, double y2, double z2, int color, float dashLength, float gapLength) {
      double value = x2 - x1;
      double value2 = y2 - y1;
      double value3 = z2 - z1;
      double value4 = Math.sqrt(value * value + value2 * value2 + value3 * value3);
      double value5 = dashLength + gapLength;
      int index = (int)(value4 / value5);
      double value6 = this.yf * value5;

      for (int index2 = 0; index2 <= index; index2++) {
         double value7 = (index2 * value5 - value6) / value4;
         double value8 = Math.min((index2 * value5 + dashLength - value6) / value4, 1);
         if (!(value8 < 0)) {
            if (value7 >= 1) {
               break;
            }

            value7 = Math.max(value7, 0);
            double value9 = x1 + value * value7;
            double value10 = y1 + value2 * value7;
            double value11 = z1 + value3 * value7;
            double value12 = x1 + value * value8;
            double value13 = y1 + value2 * value8;
            double value14 = z1 + value3 * value8;
            WorldShapeRenderer.drawLine(entry, value9, value10, value11, value12, value13, value14, color, 2.0F, false);
         }
      }
   }

      private void convertMethod36(BlockPos targetPos) {
      long timestamp = System.currentTimeMillis();
      float value = (float)(timestamp - this.lzdyu) / 1000.0F;
      this.lzdyu = timestamp;
      if (this.xnxvk == null || !this.xnxvk.equals(targetPos)) {
         this.a17 = this.xnxvk;
         this.xnxvk = targetPos;
         this.jmbgs = 0F;
      }

      if (this.validateField50 == null) {
         this.validateField50 = new Vec3d(targetPos.getX(), targetPos.getY(), targetPos.getZ());
      } else {
         Vec3d x2 = new Vec3d(targetPos.getX(), targetPos.getY(), targetPos.getZ());
         double value2 = this.kokzx.getValue() * value;
         double x3 = x2.x - this.validateField50.x;
         double y2 = x2.y - this.validateField50.y;
         double z2 = x2.z - this.validateField50.z;
         double value3 = Math.sqrt(x3 * x3 + y2 * y2 + z2 * z2);
         if (value3 < 0.01) {
            this.validateField50 = x2;
            this.jmbgs = 1F;
         } else {
            double value4 = Math.min(value2, 1);
            this.validateField50 = new Vec3d(
               this.validateField50.x + x3 * value4, this.validateField50.y + y2 * value4, this.validateField50.z + z2 * value4
            );
            this.jmbgs = Math.min(1F, this.jmbgs + (float)value2);
         }
      }
   }

      private Box xjyitb(Box box, double offsetX, double offsetY, double offsetZ) {
      box = box.offset(offsetX, offsetY, offsetZ);
      if (this.exv.isValue() && this.handleField19.isValue() && this.jmbgs < 1F) {
         double value = 1 + (1 - this.jmbgs) * 0.1;
         double value2 = (box.minX + box.maxX) / 2.0;
         double value3 = (box.minY + box.maxY) / 2.0;
         double value4 = (box.minZ + box.maxZ) / 2.0;
         double value5 = (box.maxX - box.minX) * value;
         double value6 = (box.maxY - box.minY) * value;
         double value7 = (box.maxZ - box.minZ) * value;
         box = new Box(value2 - value5 / 2.0, value3 - value6 / 2.0, value4 - value7 / 2.0, value2 + value5 / 2.0, value3 + value6 / 2.0, value4 + value7 / 2.0);
      }

      return box;
   }

}
