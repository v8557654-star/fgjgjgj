package winvi.noxiumvisuals.modules.world;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class ItemPhysicsModule extends Module {
      public final ChoiceSetting mode;
      public final BooleanSetting bottleFlip;
      public final SettingGroup visualSettings;

   public ItemPhysicsModule() {
      super("Item Physics", ModuleCategory.WORLD);
      this.mode = new ChoiceSetting(
            "Mode",
            "Physics mode"
         )
         .value("Normal", "2D")
         .selected("Normal");
      this.mode.withTranslation("itemphysics.mode", "itemphysics.mode.desc");
      this.bottleFlip = new BooleanSetting(
            "Bottle Flip",
            "Enable bottle flip challenge mode"
         )
         .setValue(false);
      this.bottleFlip.withTranslation("itemphysics.bottleflip", "itemphysics.bottleflip.desc");
      this.visualSettings = new SettingGroup(
            "Visual Settings",
            "Visual settings for item physics"
         )
         .settings(this.mode, this.bottleFlip)
         .setValue(true);
      this.visualSettings.withTranslation("itemphysics.visualsettings", "itemphysics.visualsettings.desc");
      this.setup(new ModuleSetting[]{this.visualSettings});
   }

}
