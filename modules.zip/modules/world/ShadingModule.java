package winvi.noxiumvisuals.modules.world;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public final class ShadingModule extends Module {
      private static ShadingModule removeField59;
      private final BooleanSetting w23;
      private final ChoiceSetting removeField890;
      private final ColorSetting setField92;
      private final ChoiceSetting addField36;
      private final ColorSetting slvzx;
      private final NumberSetting zb1;
      private final NumberSetting zwqgq;
      private final NumberSetting ezd;
      private final NumberSetting viigx;
      private final NumberSetting dkkuu;
      private final BooleanSetting getField90;
      private final NumberSetting manageField42;
      private final BooleanSetting manageField19;
      private final NumberSetting fzbxx;
      private final NumberSetting runField98;
      private final NumberSetting l14;
      private final NumberSetting qgtja;
      private final NumberSetting deleteField581;
      private final BooleanSetting runField45;
      private final ChoiceSetting setField950;
      private final ColorSetting executeField85;
      private final NumberSetting ashki;
      private final NumberSetting rnfrq;

   public ShadingModule() {
      super("Shading", ModuleCategory.WORLD);
      removeField59 = this;
      this.w23 = new BooleanSetting(
            "Fade Cloud",
            "Render soft volumetric clouds"
         )
         .setValue(true);
      this.w23.withTranslation("shading.fadecloud", "shading.fadecloud.desc");
      this.removeField890 = new ChoiceSetting(
            "Bottom Color Source",
            "Color source at the bottom of the clouds"
         )
         .value(
            "Visual Color",
            "Custom",
            "Fog Color"
         )
         .selected("Custom")
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .alias(
            "Fog",
            "Fog Color"
         )
         .visible(this.w23::isValue);
      this.removeField890.withTranslation("shading.bottomcolorsource", "shading.bottomcolorsource.desc");
      this.setField92 = new ColorSetting(
            "Bottom Color",
            "Color at the bottom of the clouds"
         )
         .setColor(-4667172);
      this.setField92.withTranslation("shading.bottomcolor", "shading.bottomcolor.desc");
      this.setField92.visible(() -> {
         return this.w23.isValue() && this.removeField890.isSelected("Custom");
      });
      this.addField36 = new ChoiceSetting(
            "Top Color Source",
            "Color source at the top of the clouds"
         )
         .value(
            "Visual Color",
            "Custom",
            "Fog Color"
         )
         .selected("Custom")
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .alias(
            "Fog",
            "Fog Color"
         )
         .visible(this.w23::isValue);
      this.addField36.withTranslation("shading.topcolorsource", "shading.topcolorsource.desc");
      this.slvzx = new ColorSetting(
            "Top Color",
            "Color at the top of the clouds"
         )
         .setColor(-722945);
      this.slvzx.withTranslation("shading.topcolor", "shading.topcolor.desc");
      this.slvzx.visible(() -> {
         return this.w23.isValue() && this.addField36.isSelected("Custom");
      });
      this.zb1 = new NumberSetting(
            "Color Fade",
            "Strength of the smooth gradient between both colors"
         )
         .setValue(100.0F)
         .range(0F, 100.0F);
      this.zb1.withTranslation("shading.colorfade", "shading.colorfade.desc");
      this.zb1.visible(this.w23::isValue);
      this.zwqgq = new NumberSetting(
            "Opacity",
            "Cloud opacity"
         )
         .setValue(90.0F)
         .range(10.0F, 100.0F);
      this.zwqgq.withTranslation("shading.opacity", "shading.opacity.desc");
      this.zwqgq.visible(this.w23::isValue);
      this.ezd = new NumberSetting(
            "Softness",
            "Soft vertical edges and face lighting"
         )
         .setValue(88.0F)
         .range(0F, 100.0F);
      this.ezd.withTranslation("shading.softness", "shading.softness.desc");
      this.ezd.visible(this.w23::isValue);
      this.viigx = new NumberSetting(
            "Fog Blend",
            "Blend clouds into the atmospheric fog"
         )
         .setValue(70.0F)
         .range(0F, 100.0F);
      this.viigx.withTranslation("shading.fogblend", "shading.fogblend.desc");
      this.viigx.visible(this.w23::isValue);
      this.dkkuu = new NumberSetting(
            "Cloud Height",
            "Vertical cloud thickness"
         )
         .setValue(2.0F)
         .range(1F, 3.0F);
      this.dkkuu.withTranslation("shading.height", "shading.height.desc");
      this.dkkuu.visible(this.w23::isValue);
      this.getField90 = new BooleanSetting(
            "Soft Lighting",
            "Filmic lighting correction for the whole world"
         )
         .setValue(true);
      this.getField90.withTranslation("shading.softlighting", "shading.softlighting.desc");
      this.manageField42 = new NumberSetting(
            "Lighting Strength",
            "Strength of the filmic lighting correction"
         )
         .setValue(40.0F)
         .range(1F, 100.0F);
      this.manageField42.withTranslation("shading.softlightingstrength", "shading.softlightingstrength.desc");
      this.manageField42.visible(this.getField90::isValue);
      this.manageField19 = new BooleanSetting(
            "Glow",
            "Soft bloom for bright world details"
         )
         .setValue(true);
      this.manageField19.withTranslation("shading.glow", "shading.glow.desc");
      this.fzbxx = new NumberSetting(
            "Glow Strength",
            "Brightness of the glow"
         )
         .setValue(1.5F)
         .range(0.01F, 5.0F);
      this.fzbxx.withTranslation("shading.glowstrength", "shading.glowstrength.desc");
      this.fzbxx.visible(this.manageField19::isValue);
      this.runField98 = new NumberSetting(
            "Glow Threshold",
            "Sensitivity to bright world details"
         )
         .setValue(62.0F)
         .range(0F, 100.0F);
      this.runField98.withTranslation("shading.glowthreshold", "shading.glowthreshold.desc");
      this.runField98.visible(this.manageField19::isValue);
      this.l14 = new NumberSetting(
            "Glow Radius",
            "Spread of the soft glow"
         )
         .setValue(65.0F)
         .range(1F, 100.0F);
      this.l14.withTranslation("shading.glowradius", "shading.glowradius.desc");
      this.l14.visible(this.manageField19::isValue);
      this.qgtja = new NumberSetting(
            "Glow Quality",
            "Number of active bloom pyramid levels"
         )
         .setValue(3.0F)
         .range(1, 4);
      this.qgtja.withTranslation("shading.glowquality", "shading.glowquality.desc");
      this.qgtja.visible(this.manageField19::isValue);
      this.deleteField581 = new NumberSetting(
            "Glow Distance",
            "Maximum world distance affected by glow"
         )
         .setValue(75.0F)
         .range(8.0F, 256.0F);
      this.deleteField581.withTranslation("shading.glowdistance", "shading.glowdistance.desc");
      this.deleteField581.visible(this.manageField19::isValue);
      this.runField45 = new BooleanSetting(
            "Outline",
            "Outline visible world geometry"
         )
         .setValue(true);
      this.runField45.withTranslation("shading.outline", "shading.outline.desc");
      this.setField950 = new ChoiceSetting(
            "Outline Color Source",
            "Color source for world outlines"
         )
         .value(
            "Visual Color",
            "Custom"
         )
         .selected("Visual Color")
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .visible(this.runField45::isValue);
      this.setField950.withTranslation("shading.outlinecolorsource", "shading.outlinecolorsource.desc");
      this.executeField85 = new ColorSetting(
            "Outline Color",
            "Custom world outline color"
         )
         .setColor(-1);
      this.executeField85.withTranslation("shading.outlinecolor", "shading.outlinecolor.desc");
      this.executeField85.visible(() -> {
         return this.runField45.isValue() && this.setField950.isSelected("Custom");
      });
      this.ashki = new NumberSetting(
            "Outline Thickness",
            "Width of world outlines"
         )
         .setValue(1F)
         .range(0.5F, 4.0F);
      this.ashki.withTranslation("shading.outlinethickness", "shading.outlinethickness.desc");
      this.ashki.visible(this.runField45::isValue);
      this.rnfrq = new NumberSetting(
            "Outline Opacity",
            "Opacity of world outlines"
         )
         .setValue(65.0F)
         .range(1F, 100.0F);
      this.rnfrq.withTranslation("shading.outlineopacity", "shading.outlineopacity.desc");
      this.rnfrq.visible(this.runField45::isValue);
      this.setup(
         new ModuleSetting[]{
            this.w23,
            this.removeField890,
            this.setField92,
            this.addField36,
            this.slvzx,
            this.zb1,
            this.zwqgq,
            this.ezd,
            this.viigx,
            this.dkkuu,
            this.getField90,
            this.manageField42,
            this.manageField19,
            this.fzbxx,
            this.runField98,
            this.l14,
            this.qgtja,
            this.deleteField581,
            this.runField45,
            this.setField950,
            this.executeField85,
            this.ashki,
            this.rnfrq
         }
      );
   }

      public static ShadingModule getInstance() {
      return removeField59;
   }

      public boolean shouldRenderFadeCloud() {
      return this.isState() && this.w23.isValue();
   }

      public int getBottomColor() {
      return this.e24(this.removeField890, this.setField92);
   }

      public boolean isBottomFogColor() {
      return this.removeField890.isSelected("Fog Color");
   }

      public int getTopColor() {
      return this.e24(this.addField36, this.slvzx);
   }

      public boolean isTopFogColor() {
      return this.addField36.isSelected("Fog Color");
   }

      public float getColorFade() {
      return this.zb1.getValue() / 100.0F;
   }

      public float getCloudOpacity() {
      return this.zwqgq.getValue() / 100.0F;
   }

      public float getCloudSoftness() {
      return this.ezd.getValue() / 100.0F;
   }

      public float getCloudFogBlend() {
      return this.viigx.getValue() / 100.0F;
   }

      public float getCloudHeightScale() {
      return this.dkkuu.getValue();
   }

      public int getCloudGeometrySignature() {
      return Float.floatToIntBits(this.getCloudHeightScale());
   }

      public boolean shouldRenderGlow() {
      return this.isState() && this.manageField19.isValue();
   }

      public boolean shouldRenderSoftLighting() {
      return this.isState() && this.getField90.isValue();
   }

      public float getSoftLightingStrength() {
      return this.manageField42.getValue() / 100.0F;
   }

      public float getGlowStrength() {
      return this.fzbxx.getValue();
   }

      public float getGlowThreshold() {
      return 1F - this.runField98.getValue() / 100.0F * 0.92F;
   }

      public float getGlowRadius() {
      return this.l14.getValue() / 100.0F;
   }

      public int getGlowQuality() {
      return Math.max(1, Math.min(4, this.qgtja.getInt()));
   }

      public float getGlowDistance() {
      return this.deleteField581.getValue();
   }

      public boolean shouldRenderOutline() {
      return this.isState() && this.runField45.isValue();
   }

      public int getOutlineColor() {
      return this.resolveVisualOrCustomColor(this.setField950, this.executeField85);
   }

      public float getOutlineThickness() {
      return this.ashki.getValue();
   }

      public float getOutlineOpacity() {
      int index = this.getOutlineColor() >>> 24 & 0xFF;
      return this.rnfrq.getValue() / 100.0F * index / 255.0F;
   }

      public boolean hasWorldPostProcess() {
      return this.shouldRenderSoftLighting() || this.shouldRenderGlow() || this.shouldRenderOutline();
   }

      private int e24(ChoiceSetting colorMode, ColorSetting customColor) {
      return colorMode.isSelected("Fog Color")
         ? -1
         : this.resolveVisualOrCustomColor(colorMode, customColor);
   }

}
