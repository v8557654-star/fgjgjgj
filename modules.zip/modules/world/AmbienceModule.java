package winvi.noxiumvisuals.modules.world;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import winvi.noxiumvisuals.mixins.LightmapTextureManagerMixin;
import winvi.noxiumvisuals.mixins.ParticleManagerMixin;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.PacketEventProvider;
import winvi.noxiumvisuals.systems.events.EventDirection;
public class AmbienceModule extends Module {
      static final int WEATHER_DECOR_INTERVAL_TICKS = 4;
      static final int WEATHER_DECOR_BURST = 2;
      static final ParticleEffect GREEN_LEAVES_FALLBACK = new BlockStateParticleEffect(ParticleTypes.FALLING_DUST, Blocks.OAK_LEAVES.getDefaultState());
      private final ChoiceSetting cnokv;
      private final NumberSetting fksha;
      private final BooleanSetting wt0;
      private final NumberSetting ogrma;
      private final BooleanSetting hcnfx;
      private final ChoiceSetting fmbfq;
      private final NumberSetting x22;
      private final BooleanSetting gbldy;
      private final ChoiceSetting ewz;
      private boolean handleField81;
      private String yznol;
      private boolean ulzcq;
      private boolean computeField27;
      private String validateField34;
      private int isField33;

   public AmbienceModule() {
      super("Ambience", ModuleCategory.WORLD);
      this.cnokv = new ChoiceSetting(
            "Mode",
            "Time of day preset"
         )
         .value(
            "Day",
            "Noon",
            "Night",
            "Midnight",
            "Custom"
         )
         .selected("Day");
      this.fksha = new NumberSetting(
            "Time",
            "Custom world time"
         )
         .setValue(1000.0F)
         .range(0F, 24000.0F)
         .visible(() -> {
            return this.cnokv.isSelected("Custom");
         });
      this.wt0 = new BooleanSetting(
            "Saturation",
            "Enable world saturation adjustment"
         )
         .setValue(false);
      this.ogrma = new NumberSetting(
            "Saturation Value",
            "World saturation"
         )
         .setValue(0F)
         .range(-1F, 1F)
         .visible(this.wt0::isValue);
      this.hcnfx = new BooleanSetting(
            "Brightness",
            "Enable brightness adjustment"
         )
         .setValue(false);
      this.fmbfq = new ChoiceSetting(
            "Brightness Mode",
            "Brightness mode"
         )
         .value(
            "Gamma",
            "Effect"
         )
         .selected("Gamma")
         .visible(this.hcnfx::isValue);
      this.x22 = new NumberSetting(
            "Brightness Level",
            "Sets the brightness level"
         )
         .setValue(1F)
         .range(0F, 1F)
         .visible(() -> {
            return this.hcnfx.isValue() && this.fmbfq.isSelected("Gamma");
         });
      this.gbldy = new BooleanSetting(
            "Weather",
            "Enable custom client-side weather"
         )
         .setValue(false);
      this.ewz = new ChoiceSetting(
            "Weather Type",
            "Select weather type"
         )
         .value(
            "Clear",
            "Rain",
            "Thunder",
            "Snow",
            "Sakura",
            "Leaves"
         )
         .selected("Clear")
         .visible(this.gbldy::isValue);
      this.handleField81 = false;
      this.yznol = "Gamma";
      this.ulzcq = false;
      this.computeField27 = false;
      this.validateField34 = "";
      this.isField33 = 0;
      this.cnokv.withTranslation("ambience.mode", "ambience.mode.desc");
      this.fksha.withTranslation("ambience.time", "ambience.time.desc");
      this.wt0.withTranslation("ambience.saturation", "ambience.saturation.desc");
      this.ogrma.withTranslation("ambience.saturationvalue", "ambience.saturationvalue.desc");
      this.x22.withTranslation("ambience.brightnesslevel", "ambience.brightnesslevel.desc");
      this.hcnfx.withTranslation("ambience.brightnessenabled", "ambience.brightnessenabled.desc");
      this.fmbfq.withTranslation("ambience.brightnessmode", "ambience.brightnessmode.desc");
      this.gbldy.withTranslation("ambience.weather", "ambience.weather.desc");
      this.ewz.withTranslation("ambience.weathertype", "ambience.weathertype.desc");
      this.setup(new ModuleSetting[]{this.cnokv, this.fksha, this.wt0, this.ogrma, this.hcnfx, this.fmbfq, this.x22, this.gbldy, this.ewz});
   }

      @Override
   public void deactivate() {
      super.deactivate();
      this.dhik();
      this.kmfuiw();
      this.n17();
      if (MinecraftClient.getInstance().worldRenderer != null) {
         MinecraftClient.getInstance().worldRenderer.reload();
      }
   }

      public long getInternalTime() {
      if (this.cnokv.isSelected("Day")) {
         return 1000L;
      } else if (this.cnokv.isSelected("Noon")) {
         return 6000L;
      } else if (this.cnokv.isSelected("Night")) {
         return 13000L;
      } else {
         return this.cnokv.isSelected("Midnight") ? 18000L : (long)this.fksha.getValue();
      }
   }

      public float getSaturationFactor() {
      return !this.wt0.isValue() ? 1F : 1F + this.ogrma.getValue();
   }

      public float getBrightnessValue() {
      return !this.hcnfx.isValue() ? 0F : Math.max(0F, Math.min(1F, this.x22.getValue()));
   }

      public boolean isBrightnessGammaMode() {
      return this.hcnfx.isValue() && this.fmbfq.isSelected("Gamma");
   }

      public boolean isBrightnessEffectMode() {
      return this.hcnfx.isValue() && this.fmbfq.isSelected("Effect");
   }

      public boolean hasPostProcessAdjustments() {
      return Math.abs(this.getSaturationFactor() - 1F) > 0.001F;
   }

      public boolean isWeatherEnabled() {
      return this.gbldy.isValue();
   }

      public String getWeatherType() {
      return this.ewz.getSelected();
   }

      public boolean isRainy() {
      return this.isWeatherEnabled()
         && (
            this.ewz.isSelected("Rain")
               || this.ewz.isSelected("Thunder")
               || this.ewz.isSelected("Snow")
         );
   }

      public boolean isThunder() {
      return this.isWeatherEnabled() && this.ewz.isSelected("Thunder");
   }

      public boolean isSnowing() {
      return this.isWeatherEnabled() && this.ewz.isSelected("Snow");
   }

      public boolean hasWeatherParticles() {
      return this.isWeatherEnabled()
         && (
            this.isSnowing()
               || this.ewz.isSelected("Sakura")
               || this.ewz.isSelected("Leaves")
         );
   }

   @EventHandler
      public void onPacket(PacketEventProvider event) {
      if (event.getType() == EventDirection.RECEIVE && event.getPacket() instanceof WorldTimeUpdateS2CPacket) {
         event.cancel();
      }
   }

      @Override
   public void onTick() {
      if (MinecraftClient.getInstance().player != null) {
         String text = this.isBrightnessEffectMode()
            ? "Effect"
            : "Gamma";
         if (!text.equals(this.yznol)) {
            if (this.handleField81 && text.equals("Gamma")) {
               this.dhik();
            }

            this.yznol = text;
         }

         if (this.isState() && this.isBrightnessEffectMode()) {
            this.handleField81 = true;
            if (!MinecraftClient.getInstance().player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
               MinecraftClient.getInstance().player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 2147483647, 0, false, false));
            }
         } else if (this.handleField81) {
            this.dhik();
         }

         boolean enabled = this.isState() && this.isBrightnessGammaMode();
         if (enabled) {
            this.ulzcq = true;
            this.ideksw();
         } else if (this.ulzcq) {
            this.kmfuiw();
         }

         this.dhlh();
      }
   }

      private void dhik() {
      if (MinecraftClient.getInstance().player != null && this.handleField81) {
         MinecraftClient.getInstance().player.removeStatusEffect(StatusEffects.NIGHT_VISION);
      }

      this.handleField81 = false;
   }

      private void kmfuiw() {
      this.ulzcq = false;
      this.ideksw();
   }

      private void ideksw() {
      if (MinecraftClient.getInstance().gameRenderer != null && MinecraftClient.getInstance().gameRenderer.getLightmapTextureManager() != null) {
         ((LightmapTextureManagerMixin)MinecraftClient.getInstance().gameRenderer.getLightmapTextureManager()).noxiumvisual$setDirty(true);
      }
   }

      private void dhlh() {
      if (MinecraftClient.getInstance().world != null && MinecraftClient.getInstance().player != null) {
         boolean enabled = this.isState() && this.hasWeatherParticles();
         String text = this.getWeatherType();
         if (this.computeField27 && (!enabled || !text.equals(this.validateField34))) {
            this.n17();
         }

         if (enabled) {
            this.computeField27 = true;
            this.validateField34 = text;
            boolean enabled2 = this.ewz.isSelected("Sakura")
               || this.ewz.isSelected("Leaves");
            if (!enabled2 || this.isField33++ % 4 == 0) {
               ParticleEffect particleEffect = this.convertMethod11();
               int index = enabled2 ? 2 : 5;

               for (int index2 = 0; index2 < index; index2++) {
                  double x = MinecraftClient.getInstance().player.getX()
                     + (MinecraftClient.getInstance().world.random.nextDouble() - 0.5) * 20.0;
                  double y = MinecraftClient.getInstance().player.getY()
                     + 4.0
                     + MinecraftClient.getInstance().world.random.nextDouble() * 8.0;
                  double z = MinecraftClient.getInstance().player.getZ()
                     + (MinecraftClient.getInstance().world.random.nextDouble() - 0.5) * 20.0;
                  double value = this.isSnowing() ? 0.006 : 0.028;
                  double value2 = this.isSnowing() ? 0.012 : 0.032;
                  double client = (MinecraftClient.getInstance().world.random.nextDouble() - 0.5) * value;
                  double client2 = -(value2 + MinecraftClient.getInstance().world.random.nextDouble() * value2);
                  double client3 = (MinecraftClient.getInstance().world.random.nextDouble() - 0.5) * value;
                  Particle client4 = MinecraftClient.getInstance().particleManager.addParticle(particleEffect, x, y, z, client, client2, client3);
                  if (client4 == null && this.ewz.isSelected("Sakura")) {
                     client4 = MinecraftClient.getInstance().particleManager.addParticle(ParticleTypes.FALLING_SPORE_BLOSSOM, x, y, z, client, client2, client3);
                  } else if (client4 == null && this.ewz.isSelected("Leaves")) {
                     client4 = MinecraftClient.getInstance().particleManager.addParticle(GREEN_LEAVES_FALLBACK, x, y, z, client, client2, client3);
                  }

                  if (client4 != null && this.ewz.isSelected("Leaves")) {
                     client4.setColor(0.35F, 0.72F, 0.22F);
                  }
               }
            }
         }
      } else {
         this.n17();
      }
   }

      private ParticleEffect convertMethod11() {
      if (this.isSnowing()) {
         return ParticleTypes.SNOWFLAKE;
      } else {
         return this.ewz.isSelected("Leaves")
            ? ParticleTypes.PALE_OAK_LEAVES
            : ParticleTypes.CHERRY_LEAVES;
      }
   }

      private void n17() {
      if (this.computeField27) {
         if (MinecraftClient.getInstance().particleManager != null) {
            ((ParticleManagerMixin)MinecraftClient.getInstance().particleManager).noxiumvisual$clearParticles();
         }

         this.computeField27 = false;
         this.validateField34 = "";
         this.isField33 = 0;
      }
   }

}
