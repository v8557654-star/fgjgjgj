package winvi.noxiumvisuals.modules.client;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class ItemHighlighterModule extends Module {
      public final BooleanSetting paintHeldItems;

   public ItemHighlighterModule() {
      super("Item Highlighter", ModuleCategory.CLIENT);
      this.paintHeldItems = new BooleanSetting(
            "Paint Held Item",
            "Tint matching items while they are rendered in hand"
         )
         .setValue(true);
      this.setup(new ModuleSetting[]{this.paintHeldItems});
      this.setKey(-1);
   }

}
