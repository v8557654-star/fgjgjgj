package winvi.noxiumvisuals.modules.client;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Formatting;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.TextSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.TextEventProvider;
import winvi.noxiumvisuals.systems.managers.FriendManager;
public class NameProtectModule extends Module {
      private final TextSetting btknk;
      private final BooleanSetting stopField910;
      private final ColorSetting addField43;
      private final MultiSelectSetting hlcum;

   public NameProtectModule() {
      super(
         "NameProtect",
         "Name Protect",
         ModuleCategory.CLIENT
      );
      this.btknk = new TextSetting(
            "Name",
            "Nickname that will be replaced with yours"
         )
         .setText("Protect")
         .setMax(16);
      this.btknk.withTranslation("nameprotect.name", "nameprotect.name.desc");
      this.stopField910 = new BooleanSetting(
            "Friends",
            "Hides friends' nicknames"
         )
         .setValue(true);
      this.stopField910.withTranslation("nameprotect.friends", "nameprotect.friends.desc");
      this.addField43 = new ColorSetting(
            "Color",
            "Color for protected name"
         )
         .setColor(-1);
      this.hlcum = new MultiSelectSetting(
            "Text Style",
            "Text formatting styles"
         )
         .value(
            "Bold",
            "Italic",
            "Underline",
            "Strikethrough"
         );
      this.setup(new ModuleSetting[]{this.btknk, this.stopField910, this.addField43, this.hlcum});
   }

      public static NameProtectModule getInstance() {
      return ModuleLookup.get(NameProtectModule.class);
   }

      public int getCustomColor() {
      return this.addField43.getColor();
   }

      public String getProtectedName() {
      String text = this.btknk.getText();
      return text != null && !text.isBlank() ? text : "Protect";
   }

      public boolean shouldProtect(String name) {
      if (this.isState() && name != null && MinecraftClient.getInstance().getSession() != null) {
         String client = MinecraftClient.getInstance().getSession().getUsername();
         return name.equalsIgnoreCase(client) ? true : this.stopField910.isValue() && FriendManager.isFriend(name);
      } else {
         return false;
      }
   }

      public String protectPlain(String name) {
      return this.shouldProtect(name) ? this.getProtectedName() : name;
   }

   @EventHandler
      public void onTextFactory(TextEventProvider event) {
      if (this.isState() && MinecraftClient.getInstance().getSession() != null) {
         String client = MinecraftClient.getInstance().getSession().getUsername();
         String text = this.rixzpt();
         event.replaceText(client, text);
         if (this.stopField910.isValue()) {
            for (String text2 : FriendManager.getFriendNames()) {
               if (!text2.equalsIgnoreCase(client)) {
                  event.replaceText(text2, text);
               }
            }
         }
      }
   }

      private String rixzpt() {
      int color = this.addField43.getColor();
      String text = String.format("%06X", color & 16777215);
      StringBuilder stringBuilder = new StringBuilder("§x");

      for (int index = 0; index < text.length(); index++) {
         stringBuilder.append('§').append(text.charAt(index));
      }

      return stringBuilder + this.ivcfyn() + this.getProtectedName() + Formatting.RESET;
   }

      private String ivcfyn() {
      StringBuilder stringBuilder = new StringBuilder();
      List list = this.hlcum.getSelected();
      if (list.contains("Bold")) {
         stringBuilder.append(Formatting.BOLD);
      }

      if (list.contains("Italic")) {
         stringBuilder.append(Formatting.ITALIC);
      }

      if (list.contains("Underline")) {
         stringBuilder.append(Formatting.UNDERLINE);
      }

      if (list.contains("Strikethrough")) {
         stringBuilder.append(Formatting.STRIKETHROUGH);
      }

      return stringBuilder.toString();
   }

}
