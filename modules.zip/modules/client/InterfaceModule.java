package winvi.noxiumvisuals.modules.client;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.KeybindSetting;
import winvi.noxiumvisuals.modules.settings.ActionSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.modules.manager.CustomChatModule;
import winvi.noxiumvisuals.modules.manager.InventoryModule;
import winvi.noxiumvisuals.systems.events.RenderEventData;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.ui.gui.CustomScreenManager;
import winvi.noxiumvisuals.ui.gui.CounterGuiScreen;
import winvi.noxiumvisuals.ui.gui.ClickGuiScreen;
import winvi.noxiumvisuals.utils.JsonFileRenderer;
import winvi.noxiumvisuals.utils.CustomSoundAssetRegistry;
import winvi.noxiumvisuals.utils.Language;
public class InterfaceModule extends Module {
      private final KeybindSetting susph;
      private final ChoiceSetting dusic;
      private final ChoiceSetting md1;
      private final ChoiceSetting e16;
   private final BooleanSetting formatField86;
   private final BooleanSetting liveMenu;
   private final ChoiceSetting dysonScheme;
   private final NumberSetting dysonBloom;
   private final BooleanSetting dysonGlitches;
   private final NumberSetting dysonRotation;
   private final NumberSetting dysonScale;
   private final BooleanSetting dysonEnabled;
   private final BooleanSetting tofjs;
      private final BooleanSetting computeField2;
      private final BooleanSetting calculateField56;
      private final BooleanSetting dmjp;
      private final ChoiceSetting mk;
      private final ChoiceSetting hasField98;
      private final NumberSetting formatField55;
      private final NumberSetting n13;
      private final ActionSetting dmo;
      private final ChoiceSetting deleteField820;
      private final MultiSelectSetting checkField64;
      private static final Map<String, Class<? extends Module>> hasField130 = new HashMap<>();

   public InterfaceModule() {
      super("Interface", ModuleCategory.CLIENT);
      this.susph = new KeybindSetting(
            "GUI Key",
            "Key to open GUI"
         )
         .setKey(344);
      this.susph.withTranslation("guisettings.guibind", "guisettings.guibind.desc");
      this.dusic = new ChoiceSetting(
            "GUI Style",
            "Select click GUI style"
         )
         .value(
            "Noxium",
            "Counter"
         )
         .selected("Noxium");
      this.dusic.withTranslation("guisettings.guistyle", "guisettings.guistyle.desc");
      this.md1 = new ChoiceSetting(
            "GUI Animation",
            "Select the GUI appearance animation"
         )
         .value(
            "Cascade",
            "macOS",
            "Fade",
            "Slide",
            "Bounce",
            "Drop",
            "Rise"
         )
         .selected("Cascade");
      this.md1.withTranslation("guisettings.guianimation", "guisettings.guianimation.desc");
      this.e16 = new ChoiceSetting(
            "GUI Size",
            "ClickGUI size in percent"
         )
         .value(
            "75%",
            "100%",
            "125%",
            "150%",
            "175%",
            "200%",
            "300%"
         )
         .selected("100%");
      this.e16.withTranslation("guisettings.guiscale", "guisettings.guiscale.desc");
      this.formatField86 = new BooleanSetting(
            "Custom Menu",
            "Use the custom main menu"
         )
         .setValue(true);
      this.formatField86.withTranslation("guisettings.custommenu", "guisettings.custommenu.desc");
      this.liveMenu = new BooleanSetting(
            "3D Live Menu",
            "Use the interactive 3D main menu"
         )
         .setValue(false);
      this.liveMenu.withTranslation("guisettings.livemenu", "guisettings.livemenu.desc");
      this.dysonScheme = new ChoiceSetting(
            "Dyson Color Scheme",
            "Hologram palette of the Dyson sphere background"
         )
         .value("Supernova", "Quasar", "Pulsar")
         .selected("Supernova");
      this.dysonScheme.withTranslation("guisettings.dysonscheme", "guisettings.dysonscheme.desc");
      this.dysonBloom = new NumberSetting(
            "Dyson Bloom",
            "Glow intensity of the sphere background"
         )
         .range(0, 100)
         .setValue(60.0F);
      this.dysonBloom.setInteger(true);
      this.dysonBloom.withTranslation("guisettings.dysonbloom", "guisettings.dysonbloom.desc");
      this.dysonGlitches = new BooleanSetting(
            "Dyson Glitches",
            "Hologram noise and digital artifacts"
         )
         .setValue(true);
      this.dysonGlitches.withTranslation("guisettings.dysonglitches", "guisettings.dysonglitches.desc");
      this.dysonRotation = new NumberSetting(
            "Ring Rotation",
            "Rotation speed of the Dyson rings"
         )
         .range(0, 100)
         .setValue(25.0F);
      this.dysonRotation.setInteger(true);
      this.dysonRotation.withTranslation("guisettings.dysonrotation", "guisettings.dysonrotation.desc");
      this.dysonScale = new NumberSetting(
            "Dyson Scale",
            "Size of the Dyson sphere background"
         )
         .range(30, 130)
         .setValue(100.0F);
      this.dysonScale.setInteger(true);
      this.dysonScale.withTranslation("guisettings.dysonscale", "guisettings.dysonscale.desc");
      this.dysonEnabled = new BooleanSetting(
            "Dyson Background",
            "Show the Dyson sphere background in the live menu"
         )
         .setValue(true);
      this.dysonEnabled.withTranslation("guisettings.dysonbackground", "guisettings.dysonbackground.desc");
      this.tofjs = new BooleanSetting(
            "Online Counter",
            "Show NoxiumVisual online count in main menus"
         )
         .setValue(true);
      this.tofjs.withTranslation("guisettings.onlinecounter", "guisettings.onlinecounter.desc");
      this.computeField2 = new BooleanSetting(
            "Save Opened Settings",
            "Keep module settings open after closing the GUI"
         )
         .setValue(false);
      this.computeField2.withTranslation("guisettings.saveopenedsettings", "guisettings.saveopenedsettings.desc");
      this.calculateField56 = new BooleanSetting(
            "GUI Wheel Move",
            "Move the whole GUI up and down with mouse wheel"
         )
         .setValue(true);
      this.calculateField56.withTranslation("guisettings.guiwheelmove", "guisettings.guiwheelmove.desc");
      CustomSoundAssetRegistry.refresh(true);
      this.dmjp = new BooleanSetting(
            "GUI Background",
            "Render a custom image behind ClickGUI"
         )
         .setValue(false);
      this.dmjp.withTranslation("guisettings.counterbackground", "guisettings.counterbackground.desc");
      this.mk = new ChoiceSetting(
            "Background Image",
            "PNG image used as the Counter GUI background"
         )
         .value(CustomSoundAssetRegistry.getTextureKeys().toArray(x$0 -> {
            return new String[x$0];
         }))
         .selected("none")
         .displayFormatter(CustomSoundAssetRegistry::getDisplayName)
         .visible(this.dmjp::isValue);
      this.mk.withTranslation("guisettings.counterbackgroundtexture", "guisettings.counterbackgroundtexture.desc");
      this.hasField98 = new ChoiceSetting(
            "Image Fit",
            "How the image fills Counter GUI"
         )
         .value(
            "Cover",
            "Contain",
            "Stretch"
         )
         .selected("Cover")
         .visible(this.dmjp::isValue);
      this.hasField98.withTranslation("guisettings.counterbackgroundfit", "guisettings.counterbackgroundfit.desc");
      this.formatField55 = new NumberSetting(
            "Image Opacity",
            "Counter GUI background image opacity"
         )
         .setValue(0.72F)
         .range(0.05F, 1F)
         .visible(this.dmjp::isValue);
      this.formatField55.withTranslation("guisettings.counterbackgroundopacity", "guisettings.counterbackgroundopacity.desc");
      this.n13 = new NumberSetting(
            "Image Dim",
            "Dark overlay over the background image"
         )
         .setValue(0.18F)
         .range(0F, 0.8F)
         .visible(this.dmjp::isValue);
      this.n13.withTranslation("guisettings.counterbackgrounddim", "guisettings.counterbackgrounddim.desc");
      this.dmo = new ActionSetting(
            "Background Folder",
            "Open the Counter GUI background folder"
         )
         .setButtonName("Open Folder")
         .setRunnable(CustomSoundAssetRegistry::openFolder);
      this.dmo.withTranslation("guisettings.counterbackgroundfolder", "guisettings.counterbackgroundfolder.desc");
      this.deleteField820 = new ChoiceSetting(
            "Interface Language",
            "Language used by the client interface"
         )
         .value("RU", "EN")
         .selected("RU")
         .visible(() -> {
            return false;
         })
         .onChange(value -> {
            this.zfdwap();
         });
      this.checkField64 = new MultiSelectSetting(
            "HUD Elements",
            "Select which HUD elements to display"
         )
         .value(
            "Target HUD",
            "Coordinates",
            "Information HUD",
            "Armor",
            "HotBar",
            "Inventory",
            "Potions",
            "Cooldowns",
            "Hotkeys",
            "ScoreBoard",
            "Notifications",
            "Custom Chat"
         )
         .selected();
      this.checkField64.withTranslation("guisettings.hudelements", "guisettings.hudelements.desc");
      this.setKey(-1);
      NoxiumVisuals.getInstance().getEventManager().register(this);
      this.checkField64.onChange(selected -> {
         this.syncHudElements();
      });
      this.setup(
         new ModuleSetting[]{
            this.susph,
            this.dusic,
            this.md1,
            this.e16,
            this.formatField86,
            this.liveMenu,
            this.dysonScheme,
            this.dysonBloom,
            this.dysonGlitches,
            this.dysonRotation,
            this.dysonScale,
            this.dysonEnabled,
            this.tofjs,
            this.computeField2,
            this.calculateField56,
            this.dmjp,
            this.mk,
            this.hasField98,
            this.formatField55,
            this.n13,
            this.dmo,
            this.deleteField820,
            this.checkField64
         }
      );
      this.hhreod();
      this.syncHudSelectionFromModules();
      this.zfdwap();
   }

      @Override
   public void setState(boolean state) {
      super.setState(state);
   }

      public void toggle() {
   }

      public boolean shouldShowOnlineCounter() {
      return this.tofjs.isValue();
   }

      @Override
   public void activate() {
      super.activate();
      this.syncHudElements();
   }

      private void hhreod() {
      if (NoxiumVisuals.getInstance() != null && NoxiumVisuals.getInstance().getModuleProvider() != null) {
         for (Entry entry : hasField130.entrySet()) {
            this.rotwqz((String)entry.getKey(), (Class<? extends Module>)entry.getValue());
         }
      }
   }

      private void rotwqz(String displayName, Class<? extends Module> moduleClass) {
      try {
         Module module = this.hoilrn(moduleClass);
         if (module != null) {
            module.setStateChangeCallback(state -> {
               ArrayList var3x = new ArrayList<>(this.checkField64.getSelected());
               if (state && !var3x.contains(displayName)) {
                  var3x.add(displayName);
               } else {
                  if (state || !var3x.contains(displayName)) {
                     return;
                  }

                  var3x.remove(displayName);
               }

               this.checkField64.setSelected(var3x);
            });
         }
      } catch (Exception exception) {
      }
   }

      public void syncHudElements() {
      if (NoxiumVisuals.getInstance() != null && NoxiumVisuals.getInstance().getModuleProvider() != null) {
         for (Entry entry : hasField130.entrySet()) {
            this.mpwzhf((String)entry.getKey(), (Class<? extends Module>)entry.getValue());
         }
      }
   }

      public void syncHudSelectionFromModules() {
      if (NoxiumVisuals.getInstance() != null && NoxiumVisuals.getInstance().getModuleProvider() != null) {
         ArrayList arrayList = new ArrayList();

         for (Entry entry : hasField130.entrySet()) {
            Module module = this.hoilrn((Class<? extends Module>)entry.getValue());
            if (module != null && module.isState()) {
               arrayList.add((String)entry.getKey());
            }
         }

         if (!arrayList.equals(this.checkField64.getSelected())) {
            this.checkField64.setSelected(arrayList);
         }
      }
   }

      private void mpwzhf(String displayName, Class<? extends Module> moduleClass) {
      try {
         Module module = this.hoilrn(moduleClass);
         if (module != null) {
            boolean enabled = this.checkField64.isSelected(displayName) || this.ckjs(displayName);
            if (module.isState() != enabled) {
               module.setState(enabled);
            }
         }
      } catch (Exception exception) {
      }
   }

      private Module hoilrn(Class<? extends Module> moduleClass) {
      if (NoxiumVisuals.getInstance() != null && NoxiumVisuals.getInstance().getModuleProvider() != null) {
         List list = NoxiumVisuals.getInstance().getModuleProvider().getModules();

         for (int index = 0; index < list.size(); index++) {
            Module module = (Module)list.get(index);
            if (moduleClass.isInstance(module)) {
               return module;
            }
         }

         return null;
      } else {
         return null;
      }
   }

      private boolean ckjs(String displayName) {
      return switch (displayName) {
         case "Cooldowns" -> this.checkField64
               .isSelected("CoolDowns")
            || this.checkField64.isSelected("Cool Downs");
         case "Hotkeys" -> this.checkField64
               .isSelected("KeyBinds")
            || this.checkField64.isSelected("Key Binds");
         case "Information HUD" -> this.checkField64
               .isSelected("Information")
            || this.checkField64.isSelected("TPS")
            || this.checkField64.isSelected("TPS Info");
         default -> false;
      };
   }

   @EventHandler
      public void onKey(RenderEventData e) {
      if (e.key() == this.susph.getKey() && e.action() == 1) {
         if (CustomScreenManager.isOpen()) {
            CustomScreenManager.requestClose();
         } else {
            this.openConfiguredGui();
         }
      }
   }

      public void openConfiguredGui() {
      winvi.noxiumvisuals.ui.gui.BlackholeGuiScreen.INSTANCE.openGui();
   }

      public boolean isCounterGuiSelected() {
      return this.dusic != null && this.dusic.isSelected("Counter");
   }

      public String getGuiAnimation() {
      if (this.md1 != null && this.md1.getSelected() != null) {
         String text = this.md1.getSelected().toLowerCase(Locale.ROOT);

         return switch (text) {
            case "macos", "fade", "slide", "bounce", "drop", "rise" -> this.md1.getSelected();
            default -> "Cascade";
         };
      } else {
         return "Cascade";
      }
   }

      public KeybindSetting getGuiBind() {
      return this.susph;
   }

      public ChoiceSetting getGuiScale() {
      return this.e16;
   }

      public float getGuiScaleFactor() {
      String text = this.e16.getSelected();
      if (text == null) {
         return 1F;
      } else {
         try {
            float value = Float.parseFloat(text.replace("%", ""));
            return Math.max(0.75F, Math.min(3.0F, value / 100.0F));
         } catch (NumberFormatException numberFormatException) {
            return 1F;
         }
      }
   }

      public boolean shouldSaveOpenedSettings() {
      return this.computeField2.isValue();
   }

      public boolean shouldMoveGuiWithWheel() {
      return this.calculateField56.isValue();
   }

      public BooleanSetting getCounterBackgroundEnabled() {
      return this.dmjp;
   }

      public ChoiceSetting getCounterBackgroundTexture() {
      return this.mk;
   }

      public ChoiceSetting getCounterBackgroundFit() {
      return this.hasField98;
   }

      public NumberSetting getCounterBackgroundOpacity() {
      return this.formatField55;
   }

      public NumberSetting getCounterBackgroundDim() {
      return this.n13;
   }

      public boolean isCustomMenuEnabled() {
      return this.formatField86.isValue();
   }

      public boolean isLiveMenuEnabled() {
      return this.liveMenu.isValue();
   }

      public void toggleLiveMenu() {
      this.liveMenu.setValue(!this.liveMenu.isValue());
   }

      public String getDysonScheme() {
      return this.dysonScheme.getSelected();
   }

      public float getDysonBloom() {
      return this.dysonBloom.getValue();
   }

      public boolean isDysonGlitchesEnabled() {
      return this.dysonGlitches.isValue();
   }

      public float getDysonRotation() {
      return this.dysonRotation.getValue();
   }

      public void setDysonRotation(float value) {
      this.dysonRotation.setValue(value);
   }

      public void setDysonBloom(float value) {
      this.dysonBloom.setValue(value);
   }

      public void setDysonGlitches(boolean value) {
      this.dysonGlitches.setValue(value);
   }

      public float getDysonScale() {
      return this.dysonScale.getValue();
   }

      public void setDysonScale(float value) {
      this.dysonScale.setValue(value);
   }

      public boolean isDysonEnabled() {
      return this.dysonEnabled.isValue();
   }

      public void setDysonEnabled(boolean value) {
      this.dysonEnabled.setValue(value);
   }

      public void cycleDysonScheme() {
      List<String> values = this.dysonScheme.getValues();
      if (!values.isEmpty()) {
         int index = values.indexOf(this.dysonScheme.getSelected());
         this.dysonScheme.setSelected(values.get((index + 1) % values.size()));
      }
   }

      public Language getInterfaceLanguage() {
      return Language.fromCode(this.deleteField820.getSelected());
   }

      public void toggleInterfaceLanguage() {
      String text = this.getInterfaceLanguage() == Language.RUSSIAN ? Language.ENGLISH.getCode() : Language.RUSSIAN.getCode();
      this.deleteField820.updateSelected(text);
      this.zfdwap();
   }

      private void zfdwap() {
      if (this.deleteField820 != null) {
         JsonFileRenderer.setLanguage(this.getInterfaceLanguage());
      }
   }

      public MultiSelectSetting getHudElements() {
      return this.checkField64;
   }

   static {
      int index = 0;
      hasField130.put("Target HUD", TargetHUDModule.class);
      hasField130.put("Coordinates", CoordinatesInfoModule.class);
      hasField130.put("Information HUD", InformationHUDModule.class);
      hasField130.put("Armor", ArmorModule.class);
      hasField130.put("HotBar", HotBarModule.class);
      hasField130.put("Inventory", InventoryModule.class);
      hasField130.put("Potions", PotionsModule.class);
      hasField130.put("Cooldowns", CooldownsModule.class);
      hasField130.put("Hotkeys", HotkeysModule.class);
      hasField130.put("ScoreBoard", ScoreBoardModule.class);
      hasField130.put("Notifications", NotificationsModule.class);
      hasField130.put("Custom Chat", CustomChatModule.class);
   }
}
