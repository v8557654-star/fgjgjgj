package winvi.noxiumvisuals.modules.client;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.TextSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.utils.DiscordJsonManager;
public class RPCModule extends Module {
      private final ChoiceSetting transformField46;
      private final TextSetting deleteField84;
      private long processField29;
      private long zayaq;
      private String dnao;
      private String updateField78;

   public RPCModule() {
      super("RPC", ModuleCategory.CLIENT);
      this.transformField46 = new ChoiceSetting(
            "RPC State",
            "What to show in status"
         )
         .value(
            "NAME",
            "IP",
            "CUSTOM"
         )
         .selected("NAME");
      this.transformField46.withTranslation("rpc.state", "rpc.state.desc");
      this.deleteField84 = new TextSetting(
            "Custom State Text",
            "Text for CUSTOM"
         )
         .setText("Playing with NoxiumVisuals");
      this.deleteField84.withTranslation("rpc.custom", "rpc.custom.desc");
      this.processField29 = 0L;
      this.zayaq = 0L;
      this.dnao = "";
      this.updateField78 = "";
      this.setup(new ModuleSetting[]{this.transformField46, this.deleteField84});
      this.setState(true);
   }

      @Override
   public void activate() {
      this.zayaq = System.currentTimeMillis() / 1000L;
      this.processField29 = 0L;
      this.dnao = "";
      this.updateField78 = "";
      DiscordJsonManager discordJsonManager = NoxiumVisuals.getInstance().getDiscordManager();
      discordJsonManager.init();
   }

   @EventHandler
      public void onTick(ClientTickEvent e) {
      if (this.isState()) {
         DiscordJsonManager discordJsonManager = NoxiumVisuals.getInstance().getDiscordManager();
         long timestamp = System.currentTimeMillis();
         if (timestamp - this.processField29 >= 1000L) {
            this.processField29 = timestamp;
            String text = this.kn();
            String text2 = this.ko();
            if (!text.equals(this.dnao) || !text2.equals(this.updateField78) || !discordJsonManager.isRunning()) {
               ClientPlayerEntity client = MinecraftClient.getInstance().player;
               if (client != null) {
                  if (this.zayaq <= 0L) {
                     this.zayaq = System.currentTimeMillis() / 1000L;
                  }

                  if (discordJsonManager.updatePresence("Dev: @auto_pack", text, this.zayaq)) {
                     this.dnao = text;
                     this.updateField78 = text2;
                  }
               }
            }
         }
      }
   }

      private String kn() {
      ClientPlayerEntity client = MinecraftClient.getInstance().player;
      if (client == null) {
         return "Offline";
      } else {
         String text = this.transformField46.getSelected();

         return switch (text) {
            case "IP" -> MinecraftClient.getInstance().getNetworkHandler() != null
                  && MinecraftClient.getInstance().getNetworkHandler().getServerInfo() != null
                  && MinecraftClient.getInstance().getNetworkHandler().getServerInfo().address != null
               ? MinecraftClient.getInstance().getNetworkHandler().getServerInfo().address.toLowerCase()
               : "Offline";
            case "CUSTOM" -> this.deleteField84.getText() == null
               ? "Playing with NoxiumVisuals"
               : this.deleteField84.getText();
            default -> client.getGameProfile() != null
               ? client.getGameProfile().getName()
               : "NoxiumVisuals";
         };
      }
   }

      private String ko() {
      if (MinecraftClient.getInstance().getNetworkHandler() != null && MinecraftClient.getInstance().getNetworkHandler().getServerInfo() != null) {
         return MinecraftClient.getInstance().getNetworkHandler().getServerInfo().address != null
            ? MinecraftClient.getInstance().getNetworkHandler().getServerInfo().address.toLowerCase()
            : "";
      } else {
         return "";
      }
   }

      @Override
   public void deactivate() {
      DiscordJsonManager discordJsonManager = NoxiumVisuals.getInstance().getDiscordManager();
      discordJsonManager.stopRPC();
      this.zayaq = 0L;
      this.processField29 = 0L;
      this.dnao = "";
      this.updateField78 = "";
   }

      public String getState() {
      return this.transformField46.getSelected();
   }

      public String getCustomText() {
      return this.deleteField84.getText();
   }

}
