package winvi.noxiumvisuals.modules.client;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.ActionSetting;
import winvi.noxiumvisuals.ui.gui.ClickGuiScreen;
public class FriendsManagerModule extends Module {

   public FriendsManagerModule() {
      super("Friends Manager", ModuleCategory.CLIENT);
      ActionSetting client = new ActionSetting(
            "Open Friends",
            "Open friends list window"
         )
         .setButtonName("Open Friends")
         .setRunnable(() -> {
            if (MinecraftClient.getInstance().currentScreen != null) {
               ClickGuiScreen.INSTANCE.openUtilsFriendsTab();
            }
         });
      this.setup(new ModuleSetting[]{client});
      this.setKey(-1);
   }

      @Override
   public void setState(boolean state) {
      super.setState(state);
   }

      public void toggle() {
   }

   static {
      int index = 0;
   }
}
