package winvi.noxiumvisuals.modules.client;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
public class CustomLoadingScreenModule extends Module {
      private static CustomLoadingScreenModule xipjt;
      private final ChoiceSetting linau;

   public CustomLoadingScreenModule() {
      super(
         "Custom Loading Screen",
         "Custom loading screen",
         ModuleCategory.CLIENT
      );
      this.linau = new ChoiceSetting(
            "Style",
            "Loading screen style selection"
         )
         .value(
            "Winvi",
            "Hello"
         )
         .selected("Winvi")
         .withTranslation("customloadingscreen.style", "customloadingscreen.style.desc");
      this.setState(true);
      xipjt = this;
      this.setup(new ModuleSetting[]{this.linau});
   }

      @Override
   public void activate() {
      super.activate();
   }

      @Override
   public void deactivate() {
      super.deactivate();
   }

      public ChoiceSetting getStyle() {
      return this.linau;
   }

      public static CustomLoadingScreenModule getInstance() {
      return xipjt;
   }

}
