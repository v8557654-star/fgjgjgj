package winvi.noxiumvisuals.modules.client;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.awt.Color;
import net.minecraft.client.MinecraftClient;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.ActionSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.ui.gui.ClickGuiScreen;
import winvi.noxiumvisuals.systems.theme.ThemeSettings;
import winvi.noxiumvisuals.utils.ColorAnimationProvider;
public class ThemeModule extends Module {
      public static ThemeModule INSTANCE;

   public ThemeModule() {
      super("Theme", ModuleCategory.CLIENT);
      ActionSetting client = new ActionSetting(
            "Open Themes",
            "Open themes selection window"
         )
         .setButtonName("Open Themes")
         .setRunnable(() -> {
            if (MinecraftClient.getInstance().currentScreen != null) {
               ClickGuiScreen.INSTANCE.openClientThemeTab();
            }
         });
      client.withTranslation("theme.openthemes", "theme.openthemes.desc");
      this.setup(new ModuleSetting[]{client});
      this.setKey(-1);
      super.setState(true);
      INSTANCE = this;
   }

      @Override
   public void setState(boolean state) {
      super.setState(true);
   }

      @Override
   public void switchState() {
      super.setState(true);
   }

      public void toggle() {
   }

      public ColorSetting getClientColor() {
      return ThemeSettings.INSTANCE.getClientColor();
   }

      public ColorSetting getThemeVisualColor() {
      return ThemeSettings.INSTANCE.getVisualColor();
   }

      public ColorSetting getMainGuiColor() {
      return ThemeSettings.INSTANCE.getMainGuiColor();
   }

      public ColorSetting getSubGuiColor() {
      return ThemeSettings.INSTANCE.getSubGuiColor();
   }

      public ColorSetting getComponentGuiColor() {
      return ThemeSettings.INSTANCE.getComponentGuiColor();
   }

      public ColorSetting getRectDarkerColor() {
      return new ColorSetting("", "").setColor(-16777216);
   }

      public ColorSetting getTextColor() {
      return ThemeSettings.INSTANCE.getTextColor();
   }

   @Deprecated
      public ColorSetting getSeparatorColor() {
      return ThemeSettings.INSTANCE.getOutlineColor();
   }

      public ColorSetting getOutlineColor() {
      return ThemeSettings.INSTANCE.getOutlineColor();
   }

      public BooleanSetting getGlow() {
      return ThemeSettings.INSTANCE.getGlow();
   }

      public NumberSetting getGlowIntensity() {
      return ThemeSettings.INSTANCE.getGlowIntensity();
   }

      public ColorSetting getGlowColor() {
      return ThemeSettings.INSTANCE.getGlowColor();
   }

   @Deprecated
      public BooleanSetting getHudGlow() {
      return this.getGlow();
   }

   @Deprecated
      public NumberSetting getHudGlowIntensity() {
      return this.getGlowIntensity();
   }

      public BooleanSetting getShowSmallText() {
      return ThemeSettings.INSTANCE.getShowSmallText();
   }

   @Deprecated
      public BooleanSetting getCustomGuiTextures() {
      return new BooleanSetting("", "").setValue(false);
   }

   @Deprecated
      public ColorSetting getBackgroundTextureColor() {
      return new ColorSetting("", "").setColor(-1);
   }

   @Deprecated
      public ColorSetting getAboutTextureColor() {
      return new ColorSetting("", "").setColor(-1);
   }

   @Deprecated
      public ColorSetting getTabTextureColor() {
      return new ColorSetting("", "").setColor(-1);
   }

      public NumberSetting getCornerRadius() {
      return ThemeSettings.INSTANCE.getCornerRadius();
   }

      public NumberSetting getHudCornerRadius() {
      return ThemeSettings.INSTANCE.getHudCornerRadius();
   }

      public NumberSetting getHudRectOpacity() {
      return ThemeSettings.INSTANCE.getHudRectOpacity();
   }

      public BooleanSetting getHudGlareEnabled() {
      return ThemeSettings.INSTANCE.getHudGlareEnabled();
   }

      public NumberSetting getHudGlareInterval() {
      return ThemeSettings.INSTANCE.getHudGlareInterval();
   }

      public ChoiceSetting getHudGlareLayer() {
      return ThemeSettings.INSTANCE.getHudGlareLayer();
   }

      public ColorSetting getHudGlareColor() {
      return ThemeSettings.INSTANCE.getHudGlareColor();
   }

      public BooleanSetting getEnableBlur() {
      return ThemeSettings.INSTANCE.getEnableBlur();
   }

      public NumberSetting getBlurSize() {
      return ThemeSettings.INSTANCE.getBlurSize();
   }

      public NumberSetting getBlurQuality() {
      return ThemeSettings.INSTANCE.getBlurQuality();
   }

      public NumberSetting getHudScale() {
      return ThemeSettings.INSTANCE.getHudScale();
   }

      public BooleanSetting getGuiMascotEnabled() {
      return ThemeSettings.INSTANCE.getGuiMascotEnabled();
   }

      public BooleanSetting getGuiMascotOnTop() {
      return ThemeSettings.INSTANCE.getGuiMascotOnTop();
   }

      public NumberSetting getGuiMascotScale() {
      return ThemeSettings.INSTANCE.getGuiMascotScale();
   }

      public NumberSetting getGuiMascotOpacity() {
      return ThemeSettings.INSTANCE.getGuiMascotOpacity();
   }

      public NumberSetting getGuiMascotX() {
      return ThemeSettings.INSTANCE.getGuiMascotX();
   }

      public NumberSetting getGuiMascotY() {
      return ThemeSettings.INSTANCE.getGuiMascotY();
   }

      public ChoiceSetting getGuiMascotTexture() {
      return ThemeSettings.INSTANCE.getGuiMascotTexture();
   }

      public ChoiceSetting getGuiMascotSlideDirection() {
      return ThemeSettings.INSTANCE.getGuiMascotSlideDirection();
   }

      public ActionSetting getGuiMascotOpenFolder() {
      return ThemeSettings.INSTANCE.getGuiMascotOpenFolder();
   }

      public BooleanSetting getGuiEffectEnabled() {
      return ThemeSettings.INSTANCE.getGuiEffectEnabled();
   }

      public NumberSetting getGuiEffectOpacity() {
      return ThemeSettings.INSTANCE.getGuiEffectOpacity();
   }

      public NumberSetting getMainMenuEffectOpacity() {
      return ThemeSettings.INSTANCE.getMainMenuEffectOpacity();
   }

      public ChoiceSetting getGuiPanelHeightMode() {
      return ThemeSettings.INSTANCE.getGuiPanelHeightMode();
   }

   @Deprecated
      public BooleanSetting getShowCategoryDividers() {
      return new BooleanSetting("", "").setValue(false);
   }

      public float getAnimationSpeed() {
      return ColorAnimationProvider.getAnimationSpeed();
   }

      public int getColorCountValue() {
      return ColorAnimationProvider.getColorCountValue();
   }

      public Color getColor(float position) {
      return ColorAnimationProvider.getColor(position);
   }

      public Color getRandomColor() {
      return ColorAnimationProvider.getRandomColor();
   }

      public Color getColor1() {
      return ColorAnimationProvider.getColor1();
   }

      public Color getColor2() {
      return ColorAnimationProvider.getColor2();
   }

      public Color getColor3() {
      return ColorAnimationProvider.getColor3();
   }

      public Color getColor4() {
      return ColorAnimationProvider.getColor4();
   }

      public ChoiceSetting getColorCount() {
      return ThemeSettings.INSTANCE.getColorCount();
   }

      public ColorSetting getColorSetting1() {
      return ThemeSettings.INSTANCE.getColor1();
   }

      public ColorSetting getColorSetting2() {
      return ThemeSettings.INSTANCE.getColor2();
   }

      public ColorSetting getColorSetting3() {
      return ThemeSettings.INSTANCE.getColor3();
   }

      public ColorSetting getColorSetting4() {
      return ThemeSettings.INSTANCE.getColor4();
   }

      public boolean isGradientEnabled() {
      return false;
   }

}
