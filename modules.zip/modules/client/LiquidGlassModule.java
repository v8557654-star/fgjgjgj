package winvi.noxiumvisuals.modules.client;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class LiquidGlassModule extends Module {
      public static NumberSetting fresnelPower = new NumberSetting(
         "Fresnel Power",
         "Controls fresnel effect intensity (higher = stronger edge glow)"
      )
      .setValue(50.0F)
      .range(1F, 100.0F);
      public static NumberSetting distortStrength = new NumberSetting(
         "Distort Strength",
         "Strength of texture distortion"
      )
      .setValue(0.08F)
      .range(0F, 0.2F);
      public static BooleanSetting useBlur = new BooleanSetting(
         "Use Blur",
         "Apply blur effect to background"
      )
      .setValue(true);
      public static NumberSetting blurOffset = new NumberSetting(
         "Blur Offset",
         "Blur strength"
      )
      .setValue(1F)
      .range(0F, 2.5F);
      public static NumberSetting blurQuality = new NumberSetting(
         "Blur Quality",
         "Blur render precision (higher = cleaner, lower = faster)"
      )
      .setValue(1F)
      .range(0.25F, 1F);
      public static ColorSetting backgroundColor = new ColorSetting(
         "Background Color",
         "Color of LiquidGlass background"
      )
      .setColor(-1);
      public static BooleanSetting whiteRects = new BooleanSetting(
         "White Rects",
         "Turn dark GUI and HUD rectangles white while LiquidGlass is enabled"
      )
      .setValue(true);
      public static ColorSetting rectColor = new ColorSetting(
         "Panel Color",
         "Color replacing dark GUI and HUD panels"
      )
      .setColor(452984831);

   public LiquidGlassModule() {
      super("LiquidGlass", ModuleCategory.CLIENT);
      this.setup(new ModuleSetting[]{fresnelPower, distortStrength, useBlur, blurOffset, blurQuality, backgroundColor, whiteRects, rectColor});
      this.setState(false);
      this.setKey(-1);
   }

      public static NumberSetting getFresnelPower() {
      return fresnelPower;
   }

      public static NumberSetting getDistortStrength() {
      return distortStrength;
   }

      public static BooleanSetting getUseBlur() {
      return useBlur;
   }

      public static NumberSetting getBlurQuality() {
      return blurQuality;
   }

      public static NumberSetting getBlurOffset() {
      return blurOffset;
   }

      public static ColorSetting getBackgroundColor() {
      return backgroundColor;
   }

      public static BooleanSetting getWhiteRects() {
      return whiteRects;
   }

      public static ColorSetting getRectColor() {
      return rectColor;
   }

   static {
      int index = 0;
      fresnelPower.withTranslation("liquidglass.fresnelpower", "liquidglass.fresnelpower.desc");
      distortStrength.withTranslation("liquidglass.distortstrength", "liquidglass.distortstrength.desc");
      useBlur.withTranslation("liquidglass.useblur", "liquidglass.useblur.desc");
      blurQuality.withTranslation("liquidglass.blurquality", "liquidglass.blurquality.desc");
      blurOffset.withTranslation("liquidglass.bluroffset", "liquidglass.bluroffset.desc");
      backgroundColor.withTranslation("liquidglass.backgroundcolor", "liquidglass.backgroundcolor.desc");
      whiteRects.withTranslation("liquidglass.whiterects", "liquidglass.whiterects.desc");
      rectColor.withTranslation("liquidglass.rectcolor", "liquidglass.rectcolor.desc");
      rectColor.visible(whiteRects::isValue);
   }
}
