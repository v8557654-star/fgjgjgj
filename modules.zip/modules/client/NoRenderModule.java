package winvi.noxiumvisuals.modules.client;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
public class NoRenderModule extends Module {
      public static final MultiSelectSetting elements;

   public NoRenderModule() {
      super("NoRender", ModuleCategory.CLIENT);
      this.setState(true);
      this.setup(new ModuleSetting[]{elements});
   }

      public static boolean isEnabled(String element) {
      return elements.isSelected(element);
   }

      public static boolean hasSelections() {
      return !elements.getSelected().isEmpty();
   }

   static {
      int index = 0;
      MultiSelectSetting moduleSettingHandler = new MultiSelectSetting(
         "Elements",
         "Select elements to hide"
      );
      String[] stringArray = new String[19];
      stringArray[0] = "Fire";
      stringArray[1] = "Totem";
      stringArray[2] = "Potions";
      stringArray[3] = "Scoreboard";
      stringArray[4] = "Boss Bar";
      stringArray[5] = "Particles";
      stringArray[6] = "Armor";
      stringArray[7] = "Limbs";
      stringArray[8] = "Outline";
      stringArray[9] = "Fog";
      stringArray[10] = "Camera Shake";
      stringArray[11] = "Pumpkin Overlay";
      stringArray[12] = "Hurt Cam";
      stringArray[13] = "Lightning";
      stringArray[14] = "Skylight Updates";
      stringArray[15] = "Block Breaking";
      stringArray[16] = "Entity Shadows";
      stringArray[17] = "Enchantment Glint";
      stringArray[18] = "Animated Textures";
      elements = moduleSettingHandler.value(stringArray);
      elements.withTranslation("norender.elements", "norender.elements.desc");
   }
}
