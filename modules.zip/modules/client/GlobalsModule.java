package winvi.noxiumvisuals.modules.client;

import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.utils.network.OnlinePresenceClient;

public class GlobalsModule extends Module {
   private final OnlinePresenceClient presenceClient;
   public ChoiceSetting displayMode;

   public GlobalsModule() {
      super("Globals", ModuleCategory.CLIENT);
      this.presenceClient = OnlinePresenceClient.getInstance();
      this.displayMode = new ChoiceSetting(
            "Display Mode",
            "Choose how to display roles"
         )
         .value(
            "Icon",
            "Text"
         )
         .selected("Icon");
      this.setup(new ModuleSetting[]{this.displayMode});
   }

      @Override
   public void activate() {
      if (!this.presenceClient.isConnected() && !this.presenceClient.isConnecting()) {
         this.presenceClient.connect();
      }
   }

      @Override
   public void deactivate() {
   }

      public boolean isIconMode() {
      return this.state
         && this.presenceClient.isConnected()
         && this.displayMode.getSelected().equals("Icon");
   }

      public boolean isTextMode() {
      return this.state
         && this.presenceClient.isConnected()
         && this.displayMode.getSelected().equals("Text");
   }

      public boolean shouldShowAvatar() {
      return this.state
         && this.presenceClient.isConnected()
         && this.displayMode.getSelected().equals("Icon");
   }

      public boolean shouldShowCustomNames() {
      return this.state && this.presenceClient.isConnected();
   }

      public boolean shouldShowRole() {
      return this.state
         && this.presenceClient.isConnected()
         && this.displayMode.getSelected().equals("Text");
   }

}
