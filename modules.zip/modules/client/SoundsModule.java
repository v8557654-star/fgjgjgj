package winvi.noxiumvisuals.modules.client;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.time.LocalTime;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundSystem;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.sound.SoundEvent;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.mixins.SoundManagerAccessor;
import winvi.noxiumvisuals.mixins.SoundSystemMixin;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.EntityEventProvider;
import winvi.noxiumvisuals.utils.SoundPlayerSupport;
public class SoundsModule extends Module {
      private static boolean dnc;
      private final NumberSetting dndx;
      private final ChoiceSetting e17;
      private final ChoiceSetting acpxz;
      private final SettingGroup isField29;
      private final BooleanSetting setField4;
      private final BooleanSetting dnik;
      private final BooleanSetting formatField95;
      private final BooleanSetting rorvl;
      private final BooleanSetting dsmqr;
      private final BooleanSetting yrmog;
      private final BooleanSetting cgmws;
      private final BooleanSetting xnmub;
      private final BooleanSetting isField52;
      private final BooleanSetting nq0;

   public SoundsModule() {
      super("Sounds", ModuleCategory.CLIENT);
      this.e17 = new ChoiceSetting(
            "Click Sound",
            "Sound used for GUI interactions"
         )
         .value(
            "Scroll",
            "Click"
         )
         .selected("Scroll");
      this.e17.withTranslation("sounds.clicksound", "sounds.clicksound.desc");
      this.acpxz = new ChoiceSetting(
            "Toggle Sound",
            "Sound style used when modules are enabled or disabled"
         )
         .value("1", "2", "3")
         .selected("1");
      this.acpxz.withTranslation("sounds.togglesound", "sounds.togglesound.desc");
      this.setField4 = new BooleanSetting(
            "Game Start",
            "Play a greeting after Minecraft starts"
         )
         .setValue(true);
      this.setField4.withTranslation("sounds.noxium.start", "sounds.noxium.start.desc");
      this.dnik = new BooleanSetting(
            "Leave Game",
            "Play a voice line before Minecraft closes"
         )
         .setValue(true);
      this.dnik.withTranslation("sounds.noxium.leave", "sounds.noxium.leave.desc");
      this.formatField95 = new BooleanSetting(
            "Module Toggle",
            "Use Noxium voice lines when toggling modules"
         )
         .setValue(true);
      this.formatField95.withTranslation("sounds.noxium.moduletoggle", "sounds.noxium.moduletoggle.desc");
      this.rorvl = new BooleanSetting(
            "Telegram Button",
            "Play a voice line when hovering the Telegram button"
         )
         .setValue(true);
      this.rorvl.withTranslation("sounds.noxium.telegramhover", "sounds.noxium.telegramhover.desc");
      this.dsmqr = new BooleanSetting(
            "Fake Player",
            "Play a voice line when Fake Player spawns"
         )
         .setValue(true);
      this.dsmqr.withTranslation("sounds.noxium.fakeplayer", "sounds.noxium.fakeplayer.desc");
      this.yrmog = new BooleanSetting(
            "Secret Sounds",
            "Rare secret voice lines on startup"
         )
         .setValue(true);
      this.yrmog.withTranslation("sounds.noxium.secrets", "sounds.noxium.secrets.desc");
      this.cgmws = new BooleanSetting(
            "Own Totem",
            "Play a voice line when your totem activates"
         )
         .setValue(true);
      this.cgmws.withTranslation("sounds.noxium.owntotem", "sounds.noxium.owntotem.desc");
      this.xnmub = new BooleanSetting(
            "Other Totem",
            "Play a voice line when another entity uses a totem"
         )
         .setValue(true);
      this.xnmub.withTranslation("sounds.noxium.othertotem", "sounds.noxium.othertotem.desc");
      this.isField52 = new BooleanSetting(
            "Kill",
            "Play a voice line after your kill"
         )
         .setValue(true);
      this.isField52.withTranslation("sounds.noxium.kill", "sounds.noxium.kill.desc");
      this.nq0 = new BooleanSetting(
            "Death",
            "Play a voice line when you die"
         )
         .setValue(true);
      this.nq0.withTranslation("sounds.noxium.death", "sounds.noxium.death.desc");
      this.isField29 = new SettingGroup(
            "Noxium Sounds",
            "Voice lines for game events"
         )
         .settings(this.setField4, this.dnik, this.formatField95, this.cgmws, this.xnmub, this.isField52, this.nq0, this.rorvl, this.dsmqr, this.yrmog)
         .setValue(true);
      this.isField29.withTranslation("sounds.noxiumsounds", "sounds.noxiumsounds.desc");
      this.dndx = new NumberSetting(
            "Volume",
            "Sound volume"
         )
         .setValue(50.0F)
         .range(10.0F, 100.0F);
      this.dndx.withTranslation("sounds.volume", "sounds.volume.desc");
      this.setState(true);
      this.setup(new ModuleSetting[]{this.e17, this.acpxz, this.isField29, this.dndx});
   }

      public void playOpenGuiSound() {
      this.destroyMethod70(SoundPlayerSupport.MENU_GUI_OPEN);
   }

      public void playCloseGuiSound() {
      this.destroyMethod70(SoundPlayerSupport.MENU_GUI_CLOSE);
   }

      public void playHoverSound() {
      this.destroyMethod70(
         this.e17.isSelected("Click")
            ? SoundPlayerSupport.MENU_EVENT
            : SoundPlayerSupport.MENU_SCROLL
      );
   }

      public void playEnableSound() {
      if (this.parseMethod1(this.formatField95)) {
         this.destroyMethod70(SoundPlayerSupport.NOXIUM_MODULE_ENABLE);
      } else {
         String text = this.acpxz.getSelected();

         this.destroyMethod70(switch (text) {
            case "2" -> SoundPlayerSupport.ENABLE_2;
            case "3" -> SoundPlayerSupport.ENABLE_3;
            default -> SoundPlayerSupport.ENABLE_1;
         });
      }
   }

      public void playDisableSound() {
      if (this.parseMethod1(this.formatField95)) {
         this.destroyMethod70(SoundPlayerSupport.NOXIUM_MODULE_DISABLE);
      } else {
         String text = this.acpxz.getSelected();

         this.destroyMethod70(switch (text) {
            case "2" -> SoundPlayerSupport.DISABLE_2;
            case "3" -> SoundPlayerSupport.DISABLE_3;
            default -> SoundPlayerSupport.DISABLE_1;
         });
      }
   }

      public void playOpenSettingsSound() {
      this.destroyMethod70(SoundPlayerSupport.MENU_GUI_OPEN);
   }

      public void playCloseSettingsSound() {
      this.destroyMethod70(SoundPlayerSupport.MENU_GUI_CLOSE);
   }

      public static boolean playStartupEventOnce() {
      if (dnc) {
         return false;
      } else {
         SoundsModule soundsModule = kp0();
         if (soundsModule == null) {
            return false;
         } else {
            dnc = true;
            return soundsModule.removeMethod48();
         }
      }
   }

      public static boolean hasStartupPlayed() {
      return dnc;
   }

      public static boolean isSoundSystemReady() {
      try {
         SoundSystem client = ((SoundManagerAccessor)MinecraftClient.getInstance().getSoundManager()).noxiumvisual$getSoundSystem();
         return ((SoundSystemMixin)client).noxiumvisual$isStarted();
      } catch (Throwable throwable) {
         return false;
      }
   }

      public static boolean playLeaveEvent() {
      SoundsModule soundsModule = kp0();
      return soundsModule != null && soundsModule.parseMethod18(SoundPlayerSupport.NOXIUM_LEAVE, soundsModule.dnik);
   }

      public static void playTelegramHoverEvent() {
      SoundsModule soundsModule = kp0();
      if (soundsModule != null) {
         soundsModule.parseMethod18(SoundPlayerSupport.NOXIUM_TELEGRAM_HOVER, soundsModule.rorvl);
      }
   }

      public static void playFakePlayerSpawnEvent() {
      SoundsModule soundsModule = kp0();
      if (soundsModule != null) {
         soundsModule.parseMethod18(SoundPlayerSupport.NOXIUM_FAKE_PLAYER_SPAWN, soundsModule.dsmqr);
      }
   }

      public static boolean playTotemEvent(Entity entity) {
      SoundsModule soundsModule = kp0();
      if (soundsModule == null || entity == null) {
         return false;
      } else {
         return entity == MinecraftClient.getInstance().player
            ? soundsModule.parseMethod18(SoundPlayerSupport.NOXIUM_TOTEM_SELF, soundsModule.cgmws)
            : soundsModule.parseMethod18(SoundPlayerSupport.NOXIUM_TOTEM_OTHER, soundsModule.xnmub);
      }
   }

      public static void playFakePlayerKillEvent() {
      SoundsModule soundsModule = kp0();
      if (soundsModule != null) {
         soundsModule.parseMethod18(SoundPlayerSupport.NOXIUM_KILL, soundsModule.isField52);
      }
   }

   @EventHandler
      public void onEntityDeath(EntityEventProvider event) {
      if (MinecraftClient.getInstance().player != null && event.getEntity() != null) {
         if (event.getEntity() == MinecraftClient.getInstance().player) {
            this.parseMethod18(SoundPlayerSupport.NOXIUM_DEATH, this.nq0);
         } else {
            if (event.getEntity() instanceof LivingEntity livingEntity
               && livingEntity.getRecentDamageSource() != null
               && livingEntity.getRecentDamageSource().getAttacker() == MinecraftClient.getInstance().player) {
               this.parseMethod18(SoundPlayerSupport.NOXIUM_KILL, this.isField52);
            }
         }
      }
   }

      private static SoundsModule kp0() {
      NoxiumVisuals noxiumVisuals = NoxiumVisuals.getInstance();
      return noxiumVisuals != null && noxiumVisuals.getModuleProvider() != null ? noxiumVisuals.getModuleProvider().get(SoundsModule.class) : null;
   }

      private boolean removeMethod48() {
      if (!this.parseMethod1(this.setField4)) {
         return false;
      } else {
         ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();
         if (this.yrmog.isValue() && threadLocalRandom.nextInt(40) == 0) {
            this.destroyMethod70(SoundPlayerSupport.NOXIUM_SECRET);
            return true;
         } else if (threadLocalRandom.nextInt(5) != 0) {
            this.destroyMethod70(SoundPlayerSupport.NOXIUM_START);
            return true;
         } else {
            int index = LocalTime.now().getHour();
            SoundEvent soundEvent = index >= 5 && index < 12
               ? SoundPlayerSupport.NOXIUM_START_MORNING
               : (index >= 12 && index < 18 ? SoundPlayerSupport.NOXIUM_START_DAY : SoundPlayerSupport.NOXIUM_START_EVENING);
            this.destroyMethod70(soundEvent);
            return true;
         }
      }
   }

      private boolean parseMethod18(SoundEvent sound, BooleanSetting eventSetting) {
      if (!this.parseMethod1(eventSetting)) {
         return false;
      } else {
         this.destroyMethod70(sound);
         return true;
      }
   }

      private boolean parseMethod1(BooleanSetting eventSetting) {
      return this.isState() && this.isField29.isValue() && eventSetting.isValue();
   }

      private void destroyMethod70(SoundEvent sound) {
      if (sound != null) {
         MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(sound, 1F, this.dndx.getValue() / 100.0F));
      }
   }

}
