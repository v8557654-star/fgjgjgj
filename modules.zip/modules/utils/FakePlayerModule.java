package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.Entity.RemovalReason;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import winvi.noxiumvisuals.mixins.PlayerInteractEntityC2SPacketMixin;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.PacketEntityHandler;
import winvi.noxiumvisuals.modules.visuals.TextureParticleHandler;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.modules.visuals.ModuleLookup;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.PacketEventProvider;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
public class FakePlayerModule extends Module {
      private static final PacketEntityHandler xn = new PacketEntityHandler();
      public static TextureParticleHandler fakePlayer;
      private boolean removeField5;
      private int startField15;
      private int dhtrg;
      private int r16;
      public BooleanSetting autoTotem;
      BooleanSetting regen;
      BooleanSetting invisibility;
      BooleanSetting removeFake;

      public static FakePlayerModule getInstance() {
      return ModuleLookup.get(FakePlayerModule.class);
   }

   public FakePlayerModule() {
      super("Fake Player", ModuleCategory.UTILS);
      this.removeField5 = false;
      this.dhtrg = 0;
      this.r16 = 0;
      this.autoTotem = new BooleanSetting(
            "Auto Totem",
            "Always hold totem in off hand"
         )
         .setValue(true);
      this.autoTotem.withTranslation("fakeplayer.autototem", "fakeplayer.autototem.desc");
      this.regen = new BooleanSetting(
            "Regen",
            "Regenerate fake player HP (+5 HP every 4 ticks)"
         )
         .setValue(true);
      this.regen.withTranslation("fakeplayer.regen", "fakeplayer.regen.desc");
      this.invisibility = new BooleanSetting(
            "Invisibility",
            "Apply invisibility effect to fake player"
         )
         .setValue(false);
      this.invisibility.withTranslation("fakeplayer.invisibility", "fakeplayer.invisibility.desc");
      this.removeFake = new BooleanSetting(
            "Remove Fake",
            "Remove fake player"
         )
         .setValue(false);
      this.removeFake.withTranslation("fakeplayer.remove", "fakeplayer.remove.desc");
      this.setup(new ModuleSetting[]{this.autoTotem, this.regen, this.invisibility, this.removeFake});
   }

      @Override
   public void activate() {
      super.activate();
      if (MinecraftClient.getInstance().world == null || MinecraftClient.getInstance().player == null) {
         this.setState(false);
      } else if (fakePlayer != null) {
         this.e19();
         this.setState(false);
      } else {
         this.handleMethod6();
      }
   }

      private void handleMethod6() {
      this.e19();
      GameProfile client = MinecraftClient.getInstance().player.getGameProfile();
      fakePlayer = new TextureParticleHandler(MinecraftClient.getInstance().world, client);
      fakePlayer.setPosition(
         MinecraftClient.getInstance().player.getX(),
         MinecraftClient.getInstance().player.getY(),
         MinecraftClient.getInstance().player.getZ()
      );

      try {
         int index = -1000000 - (int)(Math.random() * 1000000.0);
         fakePlayer.setId(index);
      } catch (Exception exception) {
      }

      MinecraftClient.getInstance().world.addEntity(fakePlayer);
      this.e19();
      fakePlayer = new TextureParticleHandler(MinecraftClient.getInstance().world, client);
      fakePlayer.setPosition(
         MinecraftClient.getInstance().player.getX(),
         MinecraftClient.getInstance().player.getY(),
         MinecraftClient.getInstance().player.getZ()
      );

      try {
         int index2 = -1000000 - (int)(Math.random() * 1000000.0);
         fakePlayer.setId(index2);
      } catch (Exception exception2) {
      }

      MinecraftClient.getInstance().world.addEntity(fakePlayer);
      this.r16 = 2;
      this.removeField5 = false;
      SoundsModule.playFakePlayerSpawnEvent();
   }

      private void e19() {
      if (fakePlayer != null) {
         try {
            if (MinecraftClient.getInstance().world != null) {
               fakePlayer.remove(RemovalReason.DISCARDED);
            }
         } catch (Exception exception) {
         }

         fakePlayer = null;
         this.removeField5 = false;
      }
   }

      @Override
   public void deactivate() {
      super.deactivate();
      this.e19();
      this.startField15 = 0;
      this.dhtrg = 0;
   }

      public void tickFakePlayer() {
      if (this.removeFake.isValue()) {
         this.e19();
         this.startField15 = 0;
         this.dhtrg = 0;
         this.r16 = 0;
         this.removeFake.setValue(false);
      } else {
         if (fakePlayer != null) {
            this.cpf();
         }

         if (this.r16 > 0) {
            this.r16--;
            if (this.r16 == 0 && fakePlayer != null) {
               fakePlayer.copyDataFromLocalPlayer();
               this.removeField5 = true;
            }
         } else {
            if (fakePlayer != null && this.removeField5 && MinecraftClient.getInstance().world != null && MinecraftClient.getInstance().player != null
               )
             {
               fakePlayer.syncCriticalData(MinecraftClient.getInstance().player);
               if (this.autoTotem.isValue() && fakePlayer.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING) {
                  fakePlayer.setStackInHand(Hand.OFF_HAND, new ItemStack(Items.TOTEM_OF_UNDYING));
               }

               if (this.regen.isValue()) {
                  this.dhtrg++;
                  if (this.dhtrg >= 10) {
                     this.dhtrg = 0;
                     float value = fakePlayer.getHealth();
                     float value2 = Math.min(value + 10.0F, 20.0F);
                     fakePlayer.setHealth(value2);
                  }
               }

               if (!fakePlayer.isDead() && !(fakePlayer.getHealth() <= 0F)) {
                  this.startField15 = 0;
               } else {
                  this.startField15++;
                  if (this.startField15 > 40) {
                     this.e19();
                     this.startField15 = 0;
                     this.dhtrg = 0;
                     this.r16 = 0;
                  }
               }
            }
         }
      }
   }

      private void cpf() {
      if (fakePlayer != null) {
         fakePlayer.setInvisible(this.invisibility.isValue());
         if (this.invisibility.isValue()) {
            if (!fakePlayer.hasStatusEffect(StatusEffects.INVISIBILITY)) {
               fakePlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 2147483647, 0, false, false));
            }
         } else if (fakePlayer.hasStatusEffect(StatusEffects.INVISIBILITY)) {
            fakePlayer.removeStatusEffect(StatusEffects.INVISIBILITY);
         }
      }
   }

      public boolean isInvisibilityEnabled() {
      return this.invisibility.isValue();
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      this.tickFakePlayer();
   }

   @EventHandler
      public void onPacket(PacketEventProvider event) {
      if (event.isSend()
         && event.getPacket() instanceof PlayerInteractEntityC2SPacket playerInteractEntityC2SPacket
         && fakePlayer != null
         && MinecraftClient.getInstance().world != null
         && MinecraftClient.getInstance().player != null) {
         int index = ((PlayerInteractEntityC2SPacketMixin)playerInteractEntityC2SPacket).noxiumvisual$getEntityId();
         Entity client = MinecraftClient.getInstance().world.getEntityById(index);
         if (client == fakePlayer && xn.updateMethod51(playerInteractEntityC2SPacket) && fakePlayer.hurtTime == 0) {
            fakePlayer.handleAttack();
         }
      }
   }

}
