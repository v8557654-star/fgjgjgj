package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.CrossbowItem;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.joml.Quaternionf;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.HandTransformEvent;
import winvi.noxiumvisuals.systems.events.MatrixItemStackManager;
import winvi.noxiumvisuals.systems.events.HeldItemTransformEvent;
import winvi.noxiumvisuals.utils.render.HandBoundsTracker;
public class ViewModelModule extends Module {
      private final NumberSetting suout;
      private final NumberSetting cnrru;
      private final NumberSetting ac0;
      private final NumberSetting zgfsl;
      private final NumberSetting e21;
      private final NumberSetting togjw;
      private final NumberSetting ag2;
      private final NumberSetting ah;
      private final NumberSetting manageField600;
      private final NumberSetting qnqdf;
      private final NumberSetting k11;
      private final NumberSetting qeyxp;
      private final NumberSetting fpxml;
      private final NumberSetting an;
      private final Quaternionf edzzq;
      private final Quaternionf createField0;
      private boolean vdlah;
      private boolean vmsgm;
      private float xflpo;
      private float at1;

   public ViewModelModule() {
      super(
         "ViewModel",
         "View Model",
         ModuleCategory.UTILS
      );
      this.edzzq = new Quaternionf();
      this.createField0 = new Quaternionf();
      this.suout = new NumberSetting(
            "Main Hand X",
            "Main Hand X value setting"
         )
         .setValue(0F)
         .range(-1F, 1F);
      this.suout.withTranslation("viewmodel.mainhandx", "viewmodel.mainhandx.desc");
      this.cnrru = new NumberSetting(
            "Main Hand Y",
            "Main Hand Y value setting"
         )
         .setValue(0F)
         .range(-1F, 1F);
      this.cnrru.withTranslation("viewmodel.mainhandy", "viewmodel.mainhandy.desc");
      this.ac0 = new NumberSetting(
            "Main Hand Z",
            "Main Hand Z value setting"
         )
         .setValue(0F)
         .range(-2.5F, 2.5F);
      this.ac0.withTranslation("viewmodel.mainhandz", "viewmodel.mainhandz.desc");
      this.zgfsl = new NumberSetting(
            "Main Hand Scale",
            "Main Hand scale"
         )
         .setValue(1F)
         .range(0.5F, 2.0F);
      this.zgfsl.withTranslation("viewmodel.mainhandscale", "viewmodel.mainhandscale.desc");
      this.e21 = new NumberSetting(
            "Main Hand Rotate X",
            "Main Hand X rotation"
         )
         .setValue(0F)
         .range(-360.0F, 360.0F);
      this.e21.withTranslation("viewmodel.mainhandrotatex", "viewmodel.mainhandrotatex.desc");
      this.togjw = new NumberSetting(
            "Main Hand Rotate Y",
            "Main Hand Y rotation"
         )
         .setValue(0F)
         .range(-360.0F, 360.0F);
      this.togjw.withTranslation("viewmodel.mainhandrotatey", "viewmodel.mainhandrotatey.desc");
      this.ag2 = new NumberSetting(
            "Main Hand Rotate Z",
            "Main Hand Z rotation"
         )
         .setValue(0F)
         .range(-360.0F, 360.0F);
      this.ag2.withTranslation("viewmodel.mainhandrotatez", "viewmodel.mainhandrotatez.desc");
      this.ah = new NumberSetting(
            "Off Hand X",
            "Off Hand X value setting"
         )
         .setValue(0F)
         .range(-1F, 1F);
      this.ah.withTranslation("viewmodel.offhandx", "viewmodel.offhandx.desc");
      this.manageField600 = new NumberSetting(
            "Off Hand Y",
            "Off Hand Y value setting"
         )
         .setValue(0F)
         .range(-1F, 1F);
      this.manageField600.withTranslation("viewmodel.offhandy", "viewmodel.offhandy.desc");
      this.qnqdf = new NumberSetting(
            "Off Hand Z",
            "Off Hand Z value setting"
         )
         .setValue(0F)
         .range(-2.5F, 2.5F);
      this.qnqdf.withTranslation("viewmodel.offhandz", "viewmodel.offhandz.desc");
      this.k11 = new NumberSetting(
            "Off Hand Scale",
            "Off Hand scale"
         )
         .setValue(1F)
         .range(0.5F, 2.0F);
      this.k11.withTranslation("viewmodel.offhandscale", "viewmodel.offhandscale.desc");
      this.qeyxp = new NumberSetting(
            "Off Hand Rotate X",
            "Off Hand X rotation"
         )
         .setValue(0F)
         .range(-360.0F, 360.0F);
      this.qeyxp.withTranslation("viewmodel.offhandrotatex", "viewmodel.offhandrotatex.desc");
      this.fpxml = new NumberSetting(
            "Off Hand Rotate Y",
            "Off Hand Y rotation"
         )
         .setValue(0F)
         .range(-360.0F, 360.0F);
      this.fpxml.withTranslation("viewmodel.offhandrotatey", "viewmodel.offhandrotatey.desc");
      this.an = new NumberSetting(
            "Off Hand Rotate Z",
            "Off Hand Z rotation"
         )
         .setValue(0F)
         .range(-360.0F, 360.0F);
      this.an.withTranslation("viewmodel.offhandrotatez", "viewmodel.offhandrotatez.desc");
      this.setState(true);
      this.setup(
         new ModuleSetting[]{
            this.suout,
            this.cnrru,
            this.ac0,
            this.zgfsl,
            this.e21,
            this.togjw,
            this.ag2,
            this.ah,
            this.manageField600,
            this.qnqdf,
            this.k11,
            this.qeyxp,
            this.fpxml,
            this.an
         }
      );
   }

   @EventHandler
      public void onHandOffset(HeldItemTransformEvent e) {
      if (this.isState()) {
         Hand hand = e.getHand();
         this.createMethod44(hand, false, 0F);
         if (!hand.equals(Hand.MAIN_HAND) || !(e.getStack().getItem() instanceof CrossbowItem)) {
            MatrixStack matrices = e.getMatrices();
            if (hand.equals(Hand.MAIN_HAND)) {
               matrices.translate(this.suout.getValue(), this.cnrru.getValue(), this.ac0.getValue());
            } else {
               matrices.translate(this.ah.getValue(), this.manageField600.getValue(), this.qnqdf.getValue());
            }
         }
      }
   }

   @EventHandler
      public void onHandAnimation(MatrixItemStackManager event) {
      if (this.isState() && this.cqir(event.getHand())) {
         SwingAnimationModule swingAnimationModule = SwingAnimationModule.getInstance();
         if (swingAnimationModule == null || !swingAnimationModule.isCustomAnimationActive(event.getStack())) {
            this.createMethod44(event.getHand(), true, event.getSwingProgress());
            event.useNeutralVanillaSwing();
         }
      }
   }

   @EventHandler
      public void onHeldItemTransform(HandTransformEvent event) {
      if (this.isState()) {
         MatrixStack matrices = event.getMatrices();
         float value = this.getHandScale(event.getHand());
         float value2 = this.getHandRotationX(event.getHand());
         float value3 = this.getHandRotationY(event.getHand());
         float value4 = this.getHandRotationZ(event.getHand());
         boolean enabled = this.wmbmpq(event.getHand());
         if (value != 1F || value2 != 0F || value3 != 0F || value4 != 0F || enabled) {
            this.edzzq.identity().rotationXYZ((float)Math.toRadians(value2), (float)Math.toRadians(value3), (float)Math.toRadians(value4));
            matrices.translate(0.5F, 0.5F, 0.5F);
            matrices.scale(value, value, value);
            matrices.multiply(this.edzzq);
            if (enabled) {
               float value5 = controlMethod89(this.transformMethod11(event.getHand()), 0F, 1F);
               float value6 = value5 * value5 * (3.0F - 2.0F * value5);
               float value7 = (float)Math.sin(value6 * 3.141592653589793);
               float value8 = event.getArm() == Arm.RIGHT ? 1F : -1F;
               this.createField0
                  .identity()
                  .rotationXYZ(
                     (float)Math.toRadians(-32.0F * value7), (float)Math.toRadians(-14.0F * value7 * value8), (float)Math.toRadians(-10.0F * value7 * value8)
                  );
               matrices.multiply(this.createField0);
               matrices.translate(0.04F * value7 * value8, -0.06F * value7, -0.1F * value7);
            }

            matrices.translate(-0.5F, -0.5F, -0.5F);
         }
      }
   }

      public float getHandX(Hand hand) {
      return hand == Hand.MAIN_HAND ? this.suout.getValue() : this.ah.getValue();
   }

      public float getHandY(Hand hand) {
      return hand == Hand.MAIN_HAND ? this.cnrru.getValue() : this.manageField600.getValue();
   }

      public float getHandScale(Hand hand) {
      return hand == Hand.MAIN_HAND ? this.zgfsl.getValue() : this.k11.getValue();
   }

      public float getHandRotationX(Hand hand) {
      return hand == Hand.MAIN_HAND ? this.e21.getValue() : this.qeyxp.getValue();
   }

      public float getHandRotationY(Hand hand) {
      return hand == Hand.MAIN_HAND ? this.togjw.getValue() : this.fpxml.getValue();
   }

      public float getHandRotationZ(Hand hand) {
      return hand == Hand.MAIN_HAND ? this.ag2.getValue() : this.an.getValue();
   }

      public void setEditorPosition(Hand hand, float x, float y) {
      NumberSetting moduleSettingTransformer = hand == Hand.MAIN_HAND ? this.suout : this.ah;
      NumberSetting moduleSettingTransformer2 = hand == Hand.MAIN_HAND ? this.cnrru : this.manageField600;
      moduleSettingTransformer.setValue(controlMethod89(x, moduleSettingTransformer.getMin(), moduleSettingTransformer.getMax()));
      moduleSettingTransformer2.setValue(controlMethod89(y, moduleSettingTransformer2.getMin(), moduleSettingTransformer2.getMax()));
      HandBoundsTracker.invalidate(hand);
   }

      public void adjustEditorScale(Hand hand, float amount) {
      NumberSetting moduleSettingTransformer = hand == Hand.MAIN_HAND ? this.zgfsl : this.k11;
      moduleSettingTransformer.setValue(controlMethod89(moduleSettingTransformer.getValue() + amount, moduleSettingTransformer.getMin(), moduleSettingTransformer.getMax()));
      HandBoundsTracker.invalidate(hand);
   }

      public void setEditorRotationXY(Hand hand, float rotateX, float rotateY) {
      NumberSetting moduleSettingTransformer = hand == Hand.MAIN_HAND ? this.e21 : this.qeyxp;
      NumberSetting moduleSettingTransformer2 = hand == Hand.MAIN_HAND ? this.togjw : this.fpxml;
      moduleSettingTransformer.setValue(controlMethod89(rotateX, moduleSettingTransformer.getMin(), moduleSettingTransformer.getMax()));
      moduleSettingTransformer2.setValue(controlMethod89(rotateY, moduleSettingTransformer2.getMin(), moduleSettingTransformer2.getMax()));
      HandBoundsTracker.invalidate(hand);
   }

      public void adjustEditorRotationZ(Hand hand, float amount) {
      NumberSetting moduleSettingTransformer = hand == Hand.MAIN_HAND ? this.ag2 : this.an;
      moduleSettingTransformer.setValue(controlMethod89(moduleSettingTransformer.getValue() + amount, moduleSettingTransformer.getMin(), moduleSettingTransformer.getMax()));
      HandBoundsTracker.invalidate(hand);
   }

      private boolean cqir(Hand hand) {
      return this.getHandX(hand) != 0F
         || this.getHandY(hand) != 0F
         || this.busvkp(hand) != 0F
         || this.getHandScale(hand) != 1F
         || this.getHandRotationX(hand) != 0F
         || this.getHandRotationY(hand) != 0F
         || this.getHandRotationZ(hand) != 0F;
   }

      private float busvkp(Hand hand) {
      return hand == Hand.MAIN_HAND ? this.ac0.getValue() : this.qnqdf.getValue();
   }

      private void createMethod44(Hand hand, boolean active, float progress) {
      if (hand == Hand.MAIN_HAND) {
         this.vdlah = active;
         this.xflpo = progress;
      } else {
         this.vmsgm = active;
         this.at1 = progress;
      }
   }

      private boolean wmbmpq(Hand hand) {
      return hand == Hand.MAIN_HAND ? this.vdlah : this.vmsgm;
   }

      private float transformMethod11(Hand hand) {
      return hand == Hand.MAIN_HAND ? this.xflpo : this.at1;
   }

      private static float controlMethod89(float value, float min, float max) {
      return Math.max(min, Math.min(max, value));
   }

}
