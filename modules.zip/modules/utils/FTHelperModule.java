package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.Locale;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.ModuleResource;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
public class FTHelperModule extends Module {
      private static final int xf = 72;
      private final MultiSelectSetting mnkfz;
      private final BooleanSetting dxh;
      private final BooleanSetting dxi;
      private final BooleanSetting transformField30;
      private final ColorSetting hasField53;
      private final NumberSetting pzqrs;
      private final NumberSetting wcyww;

   public FTHelperModule() {
      super("FTHelper", ModuleCategory.UTILS);
      this.mnkfz = new MultiSelectSetting(
            "Items",
            "Special items whose zones are shown"
         )
         .value(
            "Radius Items",
            "Membrane",
            "Scrap",
            "Plast",
            "Freeze Snowball",
            "Potions"
         )
         .selected(
            "Radius Items",
            "Membrane",
            "Scrap",
            "Plast",
            "Freeze Snowball",
            "Potions"
         );
      this.dxh = new BooleanSetting(
            "Projectile Path",
            "Show the flight path to the effect zone"
         )
         .setValue(true);
      this.dxi = new BooleanSetting(
            "Plast Validation",
            "Mark occupied plast cells in red"
         )
         .setValue(true);
      this.transformField30 = new BooleanSetting(
            "Theme Color",
            "Use the client theme color"
         )
         .setValue(true);
      this.hasField53 = new ColorSetting(
            "Zone Color",
            "Custom zone color"
         )
         .value(-1)
         .visible(() -> {
            return !this.transformField30.isValue();
         });
      this.pzqrs = new NumberSetting(
            "Fill Opacity",
            "Opacity of zone surfaces"
         )
         .setValue(0.18F)
         .range(0F, 0.65F);
      this.wcyww = new NumberSetting(
            "Line Width",
            "Zone outline thickness"
         )
         .setValue(1.5F)
         .range(0.5F, 4.0F);
      this.mnkfz.withTranslation("fthelper.items", "fthelper.items.desc");
      this.dxh.withTranslation("fthelper.projectilepath", "fthelper.projectilepath.desc");
      this.dxi.withTranslation("fthelper.plastvalidation", "fthelper.plastvalidation.desc");
      this.transformField30.withTranslation("fthelper.themecolor", "fthelper.themecolor.desc");
      this.hasField53.withTranslation("fthelper.color", "fthelper.color.desc");
      this.pzqrs.withTranslation("fthelper.fillopacity", "fthelper.fillopacity.desc");
      this.wcyww.withTranslation("fthelper.linewidth", "fthelper.linewidth.desc");
      this.setup(new ModuleSetting[]{this.mnkfz, this.dxh, this.dxi, this.transformField30, this.hasField53, this.pzqrs, this.wcyww});
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         ItemStack client = MinecraftClient.getInstance().player.getMainHandStack();
         ItemStack client2 = MinecraftClient.getInstance().player.getOffHandStack();
         int color = this.transformField30.isValue() ? ColorUtils.getClientColor() : this.hasField53.getColor();
         if (this.mnkfz.isSelected("Freeze Snowball")
            && z23(client, client2, Items.SNOWBALL)) {
            this.coq(false, event.getPartialTicks(), color);
         } else if (this.mnkfz.isSelected("Potions") && sypqlc(client, client2)) {
            this.coq(true, event.getPartialTicks(), color);
         } else if (!this.mnkfz.isSelected("Plast") || !cpcy(client) && !cpcy(client2)) {
            if (this.mnkfz.isSelected("Scrap") && z23(client, client2, Items.NETHERITE_SCRAP)) {
               this.processMethod24(color);
            } else if (this.mnkfz.isSelected("Membrane")
               && z23(client, client2, Items.PHANTOM_MEMBRANE)) {
               this.oy0(MinecraftClient.getInstance().player.getPos().add(0, 0.08, 0), 2.0, color);
            } else {
               if (this.mnkfz.isSelected("Radius Items")
                  && (z23(client, client2, Items.ENDER_EYE) || z23(client, client2, Items.SUGAR) || z23(client, client2, Items.FIRE_CHARGE))) {
                  this.oy0(MinecraftClient.getInstance().player.getPos().add(0, 0.08, 0), 10.0, color);
               }
            }
         } else {
            this.removeMethod920(event.getPartialTicks(), color);
         }
      }
   }

      private void coq(boolean potion, float tickDelta, int color) {
      ModuleResource moduleResource = this.r15(potion, tickDelta);
      if (moduleResource != null) {
         if (this.dxh.isValue()) {
            int index = ColorUtils.multAlpha(color, 0.72F);

            for (int index2 = 1; index2 < moduleResource.path().size(); index2++) {
               WorldShapeRenderer.drawLine(moduleResource.path().get(index2 - 1), moduleResource.path().get(index2), index, Math.max(0.6F, this.wcyww.getValue() * 0.7F), false);
            }
         }

         this.oy0(moduleResource.impact().add(0, 0.035, 0), 2.5, color);
      }
   }

      private ModuleResource r15(boolean potion, float tickDelta) {
      Vec3d client = MinecraftClient.getInstance().player.getCameraPosVec(tickDelta).add(0, -0.1F, 0);
      float client2 = MinecraftClient.getInstance().player.getPitch(tickDelta) + (potion ? -20.0F : 0F);
      float client3 = MinecraftClient.getInstance().player.getYaw(tickDelta);
      Vec3d position = Vec3d.fromPolar(client2, client3).normalize().multiply(potion ? 0.5 : 1.5);
      ArrayList arrayList = new ArrayList();
      arrayList.add(client);

      for (int index = 0; index < 160; index++) {
         Vec3d position2 = client.add(position);
         HitResult hitResult = this.s24(client, position2);
         if (hitResult.getType() != Type.MISS) {
            arrayList.add(hitResult.getPos());
            return new ModuleResource(hitResult.getPos(), arrayList);
         }

         client = position2;
         if ((index & 1) == 0) {
            arrayList.add(position2);
         }

         position = position.multiply(0.99).add(0, -0.03F, 0);
         if (position2.y < MinecraftClient.getInstance().world.getBottomY() - 4) {
            break;
         }
      }

      return arrayList.size() > 1 ? new ModuleResource((Vec3d)arrayList.getLast(), arrayList) : null;
   }

      private HitResult s24(Vec3d from, Vec3d to) {
      BlockHitResult client = MinecraftClient.getInstance()
         .world
         .raycast(new RaycastContext(from, to, ShapeType.COLLIDER, FluidHandling.NONE, MinecraftClient.getInstance().player));
      Vec3d position = client.getType() == Type.MISS ? to : client.getPos();
      Box box = new Box(from, position).expand(1);
      EntityHitResult client2 = ProjectileUtil.raycast(MinecraftClient.getInstance().player, from, position, box, this::t12, from.squaredDistanceTo(position));
      return (HitResult)(client2 != null ? client2 : client);
   }

      private boolean t12(Entity entity) {
      return entity != MinecraftClient.getInstance().player
         && !entity.isSpectator()
         && entity.canHit()
         && entity.getRootVehicle() != MinecraftClient.getInstance().player.getRootVehicle();
   }

      private void removeMethod920(float tickDelta, int color) {
      HitResult client = MinecraftClient.getInstance().player.raycast(6.0, tickDelta, false);
      Direction direction = null;
      BlockPos blockPos;
      if (client instanceof BlockHitResult blockHitResult && blockHitResult.getType() == Type.BLOCK) {
         direction = blockHitResult.getSide();
         blockPos = blockHitResult.getBlockPos().offset(direction);
      } else {
         blockPos = BlockPos.ofFloored(
            MinecraftClient.getInstance()
               .player
               .getCameraPosVec(tickDelta)
               .add(MinecraftClient.getInstance().player.getRotationVec(tickDelta).multiply(4.0))
         );
      }

      if (direction != Direction.UP && direction != Direction.DOWN) {
         int index;
         int index2;
         if (direction == Direction.EAST || direction == Direction.WEST) {
            index2 = 0;
            index = 1;
         } else if (direction != Direction.NORTH && direction != Direction.SOUTH) {
            double client2 = Math.toRadians(MinecraftClient.getInstance().player.getYaw());
            int index3 = (int)Math.round(-Math.sin(client2));
            int index4 = (int)Math.round(Math.cos(client2));
            index2 = index4;
            index = -index3;
         } else {
            index2 = 1;
            index = 0;
         }

         for (int index5 = -2; index5 <= 2; index5++) {
            for (int index6 = 0; index6 < 4; index6++) {
               this.validateMethod7(blockPos.add(index2 * index5, index6, index * index5), color);
            }
         }
      } else {
         this.ov(blockPos, color);
      }
   }

      private void ov(BlockPos center, int color) {
      double client = Math.toRadians(MinecraftClient.getInstance().player.getYaw());
      int index = (int)Math.round(-Math.sin(client));
      int index2 = (int)Math.round(Math.cos(client));
      int index3 = index2;
      int index4 = -index;

      for (int index5 = -2; index5 <= 2; index5++) {
         for (int index6 = -1; index6 <= 2; index6++) {
            this.validateMethod7(center.add(index3 * index5 + index * index6, 0, index4 * index5 + index2 * index6), color);
         }
      }
   }

      private void validateMethod7(BlockPos pos, int color) {
      BlockState client = MinecraftClient.getInstance().world.getBlockState(pos);
      boolean enabled = client.isAir() || client.isReplaceable();
      int index = this.dxi.isValue() && !enabled ? -47531 : color;
      Box box = new Box(pos);
      WorldShapeRenderer.drawBox(
         box, ColorUtils.multAlpha(index, Math.max(0.06F, this.pzqrs.getValue())), this.wcyww.getValue(), true, this.pzqrs.getValue() > 0.001F, false
      );
   }

      private void processMethod24(int color) {
      BlockPos client = MinecraftClient.getInstance().player.getBlockPos();
      Box x = new Box(
         client.getX() - 1.5,
         client.getY(),
         client.getZ() - 1.5,
         client.getX() + 2.5,
         client.getY() + 4.0,
         client.getZ() + 2.5
      );
      WorldShapeRenderer.drawBox(
         x, ColorUtils.multAlpha(color, Math.max(0.08F, this.pzqrs.getValue())), this.wcyww.getValue(), true, this.pzqrs.getValue() > 0.001F, false
      );
   }

      private void oy0(Vec3d center, double radius, int color) {
      int index = ColorUtils.multAlpha(color, this.pzqrs.getValue());

      for (int index2 = 0; index2 < 72; index2++) {
         double value = 6.283185307179586 * index2 / 72.0;
         double value2 = 6.283185307179586 * (index2 + 1) / 72.0;
         Vec3d position = center.add(Math.sin(value) * radius, 0, Math.cos(value) * radius);
         Vec3d position2 = center.add(Math.sin(value2) * radius, 0, Math.cos(value2) * radius);
         WorldShapeRenderer.drawLine(position, position2, color, this.wcyww.getValue(), false);
         if (this.pzqrs.getValue() > 0.001F) {
            WorldShapeRenderer.drawQuad(center, position, position2, center, index, false);
         }
      }
   }

      private static boolean z23(ItemStack main, ItemStack off, Item item) {
      return main.isOf(item) || off.isOf(item);
   }

      private static boolean sypqlc(ItemStack main, ItemStack off) {
      return eueogy(main) || eueogy(off);
   }

      private static boolean eueogy(ItemStack stack) {
      return stack.isOf(Items.SPLASH_POTION) || stack.isOf(Items.LINGERING_POTION);
   }

      private static boolean cpcy(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else {
         String name = stack.getName().getString().toLowerCase(Locale.ROOT);
         return stack.isOf(Items.DRIED_KELP) || name.contains("пласт");
      }
   }

   static {
      int index = 0;
   }
}
