package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.BlockPositionModuleManager;
import winvi.noxiumvisuals.modules.visuals.BlockPositionHandRenderer;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.TextEventRenderer;
import winvi.noxiumvisuals.utils.RenderRenderer;
import winvi.noxiumvisuals.utils.QuadraticEaseOutAnimation;
import winvi.noxiumvisuals.utils.ClientType;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.RenderGeometry;
import winvi.noxiumvisuals.utils.render.ClientColorPalette;
public class ArrowsModule extends Module {
      private static final Identifier vj = Identifier.of("noxiumvisual", "textures/6jg7camfwj/i2re9b1mp23w.png");
      private final RenderRenderer dvka;
      private final Map<AbstractClientPlayerEntity, RenderRenderer> dvlz;
      private final List<AbstractClientPlayerEntity> dvmy;
      private final Set<AbstractClientPlayerEntity> mzxez;
      private NumberSetting destroyField79;
      private BooleanSetting convertField76;

   public ArrowsModule() {
      super("Arrows", ModuleCategory.UTILS);
      this.dvka = new QuadraticEaseOutAnimation().setMs(150).setValue(12.0);
      this.dvlz = new HashMap<>();
      this.dvmy = new ArrayList<>();
      this.mzxez = new HashSet<>();
      this.destroyField79 = new NumberSetting(
            "Size",
            "Size of arrows"
         )
         .setValue(20.0F)
         .range(8, 50);
      this.destroyField79.withTranslation("arrows.size", "arrows.size.desc");
      this.convertField76 = new BooleanSetting(
            "GPS Markers",
            "Show red arrows to GPS markers"
         )
         .setValue(true);
      this.setState(true);
      this.setup(new ModuleSetting[]{this.destroyField79, this.convertField76});
   }

   @EventHandler
      public void onTick(ClientTickEvent e) {
      this.dvka
         .setDirection(
            MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().player.isSprinting()
               ? ClientType.FORWARDS
               : ClientType.BACKWARDS
         );
   }

   @EventHandler
      public void onDraw(TextEventRenderer e) {
      if (MinecraftClient.getInstance().world != null && MinecraftClient.getInstance().player != null) {
         if (!MinecraftClient.getInstance().options.hudHidden && MinecraftClient.getInstance().options.getPerspective().equals(Perspective.FIRST_PERSON)) {
            MatrixStack matrices = e.getDrawContext().getMatrices();
            List client = MinecraftClient.getInstance().world.getPlayers();
            this.dvmy.clear();

            for (int index = 0; index < client.size(); index++) {
               AbstractClientPlayerEntity player2 = (AbstractClientPlayerEntity)client.get(index);
               if (player2 != MinecraftClient.getInstance().player && !player2.isInvisible() && !player2.isSneaking() && this.validateMethod69(player2)) {
                  this.dvmy.add(player2);
               }
            }

            this.cof(this.dvmy);
            float width = MinecraftClient.getInstance().getWindow().getScaledWidth() / 2.0F;
            float height = MinecraftClient.getInstance().getWindow().getScaledHeight() / 2.0F;
            float value = height - 35.0F - this.dvka.getOutput().floatValue();
            float value2 = this.destroyField79.getValue();
            float value3 = (float)System.currentTimeMillis() / 1000.0F * 0.1F % 1F;
            RenderSystem.enableBlend();
            RenderSystem.disableCull();
            RenderSystem.disableDepthTest();
            RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
            RenderSystem.setShaderTexture(0, vj);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
            BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            int[] intArray = new int[]{0};
            this.dvlz.entrySet().removeIf(entry -> {
               AbstractClientPlayerEntity var10x = entry.getKey();
               RenderRenderer var11x = entry.getValue();
               if (var11x.getOutput().floatValue() <= 0.01F && var11x.isDirection(ClientType.BACKWARDS)) {
                  return true;
               } else {
                  float var12x = var11x.getOutput().floatValue();
                  if (var12x > 0.01F) {
                     this.gqtvov(matrices, bufferBuilder, var10x, width, height, value, value2, var12x, value3);
                     intArray[0]++;
                  }

                  return false;
               }
            });
            if (this.convertField76.isValue()) {
               intArray[0] += this.manageMethod12(matrices, bufferBuilder, width, height, value, value2);
            }

            if (intArray[0] > 0) {
               BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
            }

            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
         }
      }
   }

      private void cof(List<AbstractClientPlayerEntity> visiblePlayers) {
      this.mzxez.clear();

      for (AbstractClientPlayerEntity player : visiblePlayers) {
         this.mzxez.add(player);
         RenderRenderer renderRenderer = this.dvlz.computeIfAbsent(player, p -> {
            return new QuadraticEaseOutAnimation().setMs(300).setValue(1);
         });
         renderRenderer.setDirection(ClientType.FORWARDS);
      }

      for (Entry entry : this.dvlz.entrySet()) {
         if (!this.mzxez.contains(entry.getKey())) {
            RenderRenderer renderRenderer2 = (RenderRenderer)entry.getValue();
            renderRenderer2.setDirection(ClientType.BACKWARDS);
         }
      }
   }

      private void gqtvov(
      MatrixStack matrix,
      BufferBuilder buffer,
      AbstractClientPlayerEntity player,
      float middleW,
      float middleH,
      float posY,
      float size,
      float alpha,
      float colorPhase
   ) {
      int color = ClientColorPalette.getColor(colorPhase).getRGB();
      int index = ColorUtils.multAlpha(color, alpha);
      int index2 = ColorUtils.multAlpha(ColorUtils.multDark(color, 0.4F), alpha * 0.5F);
      float client = getRotations(player) - MinecraftClient.getInstance().player.getYaw();
      this.vquskw(matrix, buffer, middleW, middleH, posY, size, client, index, index2);
   }

      private int manageMethod12(MatrixStack matrix, BufferBuilder buffer, float middleW, float middleH, float posY, float size) {
      if (MinecraftClient.getInstance().world != null && MinecraftClient.getInstance().player != null) {
         NoxiumVisuals noxiumVisuals = NoxiumVisuals.getInstance();
         if (noxiumVisuals != null && noxiumVisuals.getModuleProvider() != null) {
            GPSModule gpsmodule = noxiumVisuals.getModuleProvider().get(GPSModule.class);
            if (gpsmodule != null && gpsmodule.isState()) {
               String client = MinecraftClient.getInstance().world.getRegistryKey().getValue().toString();
               Vec3d client2 = MinecraftClient.getInstance().player.getPos();
               int index = 0;

               for (BlockPositionHandRenderer blockPositionHandRenderer : BlockPositionModuleManager.getMarkers()) {
                  if (client.equals(blockPositionHandRenderer.getDimension()) && !(client2.squaredDistanceTo(blockPositionHandRenderer.toCenterPos()) <= 4.0)) {
                     float client3 = this.ok(blockPositionHandRenderer.toCenterPos()) - MinecraftClient.getInstance().player.getYaw();
                     int index2 = -50373;
                     int index3 = -1717567488;
                     this.vquskw(matrix, buffer, middleW, middleH, posY, size, client3, index2, index3);
                     index++;
                  }
               }

               return index;
            } else {
               return 0;
            }
         } else {
            return 0;
         }
      } else {
         return 0;
      }
   }

      private void vquskw(MatrixStack matrix, BufferBuilder buffer, float middleW, float middleH, float posY, float size, float yaw, int color, int darkColor) {
      matrix.push();
      matrix.translate(middleW, middleH, 0F);
      matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(yaw));
      matrix.translate(-middleW, -middleH, 0F);
      Matrix4f matrix2 = matrix.peek().getPositionMatrix();
      buffer.vertex(matrix2, middleW - size / 2.0F, posY + size, 0F).texture(0F, 1F).color(darkColor);
      buffer.vertex(matrix2, middleW + size / 2.0F, posY + size, 0F).texture(1F, 1F).color(darkColor);
      buffer.vertex(matrix2, middleW + size / 2.0F, posY, 0F).texture(1F, 0F).color(color);
      buffer.vertex(matrix2, middleW - size / 2.0F, posY, 0F).texture(0F, 0F).color(color);
      matrix.pop();
   }

      private boolean validateMethod69(AbstractClientPlayerEntity player) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         Vec3d client = MinecraftClient.getInstance().player.getEyePos();
         Vec3d position = player.getEyePos();
         double value = client.distanceTo(position);
         if (value > 15.0) {
            return false;
         } else {
            Vec3d position2 = position.subtract(client).normalize();
            Vec3d client2 = MinecraftClient.getInstance().player.getRotationVec(1F);
            double value2 = client2.dotProduct(position2);
            if (value2 < -0.5F) {
               return false;
            } else {
               RaycastContext client3 = new RaycastContext(client, position, ShapeType.COLLIDER, FluidHandling.NONE, MinecraftClient.getInstance().player);
               BlockHitResult client4 = MinecraftClient.getInstance().world.raycast(client3);
               return client4.getType() == Type.MISS;
            }
         }
      } else {
         return false;
      }
   }

      public static float getRotations(Entity entity) {
      double x = RenderGeometry.interpolate(entity.prevX, entity.getX())
         - RenderGeometry.interpolate(MinecraftClient.getInstance().player.prevX, MinecraftClient.getInstance().player.getX());
      double z = RenderGeometry.interpolate(entity.prevZ, entity.getZ())
         - RenderGeometry.interpolate(MinecraftClient.getInstance().player.prevZ, MinecraftClient.getInstance().player.getZ());
      return (float)(-(Math.atan2(x, z) * 57.29577951308232));
   }

      private float ok(Vec3d pos) {
      Vec3d client = MinecraftClient.getInstance().player.getPos();
      double x2 = pos.x - client.x;
      double z2 = pos.z - client.z;
      return (float)(-(Math.atan2(x2, z2) * 57.29577951308232));
   }

   static {
      int index = 0;
   }
}
