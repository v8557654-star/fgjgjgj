package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ActionSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.EntityEventProvider;
import winvi.noxiumvisuals.utils.CustomSoundManager;
import winvi.noxiumvisuals.utils.SoundPlayerSupport;
import winvi.noxiumvisuals.utils.SoundEventType;
public class KillSoundModule extends Module {
      static String[] BUILT_IN_SOUNDS;
      private final ChoiceSetting g16;
      private final ActionSetting deleteField41;
      private final ActionSetting cmecy;
      private final NumberSetting nnkuy;
      private final NumberSetting k10;

   public KillSoundModule() {
      super("Kill Sound", ModuleCategory.UTILS);
      this.g16 = new ChoiceSetting(
            "Sound",
            "Sound to play on kill"
         )
         .value(BUILT_IN_SOUNDS)
         .selected("KILL_1")
         .displayFormatter(CustomSoundManager::getDisplayName);
      this.g16.withTranslation("killsound.sound", "killsound.sound.desc");
      CustomSoundManager.syncSelectSetting(this.g16, SoundEventType.KILL, BUILT_IN_SOUNDS);
      this.deleteField41 = new ActionSetting(
            "Custom Sounds",
            "Open the folder for custom kill sounds"
         )
         .setButtonName("Open")
         .action(() -> {
            CustomSoundManager.openFolder(SoundEventType.KILL);
         });
      this.deleteField41.withTranslation("killsound.customsounds", "killsound.customsounds.desc");
      this.cmecy = new ActionSetting(
            "Refresh Sounds",
            "Refresh the list of custom kill sounds"
         )
         .setButtonName("Refresh")
         .action(() -> {
            CustomSoundManager.refresh(true);
            CustomSoundManager.syncSelectSetting(this.g16, SoundEventType.KILL, BUILT_IN_SOUNDS);
         });
      this.cmecy.withTranslation("killsound.refreshsounds", "killsound.refreshsounds.desc");
      this.nnkuy = new NumberSetting(
            "Volume",
            "Sound volume"
         )
         .setValue(1F)
         .range(0.1F, 2.0F);
      this.nnkuy.withTranslation("killsound.volume", "killsound.volume.desc");
      this.k10 = new NumberSetting(
            "Pitch",
            "Sound pitch"
         )
         .setValue(1F)
         .range(0.5F, 2.0F);
      this.k10.withTranslation("killsound.pitch", "killsound.pitch.desc");
      this.setup(new ModuleSetting[]{this.g16, this.deleteField41, this.cmecy, this.nnkuy, this.k10});
   }

      @Override
   public void onTick() {
      CustomSoundManager.syncSelectSetting(this.g16, SoundEventType.KILL, BUILT_IN_SOUNDS);
   }

   @EventHandler
      public void onEntityDeath(EntityEventProvider event) {
      if (this.isState()) {
         MinecraftClient client = MinecraftClient.getInstance();
         if (client.player != null && client.world != null) {
            if (event.getEntity() instanceof LivingEntity livingEntity) {
               if (livingEntity != client.player) {
                  DamageSource damageSource = livingEntity.getRecentDamageSource();
                  if (damageSource != null) {
                     if (damageSource.getAttacker() == client.player) {
                        this.handleMethod550(livingEntity);
                     }
                  }
               }
            }
         }
      }
   }

      private void handleMethod550(LivingEntity entity) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.world != null && client.player != null) {
         if (CustomSoundManager.isCustom(this.g16.getSelected())) {
            CustomSoundManager.play(this.g16.getSelected(), SoundEventType.KILL, entity.getPos(), this.nnkuy.getValue(), this.k10.getValue());
         } else {
            SoundEvent soundEvent = this.j18();
            if (soundEvent != null) {
               client.world
                  .playSound(
                     client.player,
                     entity.getX(),
                     entity.getY(),
                     entity.getZ(),
                     soundEvent,
                     SoundCategory.PLAYERS,
                     this.nnkuy.getValue(),
                     this.k10.getValue()
                  );
            }
         }
      }
   }

      private SoundEvent j18() {
      String text = this.g16.getSelected();

      return switch (text) {
         case "KILL_1" -> SoundPlayerSupport.KILL_1;
         case "KILL_2" -> SoundPlayerSupport.KILL_2;
         case "KILL_3" -> SoundPlayerSupport.KILL_3;
         default -> SoundPlayerSupport.KILL_1;
      };
   }

   static {
      BUILT_IN_SOUNDS = new String[]{"KILL_1", "KILL_2", "KILL_3"};
   }
}
