package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.Perspective;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.KeybindSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.systems.events.RenderEventData;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.MouseRotationEvent;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.CameraRotationEvent;
public class ThirdPersonModule extends Module {
      static final float CAMERA_DISTANCE = 4.0F;
      static final float DISTANCE_SMOOTH_SPEED = 3.0F;
      private final KeybindSetting acydg;
      private final ChoiceSetting setField650;
      private Perspective setField67;
      private float convertField86;
      private float lnyau;
      private float dzp;
      private long q22;
      private boolean dzrn;
      private boolean deleteField42;

   public ThirdPersonModule() {
      super(
         "ThirdPerson",
         "Third Person",
         ModuleCategory.UTILS
      );
      this.acydg = new KeybindSetting(
         "Bind",
         "Hold this key to enable third person freelook"
      );
      this.setField650 = new ChoiceSetting(
            "Side",
            "Camera side while the bind is held"
         )
         .value(
            "Back",
            "Front"
         )
         .selected("Back");
      this.setField67 = Perspective.FIRST_PERSON;
      this.setup(new ModuleSetting[]{this.acydg, this.setField650});
   }

      @Override
   public void activate() {
      this.e20();
   }

      @Override
   public void deactivate() {
      this.cqcw();
   }

   @EventHandler
      public void onKey(RenderEventData event) {
      if (event.isBindDown(this.acydg)) {
         this.stopMethod33();
      } else if (event.isBindReleased(this.acydg, true)) {
         this.cqcw();
      }
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (this.dzrn && this.deleteMethod45()) {
         this.e20();
         this.cqcw();
      }
   }

   @EventHandler
      public void onMouseRotation(MouseRotationEvent event) {
      if (this.dzrn) {
         this.convertField86 = this.convertField86 + event.getCursorDeltaX() * 0.15F;
         this.lnyau = MathHelper.clamp(this.lnyau + event.getCursorDeltaY() * 0.15F, -90.0F, 90.0F);
         event.cancel();
      }
   }

   @EventHandler
      public void onCamera(CameraRotationEvent event) {
      if (this.dzrn) {
         event.setYaw(this.convertField86);
         event.setPitch(this.lnyau);
         event.cancel();
      }
   }

      public boolean shouldOverrideDistance() {
      return this.dzrn && this.deleteField42;
   }

      public float getSmoothedDistance(float clippedDistance) {
      long timestamp = System.nanoTime();
      if (this.q22 == 0L) {
         this.q22 = timestamp;
         return Math.min(clippedDistance, this.dzp);
      } else {
         float value = Math.min((float)(timestamp - this.q22) / 1E9F, 0.1F);
         this.q22 = timestamp;
         float value2 = Math.min(clippedDistance, 4.0F);
         this.dzp = this.dzp + (value2 - this.dzp) * Math.min(1F, value * 3.0F);
         return Math.min(clippedDistance, this.dzp);
      }
   }

      private void stopMethod33() {
      if (!this.dzrn && MinecraftClient.getInstance().options != null && MinecraftClient.getInstance().player != null) {
         if (this.deleteMethod45()) {
            this.e20();
         } else {
            this.dzrn = true;
            this.deleteField42 = true;
            this.setField67 = MinecraftClient.getInstance().options.getPerspective();
            this.convertField86 = MinecraftClient.getInstance().player.getYaw();
            this.lnyau = MinecraftClient.getInstance().player.getPitch();
            this.dzp = 0F;
            this.q22 = 0L;
            MinecraftClient.getInstance()
               .options
               .setPerspective(
                  this.setField650.isSelected("Front")
                     ? Perspective.THIRD_PERSON_FRONT
                     : Perspective.THIRD_PERSON_BACK
               );
         }
      }
   }

      private void cqcw() {
      if (this.dzrn || this.deleteField42) {
         this.dzrn = false;
         if (this.deleteField42 && MinecraftClient.getInstance().options != null) {
            MinecraftClient.getInstance().options.setPerspective(this.setField67);
         }

         this.deleteField42 = false;
         this.dzp = 0F;
         this.q22 = 0L;
      }
   }

      private boolean deleteMethod45() {
      if (MinecraftClient.getInstance() == null) {
         return false;
      } else {
         ServerInfo client = MinecraftClient.getInstance().getCurrentServerEntry();
         if (client != null && client.address != null) {
            String text = client.address.toLowerCase();
            return text.contains(".hypixel.")
               || text.startsWith("hypixel.")
               || text.contains("hypixel.net");
         } else {
            return false;
         }
      }
   }

      private void e20() {
      if (this.deleteMethod45() && MinecraftClient.getInstance() != null) {
         String text = "Third Person does not work on Hypixel!";
         MinecraftClient.getInstance()
            .execute(
               () -> {
                  if (MinecraftClient.getInstance().inGameHud != null) {
                     MutableText var1x = Text.literal("NoxiumVisual -> ")
                        .formatted(Formatting.LIGHT_PURPLE);
                     MutableText textComponent = Text.literal(text).formatted(Formatting.WHITE);
                     MinecraftClient.getInstance().inGameHud.getChatHud().addMessage(var1x.append(textComponent));
                  }
               }
            );
      }
   }

}
