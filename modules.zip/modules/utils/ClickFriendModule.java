package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.systems.managers.Friend;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.KeybindSetting;
import winvi.noxiumvisuals.systems.events.RenderEventData;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.managers.FriendManager;
public class ClickFriendModule extends Module {
      private final KeybindSetting setField750;

   public ClickFriendModule() {
      super(
         "ClickFriend",
         "Click Friend",
         ModuleCategory.UTILS
      );
      this.setField750 = new KeybindSetting(
         "Add Friend",
         "Add or remove the player you're looking at"
      );
      this.setup(new ModuleSetting[]{this.setField750});
   }

   @EventHandler
      public void onKey(RenderEventData event) {
      if (event.isBindDown(this.setField750)
         && MinecraftClient.getInstance().crosshairTarget instanceof EntityHitResult entityHitResult
         && entityHitResult.getEntity() instanceof PlayerEntity player) {
         if (FriendManager.isFriend(player)) {
            FriendManager.removeFriend(player);
         } else {
            FriendManager.addFriend(player);
         }
      }
   }

}
