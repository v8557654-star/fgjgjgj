package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.KeybindSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class ItemScrollerModule extends Module {
      private final KeybindSetting checkField75;
      private final KeybindSetting yb0;
      private final KeybindSetting c25;
      private final BooleanSetting parseField51;
      private final BooleanSetting lyewh;
      private final BooleanSetting initField6;

   public ItemScrollerModule() {
      super("Item Scroller", ModuleCategory.UTILS);
      this.checkField75 = new KeybindSetting(
            "Transfer Key",
            "Hold with left click to move hovered stacks"
         )
         .setKey(340)
         .setDefaultKey();
      this.yb0 = new KeybindSetting(
            "Move Matching",
            "Move every stack matching the hovered item"
         )
         .setKey(-1);
      this.c25 = new KeybindSetting(
            "Drop Matching",
            "Drop every stack matching the hovered item"
         )
         .setKey(-1);
      this.parseField51 = new BooleanSetting(
            "Drag Transfer",
            "Transfer items while dragging over slots"
         )
         .setValue(true);
      this.lyewh = new BooleanSetting(
            "Matching Transfer",
            "Enable the move-matching bind"
         )
         .setValue(true);
      this.initField6 = new BooleanSetting(
            "Matching Drop",
            "Enable the drop-matching bind"
         )
         .setValue(false);
      this.checkField75.withTranslation("itemscroller.transferbind", "itemscroller.transferbind.desc");
      this.yb0.withTranslation("itemscroller.matchbind", "itemscroller.matchbind.desc");
      this.c25.withTranslation("itemscroller.dropbind", "itemscroller.dropbind.desc");
      this.parseField51.withTranslation("itemscroller.drag", "itemscroller.drag.desc");
      this.lyewh.withTranslation("itemscroller.match", "itemscroller.match.desc");
      this.initField6.withTranslation("itemscroller.drop", "itemscroller.drop.desc");
      this.setup(new ModuleSetting[]{this.checkField75, this.yb0, this.c25, this.parseField51, this.lyewh, this.initField6});
   }

      public long getDelayMs() {
      return 50L;
   }

      public KeybindSetting getTransferBind() {
      return this.checkField75;
   }

      public KeybindSetting getMoveMatchingBind() {
      return this.yb0;
   }

      public KeybindSetting getDropMatchingBind() {
      return this.c25;
   }

      public BooleanSetting getDragTransfer() {
      return this.parseField51;
   }

      public BooleanSetting getMoveMatching() {
      return this.lyewh;
   }

      public BooleanSetting getDropMatching() {
      return this.initField6;
   }

}
