package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.utils.CustomSoundManager;
import winvi.noxiumvisuals.utils.SoundEventType;
import winvi.noxiumvisuals.utils.NoxiumSounds;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.AttackEntityEvent;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ActionSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundCategory;
public class HitSoundModule extends Module {
      static String[] BUILT_IN_SOUNDS;
      private final BooleanSetting calculateField53;
      private final ChoiceSetting cvloz;
      private final ActionSetting pcozj;
      private final ActionSetting removeField91;
      private final NumberSetting hdzvl;

   public HitSoundModule() {
      super("HitSound", ModuleCategory.UTILS);
      this.calculateField53 = new BooleanSetting(
            "Random Pitch",
            "Random sound pitch"
         )
         .setValue(false);
      this.calculateField53.withTranslation("hitsound.randompitch", "hitsound.randompitch.desc");
      this.cvloz = new ChoiceSetting(
            "Sound Type",
            "Sound type"
         )
         .value(BUILT_IN_SOUNDS)
         .selected("GET")
         .displayFormatter(CustomSoundManager::getDisplayName);
      this.cvloz.withTranslation("hitsound.soundtype", "hitsound.soundtype.desc");
      CustomSoundManager.syncSelectSetting(this.cvloz, SoundEventType.HIT, BUILT_IN_SOUNDS);
      this.pcozj = new ActionSetting(
            "Custom Sounds",
            "Open the folder for custom hit sounds"
         )
         .setButtonName("Open")
         .action(() -> {

            CustomSoundManager.openFolder(SoundEventType.HIT);
         });
      this.pcozj.withTranslation("hitsound.customsounds", "hitsound.customsounds.desc");
      this.removeField91 = new ActionSetting(
            "Refresh Sounds",
            "Refresh the list of custom hit sounds"
         )
         .setButtonName("Refresh")
         .action(() -> {

            CustomSoundManager.refresh(true);
            CustomSoundManager.syncSelectSetting(this.cvloz, SoundEventType.HIT, BUILT_IN_SOUNDS);
         });
      this.removeField91.withTranslation("hitsound.refreshsounds", "hitsound.refreshsounds.desc");
      this.hdzvl = new NumberSetting(
            "Volume",
            "Volume"
         )
         .setValue(50.0F)
         .range(10.0F, 100.0F);
      this.hdzvl.withTranslation("hitsound.volume", "hitsound.volume.desc");
      this.setup(new ModuleSetting[]{this.cvloz, this.pcozj, this.removeField91, this.calculateField53, this.hdzvl});
   }

      @Override
   public void onTick() {

      CustomSoundManager.syncSelectSetting(this.cvloz, SoundEventType.HIT, BUILT_IN_SOUNDS);
   }

   @EventHandler
      public void onAttack(AttackEntityEvent e) {

      if (MinecraftClient.getInstance().world != null && MinecraftClient.getInstance().player != null) {
         float value = this.hdzvl.getValue() / 100.0F;
         float value2 = this.calculateField53.isValue() ? 0.8F + (float)Math.random() * 0.4F : 1F;
         String text = this.cvloz.getSelected();
         if (CustomSoundManager.isCustom(text)) {
            CustomSoundManager.play(text, SoundEventType.HIT, MinecraftClient.getInstance().player.getPos(), value, value2);
         } else {
            switch (text) {
               case "GET":
                  MinecraftClient.getInstance()
                     .world
                     .playSound(
                        MinecraftClient.getInstance().player,
                        MinecraftClient.getInstance().player.getBlockPos(),
                        NoxiumSounds.HIT_GET,
                        SoundCategory.PLAYERS,
                        value,
                        value2
                     );
                  break;
               case "BUBBLE":
                  MinecraftClient.getInstance()
                     .world
                     .playSound(
                        MinecraftClient.getInstance().player,
                        MinecraftClient.getInstance().player.getBlockPos(),
                        NoxiumSounds.HIT_BUBBLE,
                        SoundCategory.PLAYERS,
                        value,
                        value2
                     );
                  break;
               case "BELL":
                  MinecraftClient.getInstance()
                     .getSoundManager()
                     .play(
                        new FadingHitSound(
                           NoxiumSounds.HIT_BELL,
                           value,
                           value2,
                           MinecraftClient.getInstance().player.getX(),
                           MinecraftClient.getInstance().player.getY(),
                           MinecraftClient.getInstance().player.getZ()
                        )
                     );
                  break;
               case "BONK":
                  MinecraftClient.getInstance()
                     .world
                     .playSound(
                        MinecraftClient.getInstance().player,
                        MinecraftClient.getInstance().player.getBlockPos(),
                        NoxiumSounds.HIT_BONK,
                        SoundCategory.PLAYERS,
                        value,
                        value2
                     );
                  break;
               case "POK":
                  MinecraftClient.getInstance()
                     .world
                     .playSound(
                        MinecraftClient.getInstance().player,
                        MinecraftClient.getInstance().player.getBlockPos(),
                        NoxiumSounds.HIT_POK,
                        SoundCategory.PLAYERS,
                        value,
                        value2
                     );
                  break;
               case "MAGIC_POK":
                  MinecraftClient.getInstance()
                     .world
                     .playSound(
                        MinecraftClient.getInstance().player,
                        MinecraftClient.getInstance().player.getBlockPos(),
                        NoxiumSounds.HIT_MAGIC_POK,
                        SoundCategory.PLAYERS,
                        value,
                        value2
                     );
                  break;
               case "MAGIC":
                  MinecraftClient.getInstance()
                     .world
                     .playSound(
                        MinecraftClient.getInstance().player,
                        MinecraftClient.getInstance().player.getBlockPos(),
                        NoxiumSounds.HIT_MAGIC,
                        SoundCategory.PLAYERS,
                        value,
                        value2
                     );
                  break;
               case "RUN":
                  MinecraftClient.getInstance()
                     .world
                     .playSound(
                        MinecraftClient.getInstance().player,
                        MinecraftClient.getInstance().player.getBlockPos(),
                        NoxiumSounds.HIT_RUN,
                        SoundCategory.PLAYERS,
                        value,
                        value2
                     );
            }
         }
      }
   }

   static {
      BUILT_IN_SOUNDS = new String[]{"GET", "BUBBLE", "BELL", "BONK", "POK", "MAGIC_POK", "MAGIC", "RUN"};
   }

}
