package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.AspectRatioEvent;
import winvi.noxiumvisuals.utils.RenderRenderer;
import winvi.noxiumvisuals.utils.QuadraticEaseOutAnimation;
import winvi.noxiumvisuals.utils.ClientType;
public class AspectRatioModule extends Module {
      private final RenderRenderer processField76;
      private float ypjin;
      private float smmmr;
      private float tvugn;
      private float dvux;
      private final BooleanSetting clbgn;
      private final ChoiceSetting vw;
      private final NumberSetting dcsnd;
      private final BooleanSetting dvy;
      private final NumberSetting destroyField24;
      private final NumberSetting sulst;
      private final SettingGroup dwbz;
      private final SettingGroup dwcc;

   public AspectRatioModule() {
      super("AspectRatio", ModuleCategory.UTILS);
      this.processField76 = new QuadraticEaseOutAnimation().setMs(300).setValue(1);
      this.ypjin = 1.7777778F;
      this.smmmr = 1.7777778F;
      this.tvugn = 1.7777778F;
      this.dvux = 0F;
      this.dvy = new BooleanSetting(
            "Rofl Mode",
            "Crazy aspect ratio changes based on camera and time"
         )
         .setValue(false);
      this.dvy.withTranslation("aspectratio.roflmode", "aspectratio.roflmode.desc");
      this.clbgn = new BooleanSetting(
            "Use Preset",
            "Use a preset aspect ratio instead of custom value"
         )
         .setValue(false);
      this.clbgn.withTranslation("aspectratio.usepreset", "aspectratio.usepreset.desc");
      this.vw = new ChoiceSetting(
            "Preset",
            "Select a preset aspect ratio"
         )
         .value(
            "16:9",
            "16:10",
            "21:9",
            "32:9",
            "4:3",
            "5:4",
            "3:2",
            "1:1",
            "9:16"
         )
         .selected("16:9")
         .visible(() -> {
            return this.clbgn.isValue() && !this.dvy.isValue();
         });
      this.vw.withTranslation("aspectratio.preset", "aspectratio.preset.desc");
      this.dcsnd = new NumberSetting(
            "Ratio",
            "Aspect ratio value setting"
         )
         .setValue(0.65F)
         .range(0.1F, 2.0F)
         .visible(() -> {
            return !this.clbgn.isValue() && !this.dvy.isValue();
         });
      this.dcsnd.withTranslation("aspectratio.ratio", "aspectratio.ratio.desc");
      this.destroyField24 = new NumberSetting(
            "Rofl Intensity",
            "Intensity of aspect ratio changes"
         )
         .setValue(0.5F)
         .range(0.1F, 2.0F);
      this.destroyField24.withTranslation("aspectratio.roflintensity", "aspectratio.roflintensity.desc");
      this.destroyField24.visible(() -> {
         return this.dvy.isValue();
      });
      this.sulst = new NumberSetting(
            "Rofl Speed",
            "Speed of aspect ratio changes"
         )
         .setValue(1F)
         .range(0.1F, 5.0F);
      this.sulst.withTranslation("aspectratio.roflspeed", "aspectratio.roflspeed.desc");
      this.sulst.visible(() -> {
         return this.dvy.isValue();
      });
      this.dwbz = new SettingGroup(
            "Aspect Ratio",
            "Change screen resolution"
         )
         .settings(this.clbgn, this.vw, this.dcsnd)
         .setValue(true);
      this.dwbz.withTranslation("aspectratio.group", "aspectratio.group.desc");
      this.dwcc = new SettingGroup(
            "Rofl Settings",
            "Crazy dynamic aspect ratio"
         )
         .settings(this.dvy, this.destroyField24, this.sulst)
         .setValue(false);
      this.dwcc.withTranslation("aspectratio.roflgroup", "aspectratio.roflgroup.desc");
      this.setup(new ModuleSetting[]{this.dwbz, this.dwcc});
   }

      private float ol0() {
      if (this.dvy.isValue() && MinecraftClient.getInstance().player != null) {
         return this.checkMethod950();
      } else if (this.clbgn.isValue()) {
         String text = this.vw.getSelected();

         return switch (text) {
            case "16:9" -> 1.7777778F;
            case "16:10" -> 1.6F;
            case "21:9" -> 2.3333333F;
            case "32:9" -> 3.5555556F;
            case "4:3" -> 1.3333334F;
            case "5:4" -> 1.25F;
            case "3:2" -> 1.5F;
            case "1:1" -> 1F;
            case "9:16" -> 0.5625F;
            default -> 1.7777778F;
         };
      } else {
         return this.dcsnd.getValue();
      }
   }

      private float checkMethod950() {
      float client = MinecraftClient.getInstance().player.getPitch();
      float client2 = MinecraftClient.getInstance().player.getYaw();
      this.dvux = this.dvux + 0.016F * this.sulst.getValue();
      float value = 1.7777778F;
      float value2 = this.destroyField24.getValue();
      float value3 = (float)Math.sin(client / 90.0F * 3.141592653589793 + this.dvux);
      float value4 = (float)Math.cos(Math.toRadians(client2) + this.dvux * 2.0F);
      float value5 = (float)Math.sin(this.dvux * 3.0F);
      float value6 = (value3 + value4 + value5) / 3.0F;
      return MathHelper.clamp(value + value6 * value2 * 1.5F, 0.5F, 3.0F);
   }

      private float qytnzb() {
      float value = this.ol0();
      if (this.dvy.isValue()) {
         float value2 = 0.15F * this.sulst.getValue();
         this.ypjin = MathHelper.lerp(value2, this.ypjin, value);
         return this.ypjin;
      } else {
         if (Math.abs(value - this.smmmr) > 0.001F) {
            this.tvugn = this.ypjin;
            this.smmmr = value;
            this.processField76.reset();
            this.processField76.setDirection(ClientType.FORWARDS);
         }

         float value3 = this.processField76.getOutput().floatValue();
         this.ypjin = MathHelper.lerp(value3, this.tvugn, this.smmmr);
         return this.ypjin;
      }
   }

   @EventHandler
      public void onAspect(AspectRatioEvent e) {
      if (this.dwbz.isValue() || this.dvy.isValue()) {
         e.setRatio(this.qytnzb());
         e.cancel();
      }
   }

}
