package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.util.math.MatrixStack;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.MouseTextRenderer;
import winvi.noxiumvisuals.ui.hud.elements.DynamicIslandHud;
public class DynamicIslandModule extends Module {
      private final NumberSetting validateField170;
      private final BooleanSetting rhqrr;
      private final ChoiceSetting dwx;
      private final ChoiceSetting startField20;
      private final BooleanSetting hasField97;
      private final BooleanSetting exhav;
      private final BooleanSetting b17;
      private final BooleanSetting fzgux;
      private final BooleanSetting dxd;
      private final ChoiceSetting calculateField58;

   public DynamicIslandModule() {
      super("Dynamic Island", ModuleCategory.UTILS);
      this.validateField170 = new NumberSetting(
            "Size",
            "Scale of Dynamic Island"
         )
         .setValue(1F)
         .range(0.7F, 1.6F)
         .displayFormatter(value -> {
            return String.format(Locale.US, "%.2fx", value);
         });
      this.rhqrr = new BooleanSetting(
            "Show on Main Menu",
            "Show Dynamic Island on Minecraft main menu"
         )
         .setValue(true);
      this.dwx = new ChoiceSetting(
            "Display Mode",
            "What to show on the right side"
         )
         .value(
            "Time",
            "FPS",
            "Both"
         )
         .selected("Time");
      this.startField20 = new ChoiceSetting(
            "Shape Mode",
            "Dynamic Island shape"
         )
         .value(
            "Island",
            "Notch"
         )
         .selected("Island")
         .withTranslation("dynamicisland.shapemode", "dynamicisland.shapemode.desc");
      this.hasField97 = new BooleanSetting(
            "Show Media Preview",
            "Show circular media preview"
         )
         .setValue(true);
      this.exhav = new BooleanSetting(
            "Show PvP Mode",
            "Show PvP mode indicator when detected"
         )
         .setValue(true);
      this.b17 = new BooleanSetting(
            "Use Album Color",
            "Use dominant color from album artwork as background"
         )
         .setValue(true);
      this.fzgux = new BooleanSetting(
            "Hide Gradient When Closed",
            "Keep closed media preview background black instead of album gradient"
         )
         .setValue(true)
         .visible(() -> {
            return this.b17.isValue();
         });
      this.dxd = new BooleanSetting(
            "Custom Browser Icon",
            "Use custom music service icon for browsers"
         )
         .setValue(false);
      this.calculateField58 = new ChoiceSetting(
            "Browser Music Service",
            "Default music service icon for browsers"
         )
         .value(
            "Yandex Music",
            "Spotify",
            "YouTube Music",
            "SoundCloud",
            "VK Music",
            "Apple Music"
         )
         .selected("Yandex Music")
         .visible(() -> {
            return this.dxd.isValue();
         });
      this.setup(new ModuleSetting[]{this.validateField170, this.rhqrr, this.dwx, this.startField20, this.hasField97, this.exhav, this.b17, this.fzgux});
      this.setState(true);
   }

   @EventHandler
      public void onScreenRender(MouseTextRenderer event) {
      if (this.isState() && this.rhqrr.isValue()) {
         if (MinecraftClient.getInstance().currentScreen instanceof TitleScreen) {
            if (NoxiumVisuals.getInstance() == null || NoxiumVisuals.getInstance().getDraggableRepository() == null) {
               return;
            }

            DynamicIslandHud dynamicIslandHud = NoxiumVisuals.getInstance().getDraggableRepository().get(DynamicIslandHud.class);
            if (dynamicIslandHud == null) {
               return;
            }

            dynamicIslandHud.tick();
            int width = (int)(
               MinecraftClient.getInstance().mouse.getX()
                  * MinecraftClient.getInstance().getWindow().getScaledWidth()
                  / MinecraftClient.getInstance().getWindow().getWidth()
            );
            int height = (int)(
               MinecraftClient.getInstance().mouse.getY()
                  * MinecraftClient.getInstance().getWindow().getScaledHeight()
                  / MinecraftClient.getInstance().getWindow().getHeight()
            );
            if (dynamicIslandHud.canDraw(dynamicIslandHud)) {
               dynamicIslandHud.startAnimation();
            } else {
               dynamicIslandHud.stopAnimation();
            }

            if (!dynamicIslandHud.isCloseAnimationFinished()) {
               dynamicIslandHud.validPosition();
               MatrixStack matrices = event.getContext().getMatrices();
               matrices.push();
               dynamicIslandHud.render(event.getContext(), width, height, event.getDelta());
               matrices.pop();
               event.getContext().draw();
            }
         }
      }
   }

      public NumberSetting getSize() {
      return this.validateField170;
   }

      public BooleanSetting getShowOnMainMenu() {
      return this.rhqrr;
   }

      public ChoiceSetting getDisplayMode() {
      return this.dwx;
   }

      public ChoiceSetting getShapeMode() {
      return this.startField20;
   }

      public BooleanSetting getShowMediaPreview() {
      return this.hasField97;
   }

      public BooleanSetting getShowPvPMode() {
      return this.exhav;
   }

      public BooleanSetting getUseAlbumColor() {
      return this.b17;
   }

      public BooleanSetting getHideGradientWhenClosed() {
      return this.fzgux;
   }

      public BooleanSetting getCustomBrowserIcon() {
      return this.dxd;
   }

      public ChoiceSetting getBrowserMusicService() {
      return this.calculateField58;
   }

   static {
      int index = 0;
   }
}
