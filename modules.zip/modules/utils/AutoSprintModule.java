package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
public class AutoSprintModule extends Module {

   public AutoSprintModule() {
      super(
         "AutoSprint",
         "Auto Sprint",
         ModuleCategory.UTILS
      );
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (MinecraftClient.getInstance().player != null
         && MinecraftClient.getInstance().world != null
         && MinecraftClient.getInstance().player.input != null) {
         if (!MinecraftClient.getInstance().player.hasVehicle()
            && !MinecraftClient.getInstance().player.isSneaking()
            && !MinecraftClient.getInstance().player.isUsingItem()
            && !MinecraftClient.getInstance().player.isClimbing()
            && !MinecraftClient.getInstance().player.isTouchingWater()
            && !MinecraftClient.getInstance().player.isSubmergedInWater()
            && !MinecraftClient.getInstance().player.isGliding()) {
            if (MinecraftClient.getInstance().player.input.hasForwardMovement()) {
               MinecraftClient.getInstance().player.setSprinting(true);
            }
         }
      }
   }

   static {
      int index = 0;
   }
}
