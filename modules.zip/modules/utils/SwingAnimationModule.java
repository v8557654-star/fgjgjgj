package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionf;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.ModuleData;
import winvi.noxiumvisuals.modules.visuals.AnimationModuleProvider;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BezierCurveSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.MatrixItemStackManager;
public class SwingAnimationModule extends Module {
      private static SwingAnimationModule dzg;
      private final ChoiceSetting hasField21;
      public final NumberSetting speed;
      public final BooleanSetting swingBack;
      public final BezierCurveSetting bezierCurve;
      public final NumberSetting startAnchorX;
      public final NumberSetting startAnchorY;
      public final NumberSetting startAnchorZ;
      public final NumberSetting startMoveX;
      public final NumberSetting startMoveY;
      public final NumberSetting startMoveZ;
      public final NumberSetting startRotateX;
      public final NumberSetting startRotateY;
      public final NumberSetting startRotateZ;
      public final NumberSetting endAnchorX;
      public final NumberSetting endAnchorY;
      public final NumberSetting endAnchorZ;
      public final NumberSetting endMoveX;
      public final NumberSetting endMoveY;
      public final NumberSetting endMoveZ;
      public final NumberSetting endRotateX;
      public final NumberSetting endRotateY;
      public final NumberSetting endRotateZ;
      private String smplv;
      private final Quaternionf dzj;

   public SwingAnimationModule() {
      super("Swing Animation", ModuleCategory.UTILS);
      this.smplv = "Block Hit";
      this.dzj = new Quaternionf();
      dzg = this;
      this.hasField21 = new ChoiceSetting(
            "Preset",
            "Select animation preset"
         )
         .value(
            "Block Hit",
            "Bonk",
            "Spin",
            "Push",
            "Vanilla+",
            "Vanilla",
            "Swipe",
            "Down",
            "Smooth",
            "Smooth2",
            "Power",
            "Feast",
            "Twist",
            "First",
            "Second",
            "Third",
            "Fourth",
            "Fifth"
         )
         .selected("Block Hit");
      this.hasField21.withTranslation("swinganimation.preset", "swinganimation.preset.desc");
      this.speed = new NumberSetting(
            "Speed",
            "Swing animation speed"
         )
         .setValue(2.0F)
         .range(1F, 5.0F);
      this.speed.withTranslation("swinganimation.speed", "swinganimation.speed.desc");
      this.swingBack = new BooleanSetting(
            "Swing Back",
            "Smooth hand return after swing"
         )
         .setValue(true);
      this.bezierCurve = new BezierCurveSetting(
            "Bezier Curve",
            "Animation curve settings"
         )
         .setValues(0.5F, 1F, 0.5F, 0F);
      this.startAnchorX = new NumberSetting(
            "Start Anchor X",
            "Start anchor point X"
         )
         .setValue(0F)
         .range(-5.0F, 5.0F);
      this.startAnchorY = new NumberSetting(
            "Start Anchor Y",
            "Start anchor point Y"
         )
         .setValue(-0.05F)
         .range(-5.0F, 5.0F);
      this.startAnchorZ = new NumberSetting(
            "Start Anchor Z",
            "Start anchor point Z"
         )
         .setValue(-0.7F)
         .range(-5.0F, 5.0F);
      this.startMoveX = new NumberSetting(
            "Start Move X",
            "Start movement X"
         )
         .setValue(1.05F)
         .range(-5.0F, 5.0F);
      this.startMoveY = new NumberSetting(
            "Start Move Y",
            "Start movement Y"
         )
         .setValue(-0.7F)
         .range(-5.0F, 5.0F);
      this.startMoveZ = new NumberSetting(
            "Start Move Z",
            "Start movement Z"
         )
         .setValue(-1.1F)
         .range(-3.0F, 3.0F);
      this.startRotateX = new NumberSetting(
            "Start Rotate X",
            "Start rotation X"
         )
         .setValue(-120.0F)
         .range(-360.0F, 360.0F);
      this.startRotateY = new NumberSetting(
            "Start Rotate Y",
            "Start rotation Y"
         )
         .setValue(-135.0F)
         .range(-360.0F, 360.0F);
      this.startRotateZ = new NumberSetting(
            "Start Rotate Z",
            "Start rotation Z"
         )
         .setValue(-60.0F)
         .range(-360.0F, 360.0F);
      this.endAnchorX = new NumberSetting(
            "End Anchor X",
            "End anchor point X"
         )
         .setValue(0F)
         .range(-5.0F, 5.0F);
      this.endAnchorY = new NumberSetting(
            "End Anchor Y",
            "End anchor point Y"
         )
         .setValue(-0.05F)
         .range(-5.0F, 5.0F);
      this.endAnchorZ = new NumberSetting(
            "End Anchor Z",
            "End anchor point Z"
         )
         .setValue(-0.7F)
         .range(-5.0F, 5.0F);
      this.endMoveX = new NumberSetting(
            "End Move X",
            "End movement X"
         )
         .setValue(1.05F)
         .range(-5.0F, 5.0F);
      this.endMoveY = new NumberSetting(
            "End Move Y",
            "End movement Y"
         )
         .setValue(-0.7F)
         .range(-5.0F, 5.0F);
      this.endMoveZ = new NumberSetting(
            "End Move Z",
            "End movement Z"
         )
         .setValue(-1.1F)
         .range(-3.0F, 3.0F);
      this.endRotateX = new NumberSetting(
            "End Rotate X",
            "End rotation X"
         )
         .setValue(-120.0F)
         .range(-360.0F, 360.0F);
      this.endRotateY = new NumberSetting(
            "End Rotate Y",
            "End rotation Y"
         )
         .setValue(-180.0F)
         .range(-360.0F, 360.0F);
      this.endRotateZ = new NumberSetting(
            "End Rotate Z",
            "End rotation Z"
         )
         .setValue(-60.0F)
         .range(-360.0F, 360.0F);
      this.setup(new ModuleSetting[]{this.hasField21, this.speed});
      this.cpt("Block Hit");
   }

      private void cpt(String presetName) {
      AnimationModuleProvider animationModuleProvider = null;
      switch (presetName) {
         case "Block Hit":
            animationModuleProvider = AnimationModuleProvider.BLOCK_HIT;
            break;
         case "Bonk":
            animationModuleProvider = AnimationModuleProvider.BONK;
            break;
         case "Spin":
            animationModuleProvider = AnimationModuleProvider.ROTATE_360;
            break;
         case "Push":
            animationModuleProvider = AnimationModuleProvider.FROM_ME;
            break;
         case "Vanilla+":
            animationModuleProvider = AnimationModuleProvider.VANILLA_PLUS;
            break;
         case "Swipe":
            animationModuleProvider = AnimationModuleProvider.SWIPE;
            break;
         case "Down":
            animationModuleProvider = AnimationModuleProvider.DOWN;
            break;
         case "Smooth":
            animationModuleProvider = AnimationModuleProvider.SMOOTH;
            break;
         case "Smooth2":
            animationModuleProvider = AnimationModuleProvider.SMOOTH2;
            break;
         case "Power":
            animationModuleProvider = AnimationModuleProvider.POWER;
            break;
         case "Feast":
            animationModuleProvider = AnimationModuleProvider.FEAST;
            break;
         case "Twist":
            animationModuleProvider = AnimationModuleProvider.TWIST;
            break;
         case "First":
            animationModuleProvider = AnimationModuleProvider.FIRST;
            break;
         case "Second":
            animationModuleProvider = AnimationModuleProvider.SECOND;
            break;
         case "Third":
            animationModuleProvider = AnimationModuleProvider.THIRD;
            break;
         case "Fourth":
            animationModuleProvider = AnimationModuleProvider.FOURTH;
            break;
         case "Fifth":
            animationModuleProvider = AnimationModuleProvider.FIFTH;
      }

      if (animationModuleProvider != null) {
         this.bezierCurve.setValues(animationModuleProvider.getBezierStartX(), animationModuleProvider.getBezierStartY(), animationModuleProvider.getBezierEndX(), animationModuleProvider.getBezierEndY());
         this.swingBack.setValue(animationModuleProvider.isSwingBack());
         this.speed.setValue(animationModuleProvider.getSpeed());
         ModuleData moduleData = animationModuleProvider.getFrom();
         this.startAnchorX.setValue(moduleData.anchorX());
         this.startAnchorY.setValue(moduleData.anchorY());
         this.startAnchorZ.setValue(moduleData.anchorZ());
         this.startMoveX.setValue(moduleData.moveX());
         this.startMoveY.setValue(moduleData.moveY());
         this.startMoveZ.setValue(moduleData.moveZ());
         this.startRotateX.setValue(moduleData.rotateX());
         this.startRotateY.setValue(moduleData.rotateY());
         this.startRotateZ.setValue(moduleData.rotateZ());
         ModuleData moduleData2 = animationModuleProvider.getTo();
         this.endAnchorX.setValue(moduleData2.anchorX());
         this.endAnchorY.setValue(moduleData2.anchorY());
         this.endAnchorZ.setValue(moduleData2.anchorZ());
         this.endMoveX.setValue(moduleData2.moveX());
         this.endMoveY.setValue(moduleData2.moveY());
         this.endMoveZ.setValue(moduleData2.moveZ());
         this.endRotateX.setValue(moduleData2.rotateX());
         this.endRotateY.setValue(moduleData2.rotateY());
         this.endRotateZ.setValue(moduleData2.rotateZ());
      }
   }

   @EventHandler
      public void onHandAnimation(MatrixItemStackManager event) {
      if (this.isState()) {
         if (this.shouldApplyAnimation(event.getStack())) {
            String text = this.hasField21.getSelected();
            this.controlMethod46(text);
            if (!"Vanilla".equals(text)) {
               AnimationModuleProvider animationModuleProvider = this.smvzrv();
               if (animationModuleProvider != null) {
                  MatrixStack matrices = event.getMatrices();
                  float value = event.getSwingProgress();
                  if (animationModuleProvider.isUseLegacyAnimation()) {
                     this.computeMethod76(matrices, value, text, event.getArm());
                  } else {
                     this.eymjzh(matrices, value, event.getArm());
                  }

                  event.cancel();
               }
            }
         }
      }
   }

      private void eymjzh(MatrixStack matrices, float swingProgress, Arm arm) {
      float value = 0F;
      if (swingProgress > 0F) {
         float value2 = this.xygona(swingProgress);
         value = this.ddfolt(this.bezierCurve.evaluate(value2));
         if (this.swingBack.isValue()) {
            value = (float)Math.sin(value * 3.141592653589793);
         }
      }

      float value3 = this.computeMethod6(this.startAnchorX.getValue(), this.endAnchorX.getValue(), value);
      float value4 = this.computeMethod6(this.startAnchorY.getValue(), this.endAnchorY.getValue(), value);
      float value5 = this.computeMethod6(this.startAnchorZ.getValue(), this.endAnchorZ.getValue(), value);
      float value6 = this.computeMethod6(this.startMoveX.getValue(), this.endMoveX.getValue(), value);
      float value7 = this.computeMethod6(this.startMoveY.getValue(), this.endMoveY.getValue(), value);
      float value8 = this.computeMethod6(this.startMoveZ.getValue(), this.endMoveZ.getValue(), value);
      float value9 = this.computeMethod6(this.startRotateX.getValue(), this.endRotateX.getValue(), value);
      float value10 = this.computeMethod6(this.startRotateY.getValue(), this.endRotateY.getValue(), value);
      float value11 = this.computeMethod6(this.startRotateZ.getValue(), this.endRotateZ.getValue(), value);
      float value12 = arm == Arm.RIGHT ? 1F : -1F;
      matrices.translate(value3 * value12, value4, value5);
      matrices.translate(value6 * value12, value7, value8);
      this.dzj.identity().rotationXYZ((float)Math.toRadians(value9), (float)Math.toRadians(value10 * value12), (float)Math.toRadians(value11 * value12));
      matrices.multiply(this.dzj);
      matrices.translate(-value3 * value12, -value4, -value5);
   }

      private AnimationModuleProvider smvzrv() {
      String text = this.hasField21.getSelected();

      return switch (text) {
         case "Block Hit" -> AnimationModuleProvider.BLOCK_HIT;
         case "Bonk" -> AnimationModuleProvider.BONK;
         case "Spin" -> AnimationModuleProvider.ROTATE_360;
         case "Push" -> AnimationModuleProvider.FROM_ME;
         case "Vanilla+" -> AnimationModuleProvider.VANILLA_PLUS;
         case "Swipe" -> AnimationModuleProvider.SWIPE;
         case "Down" -> AnimationModuleProvider.DOWN;
         case "Smooth" -> AnimationModuleProvider.SMOOTH;
         case "Smooth2" -> AnimationModuleProvider.SMOOTH2;
         case "Power" -> AnimationModuleProvider.POWER;
         case "Feast" -> AnimationModuleProvider.FEAST;
         case "Twist" -> AnimationModuleProvider.TWIST;
         case "First" -> AnimationModuleProvider.FIRST;
         case "Second" -> AnimationModuleProvider.SECOND;
         case "Third" -> AnimationModuleProvider.THIRD;
         case "Fourth" -> AnimationModuleProvider.FOURTH;
         case "Fifth" -> AnimationModuleProvider.FIFTH;
         default -> null;
      };
   }

      private void computeMethod76(MatrixStack matrices, float swingProgress, String style, Arm arm) {
      int index = arm == Arm.RIGHT ? 1 : -1;
      float value = this.ddfolt(this.bezierCurve.evaluate(this.xygona(swingProgress)));
      float value2 = (float)Math.sin(value * value * 3.141592653589793);
      float value3 = (float)Math.sin(Math.sqrt(value) * 3.141592653589793);
      float value4 = (float)(Math.sin(value * 3.141592653589793) * 0.5);
      float value5 = 1F;
      switch (style) {
         case "Swipe":
            matrices.translate(0.56F * index, -0.32F, -0.72F);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(60 * index));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-60 * index));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(value3 * value2 * -5.0F * value5));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(value3 * value2 * -120.0F * value5));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-60.0F));
            break;
         case "Down":
            matrices.translate(index * 0.56F, -0.32F, -0.72F);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(76 * index));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(value3 * -5.0F * value5));
            matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(value3 * -100.0F * value5));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(value3 * -155.0F * value5));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-100.0F));
            break;
         case "Smooth":
            matrices.translate(index * 0.56F, -0.42F, -0.72F);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(index * (45.0F + value2 * -20.0F * value5)));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(index * value3 * -20.0F * value5));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(value3 * -80.0F * value5));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(index * -45.0F));
            matrices.translate(0, -0.1F, 0);
            break;
         case "Power":
            matrices.translate(index * 0.56F, -0.32F, -0.72F);
            matrices.translate(-value4 * value4 * value2 * index, 0F, 0F);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(61 * index));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(value3 * value5));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(value3 * value2 * -5.0F * value5));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(value3 * value2 * -30.0F * value5));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-60.0F));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(value4 * -60.0F * value5));
            break;
         case "Feast":
            matrices.translate(index * 0.56F, -0.32F, -0.72F);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(30 * index));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(value3 * 75.0F * index * value5));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(value3 * -45.0F * value5));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(30 * index));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-80.0F));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(35 * index));
            break;
         case "Twist":
            matrices.translate(index * 0.56F, -0.36F, -0.72F);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(80 * index));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(value3 * -90.0F * value5));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((value2 - value3) * 60.0F * index * value5));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-30.0F));
            matrices.translate(0F, -0.1F, 0.05F);
            break;
         case "Smooth2":
            matrices.translate(index * 0.56F, -0.42F, -0.72F);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(value3 * -80.0F * value5));
            matrices.translate(0, -0.1F, 0);
            break;
         case "First":
            matrices.translate(0.56F * index, -0.5F, -0.7F);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(45 * index));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(value3 * -85.0F * value5));
            matrices.translate(-0.1F * index, 0.28F, 0.2F);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-85.0F));
            break;
         case "Second":
            matrices.translate(index * 0.56F, -0.52F, -0.72F);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(50.0F));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-60.0F * index));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((110.0F + 20.0F * value3) * index * value5));
            break;
         case "Third":
            matrices.translate(index * 0.56F, -0.52F, -0.72F);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(50.0F));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((-30.0F * (1F - value3) - 30.0F) * index));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(110.0F * index));
            break;
         case "Fourth":
            float value6 = (float)Math.sin(value * 3.141592653589793);
            matrices.translate(index * 0.56F, -0.52F, -0.72F);
            matrices.translate(0.1F * index, -0.2F, -0.3F);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-30.0F * value6 * value5 - 36.0F));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(25.0F * value6 * index));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(12.0F * index));
            break;
         case "Fifth":
            matrices.translate(index * 0.56F, -0.52F, -0.72F);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(50.0F));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-30.0F * index));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((110.0F + 30.0F * value3) * index * value5));
      }
   }

      private void controlMethod46(String currentPreset) {
      if (!currentPreset.equals(this.smplv)) {
         this.cpt(currentPreset);
         this.smplv = currentPreset;
      }
   }

      private float xygona(float swingProgress) {
      float value = Math.max(0F, Math.min(1F, swingProgress));
      float value2 = this.speed.getValue();
      return value2 <= 1F ? value : 1F - (float)Math.pow(1F - value, value2);
   }

      private float ddfolt(float progress) {
      float value = Math.max(0F, Math.min(1F, progress));
      float value2 = value * value * (3.0F - 2.0F * value);
      return this.computeMethod6(value, value2, 0.65F);
   }

      private float computeMethod6(float start, float end, float progress) {
      return start + (end - start) * progress;
   }

      public boolean shouldApplyAnimation(ItemStack itemStack) {
      Item item = itemStack.getItem();
      return item != Items.AIR && item != Items.FILLED_MAP && item != Items.CROSSBOW && item != Items.BOW && item != Items.TRIDENT;
   }

      public boolean isCustomAnimationActive(ItemStack itemStack) {
      return this.isState()
         && !"Vanilla".equals(this.hasField21.getSelected())
         && this.shouldApplyAnimation(itemStack);
   }

      public static SwingAnimationModule getInstance() {
      return dzg;
   }

      public ChoiceSetting getPresetMode() {
      return this.hasField21;
   }

      public NumberSetting getSpeed() {
      return this.speed;
   }

      public BooleanSetting getSwingBack() {
      return this.swingBack;
   }

      public BezierCurveSetting getBezierCurve() {
      return this.bezierCurve;
   }

      public NumberSetting getStartAnchorX() {
      return this.startAnchorX;
   }

      public NumberSetting getStartAnchorY() {
      return this.startAnchorY;
   }

      public NumberSetting getStartAnchorZ() {
      return this.startAnchorZ;
   }

      public NumberSetting getStartMoveX() {
      return this.startMoveX;
   }

      public NumberSetting getStartMoveY() {
      return this.startMoveY;
   }

      public NumberSetting getStartMoveZ() {
      return this.startMoveZ;
   }

      public NumberSetting getStartRotateX() {
      return this.startRotateX;
   }

      public NumberSetting getStartRotateY() {
      return this.startRotateY;
   }

      public NumberSetting getStartRotateZ() {
      return this.startRotateZ;
   }

      public NumberSetting getEndAnchorX() {
      return this.endAnchorX;
   }

      public NumberSetting getEndAnchorY() {
      return this.endAnchorY;
   }

      public NumberSetting getEndAnchorZ() {
      return this.endAnchorZ;
   }

      public NumberSetting getEndMoveX() {
      return this.endMoveX;
   }

      public NumberSetting getEndMoveY() {
      return this.endMoveY;
   }

      public NumberSetting getEndMoveZ() {
      return this.endMoveZ;
   }

      public NumberSetting getEndRotateX() {
      return this.endRotateX;
   }

      public NumberSetting getEndRotateY() {
      return this.endRotateY;
   }

      public NumberSetting getEndRotateZ() {
      return this.endRotateZ;
   }

      public String getLastAppliedPreset() {
      return this.smplv;
   }

      public Quaternionf getSwingRotation() {
      return this.dzj;
   }

}
