package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.util.Identifier;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.ActionSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.utils.TexturePlayerRenderer;
import winvi.noxiumvisuals.utils.PlayerTextureType;
public class CapeModule extends Module {
      private static CapeModule trekh;
      private final ChoiceSetting wm;
      private final ColorSetting wn;
      private final ActionSetting o17;
      private final ActionSetting obkzo;

   public CapeModule() {
      super("Cape", ModuleCategory.UTILS);
      this.wm = new ChoiceSetting(
            "Cape Texture",
            "Cape texture selection"
         )
         .value("yellow", "white", "standard", "red", "purple", "green", "gray", "cyan", "blue", "black", "noxiumvisuals", "noxiumvisualsold", "custom")
         .selected("yellow");
      this.wm.withTranslation("cape.texture", "cape.texture.desc");
      this.wn = new ColorSetting(
            "Cape Color",
            "Color tint for noxiumvisuals cape"
         )
         .value(-1)
         .visible(this::shouldApplyColor);
      this.wn.withTranslation("cape.color", "cape.color.desc");
      this.o17 = new ActionSetting(
            "Cape Folder",
            "Open the custom player texture folder"
         )
         .setButtonName("Open Folder")
         .action(TexturePlayerRenderer::openFolder);
      this.o17.withTranslation("cape.folder", "cape.folder.desc");
      this.obkzo = new ActionSetting(
            "Reload Cape",
            "Reload cape.png from disk"
         )
         .setButtonName("Reload")
         .action(TexturePlayerRenderer::refresh);
      this.obkzo.withTranslation("cape.reload", "cape.reload.desc");
      trekh = this;
      this.setup(new ModuleSetting[]{this.wm, this.o17, this.obkzo, this.wn});
   }

      public Identifier getCapeTexture() {
      String text = this.wm.getSelected();
      if (text == null || text.isEmpty() || this.wm.getList() == null || !this.wm.getList().contains(text)) {
         text = "yellow";
         this.wm.setSelected(text);
      }

      return text.equalsIgnoreCase("custom")
         ? TexturePlayerRenderer.getTexture(PlayerTextureType.CAPE)
         : Identifier.of("noxiumvisual", "textures/capes/" + text + ".png");
   }

      public int getCapeColor() {
      return this.wn.getColor();
   }

      public boolean shouldApplyColor() {
      return false;
   }

      public static CapeModule getInstance() {
      return trekh;
   }

}
