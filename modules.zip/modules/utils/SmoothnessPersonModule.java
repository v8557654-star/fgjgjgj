package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.MathHelper;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
public class SmoothnessPersonModule extends Module {
      static final float SWITCH_ANIM_SPEED = 0.26F;
      static final float DISTANCE_SPEED = 0.13F;
      static final float ROTATION_SMOOTH = 0.28F;
      static final float CAMERA_DISTANCE = 4.1F;
      static final float SNEAK_OFFSET = 0.5F;
      static final float JUMP_MULTIPLIER = 2.0F;
      static final float ANIM_SPEED = 0.13F;
      private float psoqn;
      private float trjaq;
      private float dyx;
      private float addField880;
      private float zidyt;
      private float a9;
      private float zb0;
      private float isField570;
      private boolean mdozy;
      private boolean calculateField51;
      private boolean abfpv;

   public SmoothnessPersonModule() {
      super(
         "SmoothnessPerson",
         "Smoothness Person",
         ModuleCategory.UTILS
      );
      this.abfpv = true;
   }

      @Override
   public void activate() {
      this.peqkdw();
      if (this.getMethod90()) {
         this.cpm(true);
         this.calculateField51 = true;
      }
   }

      @Override
   public void deactivate() {
      this.peqkdw();
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      this.destroyMethod73();
   }

      public boolean shouldSmoothThirdPerson(boolean thirdPerson) {
      return this.isState() && thirdPerson && MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null;
   }

      public float getInterpolatedYaw(float partialTicks) {
      if (MinecraftClient.getInstance().player == null) {
         return 0F;
      } else {
         this.ofdsis(false);
         return this.addField880 + (this.dyx - this.addField880) * partialTicks;
      }
   }

      public float getInterpolatedPitch(float partialTicks) {
      if (MinecraftClient.getInstance().player == null) {
         return 0F;
      } else {
         this.ofdsis(false);
         return MathHelper.clamp(this.a9 + (this.zidyt - this.a9) * partialTicks, -90.0F, 90.0F);
      }
   }

      public float getInterpolatedDistance(float partialTicks) {
      this.ofdsis(false);
      return this.trjaq + (this.psoqn - this.trjaq) * partialTicks;
   }

      public float getInterpolatedHeightOffset(float partialTicks) {
      this.ofdsis(false);
      return this.isField570 + (this.zb0 - this.isField570) * partialTicks;
   }

      private void destroyMethod73() {
      if (MinecraftClient.getInstance().player != null
         && MinecraftClient.getInstance().world != null
         && MinecraftClient.getInstance().options != null) {
         boolean client = !MinecraftClient.getInstance().options.getPerspective().isFirstPerson();
         if (client && !this.calculateField51) {
            this.cpm(true);
         }

         if (!client && this.calculateField51) {
            this.abfpv = true;
            this.mdozy = false;
         }

         this.calculateField51 = client;
         if (client) {
            this.deleteMethod58();
         }
      } else {
         this.peqkdw();
      }
   }

      private void cpm(boolean animateSwitch) {
      if (MinecraftClient.getInstance().player != null) {
         this.dyx = this.addField880 = this.ojrwor();
         this.zidyt = this.a9 = this.cpqp();
         this.psoqn = this.trjaq = animateSwitch ? 0F : 4.1F;
         this.zb0 = this.isField570 = 0F;
         this.mdozy = animateSwitch;
         this.abfpv = false;
      }
   }

      private void deleteMethod58() {
      if (MinecraftClient.getInstance().player != null) {
         if (this.abfpv) {
            this.cpm(true);
         } else {
            this.addField880 = this.dyx;
            this.a9 = this.zidyt;
            this.trjaq = this.psoqn;
            this.isField570 = this.zb0;
            this.dyx = this.dyx + MathHelper.wrapDegrees(this.ojrwor() - this.dyx) * 0.28F;
            this.zidyt = MathHelper.clamp(this.zidyt + (this.cpqp() - this.zidyt) * 0.28F, -90.0F, 90.0F);
            float value = this.mdozy ? 0.26F : 0.13F;
            this.psoqn = this.psoqn + (4.1F - this.psoqn) * value;
            if (this.mdozy && Math.abs(4.1F - this.psoqn) <= 0.02F) {
               this.psoqn = 4.1F;
               this.mdozy = false;
            }

            float value2 = 0F;
            if (MinecraftClient.getInstance().player.isSneaking()) {
               value2 = -0.5F;
            }

            if (!MinecraftClient.getInstance().player.isOnGround()) {
               value2 += (float)(-MinecraftClient.getInstance().player.getVelocity().y * 2.0);
            }

            this.zb0 = this.zb0 + (value2 - this.zb0) * 0.13F;
         }
      }
   }

      private void ofdsis(boolean animateSwitch) {
      if (this.abfpv) {
         this.cpm(animateSwitch);
      }
   }

      private float ojrwor() {
      return MinecraftClient.getInstance().player != null ? MinecraftClient.getInstance().player.getYaw() : 0F;
   }

      private float cpqp() {
      return MinecraftClient.getInstance().player != null ? MinecraftClient.getInstance().player.getPitch() : 0F;
   }

      private boolean getMethod90() {
      if (MinecraftClient.getInstance().player != null
         && MinecraftClient.getInstance().world != null
         && MinecraftClient.getInstance().options != null) {
         Perspective client = MinecraftClient.getInstance().options.getPerspective();
         return client != null && !client.isFirstPerson();
      } else {
         return false;
      }
   }

      private void peqkdw() {
      this.psoqn = 0F;
      this.trjaq = 0F;
      this.dyx = 0F;
      this.addField880 = 0F;
      this.zidyt = 0F;
      this.a9 = 0F;
      this.zb0 = 0F;
      this.isField570 = 0F;
      this.mdozy = false;
      this.calculateField51 = false;
      this.abfpv = true;
   }

   static {
      int index = 0;
   }
}
