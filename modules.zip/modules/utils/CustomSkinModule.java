package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.util.SkinTextures.Model;
import net.minecraft.util.Identifier;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.ActionSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.utils.TexturePlayerRenderer;
import winvi.noxiumvisuals.utils.PlayerTextureType;
public class CustomSkinModule extends Module {
      private static CustomSkinModule veokx;
      private final ChoiceSetting dys;
      private final ActionSetting setField13;
      private final ActionSetting kjpet;

   public CustomSkinModule() {
      super("Custom Skin", ModuleCategory.UTILS);
      this.dys = new ChoiceSetting(
            "Skin Model",
            "Arm model used by the custom skin"
         )
         .value(
            "Default",
            "Slim"
         )
         .selected("Default");
      this.setField13 = new ActionSetting(
            "Skin Folder",
            "Open the custom player texture folder"
         )
         .setButtonName("Open Folder")
         .action(TexturePlayerRenderer::openFolder);
      this.kjpet = new ActionSetting(
            "Reload Skin",
            "Reload skin.png from disk"
         )
         .setButtonName("Reload")
         .action(TexturePlayerRenderer::refresh);
      veokx = this;
      this.dys.withTranslation("skinoverride.model", "skinoverride.model.desc");
      this.setField13.withTranslation("skinoverride.folder", "skinoverride.folder.desc");
      this.kjpet.withTranslation("skinoverride.reload", "skinoverride.reload.desc");
      this.setup(new ModuleSetting[]{this.dys, this.setField13, this.kjpet});
   }

      public Identifier getSkinTexture() {
      return TexturePlayerRenderer.getTexture(PlayerTextureType.SKIN);
   }

      public Model getSkinModel() {
      return this.dys.isSelected("Slim") ? Model.SLIM : Model.WIDE;
   }

      public static CustomSkinModule getInstance() {
      return veokx;
   }

}
