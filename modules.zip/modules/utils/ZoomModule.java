package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.KeybindSetting;
import winvi.noxiumvisuals.systems.events.RenderEventData;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.MouseScrollEvent;
import winvi.noxiumvisuals.systems.events.FovEvent;
public class ZoomModule extends Module {
      static final float DEFAULT_ZOOM_FOV = 6.0F;
      static final float MIN_ZOOM_FOV = 3.0F;
      static final float MAX_ZOOM_FOV = 110.0F;
      static final float SCROLL_STEP = 12.0F;
      static final float SMOOTH_SPEED = 18.0F;
      private final KeybindSetting yoyzt;
      private boolean removeField270;
      private float srfgs;
      private float deleteField67;
      private long diqkj;

   public ZoomModule() {
      super("Zoom", ModuleCategory.UTILS);
      this.yoyzt = new KeybindSetting(
         "Bind",
         "Hold this key to activate zoom"
      );
      this.srfgs = 6.0F;
      this.deleteField67 = -1F;
      this.setup(new ModuleSetting[]{this.yoyzt});
   }

      @Override
   public void deactivate() {
      this.removeField270 = false;
      this.deleteField67 = -1F;
      this.diqkj = 0L;
   }

   @EventHandler
      public void onKey(RenderEventData event) {
      if (event.isBindDown(this.yoyzt)) {
         this.removeField270 = true;
      } else if (event.isBindReleased(this.yoyzt, true)) {
         this.removeField270 = false;
      }
   }

   @EventHandler
      public void onFov(FovEvent event) {
      if (MinecraftClient.getInstance().options != null) {
         float client = sanitizeFov(((Integer)MinecraftClient.getInstance().options.getFov().getValue()).intValue(), 110.0F);
         long timestamp = System.nanoTime();
         if (!Float.isFinite(this.deleteField67) || this.deleteField67 < 0F) {
            this.deleteField67 = client;
         }

         if (this.diqkj == 0L) {
            this.diqkj = timestamp;
         }

         float value = Math.min((float)(timestamp - this.diqkj) / 1E9F, 0.1F);
         this.diqkj = timestamp;
         float value2 = this.removeField270 ? sanitizeFov(Math.min(this.srfgs, client), client) : client;
         this.deleteField67 = sanitizeFov(this.deleteField67 + (value2 - this.deleteField67) * Math.min(1F, value * 18.0F), value2);
         if (!this.removeField270 && !(Math.abs(this.deleteField67 - client) > 0.05F)) {
            this.deleteField67 = client;
         } else {
            event.setFov(sanitizeFov(this.deleteField67, client));
            event.cancel();
         }
      }
   }

   @EventHandler
      public void onScroll(MouseScrollEvent event) {
      if (this.removeField270 && MinecraftClient.getInstance().currentScreen == null && event.getVertical() != 0) {
         if (!Float.isFinite(this.srfgs)) {
            this.srfgs = 6.0F;
         }

         this.srfgs = this.runMethod28(this.srfgs - (float)event.getVertical() * 12.0F, 3.0F, 110.0F);
         event.cancel();
      }
   }

      public static float sanitizeFov(float value, float fallback) {
      float value2 = Float.isFinite(fallback) ? Math.max(3.0F, Math.min(110.0F, fallback)) : 6.0F;
      return !Float.isFinite(value) ? value2 : Math.max(3.0F, Math.min(110.0F, value));
   }

      private float runMethod28(float value, float min, float max) {
      return Math.max(min, Math.min(max, value));
   }

   static {
      int index = 0;
   }
}
