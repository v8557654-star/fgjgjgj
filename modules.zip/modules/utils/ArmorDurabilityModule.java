package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.item.ItemStack;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class ArmorDurabilityModule extends Module {
      private static ArmorDurabilityModule dvd;
      private final ColorSetting setField490;
      private final ColorSetting zrlzh;
      private final BooleanSetting manageField3;
      private final NumberSetting efbkf;
      private final BooleanSetting dvij;

   public ArmorDurabilityModule() {
      super(
         "Armor Durability",
         "Colors armor based on durability",
         ModuleCategory.UTILS
      );
      this.setField490 = new ColorSetting(
            "Full Durability",
            "Color at full durability"
         )
         .setColor(-16711936)
         .withTranslation("armordurability.full", "armordurability.full.desc");
      this.zrlzh = new ColorSetting(
            "Low Durability",
            "Color at low durability"
         )
         .setColor(-65536)
         .withTranslation("armordurability.low", "armordurability.low.desc");
      this.manageField3 = new BooleanSetting(
            "Smooth Transition",
            "Smooth color transitions"
         )
         .setValue(true)
         .withTranslation("armordurability.smoothtransition", "armordurability.smoothtransition.desc");
      this.efbkf = new NumberSetting(
            "Intensity",
            "Color brightness"
         )
         .setValue(1F)
         .range(0.3F, 1.5F)
         .withTranslation("armordurability.intensity", "armordurability.intensity.desc");
      this.dvij = new BooleanSetting(
            "Only Damaged",
            "Color only damaged armor"
         )
         .setValue(false)
         .withTranslation("armordurability.onlydamaged", "armordurability.onlydamaged.desc");
      this.setup(new ModuleSetting[]{this.setField490, this.zrlzh, this.manageField3, this.efbkf, this.dvij});
      dvd = this;
   }

      public float getDurabilityProgress(ItemStack stack) {
      if (stack != null && !stack.isEmpty() && stack.isDamageable()) {
         int index = stack.getDamage();
         int index2 = stack.getMaxDamage();
         return index2 <= 0 ? 0F : (float)index / index2;
      } else {
         return 0F;
      }
   }

      public int getArmorColor(ItemStack stack) {
      if (stack != null && !stack.isEmpty() && stack.isDamageable()) {
         float value = this.getDurabilityProgress(stack);
         return this.dvij.isValue() && value == 0F ? -1 : this.vwroox(value);
      } else {
         return -1;
      }
   }

      private int vwroox(float durabilityProgress) {
      if (!this.manageField3.isValue()) {
         return durabilityProgress > 0.5F ? this.zrlzh.getColor() : this.setField490.getColor();
      } else {
         int color = this.setField490.getColor();
         int color2 = this.zrlzh.getColor();
         int index = color >> 16 & 0xFF;
         int index2 = color >> 8 & 0xFF;
         int index3 = color & 0xFF;
         int index4 = color2 >> 16 & 0xFF;
         int index5 = color2 >> 8 & 0xFF;
         int index6 = color2 & 0xFF;
         int index7 = (int)(index + (index4 - index) * durabilityProgress);
         int index8 = (int)(index2 + (index5 - index2) * durabilityProgress);
         int index9 = (int)(index3 + (index6 - index3) * durabilityProgress);
         return 0xFF000000 | index7 << 16 | index8 << 8 | index9;
      }
   }

      public float[] getArmorColorMultiplier(ItemStack stack) {
      int index = this.getArmorColor(stack);
      float value = this.efbkf.getValue();
      float value2 = (index >> 16 & 0xFF) / 255.0F * value;
      float value3 = (index >> 8 & 0xFF) / 255.0F * value;
      float value4 = (index & 0xFF) / 255.0F * value;
      return new float[]{Math.min(value2, 1F), Math.min(value3, 1F), Math.min(value4, 1F)};
   }

      public ColorSetting getFullDurabilityColor() {
      return this.setField490;
   }

      public ColorSetting getLowDurabilityColor() {
      return this.zrlzh;
   }

      public BooleanSetting getSmoothTransition() {
      return this.manageField3;
   }

      public NumberSetting getColorIntensity() {
      return this.efbkf;
   }

      public BooleanSetting getOnlyDamaged() {
      return this.dvij;
   }

      public static ArmorDurabilityModule getInstance() {
      return dvd;
   }

   static {
      int index = 0;
   }
}
