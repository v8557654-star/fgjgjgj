package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import winvi.noxiumvisuals.mixins.PlayerInteractEntityC2SPacketMixin;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.PacketEventProvider;
import winvi.noxiumvisuals.utils.render.ColorEntityRenderer;
public class ShieldIndicatorModule extends Module {
      private static final ItemStack gsbkr = new ItemStack(Items.SHIELD);
      private static ShieldIndicatorModule drbqm;
      private final ColorSetting n14;
      private final ColorSetting yvwqs;
      private final BooleanSetting p17;
      private final NumberSetting validateField12;

   public ShieldIndicatorModule() {
      super(
         "Shield Indicator",
         "Colors shield based on cooldown state",
         ModuleCategory.UTILS
      );
      this.n14 = new ColorSetting(
            "Ready",
            "Color when shield is ready"
         )
         .setColor(-16711936)
         .withTranslation("shieldindicator.ready", "shieldindicator.ready.desc");
      this.yvwqs = new ColorSetting(
            "Cooldown",
            "Color when shield is broken"
         )
         .setColor(-65536)
         .withTranslation("shieldindicator.cooldown", "shieldindicator.cooldown.desc");
      this.p17 = new BooleanSetting(
            "Smooth Transition",
            "Smooth color transitions"
         )
         .setValue(true)
         .withTranslation("shieldindicator.smoothtransition", "shieldindicator.smoothtransition.desc");
      this.validateField12 = new NumberSetting(
            "Intensity",
            "Color brightness"
         )
         .setValue(1F)
         .range(0.3F, 1.5F)
         .withTranslation("shieldindicator.intensity", "shieldindicator.intensity.desc");
      this.setup(new ModuleSetting[]{this.n14, this.yvwqs, this.p17, this.validateField12});
      drbqm = this;
   }

   @EventHandler
      public void onPacket(PacketEventProvider event) {
      if (event.isSend()) {
         if (event.getPacket() instanceof PlayerInteractEntityC2SPacket playerInteractEntityC2SPacket) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player != null && client.world != null) {
               ItemStack itemStack = client.player.getMainHandStack();
               if (!itemStack.isEmpty() && itemStack.getItem() instanceof AxeItem) {
                  int index = ((PlayerInteractEntityC2SPacketMixin)playerInteractEntityC2SPacket).noxiumvisual$getEntityId();
                  if (client.world.getEntityById(index) instanceof PlayerEntity player2 && player2.isBlocking()) {
                     ColorEntityRenderer.setPlayerShieldCooldown(index, System.currentTimeMillis(), 5000L);
                  }
               }
            }
         }
      }
   }

      public float getShieldCooldownProgress(PlayerEntity player) {
      if (player == null) {
         return 0F;
      } else {
         float player2 = ColorEntityRenderer.getPlayerShieldCooldownProgress(player.getId());
         if (player2 > 0F) {
            return player2;
         } else {
            MinecraftClient client = MinecraftClient.getInstance();
            return player == client.player ? player.getItemCooldownManager().getCooldownProgress(gsbkr, 0F) : 0F;
         }
      }
   }

      public float getShieldCooldownProgress() {
      MinecraftClient client = MinecraftClient.getInstance();
      return this.getShieldCooldownProgress(client.player);
   }

      public int getShieldColorForPlayer(PlayerEntity player) {
      float value = this.getShieldCooldownProgress(player);
      return this.ntngiw(value);
   }

      public int getShieldColorForEntityId(int entityId) {
      float player = ColorEntityRenderer.getPlayerShieldCooldownProgress(entityId);
      return this.ntngiw(player);
   }

      public int getShieldColor() {
      float value = this.getShieldCooldownProgress();
      return this.ntngiw(value);
   }

      private int ntngiw(float cooldownProgress) {
      if (!this.p17.isValue()) {
         return cooldownProgress > 0F ? this.yvwqs.getColor() : this.n14.getColor();
      } else {
         int color = this.n14.getColor();
         int color2 = this.yvwqs.getColor();
         int index = color >> 16 & 0xFF;
         int index2 = color >> 8 & 0xFF;
         int index3 = color & 0xFF;
         int index4 = color2 >> 16 & 0xFF;
         int index5 = color2 >> 8 & 0xFF;
         int index6 = color2 & 0xFF;
         int index7 = (int)(index + (index4 - index) * cooldownProgress);
         int index8 = (int)(index2 + (index5 - index2) * cooldownProgress);
         int index9 = (int)(index3 + (index6 - index3) * cooldownProgress);
         return 0xFF000000 | index7 << 16 | index8 << 8 | index9;
      }
   }

      public float[] getShieldColorMultiplier() {
      int index = this.getShieldColor();
      float value = this.validateField12.getValue();
      float value2 = (index >> 16 & 0xFF) / 255.0F * value;
      float value3 = (index >> 8 & 0xFF) / 255.0F * value;
      float value4 = (index & 0xFF) / 255.0F * value;
      return new float[]{Math.min(value2, 1F), Math.min(value3, 1F), Math.min(value4, 1F)};
   }

      public static void setCurrentEntity(LivingEntity entity) {
   }

      public static void clearCurrentEntity() {
   }

      public ColorSetting getReadyColor() {
      return this.n14;
   }

      public ColorSetting getCooldownColor() {
      return this.yvwqs;
   }

      public BooleanSetting getSmoothTransition() {
      return this.p17;
   }

      public NumberSetting getColorIntensity() {
      return this.validateField12;
   }

      public static ShieldIndicatorModule getInstance() {
      return drbqm;
   }

}
