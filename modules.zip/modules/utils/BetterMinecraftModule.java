package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.MatrixAnimationRenderer;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.utils.JsonFileRenderer;
public class BetterMinecraftModule extends Module {
      private final ChoiceSetting setField530;
      private final BooleanSetting dwec;
      private final BooleanSetting oxsrl;
      private final BooleanSetting dwgz;
      private final BooleanSetting dmmgo;
      private final BooleanSetting wmnxh;
      private final BooleanSetting parseField65;
      private final NumberSetting getField73;

   public BetterMinecraftModule() {
      super("Better Minecraft", ModuleCategory.UTILS);
      this.setField530 = new ChoiceSetting(
            "Animation",
            "Animation style"
         )
         .value(
            "Slide",
            "Size"
         )
         .selected("Slide");
      this.dwec = new BooleanSetting(
            "Chat",
            "Animate chat opening"
         )
         .setValue(true);
      this.oxsrl = new BooleanSetting(
            "Tab",
            "Animate player list opening"
         )
         .setValue(true);
      this.dwgz = new BooleanSetting(
            "Inventory",
            "Animate inventory and container screens"
         )
         .setValue(true);
      this.dmmgo = new BooleanSetting(
            "Hotbar Slot",
            "Smooth selected hotbar slot movement"
         )
         .setValue(true);
      this.wmnxh = new BooleanSetting(
            "Pause Menu",
            "Animate the escape menu"
         )
         .setValue(true);
      this.parseField65 = new BooleanSetting(
            "Item Tooltip",
            "Animate the held item tooltip"
         )
         .setValue(true);
      this.getField73 = new NumberSetting(
            "Speed",
            "Animation speed"
         )
         .setValue(14.0F)
         .range(4.0F, 28.0F);
      this.setField530.withTranslation("betterminecraft.animation", "betterminecraft.animation.desc");
      this.dwec.withTranslation("betterminecraft.chat", "betterminecraft.chat.desc");
      this.oxsrl.withTranslation("betterminecraft.tab", "betterminecraft.tab.desc");
      this.dwgz.withTranslation("betterminecraft.inventory", "betterminecraft.inventory.desc");
      this.dmmgo.withTranslation("betterminecraft.hotbarslot", "betterminecraft.hotbarslot.desc");
      this.wmnxh.withTranslation("betterminecraft.pausemenu", "betterminecraft.pausemenu.desc");
      this.parseField65.withTranslation("betterminecraft.itemtooltip", "betterminecraft.itemtooltip.desc");
      this.getField73.withTranslation("betterminecraft.speed", "betterminecraft.speed.desc");
      this.setField530.displayFormatter(BetterMinecraftModule::oo0);
      this.setup(new ModuleSetting[]{this.setField530, this.dwec, this.oxsrl, this.dwgz, this.dmmgo, this.wmnxh, this.parseField65, this.getField73});
   }

      public boolean isSlideAnimation() {
      return this.setField530.isSelected("Slide");
   }

      public boolean shouldAnimateChat() {
      return this.dwec.isValue();
   }

      public boolean shouldAnimateTab() {
      return this.oxsrl.isValue();
   }

      public boolean shouldAnimateInventory() {
      return this.dwgz.isValue();
   }

      public boolean shouldAnimateHotbarSlot() {
      return this.dmmgo.isValue();
   }

      public boolean shouldAnimatePauseMenu() {
      return this.wmnxh.isValue();
   }

      public boolean shouldAnimateItemTooltip() {
      return this.parseField65.isValue();
   }

      public float getAnimationSpeed() {
      return this.getField73.getValue();
   }

      @Override
   public void activate() {
      MatrixAnimationRenderer.onModuleEnabled();
   }

      @Override
   public void deactivate() {
      MatrixAnimationRenderer.onModuleDisabled();
   }

      private static String oo0(String value) {
      String text = "betterminecraft.animation." + value.toLowerCase();
      return JsonFileRenderer.has(text) ? JsonFileRenderer.get(text) : value;
   }

      public ChoiceSetting getAnimationMode() {
      return this.setField530;
   }

      public BooleanSetting getChatAnimation() {
      return this.dwec;
   }

      public BooleanSetting getTabAnimation() {
      return this.oxsrl;
   }

      public BooleanSetting getInventoryAnimation() {
      return this.dwgz;
   }

      public BooleanSetting getHotbarSlotAnimation() {
      return this.dmmgo;
   }

      public BooleanSetting getPauseMenuAnimation() {
      return this.wmnxh;
   }

      public BooleanSetting getItemTooltipAnimation() {
      return this.parseField65;
   }

      public NumberSetting getSpeed() {
      return this.getField73;
   }

}
