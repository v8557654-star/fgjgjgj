package winvi.noxiumvisuals.modules.utils;

import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;

/** Short positioned sound that fades during its last ten ticks. */
final class FadingHitSound extends MovingSoundInstance {
   private final float initialVolume;
   private int age;

   FadingHitSound(SoundEvent sound, float volume, float pitch, double x, double y, double z) {
      super(sound, SoundCategory.PLAYERS, SoundInstance.createRandom());
      this.initialVolume = volume;
      this.volume = volume;
      this.pitch = pitch;
      this.x = x;
      this.y = y;
      this.z = z;
      this.attenuationType = SoundInstance.AttenuationType.LINEAR;
   }

   @Override
   public void tick() {
      age++;
      if (age >= 18) {
         volume = 0F;
         setDone();
      } else if (age >= 8) {
         float progress = (age - 8) / 10.0F;
         float smooth = progress * progress * (3.0F - 2.0F * progress);
         volume = initialVolume * (1F - smooth);
      }
   }
}
