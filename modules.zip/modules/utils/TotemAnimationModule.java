package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
public class TotemAnimationModule extends Module {
      private static TotemAnimationModule removeField25;
      private final ChoiceSetting btris;
      private final NumberSetting zv;
      private final BooleanSetting transformField17;
      private ItemStack destroyField41;
      private int dzy;
      private boolean createField77;

   public TotemAnimationModule() {
      super("Totem Animation", ModuleCategory.UTILS);
      this.destroyField41 = null;
      this.createField77 = false;
      this.transformField17 = new BooleanSetting(
            "Test Animation",
            "Click to preview totem animation"
         )
         .setValue(false);
      this.transformField17.withTranslation("totemanimation.test", "totemanimation.test.desc");
      this.btris = new ChoiceSetting(
            "Mode",
            "Select totem animation mode"
         )
         .value(
            "Vanilla",
            "Circular",
            "Zoom",
            "Spiral",
            "Bounce",
            "Wave",
            "Flip",
            "Drift",
            "Explosion",
            "Portal"
         )
         .selected("Circular");
      this.btris.withTranslation("totemanimation.mode", "totemanimation.mode.desc");
      this.zv = new NumberSetting(
            "Speed",
            "Animation speed"
         )
         .setValue(5.0F)
         .range(1F, 10.0F);
      this.zv.withTranslation("totemanimation.speed", "totemanimation.speed.desc");
      removeField25 = this;
      this.setup(new ModuleSetting[]{this.transformField17, this.btris, this.zv});
   }

      public void showFloatingItem(ItemStack floatingItem) {
      this.destroyField41 = floatingItem;
      this.dzy = this.h16();
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (this.isState()) {
         this.skhuhz();
         this.g17();
      }
   }

      private void skhuhz() {
      if (MinecraftClient.getInstance().player != null) {
         boolean enabled = this.transformField17.isValue();
         if (enabled && !this.createField77) {
            ItemStack itemStack = new ItemStack(Items.TOTEM_OF_UNDYING);
            this.showFloatingItem(itemStack);
            this.transformField17.setValue(false);
         }

         this.createField77 = enabled;
      }
   }

      private void g17() {
      if (this.dzy > 0) {
         this.dzy--;
         if (this.dzy == 0) {
            this.destroyField41 = null;
         }
      }
   }

      public void renderFloatingItem(float tickDelta) {
      if (this.destroyField41 != null
         && this.dzy > 0
         && !"Vanilla".equals(this.btris.getSelected())) {
         int width = MinecraftClient.getInstance().getWindow().getScaledWidth();
         int height = MinecraftClient.getInstance().getWindow().getScaledHeight();
         int index = this.h16() - this.dzy;
         float value = (index + tickDelta) / this.h16();
         float value2 = value * value;
         float value3 = value * value2;
         float value4 = 10.25F * value3 * value2 - 24.95F * value2 * value2 + 25.5F * value3 - 13.8F * value2 + 4.0F * value;
         float value5 = value4 * 3.1415927F;
         RenderSystem.enableDepthTest();
         RenderSystem.disableCull();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         MatrixStack matrices = new MatrixStack();
         matrices.push();
         float value6 = index + tickDelta;
         float value7 = 50.0F + 175.0F * MathHelper.sin(value5);
         String text = this.btris.getSelected();
         switch (text) {
            case "Circular":
               float value8 = value * 150.0F;
               float value9 = value * 720.0F;
               float value10 = (float)(Math.cos(Math.toRadians(value9)) * value8);
               float value11 = (float)(Math.sin(Math.toRadians(value9)) * value8);
               matrices.translate(width / 2 + value10, height / 2 + value11, -50.0F);
               matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-value9));
               matrices.scale(value7, -value7, value7);
               break;
            case "Zoom":
               float value12 = (float)(Math.sin(value * 3.141592653589793 * 4.0) * 20.0 + 1);
               matrices.translate(width / 2, height / 2, -50.0F);
               matrices.scale(value7 + value12, -(value7 + value12), value7 + value12);
               break;
            case "Spiral":
               float value13 = (1F - value) * 200.0F;
               float value14 = value * 1080.0F;
               float value15 = (float)(Math.cos(Math.toRadians(value14)) * value13);
               float value16 = (float)(Math.sin(Math.toRadians(value14)) * value13) - value * 100.0F;
               matrices.translate(width / 2 + value15, height / 2 + value16, -50.0F);
               matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(value14));
               matrices.scale(200.0F - value6 * 1.5F, -200.0F + value6 * 1.5F, 200.0F - value6 * 1.5F);
               break;
            case "Bounce":
               float value17 = (float)Math.abs(Math.sin(value * 3.141592653589793 * 3.0)) * (1F - value) * 150.0F;
               matrices.translate(width / 2, height / 2 - value17, -50.0F);
               matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(value * 180.0F));
               matrices.scale(200.0F - value6 * 1.5F, -200.0F + value6 * 1.5F, 200.0F - value6 * 1.5F);
               break;
            case "Wave":
               float value18 = (float)(Math.sin(value * 3.141592653589793 * 2.0) * 100.0);
               float value19 = (float)(Math.cos(value * 3.141592653589793 * 3.0) * 50.0);
               matrices.translate(width / 2 + value18, height / 2 + value19, -50.0F);
               matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)(Math.sin(value * 3.141592653589793 * 2.0) * 45.0)));
               matrices.scale(value7, -value7, value7);
               break;
            case "Flip":
               matrices.translate(width / 2, height / 2, -50.0F);
               matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(value * 360.0F));
               matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(value * 180.0F));
               matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(value * 90.0F));
               matrices.scale(200.0F - value6 * 1.5F, -200.0F + value6 * 1.5F, 200.0F - value6 * 1.5F);
               break;
            case "Drift":
               float value20 = (float)(Math.pow(value, 2.0) * 300.0);
               float value21 = (float)(Math.sin(value * 3.141592653589793) * 50.0);
               matrices.translate(width / 2 + value20, height / 2 + value21, -50.0F);
               matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(value * 720.0F));
               matrices.scale(200.0F - value6 * 1.5F, -200.0F + value6 * 1.5F, 200.0F - value6 * 1.5F);
               break;
            case "Explosion":
               float value22 = 1F + value * 3.0F;
               float value23 = (float)((Math.random() - 0.5) * 20.0 * (1F - value));
               matrices.translate(width / 2 + value23, height / 2 + value23, -50.0F);
               matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)(Math.random() * 360.0)));
               matrices.scale(value7 * value22, -value7 * value22, value7 * value22);
               break;
            case "Portal":
               float value24 = (float)(1 - Math.pow(value, 2.0));
               float value25 = value * 1440.0F;
               matrices.translate(width / 2, height / 2, -50.0F);
               matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(value25));
               matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(value * 180.0F));
               matrices.scale(value7 * value24, -value7 * value24, value7 * value24);
         }

         Immediate client = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
         RenderSystem.setShaderColor(1F, 1F, 1F, 1F - value);
         MinecraftClient.getInstance()
            .getItemRenderer()
            .renderItem(
               this.destroyField41,
               ModelTransformationMode.FIXED,
               15728880,
               OverlayTexture.DEFAULT_UV,
               matrices,
               client,
               MinecraftClient.getInstance().world,
               0
            );
         matrices.pop();
         client.draw();
         RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
         RenderSystem.disableBlend();
         RenderSystem.enableCull();
         RenderSystem.disableDepthTest();
      }
   }

      private int h16() {
      int index = (int)((11.0F - this.zv.getValue()) * 10.0F);
      String text = this.btris.getSelected();
      if ("Circular".equals(text)
         || "Explosion".equals(text)) {
         return (int)(index * 0.7F);
      } else {
         return !"Bounce".equals(text)
               && !"Wave".equals(text)
            ? index
            : (int)(index * 0.85F);
      }
   }

      public static TotemAnimationModule getInstance() {
      return removeField25;
   }

   static {
      int index = 0;
   }
}
