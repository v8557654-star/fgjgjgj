package winvi.noxiumvisuals.modules.utils;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.Locale;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class CommandFixModule extends Module {
      private static final String convertField31 = "ёйцукенгшщзхъфывапролджэячсмитьбю";
      private static final String ws0 = "`qwertyuiop[]asdfghjkl;'zxcvbnm,.";
      private final BooleanSetting pjybp;
      private final BooleanSetting calculateField460;

   public CommandFixModule() {
      super("Command Fix", ModuleCategory.UTILS);
      this.pjybp = new BooleanSetting(
            "Keyboard Layout",
            "Convert commands typed with the Russian keyboard layout"
         )
         .setValue(true);
      this.calculateField460 = new BooleanSetting(
            "Normalize Case",
            "Convert the command name to lower case"
         )
         .setValue(true);
      this.pjybp.withTranslation("commandfix.layout", "commandfix.layout.desc");
      this.calculateField460.withTranslation("commandfix.case", "commandfix.case.desc");
      this.setup(new ModuleSetting[]{this.pjybp, this.calculateField460});
   }

      public String fixCommand(String command) {
      if (command != null && !command.isBlank()) {
         int index = command.indexOf(32);
         String text = index < 0 ? command : command.substring(0, index);
         String text2 = index < 0 ? "" : command.substring(index);
         if (this.pjybp.isValue()) {
            text = op0(text);
         }

         if (this.calculateField460.isValue()) {
            text = text.toLowerCase(Locale.ROOT);
         }

         return text + text2;
      } else {
         return command;
      }
   }

      private static String op0(String text) {
      StringBuilder stringBuilder = new StringBuilder(text.length());

      for (int index = 0; index < text.length(); index++) {
         char character = Character.toLowerCase(text.charAt(index));
         int index2 = "ёйцукенгшщзхъфывапролджэячсмитьбю"
            .indexOf(character);
         stringBuilder.append(
            index2 >= 0 ? "`qwertyuiop[]asdfghjkl;'zxcvbnm,.".charAt(index2) : character
         );
      }

      return stringBuilder.toString();
   }

   static {
      int index = 0;
   }
}
