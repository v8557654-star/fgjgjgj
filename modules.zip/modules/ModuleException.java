package winvi.noxiumvisuals.modules;

public final class ModuleException extends RuntimeException {
      private final String bdhqb;
      private final String dp;

   public ModuleException(String message, String moduleName) {
      this.bdhqb = message;
      this.dp = moduleName;
   }

      @Override
   public String getMessage() {
      return this.bdhqb;
   }

      public String getModuleName() {
      return this.dp;
   }

      @Override
   public String toString() {
      return "ModuleException(message=" + this.getMessage() + ", moduleName=" + this.getModuleName() + ")";
   }

      @Override
   public boolean equals(Object o) {
      if (o == this) {
         return true;
      } else if (!(o instanceof ModuleException clientException001)) {
         return false;
      } else if (!clientException001.canEqual(this)) {
         return false;
      } else if (!super.equals(o)) {
         return false;
      } else {
         String text = this.getMessage();
         String text2 = clientException001.getMessage();
         if (text == null ? text2 == null : text.equals(text2)) {
            String text3 = this.getModuleName();
            String text4 = clientException001.getModuleName();
            return text3 == null ? text4 == null : text3.equals(text4);
         } else {
            return false;
         }
      }
   }

      protected boolean canEqual(Object other) {
      return other instanceof ModuleException;
   }

      @Override
   public int hashCode() {
      byte byteValue = 59;
      int index = super.hashCode();
      String text = this.getMessage();
      index = index * 59 + (text == null ? 43 : text.hashCode());
      String text2 = this.getModuleName();
      return index * 59 + (text2 == null ? 43 : text2.hashCode());
   }

}
