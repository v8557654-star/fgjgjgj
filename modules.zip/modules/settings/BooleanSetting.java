package winvi.noxiumvisuals.modules.settings;

import java.util.function.Supplier;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
public class BooleanSetting extends ModuleSetting {
      private boolean value;
      private int key = -1;
      private int activationType = 1;
      private boolean defaultValue;
      private boolean defaultValueSet = false;

   public BooleanSetting(String name, String description) {
      super(name, description);
   }

      public BooleanSetting setValue(boolean value) {
      if (!this.defaultValueSet) {
         this.defaultValue = value;
         this.defaultValueSet = true;
      }

      boolean enabled = this.value;
      this.value = value;
      if (enabled != this.value) {
         this.markConfigDirty();
      }

      return this;
   }

      private void markConfigDirty() {
      try {
         NoxiumVisuals noxiumVisuals = NoxiumVisuals.getInstance();
         if (noxiumVisuals != null && noxiumVisuals.getFileController() != null) {
            noxiumVisuals.getFileController().markDirty();
         }
      } catch (Exception exception) {
      }
   }

      public BooleanSetting setDefaultValue() {
      if (!this.defaultValueSet) {
         this.defaultValue = this.value;
         this.defaultValueSet = true;
      }

      return this;
   }

      public void setKey(int key) {
      this.key = key;
   }

      public void setType(int type) {
      this.activationType = type;
   }

      public void reset() {
      if (this.defaultValueSet) {
         this.value = this.defaultValue;
      }
   }

      public boolean isModified() {
      return !this.defaultValueSet ? false : this.value != this.defaultValue;
   }

      public BooleanSetting visible(Supplier<Boolean> visible) {
      this.setVisible(visible);
      return this;
   }

      public boolean isValue() {
      return this.value;
   }

      public int getKey() {
      return this.key;
   }

      public int getType() {
      return this.activationType;
   }

      public boolean isDefaultValue() {
      return this.defaultValue;
   }

      public boolean isDefaultValueSet() {
      return this.defaultValueSet;
   }
}
