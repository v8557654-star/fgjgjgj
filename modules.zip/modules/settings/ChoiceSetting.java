package winvi.noxiumvisuals.modules.settings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
public class ChoiceSetting extends ModuleSetting {
      private String selected;
      private List<String> values;
      private Consumer<String> onChange;
      private Function<String, String> displayFormatter;
      private final Map<String, String> aliases = new HashMap<>();
      private String defaultSelected;

   public ChoiceSetting(String name, String description) {
      super(name, description);
   }

      public ChoiceSetting value(String... values) {
      this.values = new ArrayList<>(Arrays.asList(values));
      this.selected = this.values.getFirst();
      if (this.defaultSelected == null) {
         this.defaultSelected = this.values.getFirst();
      }

      return this;
   }

      public ChoiceSetting visible(Supplier<Boolean> visible) {
      this.setVisible(visible);
      return this;
   }

      public ChoiceSetting selected(String string) {
      this.selected = string;
      if (this.defaultSelected == null) {
         this.defaultSelected = string;
      }

      return this;
   }

      public void setSelected(String selected) {
      String text = this.canonicalValue(selected);
      if (this.values != null && !this.values.isEmpty()) {
         boolean enabled = text != null && this.values.stream().anyMatch(value -> {
            return value.equalsIgnoreCase(text);
         });
         this.selected = enabled ? text : this.values.getFirst();
      } else {
         this.selected = text;
      }
   }

      public ChoiceSetting onChange(Consumer<String> onChange) {
      this.onChange = onChange;
      return this;
   }

      public ChoiceSetting displayFormatter(Function<String, String> formatter) {
      this.displayFormatter = formatter;
      return this;
   }

      public ChoiceSetting alias(String legacyValue, String currentValue) {
      if (legacyValue != null && currentValue != null) {
         this.aliases.put(legacyValue.toLowerCase(), currentValue);
      }

      return this;
   }

      public void updateSelected(String selected) {
      selected = this.canonicalValue(selected);
      String text = this.selected;
      this.selected = selected;
      if (!selected.equals(text)) {
         this.ensureSelectedValue();
      }

      if (this.onChange != null) {
         this.onChange.accept(selected);
      }
   }

      private void ensureSelectedValue() {
      try {
         NoxiumVisuals noxiumVisuals = NoxiumVisuals.getInstance();
         if (noxiumVisuals != null && noxiumVisuals.getFileController() != null) {
            noxiumVisuals.getFileController().markDirty();
         }
      } catch (Exception exception) {
      }
   }

      public void clearValues() {
      if (this.values != null) {
         this.values.clear();
      }
   }

      public List<String> getValues() {
      return this.values;
   }

      public String getDisplayValue(String value) {
      try {
         return this.displayFormatter != null ? this.displayFormatter.apply(value) : this.normalizeAlias(value);
      } catch (Exception exception) {
         return value;
      }
   }

      private String normalizeAlias(String value) {
      return this.getLocalizedOption(value);
   }

      public boolean isSelected(String name) {
      return this.selected.equalsIgnoreCase(name);
   }

      private String canonicalValue(String value) {
      return value == null ? null : this.aliases.getOrDefault(value.toLowerCase(), value);
   }

      public void reset() {
      if (this.defaultSelected != null) {
         this.selected = this.defaultSelected;
      }
   }

      public boolean isModified() {
      return this.defaultSelected == null ? false : !this.defaultSelected.equals(this.selected);
   }

      public String getSelected() {
      return this.selected;
   }

      public List<String> getList() {
      return this.values;
   }

      public Consumer<String> getOnChange() {
      return this.onChange;
   }

      public Function<String, String> getDisplayFormatter() {
      return this.displayFormatter;
   }

      public Map<String, String> getAliases() {
      return this.aliases;
   }

      public String getDefaultSelected() {
      return this.defaultSelected;
   }

}
