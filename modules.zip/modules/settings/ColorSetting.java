package winvi.noxiumvisuals.modules.settings;

import java.awt.Color;
import java.util.function.Supplier;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.utils.render.RenderGeometry;
public class ColorSetting extends ModuleSetting {
      private float hue = 0.583F;
      private float saturation = 1F;
      private float brightness = 1F;
      private float alpha = 1F;
      private int[] presets;
      private float defaultHue = 0.583F;
      private float defaultSaturation = 1F;
      private float defaultBrightness = 1F;
      private float defaultAlpha = 1F;
      private boolean defaultValueSet = false;

   public ColorSetting(String name, String description) {
      super(name, description);
   }

      public void reset() {
      if (this.defaultValueSet) {
         boolean enabled = this.hue != this.defaultHue || this.saturation != this.defaultSaturation || this.brightness != this.defaultBrightness || this.alpha != this.defaultAlpha;
         this.hue = this.defaultHue;
         this.saturation = this.defaultSaturation;
         this.brightness = this.defaultBrightness;
         this.alpha = this.defaultAlpha;
         if (enabled) {
            this.markConfigDirty();
         }
      }
   }

      public boolean isModified() {
      return !this.defaultValueSet
         ? false
         : this.hue != this.defaultHue || this.saturation != this.defaultSaturation || this.brightness != this.defaultBrightness || this.alpha != this.defaultAlpha;
   }

      public ColorSetting value(int value) {
      this.setColor(value);
      return this;
   }

      public ColorSetting presets(int... presets) {
      this.presets = presets;
      return this;
   }

      public ColorSetting visible(Supplier<Boolean> visible) {
      this.setVisible(visible);
      return this;
   }

      public int getColor() {
      float[] floatArray = new float[]{this.hue, this.saturation, this.brightness};
      int color = Color.HSBtoRGB(floatArray[0], floatArray[1], floatArray[2]);
      int index = Math.round(this.alpha * 255.0F);
      return index << 24 | color & 16777215;
   }

      public int getColorWithAlpha() {
      float[] floatArray = new float[]{this.hue, this.saturation, this.brightness};
      int color = Color.HSBtoRGB(floatArray[0], floatArray[1], floatArray[2]);
      int index = Math.round(this.alpha * 255.0F);
      return index << 24 | color & 16777215;
   }

      public ColorSetting setColor(int color) {
      return this.applyColor(color, false);
   }

      public ColorSetting updateColor(int color) {
      return this.applyColor(color, true);
   }

      private ColorSetting applyColor(int color, boolean markDirty) {
      int color2 = this.getColor();
      float[] color3 = Color.RGBtoHSB(RenderGeometry.getRed(color), RenderGeometry.getGreen(color), RenderGeometry.getBlue(color), null);
      if (!this.defaultValueSet) {
         this.defaultHue = color3[0];
         this.defaultSaturation = color3[1];
         this.defaultBrightness = color3[2];
         this.defaultAlpha = RenderGeometry.getAlpha(color) / 255.0F;
         this.defaultValueSet = true;
      }

      this.hue = color3[0];
      this.saturation = color3[1];
      this.brightness = color3[2];
      this.alpha = RenderGeometry.getAlpha(color) / 255.0F;
      if (markDirty && color2 != this.getColor()) {
         this.markConfigDirty();
      }

      return this;
   }

      public void updateHSB(float hue, float saturation, float brightness, float alpha) {
      boolean enabled = this.hue != hue || this.saturation != saturation || this.brightness != brightness || this.alpha != alpha;
      this.hue = hue;
      this.saturation = saturation;
      this.brightness = brightness;
      this.alpha = alpha;
      if (enabled) {
         this.markConfigDirty();
      }
   }

      private void markConfigDirty() {
      try {
         NoxiumVisuals noxiumVisuals = NoxiumVisuals.getInstance();
         if (noxiumVisuals != null && noxiumVisuals.getFileController() != null) {
            noxiumVisuals.getFileController().markDirty();
         }
      } catch (Exception exception) {
      }
   }

      public ColorSetting setDefaultValue() {
      if (!this.defaultValueSet) {
         this.defaultHue = this.hue;
         this.defaultSaturation = this.saturation;
         this.defaultBrightness = this.brightness;
         this.defaultAlpha = this.alpha;
         this.defaultValueSet = true;
      }

      return this;
   }

      public float getHue() {
      return this.hue;
   }

      public float getSaturation() {
      return this.saturation;
   }

      public float getBrightness() {
      return this.brightness;
   }

      public float getAlpha() {
      return this.alpha;
   }

      public int[] getPresets() {
      return this.presets;
   }

      public float getDefaultHue() {
      return this.defaultHue;
   }

      public float getDefaultSaturation() {
      return this.defaultSaturation;
   }

      public float getDefaultBrightness() {
      return this.defaultBrightness;
   }

      public float getDefaultAlpha() {
      return this.defaultAlpha;
   }

      public boolean isDefaultValueSet() {
      return this.defaultValueSet;
   }

      public void setHue(float hue) {
      this.hue = hue;
   }

      public void setSaturation(float saturation) {
      this.saturation = saturation;
   }

      public void setBrightness(float brightness) {
      this.brightness = brightness;
   }

      public void setAlpha(float alpha) {
      this.alpha = alpha;
   }

      public void setPresets(int[] presets) {
      this.presets = presets;
   }

      public void setDefaultHue(float defaultHue) {
      this.defaultHue = defaultHue;
   }

      public void setDefaultSaturation(float defaultSaturation) {
      this.defaultSaturation = defaultSaturation;
   }

      public void setDefaultBrightness(float defaultBrightness) {
      this.defaultBrightness = defaultBrightness;
   }

      public void setDefaultAlpha(float defaultAlpha) {
      this.defaultAlpha = defaultAlpha;
   }

      public void setDefaultValueSet(boolean defaultValueSet) {
      this.defaultValueSet = defaultValueSet;
   }

}
