package winvi.noxiumvisuals.modules.settings;

import java.util.function.Supplier;
import winvi.noxiumvisuals.modules.ModuleSetting;
public class ActionSetting extends ModuleSetting {
      private Runnable action = () -> {
   };
      private String buttonName;

   public ActionSetting(String name, String description) {
      super(name, description);
      this.buttonName = "Click";
   }

      public ActionSetting action(Runnable action) {
      this.action = action;
      return this;
   }

      public ActionSetting setRunnable(Runnable action) {
      this.action = action;
      return this;
   }

      public ActionSetting setButtonName(String buttonName) {
      this.buttonName = buttonName;
      return this;
   }

      public Runnable getRunnable() {
      return this.action;
   }

      public void execute() {
      if (this.action != null) {
         this.action.run();
      }
   }

      public ActionSetting visible(Supplier<Boolean> visible) {
      this.setVisible(visible);
      return this;
   }

      public Runnable getAction() {
      return this.action;
   }

      public String getButtonName() {
      return this.buttonName;
   }

      public ActionSetting setAction(Runnable action) {
      this.action = action;
      return this;
   }

}
