package winvi.noxiumvisuals.modules.settings;

import winvi.noxiumvisuals.modules.ModuleSetting;
public class BezierCurveSetting extends ModuleSetting {
      private float x1;
      private float y1;
      private float x2;
      private float y2;
      private float defaultX1;
      private float defaultY1;
      private float defaultX2;
      private float defaultY2;
      private boolean defaultValueSet = false;

   public BezierCurveSetting(String name, String description) {
      super(name, description);
      this.x1 = 0.25F;
      this.y1 = 0.1F;
      this.x2 = 0.25F;
      this.y2 = 1F;
      this.defaultX1 = this.x1;
      this.defaultY1 = this.y1;
      this.defaultX2 = this.x2;
      this.defaultY2 = this.y2;
      this.defaultValueSet = true;
   }

      public void reset() {
      if (this.defaultValueSet) {
         this.x1 = this.defaultX1;
         this.y1 = this.defaultY1;
         this.x2 = this.defaultX2;
         this.y2 = this.defaultY2;
      }
   }

      public boolean isModified() {
      return !this.defaultValueSet
         ? false
         : this.x1 != this.defaultX1 || this.y1 != this.defaultY1 || this.x2 != this.defaultX2 || this.y2 != this.defaultY2;
   }

      public BezierCurveSetting setValues(float x1, float y1, float x2, float y2) {
      if (!this.defaultValueSet) {
         this.defaultX1 = x1;
         this.defaultY1 = y1;
         this.defaultX2 = x2;
         this.defaultY2 = y2;
         this.defaultValueSet = true;
      }

      this.x1 = x1;
      this.y1 = y1;
      this.x2 = x2;
      this.y2 = y2;
      return this;
   }

      public BezierCurveSetting setDefaultValue() {
      if (!this.defaultValueSet) {
         this.defaultX1 = this.x1;
         this.defaultY1 = this.y1;
         this.defaultX2 = this.x2;
         this.defaultY2 = this.y2;
         this.defaultValueSet = true;
      }

      return this;
   }

      public float evaluate(float t) {
      double value = t;
      double value2 = 0.001;

      for (int index = 0; index < 8; index++) {
         double value3 = this.sampleX(value);
         double value4 = value3 - t;
         if (Math.abs(value4) < value2) {
            break;
         }

         double value5 = this.sampleXDerivative(value);
         if (Math.abs(value5) < 1E-6) {
            break;
         }

         value -= value4 / value5;
      }

      return (float)this.sampleY(value);
   }

      private double sampleX(double t) {
      double value = 1 - t;
      return 3.0 * value * value * t * this.x1 + 3.0 * value * t * t * this.x2 + t * t * t;
   }

      private double sampleY(double t) {
      double value = 1 - t;
      return 3.0 * value * value * t * this.y1 + 3.0 * value * t * t * this.y2 + t * t * t;
   }

      private double sampleXDerivative(double t) {
      double value = 1 - t;
      return 3.0 * value * value * this.x1 + 6.0 * value * t * (this.x2 - this.x1) + 3.0 * t * t * (1F - this.x2);
   }

      public float getStartX() {
      return this.x1;
   }

      public float getStartY() {
      return this.y1;
   }

      public float getEndX() {
      return this.x2;
   }

      public float getEndY() {
      return this.y2;
   }

      public float getX1() {
      return this.x1;
   }

      public float getY1() {
      return this.y1;
   }

      public float getX2() {
      return this.x2;
   }

      public float getY2() {
      return this.y2;
   }

      public void setStart(float x, float y) {
      this.x1 = x;
      this.y1 = y;
   }

      public void setEnd(float x, float y) {
      this.x2 = x;
      this.y2 = y;
   }

      public float getDefaultX1() {
      return this.defaultX1;
   }

      public float getDefaultY1() {
      return this.defaultY1;
   }

      public float getDefaultX2() {
      return this.defaultX2;
   }

      public float getDefaultY2() {
      return this.defaultY2;
   }

      public boolean isDefaultValueSet() {
      return this.defaultValueSet;
   }

      public void setX1(float x1) {
      this.x1 = x1;
   }

      public void setY1(float y1) {
      this.y1 = y1;
   }

      public void setX2(float x2) {
      this.x2 = x2;
   }

      public void setY2(float y2) {
      this.y2 = y2;
   }

      public void setDefaultX1(float defaultX1) {
      this.defaultX1 = defaultX1;
   }

      public void setDefaultY1(float defaultY1) {
      this.defaultY1 = defaultY1;
   }

      public void setDefaultX2(float defaultX2) {
      this.defaultX2 = defaultX2;
   }

      public void setDefaultY2(float defaultY2) {
      this.defaultY2 = defaultY2;
   }

      public void setDefaultValueSet(boolean defaultValueSet) {
      this.defaultValueSet = defaultValueSet;
   }
}
