package winvi.noxiumvisuals.modules.settings;

import java.util.function.Supplier;
import winvi.noxiumvisuals.modules.ModuleSetting;
public class TextSetting extends ModuleSetting {
      private String text = "";
      private int minimumLength;
      private int maximumLength;
      private String defaultText = "";
      private boolean defaultTextSet = false;

   public TextSetting(String name, String description) {
      super(name, description);
   }

      public TextSetting visible(Supplier<Boolean> visible) {
      this.setVisible(visible);
      return this;
   }

      public TextSetting setText(String text) {
      if (!this.defaultTextSet) {
         this.defaultText = text;
         this.defaultTextSet = true;
      }

      this.text = text;
      return this;
   }

      public void reset() {
      if (this.defaultTextSet) {
         this.text = this.defaultText;
      }
   }

      public boolean isModified() {
      return !this.defaultTextSet ? false : !this.text.equals(this.defaultText);
   }

      public TextSetting setDefaultText() {
      this.defaultText = this.text;
      this.defaultTextSet = true;
      return this;
   }

      public String getText() {
      return this.text;
   }

      public int getMin() {
      return this.minimumLength;
   }

      public int getMax() {
      return this.maximumLength;
   }

      public String getDefaultText() {
      return this.defaultText;
   }

      public boolean isDefaultTextSet() {
      return this.defaultTextSet;
   }

      public TextSetting setMin(int min) {
      this.minimumLength = min;
      return this;
   }

      public TextSetting setMax(int max) {
      this.maximumLength = max;
      return this;
   }

      public TextSetting setDefaultText(String defaultText) {
      this.defaultText = defaultText;
      return this;
   }

      public TextSetting setDefaultTextSet(boolean defaultTextSet) {
      this.defaultTextSet = defaultTextSet;
      return this;
   }
}
