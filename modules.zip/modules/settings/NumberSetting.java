package winvi.noxiumvisuals.modules.settings;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;
import java.util.function.Function;
import java.util.function.Supplier;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
public class NumberSetting extends ModuleSetting {
      private float value;
      private float minimum;
      private float maximum;
      private boolean integer;
      private float defaultValue;
      private boolean defaultValueSet = false;
      private Function<Float, String> displayFormatter;

   public NumberSetting(String name, String description) {
      super(name, description);
   }

      public void setDefaultValue(float defaultValue) {
      this.defaultValue = defaultValue;
      this.defaultValueSet = true;
   }

      public void reset() {
      if (this.defaultValueSet) {
         this.value = this.defaultValue;
      }
   }

      public boolean isModified() {
      return !this.defaultValueSet ? false : this.value != this.defaultValue;
   }

      public NumberSetting range(float min, float max) {
      this.minimum = min;
      this.maximum = max;
      return this;
   }

      public NumberSetting range(int min, int max) {
      this.minimum = min;
      this.maximum = max;
      this.integer = true;
      return this;
   }

      public NumberSetting setValue(float value) {
      return this.updateValue(value, true);
   }

      public NumberSetting setValueSilently(float value) {
      return this.updateValue(value, false);
   }

      public NumberSetting displayFormatter(Function<Float, String> displayFormatter) {
      this.displayFormatter = displayFormatter;
      return this;
   }

      public String getDisplayValue(float value) {
      if (this.displayFormatter != null) {
         return this.displayFormatter.apply(value);
      } else {
         return this.integer
            ? String.valueOf(Math.round(value))
            : String.format(Locale.US, "%.2f", value);
      }
   }

      private NumberSetting updateValue(float value, boolean markDirty) {
      if (!this.defaultValueSet) {
         this.defaultValue = value;
         this.defaultValueSet = true;
      }

      float value2 = this.value;
      if (this.integer) {
         this.value = (int)value;
      } else {
         BigDecimal bigDecimal = BigDecimal.valueOf((double)value).setScale(2, RoundingMode.HALF_UP);
         this.value = bigDecimal.floatValue();
      }

      if (markDirty && value2 != this.value) {
         this.markConfigDirty();
      }

      return this;
   }

      private void markConfigDirty() {
      try {
         NoxiumVisuals noxiumVisuals = NoxiumVisuals.getInstance();
         if (noxiumVisuals != null && noxiumVisuals.getFileController() != null) {
            noxiumVisuals.getFileController().markDirty();
         }
      } catch (Exception exception) {
      }
   }

      public NumberSetting setDefaultValue() {
      this.defaultValue = this.value;
      this.defaultValueSet = true;
      return this;
   }

      public void setMin(float min) {
      this.minimum = min;
   }

      public void setMax(float max) {
      this.maximum = max;
   }

      public void setInteger(boolean integer) {
      this.integer = integer;
   }

      public int getInt() {
      return (int)this.value;
   }

      public NumberSetting visible(Supplier<Boolean> visible) {
      this.setVisible(visible);
      return this;
   }

      public float getValue() {
      return this.value;
   }

      public float getMin() {
      return this.minimum;
   }

      public float getMax() {
      return this.maximum;
   }

      public boolean isInteger() {
      return this.integer;
   }

      public float getDefaultValue() {
      return this.defaultValue;
   }

      public boolean isDefaultValueSet() {
      return this.defaultValueSet;
   }

      public Function<Float, String> getDisplayFormatter() {
      return this.displayFormatter;
   }

}
