package winvi.noxiumvisuals.modules.settings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
public class MultiSelectSetting extends ModuleSetting {
      private List<String> values;
      private List<String> selected = new ArrayList<>();
      private Consumer<List<String>> onChange;
      private Function<String, String> displayFormatter;
      private final List<String> defaultSelected = new ArrayList<>();

   public MultiSelectSetting(String name, String description) {
      super(name, description);
   }

      public MultiSelectSetting value(String... settings) {
      this.values = Arrays.asList(settings);
      return this;
   }

      public MultiSelectSetting visible(Supplier<Boolean> visible) {
      this.setVisible(visible);
      return this;
   }

      public boolean isSelected(String name) {
      return this.selected.contains(name);
   }

      public MultiSelectSetting selected(String... settings) {
      this.selected.clear();
      this.selected.addAll(Arrays.asList(settings));
      if (this.defaultSelected.isEmpty()) {
         this.defaultSelected.addAll(Arrays.asList(settings));
      }

      return this;
   }

      public MultiSelectSetting onChange(Consumer<List<String>> onChange) {
      this.onChange = onChange;
      return this;
   }

      public MultiSelectSetting displayFormatter(Function<String, String> formatter) {
      this.displayFormatter = formatter;
      return this;
   }

      public void setSelected(List<String> selected) {
      ArrayList arrayList = new ArrayList<>(this.selected);
      this.selected = selected;
      if (!arrayList.equals(selected)) {
         this.retainKnownValues();
      }

      if (this.onChange != null) {
         this.onChange.accept(selected);
      }
   }

      private void retainKnownValues() {
      try {
         NoxiumVisuals noxiumVisuals = NoxiumVisuals.getInstance();
         if (noxiumVisuals != null && noxiumVisuals.getFileController() != null) {
            noxiumVisuals.getFileController().markDirty();
         }
      } catch (Exception exception) {
      }
   }

      public void reset() {
      if (!this.defaultSelected.isEmpty()) {
         this.selected.clear();
         this.selected.addAll(this.defaultSelected);
      }
   }

      public boolean isModified() {
      if (this.defaultSelected.isEmpty()) {
         return false;
      } else {
         return this.selected.size() != this.defaultSelected.size() ? true : !this.selected.containsAll(this.defaultSelected);
      }
   }

      public String getDisplayValue(String value) {
      try {
         return this.displayFormatter != null ? this.displayFormatter.apply(value) : this.normalizeValue(value);
      } catch (Exception exception) {
         return value;
      }
   }

      private String normalizeValue(String value) {
      return this.getLocalizedOption(value);
   }

      public List<String> getList() {
      return this.values;
   }

      public List<String> getSelected() {
      return this.selected;
   }

      public Consumer<List<String>> getOnChange() {
      return this.onChange;
   }

      public Function<String, String> getDisplayFormatter() {
      return this.displayFormatter;
   }

      public List<String> getDefaultSelected() {
      return this.defaultSelected;
   }

      public void setList(List<String> list) {
      this.values = list;
   }

      public void setOnChange(Consumer<List<String>> onChange) {
      this.onChange = onChange;
   }

      public void setDisplayFormatter(Function<String, String> displayFormatter) {
      this.displayFormatter = displayFormatter;
   }
}
