package winvi.noxiumvisuals.modules.settings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;
import winvi.noxiumvisuals.modules.ModuleSetting;
public class SettingGroup extends ModuleSetting {
      private boolean value;
      private List<ModuleSetting> subSettings = new ArrayList<>();
      private boolean defaultValue;
      private boolean defaultValueSet = false;

   public SettingGroup(String name, String description) {
      super(name, description);
   }

      public SettingGroup settings(ModuleSetting... setting) {
      this.subSettings.addAll(Arrays.asList(setting));
      return this;
   }

      public SettingGroup setValue(boolean value) {
      if (!this.defaultValueSet) {
         this.defaultValue = value;
         this.defaultValueSet = true;
      }

      this.value = value;
      return this;
   }

      public SettingGroup setDefaultValue() {
      this.defaultValue = this.value;
      this.defaultValueSet = true;
      return this;
   }

      public void reset() {
      if (this.defaultValueSet) {
         this.value = this.defaultValue;
      }
   }

      public boolean isModified() {
      return !this.defaultValueSet ? false : this.value != this.defaultValue;
   }

      public SettingGroup visible(Supplier<Boolean> visible) {
      this.setVisible(visible);
      return this;
   }

      public ModuleSetting getSubSetting(String name) {
      for (int index = 0; index < this.subSettings.size(); index++) {
         ModuleSetting moduleProvider3 = this.subSettings.get(index);
         if (moduleProvider3.getName().equalsIgnoreCase(name)) {
            return moduleProvider3;
         }
      }

      return null;
   }

      public boolean isValue() {
      return this.value;
   }

      public List<ModuleSetting> getSubSettings() {
      return this.subSettings;
   }

      public boolean isDefaultValue() {
      return this.defaultValue;
   }

      public boolean isDefaultValueSet() {
      return this.defaultValueSet;
   }

      public SettingGroup setSubSettings(List<ModuleSetting> subSettings) {
      this.subSettings = subSettings;
      return this;
   }

      public SettingGroup setDefaultValue(boolean defaultValue) {
      this.defaultValue = defaultValue;
      return this;
   }

      public SettingGroup setDefaultValueSet(boolean defaultValueSet) {
      this.defaultValueSet = defaultValueSet;
      return this;
   }

}
