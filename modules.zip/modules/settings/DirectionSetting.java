package winvi.noxiumvisuals.modules.settings;

import java.util.function.Supplier;
import winvi.noxiumvisuals.modules.ModuleSetting;
public class DirectionSetting extends ModuleSetting {
      private float x = 0F;
      private float z = 0F;
      private float defaultX = 0F;
      private float defaultZ = 0F;
      private final float maximumDistance = 1F;
      private boolean enabled = false;

   public DirectionSetting(String name, String description) {
      super(name, description);
   }

      public DirectionSetting setValue(float x, float z) {
      this.x = this.clampDirection(x);
      this.z = this.clampDirection(z);
      this.defaultX = x;
      this.defaultZ = z;
      return this;
   }

      public DirectionSetting maxDistance(float distance) {
      return this;
   }

      public void setDirection(float x, float z) {
      float value = (float)Math.sqrt(x * x + z * z);
      if (value > this.maximumDistance) {
         float value2 = this.maximumDistance / value;
         x *= value2;
         z *= value2;
      }

      this.x = this.clampDirection(x);
      this.z = this.clampDirection(z);
   }

      private float clampDirection(float value) {
      return Math.max(-this.maximumDistance, Math.min(this.maximumDistance, value));
   }

      public float getX() {
      return this.x;
   }

      public float getZ() {
      return this.z;
   }

      public float getMaxDistance() {
      return this.maximumDistance;
   }

      public void reset() {
      this.x = this.defaultX;
      this.z = this.defaultZ;
   }

      public boolean isModified() {
      return this.x != this.defaultX || this.z != this.defaultZ;
   }

      public boolean isEnabled() {
      return this.enabled;
   }

      public void setEnabled(boolean enabled) {
      this.enabled = enabled;
   }

      public void toggleEnabled() {
      this.enabled = !this.enabled;
   }

      public DirectionSetting visible(Supplier<Boolean> visible) {
      this.setVisible(visible);
      return this;
   }

}
