package winvi.noxiumvisuals.modules.settings;

import java.util.function.Supplier;
import winvi.noxiumvisuals.modules.ModuleSetting;
public class KeybindSetting extends ModuleSetting {
      private int key = -1;
      private int defaultKey = -1;
      private boolean defaultKeySet = false;

   public KeybindSetting(String name, String description) {
      super(name, description);
      this.defaultKey = -1;
      this.defaultKeySet = true;
   }

      public KeybindSetting visible(Supplier<Boolean> visible) {
      this.setVisible(visible);
      return this;
   }

      public KeybindSetting setKey(int key) {
      if (!this.defaultKeySet) {
         this.defaultKey = key;
         this.defaultKeySet = true;
      }

      this.key = key;
      return this;
   }

      public void reset() {
      if (this.defaultKeySet) {
         this.key = this.defaultKey;
      }
   }

      public boolean isModified() {
      return !this.defaultKeySet ? false : this.key != this.defaultKey;
   }

      public KeybindSetting setDefaultKey() {
      this.defaultKey = this.key;
      this.defaultKeySet = true;
      return this;
   }

      public int getKey() {
      return this.key;
   }

      public int getDefaultKey() {
      return this.defaultKey;
   }

      public boolean isDefaultKeySet() {
      return this.defaultKeySet;
   }

      public KeybindSetting setDefaultKey(int defaultKey) {
      this.defaultKey = defaultKey;
      return this;
   }

      public KeybindSetting setDefaultKeySet(boolean defaultKeySet) {
      this.defaultKeySet = defaultKeySet;
      return this;
   }
}
