package winvi.noxiumvisuals.modules;

public enum ModuleCategory {
      VISUAL("Visual"),
      WORLD("World"),
      PARTICLES("Particles"),
      UTILS("Utils"),
      CLIENT("Client"),
      MANAGER("Manager");

      final String readableName;

   private ModuleCategory(final String readableName) {
      this.readableName = readableName;
   }

      public String getReadableName() {
      return this.readableName;
   }

}
