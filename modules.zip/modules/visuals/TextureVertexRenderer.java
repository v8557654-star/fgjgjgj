package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory.Context;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import winvi.noxiumvisuals.modules.visuals.PetsModule;
public class TextureVertexRenderer extends EntityRenderer<ParticleEntityFactory, EntityRenderRenderer> {
      private static final Identifier evr = PetsModule.DOG_TEXTURE;
      private final TaksaPetModel runField55 = new TaksaPetModel();

   public TextureVertexRenderer(Context context) {
      super(context);
   }

      public void render(EntityRenderRenderer state, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
      if (state.dogEntity != null) {
         matrices.push();
         matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-state.dogEntity.getBodyYaw() + 180.0F));
         matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180.0F));
         double value = state.dogEntity.isLaying() ? -1F : -1.35F;
         matrices.translate(0, value, 0);
         matrices.scale(1F, 1F, 1F);
         float value2 = state.dogEntity.age + state.age;
         this.runField55.setRotationAngles(value2, state.dogEntity);
         Identifier identifier = PetsModule.getInstance() != null ? PetsModule.getInstance().getDogTexture() : evr;
         RenderLayer renderLayer = this.runField55.getLayer(identifier);
         this.runField55.render(matrices, vertexConsumers.getBuffer(renderLayer), light, OverlayTexture.DEFAULT_UV);
         matrices.pop();
         super.render(state, matrices, vertexConsumers, light);
      }
   }

      public EntityRenderRenderer createRenderState() {
      return new EntityRenderRenderer();
   }

      public void updateRenderState(ParticleEntityFactory entity, EntityRenderRenderer state, float tickDelta) {
      super.updateRenderState(entity, state, tickDelta);
      state.dogEntity = entity;
   }

}
