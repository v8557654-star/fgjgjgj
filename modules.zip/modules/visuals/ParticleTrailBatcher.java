package winvi.noxiumvisuals.modules.visuals;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.particles.ParticleTrailModule;
import winvi.noxiumvisuals.utils.MatrixEntityProvider;
import winvi.noxiumvisuals.utils.render.WorldParticleBatcher;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public class ParticleTrailBatcher {
      private static final MinecraftClient computeField81 = MinecraftClient.getInstance();
      private static final List<MatrixTrailSupport> dudo = new ArrayList<>(8);
      private static final MatrixStack duep = new MatrixStack();
      private static final float mvwyk = 1.3888888F;
      private static int addField47;

      public static void queueKagune(MatrixStack stack, List<ColorEntityManager> trails) {
      if (!trails.isEmpty()) {
         MatrixTrailSupport matrixTrailSupport;
         if (addField47 < dudo.size()) {
            matrixTrailSupport = dudo.get(addField47);
         } else {
            matrixTrailSupport = new MatrixTrailSupport();
            dudo.add(matrixTrailSupport);
         }

         matrixTrailSupport.dyvp(MatrixEntityProvider.acquire(stack.peek().getPositionMatrix()), trails);
         addField47++;
      }
   }

      public static void renderBatches(float tickDelta) {
      if (addField47 > 0) {
         ysqyez(tickDelta);
      }
   }

   // $VF: Could not verify finally blocks. A semaphore variable has been added to preserve control flow.
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      private static void ysqyez(float tickDelta) {
      int index = addField47;
      addField47 = 0;
      Camera camera = computeField81.gameRenderer.getCamera();
      List list = ParticleTrailModule.kaguneTextures.getSelected();
      if (list.isEmpty()) {
         list = List.of("Bloom");
      }

      int index2 = 0;
      boolean enabled = false /* VF: Semaphore variable */;

      try {
         enabled = true;

         for (int index3 = 0; index3 < index; index3++) {
            MatrixTrailSupport matrixTrailSupport = dudo.get(index3);
            Matrix4f matrix = matrixTrailSupport.hasField750;
            List list2 = matrixTrailSupport.validateField15;
            boolean enabled2 = ParticleTrailModule.trailStyle.getSelected().equals("Trails");
            String text = (String)list.get(index2 % list.size());
            index2++;
            Identifier identifier = ParticleTextures.getParticleTexture(text);
            if (list2.size() < 2) {
               if (!list2.isEmpty()) {
                  manageMethod680(identifier, matrix, camera, (ColorEntityManager)list2.get(0), enabled2);
               }
            } else {
               for (int index4 = 0; index4 < list2.size(); index4++) {
                  ColorEntityManager colorEntityManager = (ColorEntityManager)list2.get(index4);
                  manageMethod680(identifier, matrix, camera, colorEntityManager, enabled2);
                  if (index4 < list2.size() - 1 && !enabled2) {
                     ColorEntityManager colorEntityManager2 = (ColorEntityManager)list2.get(index4 + 1);
                     double value = colorEntityManager.currentPos.distanceTo(colorEntityManager2.currentPos);
                     if (value > 0.05) {
                        int index5 = Math.min(1, (int)(value * 5.0));

                        for (int index6 = 1; index6 <= index5; index6++) {
                           float value2 = (float)index6 / (index5 + 1);
                           double value3 = MathHelper.lerp(value2, colorEntityManager.currentPos.x, colorEntityManager2.currentPos.x);
                           double value4 = MathHelper.lerp(value2, colorEntityManager.currentPos.y, colorEntityManager2.currentPos.y);
                           double value5 = MathHelper.lerp(value2, colorEntityManager.currentPos.z, colorEntityManager2.currentPos.z);
                           float value6 = MathHelper.lerp(value2, colorEntityManager.getAlpha(), colorEntityManager2.getAlpha());
                           float value7 = MathHelper.lerp(value2, colorEntityManager.getProgress(), colorEntityManager2.getProgress());
                           int color2 = colorEntityManager.color().getRGB();
                           stopMethod0(identifier, matrix, camera, value3, value4, value5, value6, value7, false, color2);
                        }
                     }
                  }
               }
            }
         }

         enabled = false;
      } finally {
         if (enabled) {
            for (int index7 = 0; index7 < index; index7++) {
               MatrixTrailSupport matrixTrailSupport2 = dudo.get(index7);
               MatrixEntityProvider.release(matrixTrailSupport2.hasField750);
               matrixTrailSupport2.yqszze();
            }
         }
      }

      for (int index8 = 0; index8 < index; index8++) {
         MatrixTrailSupport matrixTrailSupport3 = dudo.get(index8);
         MatrixEntityProvider.release(matrixTrailSupport3.hasField750);
         matrixTrailSupport3.yqszze();
      }
   }

      private static void manageMethod680(Identifier texture, Matrix4f baseMatrix, Camera camera, ColorEntityManager segment, boolean isTrailsStyle) {
      Vec3d position = segment.currentPos;
      float value = segment.getAlpha();
      float value2 = segment.getProgress();
      stopMethod0(texture, baseMatrix, camera, position.x, position.y, position.z, value, value2, isTrailsStyle, segment.color().getRGB());
   }

      private static void stopMethod0(
      Identifier texture,
      Matrix4f baseMatrix,
      Camera camera,
      double posX,
      double posY,
      double posZ,
      float alpha,
      float progress,
      boolean isTrailsStyle,
      int baseColor
   ) {
      if (!(alpha <= 0F)) {
         int index = runMethod16(progress, baseColor);
         duep.loadIdentity();
         duep.peek().getPositionMatrix().set(baseMatrix);
         duep.translate(posX, posY + 0.8999999761581421, posZ);
         duep.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
         duep.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
         duep.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180.0F));
         float value = isTrailsStyle ? ParticleTrailModule.trailsStripSize.getValue() : ParticleTrailModule.kaguneSize.getValue();
         if (!(value <= 0F)) {
            Matrix4f matrix = MatrixEntityProvider.acquire(duep.peek().getPositionMatrix());
            WorldParticleBatcher.queueOwnedGhostParticle(matrix, texture, value * 2.0F, Math.min(1F, alpha * 1.3888888F), index, false, null);
         }
      }
   }

      private static int runMethod16(float progress, int baseColor) {
      float value = (1F - progress) * (1F - progress);
      int index = baseColor >> 16 & 0xFF;
      int index2 = baseColor >> 8 & 0xFF;
      int index3 = baseColor & 0xFF;
      index = (int)(index + (255 - index) * value);
      index2 = (int)(index2 + (255 - index2) * value);
      index3 = (int)(index3 + (255 - index3) * value);
      return index << 16 | index2 << 8 | index3;
   }

}
