package winvi.noxiumvisuals.modules.visuals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
public final class ColorItemStackManager {
      private static final List<ColorModuleProvider> nz = new ArrayList<>();
      private static final Map<String, ColorModuleProvider> yrroq = new HashMap<>();
      private static final Set<String> dob = new HashSet<>();

      public static List<ColorModuleProvider> getPresets() {
      return nz;
   }

      public static void addPreset(String query, int color) {
      String text = convertMethod42(query);
      if (!text.isEmpty()) {
         ColorModuleProvider colorModuleProvider = findPreset(text);
         if (colorModuleProvider != null) {
            colorModuleProvider.setQuery(text);
            colorModuleProvider.setColor(color);
            manageMethod70();
         } else {
            nz.add(new ColorModuleProvider(text, color));
            manageMethod70();
         }
      }
   }

      public static void addPresetAndSave(String query, int color) {
      addPreset(query, color);
      ColorConfigRenderer.getInstance().save();
   }

      public static void removePreset(ColorModuleProvider preset) {
      if (preset != null) {
         nz.remove(preset);
         manageMethod70();
      }
   }

      public static void removePresetAndSave(ColorModuleProvider preset) {
      removePreset(preset);
      ColorConfigRenderer.getInstance().save();
   }

      public static ColorModuleProvider findPreset(String query) {
      String text = zbrbuq(query);
      if (text.isEmpty()) {
         return null;
      } else {
         for (ColorModuleProvider colorModuleProvider : nz) {
            if (zbrbuq(colorModuleProvider.getQuery()).equals(text)) {
               return colorModuleProvider;
            }
         }

         return null;
      }
   }

      public static ColorModuleProvider findMatchingPreset(ItemStack stack) {
      if (stack != null && !stack.isEmpty()) {
         String name = zbrbuq(stack.getName().getString());
         String name2 = zbrbuq(stack.getItem().getName().getString());
         String text = zbrbuq(Registries.ITEM.getId(stack.getItem()).getPath());
         String text2 = text + "|" + name2 + "|" + name;
         if (dob.contains(text2)) {
            return null;
         } else {
            ColorModuleProvider colorModuleProvider = yrroq.get(text2);
            if (colorModuleProvider != null) {
               return colorModuleProvider;
            } else {
               for (ColorModuleProvider colorModuleProvider2 : nz) {
                  String text3 = zbrbuq(colorModuleProvider2.getQuery());
                  if (!text3.isEmpty() && (name.contains(text3) || name2.contains(text3) || text.contains(text3))) {
                     yrroq.put(text2, colorModuleProvider2);
                     return colorModuleProvider2;
                  }
               }

               dob.add(text2);
               return null;
            }
         }
      } else {
         return null;
      }
   }

      public static void setPresets(List<ColorModuleProvider> newPresets) {
      nz.clear();
      manageMethod70();
      if (newPresets != null) {
         for (ColorModuleProvider colorModuleProvider : newPresets) {
            if (colorModuleProvider != null) {
               String text = convertMethod42(colorModuleProvider.getQuery());
               if (!text.isEmpty()) {
                  ColorModuleProvider colorModuleProvider2 = findPreset(text);
                  if (colorModuleProvider2 != null) {
                     colorModuleProvider2.setQuery(text);
                     colorModuleProvider2.setColor(colorModuleProvider.getColor());
                  } else {
                     nz.add(new ColorModuleProvider(text, colorModuleProvider.getColor()));
                  }
               }
            }
         }
      }
   }

      private static void manageMethod70() {
      yrroq.clear();
      dob.clear();
   }

      private static String convertMethod42(String query) {
      return query == null ? "" : query.trim();
   }

      private static String zbrbuq(String value) {
      return value == null ? "" : value.toLowerCase(Locale.ROOT).trim();
   }

   private ColorItemStackManager() {
      throw new UnsupportedOperationException(
         "This is a utility class and cannot be instantiated"
      );
   }

   static {
      int index = 0;
   }
}
