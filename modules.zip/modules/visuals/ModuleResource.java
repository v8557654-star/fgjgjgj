package winvi.noxiumvisuals.modules.visuals;

import java.util.List;
import net.minecraft.util.math.Vec3d;
public record ModuleResource(
   Vec3d impact,
   List<Vec3d> path
) {

      public Vec3d impact() {
      return this.impact;
   }

      public List<Vec3d> path() {
      return this.path;
   }

}
