package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL30;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.TorusPulse;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
import winvi.noxiumvisuals.utils.render.TorusReflectionShader;
import winvi.noxiumvisuals.utils.render.ShaderFramebufferRegistry;
public final class TorusModule extends Module {
      private static final int ibwwb = 10;
      private static final int euo = 30;
      private final BooleanSetting wyzpt;
      private final NumberSetting yuudq;
      private final NumberSetting ur;
      private final NumberSetting calculateField64;
      private final List<TorusPulse> aoflf;
      private SimpleFramebuffer removeField65;
      private long v30;
      private int startField87;

   public TorusModule() {
      super("Torus", ModuleCategory.VISUAL);
      this.wyzpt = new BooleanSetting(
            "Transparent",
            "Render the torus without the visual color tint"
         )
         .setValue(false);
      this.yuudq = new NumberSetting(
            "Noise",
            "Reflection distortion strength"
         )
         .setValue(45.0F)
         .range(0F, 100.0F);
      this.ur = new NumberSetting(
            "Life Time",
            "Torus lifetime in milliseconds"
         )
         .setValue(1000.0F)
         .range(500.0F, 5000.0F);
      this.calculateField64 = new NumberSetting(
            "Size",
            "Torus scale"
         )
         .setValue(0.5F)
         .range(0.2F, 2.0F);
      this.aoflf = new ArrayList<>();
      this.startField87 = -2147483648;
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{this.wyzpt, this.yuudq, this.ur, this.calculateField64});
   }

      @Override
   public void deactivate() {
      super.deactivate();
      this.aoflf.clear();
      if (this.removeField65 != null) {
         this.removeField65.delete();
         this.removeField65 = null;
      }
   }

      public static void onHit(Entity entity) {
      NoxiumVisuals noxiumVisuals = NoxiumVisuals.getInstance();
      if (entity != null && noxiumVisuals != null && noxiumVisuals.getModuleProvider() != null) {
         TorusModule torusModule = noxiumVisuals.getModuleProvider().get(TorusModule.class);
         if (torusModule != null && torusModule.isState()) {
            torusModule.gd0(entity);
         }
      }
   }

      private void gd0(Entity entity) {
      if (MinecraftClient.getInstance().player != null && entity != MinecraftClient.getInstance().player && EntityVisibilityFilter.shouldRender(entity)) {
         long timestamp = System.currentTimeMillis();
         if (entity.getId() != this.startField87 || timestamp - this.v30 >= 300L) {
            Vec3d position = entity.getEyePos();
            if (MinecraftClient.getInstance().crosshairTarget instanceof EntityHitResult entityHitResult && entityHitResult.getEntity() == entity) {
               position = entityHitResult.getPos();
            }

            Vec3d client = position.subtract(MinecraftClient.getInstance().player.getEyePos()).normalize();
            float value = (float)Math.toDegrees(Math.atan2(client.z, client.x)) - 90.0F;
            float value2 = (float)(-Math.toDegrees(Math.asin(client.y)));
            this.aoflf.add(new TorusPulse(position, value, value2, this.ur.getValue(), this.calculateField64.getValue()));
            this.v30 = timestamp;
            this.startField87 = entity.getId();
         }
      }
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState() && !this.aoflf.isEmpty() && MinecraftClient.getInstance().getFramebuffer() != null) {
         long timestamp = System.currentTimeMillis();
         Iterator iterator2 = this.aoflf.iterator();

         while (iterator2.hasNext()) {
            if (((TorusPulse)iterator2.next()).g31(timestamp)) {
               iterator2.remove();
            }
         }

         if (!this.aoflf.isEmpty()) {
            this.convertMethod53(event, timestamp);
         }
      }
   }

      private void convertMethod53(VertexMatrixRenderer event, long now) {
      ShaderFramebufferRegistry.initShadersIfNeeded();
      if (ShaderFramebufferRegistry.isInitialized()) {
         TorusReflectionShader matrixColorRenderer16 = ShaderFramebufferRegistry.getTorusReflectionShader();
         Framebuffer client = MinecraftClient.getInstance().getFramebuffer();
         SimpleFramebuffer simpleFramebuffer = this.dgfl(client);
         if (simpleFramebuffer != null && matrixColorRenderer16 != null) {
            try {
               dgh(client, simpleFramebuffer);
               client.beginWrite(false);
               RenderSystem.enableDepthTest();
               RenderSystem.enableBlend();
               RenderSystem.defaultBlendFunc();
               RenderSystem.disableCull();
               RenderSystem.depthMask(false);
               RenderSystem.activeTexture(33984);
               RenderSystem.bindTexture(simpleFramebuffer.getColorAttachment());
               Matrix4f matrix = RenderSystem.getProjectionMatrix();
               Matrix4f matrix2 = event.getStack().peek().getPositionMatrix();

               for (TorusPulse moduleSupport3 : this.aoflf) {
                  float value = moduleSupport3.sicozm(now);
                  Matrix4f matrix3 = gg0(matrix2, moduleSupport3);
                  matrixColorRenderer16.setup(
                     matrix3,
                     matrix,
                     this.yuudq.getValue() / 100.0F,
                     MinecraftClient.getInstance().gameRenderer.getCamera().getPos(),
                     this.getVisualColor(),
                     this.wyzpt.isValue() ? 0F : 0.68F
                  );
                  dgi(moduleSupport3.executeMethod990(value), moduleSupport3.deleteMethod380(value));
               }

               matrixColorRenderer16.unbind();
            } catch (Throwable throwable) {
               client.beginWrite(false);
            } finally {
               matrixColorRenderer16.unbind();
               client.beginWrite(false);
               RenderSystem.bindTexture(0);
               RenderSystem.defaultBlendFunc();
               RenderSystem.depthMask(true);
               RenderSystem.enableCull();
               RenderSystem.enableDepthTest();
            }
         }
      }
   }

      private SimpleFramebuffer dgfl(Framebuffer main) {
      int width = Math.max(1, main.textureWidth);
      int height = Math.max(1, main.textureHeight);
      if (this.removeField65 != null && (this.removeField65.textureWidth != width || this.removeField65.textureHeight != height)) {
         this.removeField65.delete();
         this.removeField65 = null;
      }

      if (this.removeField65 == null) {
         this.removeField65 = new SimpleFramebuffer(width, height, false);
         this.removeField65.setClearColor(0F, 0F, 0F, 0F);
      }

      return this.removeField65;
   }

      private static Matrix4f gg0(Matrix4f baseMatrix, TorusPulse effect) {
      return new Matrix4f(baseMatrix)
         .translate((float)effect.gjds.x, (float)effect.gjds.y, (float)effect.gjds.z)
         .rotate(RotationAxis.POSITIVE_Y.rotationDegrees(-effect.je))
         .rotate(RotationAxis.POSITIVE_X.rotationDegrees(effect.naxat));
   }

      private static void dgh(Framebuffer source, SimpleFramebuffer target) {
      GlStateManager._glBindFramebuffer(36008, source.fbo);
      GlStateManager._glBindFramebuffer(36009, target.fbo);
      GL30.glBlitFramebuffer(0, 0, source.textureWidth, source.textureHeight, 0, 0, target.textureWidth, target.textureHeight, 16384, 9728);
   }

      private static void dgi(float outerRadius, float innerRadius) {
      BufferBuilder bufferBuilder = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.LINES);

      for (int index = 0; index < 10; index++) {
         double value = 6.283185307179586 * index / 10.0;
         double value2 = 6.283185307179586 * (index + 1) / 10.0;

         for (int index2 = 0; index2 < 30; index2++) {
            double value3 = 6.283185307179586 * index2 / 30.0;
            double value4 = 6.283185307179586 * (index2 + 1) / 30.0;
            xjrxdl(bufferBuilder, outerRadius, innerRadius, value, value3);
            xjrxdl(bufferBuilder, outerRadius, innerRadius, value2, value3);
            xjrxdl(bufferBuilder, outerRadius, innerRadius, value2, value4);
            xjrxdl(bufferBuilder, outerRadius, innerRadius, value, value4);
         }
      }

      BufferRenderer.draw(bufferBuilder.end());
   }

      private static void xjrxdl(BufferBuilder buffer, float outerRadius, float innerRadius, double theta, double phi) {
      float value = (float)Math.cos(theta);
      float value2 = (float)Math.sin(theta);
      float value3 = (float)Math.cos(phi);
      float value4 = (float)Math.sin(phi);
      float value5 = (outerRadius + innerRadius * value) * value3;
      float value6 = (outerRadius + innerRadius * value) * value4;
      float value7 = innerRadius * value2;
      buffer.vertex(value5, value6, value7).color(255, 255, 255, 255).normal(value * value3, value * value4, value2);
   }

   static {
      int index = 0;
   }
}
