package winvi.noxiumvisuals.modules.visuals;

import java.awt.Color;
import java.util.Arrays;
import net.minecraft.block.AirBlock;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.shape.VoxelShape;
import winvi.noxiumvisuals.modules.particles.ExperienceParticleModule;
import winvi.noxiumvisuals.utils.ClientPosition;
import winvi.noxiumvisuals.utils.ParticleInstance;
import winvi.noxiumvisuals.utils.ParticlePhysics;
import winvi.noxiumvisuals.utils.render.WorldParticleBatcher;
import winvi.noxiumvisuals.utils.ParticleCameraRenderer;
import winvi.noxiumvisuals.utils.render.RenderMath;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public class MatrixColorRenderer extends ParticleInstance {
      private final ExperienceParticleModule stopField24;
      private final long fh0;
      private final long oyckg;
      private final Identifier j32;
      private final int[] formatField75;
      private final float formatField88;
      private final float getField88;
      private float transformField47;
      private final float executeField74;

   public MatrixColorRenderer(float x, float y, float z, float rotationAngle, float rotationSpeed, ExperienceParticleModule module) {
      super(x, y, z);
      this.stopField24 = module;
      this.fh0 = System.currentTimeMillis();
      this.oyckg = 2000L;
      this.transformField47 = rotationAngle;
      this.executeField74 = rotationSpeed;
      this.formatField88 = 0.55F + (module.updateField38.getValue() - 1F) / 4.0F * 1.1F;
      this.getField88 = module.initField63.getValue();
      String text = module.handleField751.getSelected();
      boolean enabled = text.equals("BOUNCE");
      float value = RenderMath.random(0.018F, 0.05F);
      this.motionX = RenderMath.random(-value, value);
      this.motionY = enabled ? RenderMath.random(0.012F, 0.05F) : RenderMath.random(0.004F, 0.03F);
      this.motionZ = RenderMath.random(-value, value);
      if (!ExperienceParticleModule.computeField47.isEmpty()) {
         this.j32 = ExperienceParticleModule.computeField47.get(ExperienceParticleModule.createField8.nextInt(ExperienceParticleModule.computeField47.size()));
      } else {
         this.j32 = ParticleTextures.BLOOM;
      }

      this.formatField75 = module.dsf.isValue() ? asmafd() : dyeh(module.getVisualColor());
   }

      @Override
   public boolean update(long currentTime, boolean isVisible) {
      this.px = this.x;
      this.py = this.y;
      this.pz = this.z;
      boolean enabled = this.stopField24.handleField751.getSelected().equals("BOUNCE");
      ClientPosition clientPosition = enabled
         ? ParticlePhysics.bounce(this.x, this.y, this.z, this.motionX, this.motionY, this.motionZ, this.formatField88, 0.0016F)
         : ParticlePhysics.drift(this.x, this.y, this.z, this.motionX, this.motionY, this.motionZ, this.formatField88, -2.5E-4F);
      this.x = clientPosition.x();
      this.y = clientPosition.y();
      this.z = clientPosition.z();
      this.motionX = clientPosition.motionX();
      this.motionY = clientPosition.motionY();
      this.motionZ = clientPosition.motionZ();
      float value = this.z33(currentTime);
      return value >= 1F;
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (this.stopField24.isState()) {
         float value = this.z33(System.currentTimeMillis());
         value = MathHelper.clamp(value, 0F, 1F);
         float value2 = 1F;
         float value3 = this.getField88;
         if (value < 0.12F) {
            value2 = value / 0.12F;
         }

         if (value >= 0.75F) {
            float value4 = 1F - (value - 0.75F) / 0.25F;
            if (this.stopField24.removeField300.getSelected().equals("ALPHA")) {
               value2 *= value4;
            } else {
               value3 *= value4;
            }
         }

         if (!(value2 <= 0F) && !(value3 <= 0F)) {
            float value5 = 0.07F;
            if (ParticleCameraRenderer.isParticleVisible(this.getX(), this.getY(), this.getZ(), value3 * value5)) {
               MinecraftClient client = MinecraftClient.getInstance();
               double value6 = MathHelper.lerp(tickDelta, this.px, this.x);
               double value7 = MathHelper.lerp(tickDelta, this.py, this.y);
               double value8 = MathHelper.lerp(tickDelta, this.pz, this.z);
               matrixStack.push();
               matrixStack.translate(value6, value7, value8);
               matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-client.gameRenderer.getCamera().getYaw()));
               matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.gameRenderer.getCamera().getPitch()));
               int index = Math.max(30, client.getCurrentFps());
               this.transformField47 = this.transformField47 + 1F / index * this.executeField74;
               matrixStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(this.transformField47));
               WorldParticleBatcher.queueGhostParticle(matrixStack, this.j32, value5 * value3, value2, this.formatField75[0], true, this.formatField75);
               matrixStack.pop();
            }
         }
      }
   }

      private float z33(long currentTime) {
      return Math.min(1F, (float)(currentTime - this.fh0) / (float)this.oyckg);
   }

      private float jmmidi() {
      return 0.03F + this.getField88 * 0.012F;
   }

      private boolean createMethod20(double x, double y, double z, float radius) {
      return this.c35(x, y, z)
         || this.c35(x + radius, y, z)
         || this.c35(x - radius, y, z)
         || this.c35(x, y, z + radius)
         || this.c35(x, y, z - radius)
         || this.c35(x, y + radius, z)
         || this.c35(x, y - radius, z);
   }

      private boolean c35(double x, double y, double z) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null && client.world != null) {
         BlockPos blockPos = BlockPos.ofFloored(x, y, z);
         BlockState blockState = client.world.getBlockState(blockPos);
         if (!(blockState.getBlock() instanceof AirBlock) && !blockState.isAir()) {
            VoxelShape voxelShape = blockState.getCollisionShape(client.world, blockPos);
            return !voxelShape.isEmpty();
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

      private static int[] asmafd() {
      float value = ExperienceParticleModule.createField8.nextFloat();
      float value2 = 0.82F + ExperienceParticleModule.createField8.nextFloat() * 0.28F;
      return new int[]{
         ojeopd(dyf(new Color(9961355), new Color(4125095), value), value2),
         ojeopd(dyf(new Color(6160298), new Color(6750180), value), value2),
         ojeopd(dyf(new Color(7995360), new Color(10813394), value), value2),
         ojeopd(dyf(new Color(12058522), new Color(6553552), value), value2)
      };
   }

      private static int[] dyeh(int color) {
      int[] intArray = new int[4];
      Arrays.fill(intArray, color);
      return intArray;
   }

      private static Color dyf(Color start, Color end, float progress) {
      float value = MathHelper.clamp(progress, 0F, 1F);
      int index = (int)(start.getRed() + (end.getRed() - start.getRed()) * value);
      int index2 = (int)(start.getGreen() + (end.getGreen() - start.getGreen()) * value);
      int index3 = (int)(start.getBlue() + (end.getBlue() - start.getBlue()) * value);
      return new Color(index, index2, index3);
   }

      private static int ojeopd(Color color, float brightness) {
      float value = MathHelper.clamp(brightness, 0F, 1.35F);
      int index = Math.min(255, Math.round(color.getRed() * value));
      int index2 = Math.min(255, Math.round(color.getGreen() * value));
      int index3 = Math.min(255, Math.round(color.getBlue() * value));
      return new Color(index, index2, index3).getRGB();
   }

}
