package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.client.render.entity.state.EntityRenderState;
public class EntityRenderRenderer extends EntityRenderState {
      public ParticleEntityFactory dogEntity;

   static {
      int index = 0;
   }
}
