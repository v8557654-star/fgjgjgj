package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.MathHelper;
import winvi.noxiumvisuals.modules.particles.DashTrailModule;
public final class TrailHandManager {
   private final DashTrailModule this$0;
      public double ghlj;
      public double hm1;
      public double ghng;
      public double gho;
      public double removeField6;
      public double validateField150;
      public final double ghru;
      public final double removeField800;
      public final double tsnjm;
      public final long rswjk;

   public TrailHandManager(final DashTrailModule dashTrailModule) {
      this.this$0 = dashTrailModule;
      this.ghru = this.this$0.validateField0.nextDouble() / 50.0;
      this.removeField800 = this.this$0.validateField0.nextDouble() * 360.0;
      this.tsnjm = -90.0F + this.this$0.validateField0.nextDouble() * 180.0;
      this.rswjk = System.currentTimeMillis();
   }

      public double esdpgf() {
      return MathHelper.clamp((System.currentTimeMillis() - this.rswjk) / 1000.0, 0, 1);
   }

      public double zq() {
      return 1 - this.esdpgf();
   }

      public boolean deybzo() {
      return this.esdpgf() >= 1;
   }

      public void dzsr() {
      double value = Math.toRadians(this.removeField800);
      this.gho = this.ghlj;
      this.removeField6 = this.hm1;
      this.validateField150 = this.ghng;
      this.ghlj = this.ghlj + Math.sin(value) * this.ghru;
      this.hm1 = this.hm1 + Math.cos(Math.toRadians(this.tsnjm - 90.0)) * this.ghru;
      this.ghng = this.ghng + Math.cos(value) * this.ghru;
   }

      public double calculateMethod87(float tickDelta) {
      return MathHelper.lerp(tickDelta, this.gho, this.ghlj);
   }

      public double handleMethod77(float tickDelta) {
      return MathHelper.lerp(tickDelta, this.removeField6, this.hm1);
   }

      public double dzv(float tickDelta) {
      return MathHelper.lerp(tickDelta, this.validateField150, this.ghng);
   }

}
