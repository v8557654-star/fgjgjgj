package winvi.noxiumvisuals.modules.visuals;

import com.mojang.authlib.GameProfile;
import java.util.Objects;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerModelPart;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.utils.FakePlayerModule;
import winvi.noxiumvisuals.modules.client.SoundsModule;
import winvi.noxiumvisuals.modules.particles.KillParticleModule;
import winvi.noxiumvisuals.modules.particles.TotemParticleModule;
public class TextureParticleHandler extends OtherClientPlayerEntity {
      private boolean convertField30 = false;
      private Box xt;
      private final GameProfile dxu;

   public TextureParticleHandler(ClientWorld clientWorld, GameProfile gameProfile) {
      super(clientWorld, gameProfile);
      this.dxu = gameProfile;
      this.copyDataFromLocalPlayer();
   }

      public void copyDataFromLocalPlayer() {
      ClientPlayerEntity client = MinecraftClient.getInstance().player;
      if (client != null) {
         this.updateDataFromClientPlayer(client);
      }
   }

      public boolean isPartVisible(PlayerModelPart modelPart) {
      ClientPlayerEntity client = MinecraftClient.getInstance().player;
      return client != null ? client.isPartVisible(modelPart) : super.isPartVisible(modelPart);
   }

      public void updateDataFromClientPlayer(ClientPlayerEntity localPlayer) {
      this.copyPositionAndRotation(localPlayer);
      this.setFireTicks(localPlayer.getFireTicks());
      this.setHealth(localPlayer.getHealth());
      this.setSneaking(localPlayer.isSneaking());
      this.setSprinting(false);
      this.noClip = false;
      this.limbAnimator.updateLimbs(0F, 0F, 20.0F);
      this.xt = localPlayer.getBoundingBox();
      this.bodyYaw = localPlayer.bodyYaw;
      this.headYaw = localPlayer.headYaw;
      this.fallDistance = localPlayer.fallDistance;
      this.convertField30 = localPlayer.isSneaking();
   }

      public void syncCriticalData(ClientPlayerEntity localPlayer) {
      this.fallDistance = localPlayer.fallDistance;
      this.setVelocity(localPlayer.getVelocity());
   }

      public void tick() {
      super.tick();
      ClientPlayerEntity client = MinecraftClient.getInstance().player;
      if (client != null) {
         if (this.convertField30) {
            Vec3d position = this.getPos();
            this.setBoundingBox(
               new Box(position.x - 0.3, position.y, position.z - 0.3, position.x + 0.3, position.y + 1.5, position.z + 0.3)
            );
         } else if (this.xt != null) {
            this.setBoundingBox(this.xt);
         }
      }
   }

      public boolean isInSneakingPose() {
      return this.convertField30;
   }

      public boolean isInvisibleTo(PlayerEntity player) {
      FakePlayerModule fakePlayerModule = FakePlayerModule.getInstance();
      return fakePlayerModule != null && fakePlayerModule.isInvisibilityEnabled() ? true : super.isInvisibleTo(player);
   }

      public boolean canBeHitByProjectile() {
      return false;
   }

      public boolean canHit() {
      return true;
   }

      public void pushAwayFrom(Entity entity) {
   }

      public boolean isPushable() {
      return false;
   }

      protected void pushAway(Entity entity) {
   }

      public SkinTextures getSkinTextures() {
      ClientPlayerEntity client = MinecraftClient.getInstance().player;
      if (client instanceof AbstractClientPlayerEntity) {
         ClientPlayerEntity player2 = client;

         try {
            return player2.getSkinTextures();
         } catch (Exception exception) {
         }
      }

      return super.getSkinTextures();
   }

      public void handleAttack() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.world != null && client.player != null) {
         client.world
            .playSound(
               client.player, this.getX(), this.getY(), this.getZ(), SoundEvents.ENTITY_PLAYER_HURT, SoundCategory.PLAYERS, 1F, 1F
            );
         this.onDamaged(client.world.getDamageSources().generic());
         float value = this.runMethod4();
         boolean enabled = !client.player.isOnGround()
            && !client.player.isClimbing()
            && !client.player.isTouchingWater()
            && !client.player.hasStatusEffect(StatusEffects.BLINDNESS)
            && client.player.getVelocity().y < 0
            && !client.player.hasVehicle();
         if (enabled) {
            value *= 1.5F;
            client.world
               .playSound(
                  client.player,
                  this.getX(),
                  this.getY(),
                  this.getZ(),
                  SoundEvents.ENTITY_PLAYER_ATTACK_CRIT,
                  SoundCategory.PLAYERS,
                  1F,
                  1F
               );

            for (int index = 0; index < 5; index++) {
               double value2 = this.getRandom().nextGaussian() * 0.02;
               double value3 = this.getRandom().nextGaussian() * 0.02;
               double value4 = this.getRandom().nextGaussian() * 0.02;
               client.world
                  .addParticle(
                     ParticleTypes.CRIT,
                     this.getX() + value2,
                     this.getY() + this.getHeight() * 0.5 + value3,
                     this.getZ() + value4,
                     value2,
                     value3,
                     value4
                  );
            }
         }

         if (FakePlayerModule.getInstance().autoTotem.isValue()
            && this.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING
            && this.getHealth() + this.getAbsorptionAmount() <= value) {
            this.setHealth(1F);
            this.setAbsorptionAmount(8.0F);
            this.getOffHandStack().decrement(1);
            if (!SoundsModule.playTotemEvent(this)) {
               client.world
                  .playSound(
                     client.player,
                     this.getX(),
                     this.getY(),
                     this.getZ(),
                     SoundEvents.ITEM_TOTEM_USE,
                     SoundCategory.PLAYERS,
                     1F,
                     1F
                  );
            }

            TotemParticleModule totemParticleModule = NoxiumVisuals.getInstance().getModuleProvider().get(TotemParticleModule.class);
            if (totemParticleModule != null && totemParticleModule.state) {
               TotemParticleModule.onTotemPop(this);
            } else {
               client.particleManager.addEmitter(this, ParticleTypes.TOTEM_OF_UNDYING, 30);
            }
         } else {
            if (this.getAbsorptionAmount() > 0F) {
               float value5 = Math.min(value, this.getAbsorptionAmount());
               this.setAbsorptionAmount(this.getAbsorptionAmount() - value5);
               value -= value5;
            }

            float value6 = Math.max(0F, this.getHealth() - value);
            this.setHealth(value6);
            if (value6 <= 0F) {
               SoundsModule.playFakePlayerKillEvent();
               KillParticleModule.spawnLightning(this);
            }
         }
      }
   }

      private float runMethod4() {
      MinecraftClient client = MinecraftClient.getInstance();
      ItemStack itemStack = client.player.getMainHandStack();
      if (itemStack.isEmpty()) {
         return 1F;
      } else {
         float value = this.zwucci(itemStack.getItem());
         if (client.player.hasStatusEffect(StatusEffects.STRENGTH)) {
            int index = Objects.requireNonNull(client.player.getStatusEffect(StatusEffects.STRENGTH)).getAmplifier() + 1;
            value += 3.0F * index;
         }

         if (client.player.hasStatusEffect(StatusEffects.WEAKNESS)) {
            int index2 = Objects.requireNonNull(client.player.getStatusEffect(StatusEffects.WEAKNESS)).getAmplifier() + 1;
            value -= 4.0F * index2;
         }

         return Math.max(0F, value);
      }
   }

      private float zwucci(Item item) {
      if (item == Items.NETHERITE_SWORD) {
         return 8.0F;
      } else if (item == Items.DIAMOND_SWORD) {
         return 7.0F;
      } else if (item == Items.IRON_SWORD) {
         return 6.0F;
      } else if (item == Items.STONE_SWORD) {
         return 5.0F;
      } else if (item == Items.WOODEN_SWORD || item == Items.GOLDEN_SWORD) {
         return 4.0F;
      } else if (item == Items.NETHERITE_AXE) {
         return 10.0F;
      } else if (item == Items.DIAMOND_AXE) {
         return 9.0F;
      } else if (item == Items.IRON_AXE) {
         return 9.0F;
      } else if (item == Items.STONE_AXE) {
         return 9.0F;
      } else if (item == Items.WOODEN_AXE || item == Items.GOLDEN_AXE) {
         return 7.0F;
      } else if (item == Items.TRIDENT) {
         return 9.0F;
      } else if (item == Items.NETHERITE_PICKAXE || item == Items.DIAMOND_PICKAXE) {
         return 6.0F;
      } else if (item == Items.IRON_PICKAXE) {
         return 5.0F;
      } else if (item == Items.STONE_PICKAXE) {
         return 4.0F;
      } else if (item == Items.WOODEN_PICKAXE || item == Items.GOLDEN_PICKAXE) {
         return 3.0F;
      } else if (item == Items.NETHERITE_SHOVEL || item == Items.DIAMOND_SHOVEL) {
         return 5.5F;
      } else if (item == Items.IRON_SHOVEL) {
         return 4.5F;
      } else if (item == Items.STONE_SHOVEL) {
         return 3.5F;
      } else {
         return item != Items.WOODEN_SHOVEL && item != Items.GOLDEN_SHOVEL ? 1F : 2.5F;
      }
   }

}
