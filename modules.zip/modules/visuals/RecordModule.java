package winvi.noxiumvisuals.modules.visuals;

import java.io.File;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.settings.ActionSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.modules.settings.KeybindSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.RenderEventData;
import winvi.noxiumvisuals.utils.recording.ScreenRecorder;

public class RecordModule extends Module {
   private static final float SOUND_DECAY = 6.5F;
   private static volatile float soundLevel = 0.0F;
   public final KeybindSetting startBind;
   public final KeybindSetting stopBind;
   public final BooleanSetting microphone;
   public final NumberSetting fps;

   public RecordModule() {
      super("Record", ModuleCategory.VISUAL);
      this.startBind = new KeybindSetting(
         "Start Record",
         "Start recording the screen and sound"
      );
      this.startBind.setKey(GLFW.GLFW_KEY_F9);
      this.startBind.withTranslation("record.startrecord", "record.startrecord.desc");
      this.stopBind = new KeybindSetting(
         "Stop Record",
         "Stop the current recording"
      );
      this.stopBind.setKey(GLFW.GLFW_KEY_F10);
      this.stopBind.withTranslation("record.stoprecord", "record.stoprecord.desc");
      this.microphone = new BooleanSetting(
         "Microphone",
         "Include microphone sound in the recording"
      );
      this.microphone.withTranslation("record.microphone", "record.microphone.desc");
      this.fps = new NumberSetting(
         "FPS",
         "Recording framerate"
      )
      .range(10, 60)
      .setValue(20.0F)
      .displayFormatter(value -> String.valueOf((int)Math.round(value)));
      this.fps.withTranslation("record.fps", "record.fps.desc");
      ActionSetting openFolder = new ActionSetting(
         "Recordings",
         "Open the folder with saved recordings"
      )
      .setButtonName("Open")
      .setRunnable(() -> {
         Util.getOperatingSystem().open(ScreenRecorder.RECORDINGS_DIR.toFile());
      });
      openFolder.withTranslation("record.openfolder", "record.openfolder.desc");
      this.setup(
         new ModuleSetting[]{
            this.startBind,
            this.stopBind,
            this.microphone,
            this.fps,
            openFolder
         }
      );
   }

   @EventHandler
   public void onKey(RenderEventData event) {
      if (event.isBindDown(this.startBind)) {
         this.startRecording();
      } else if (event.isBindDown(this.stopBind)) {
         this.stopRecording();
      }
   }

   @Override
   public void deactivate() {
      this.stopRecording();
      resetLevels();
   }

   public void startRecording() {
      ScreenRecorder recorder = ScreenRecorder.getInstance();
      if (recorder.isRecording()) {
         return;
      }

      File file = recorder.start((int)this.fps.getValue(), this.microphone.isValue());
      if (file != null) {
         resetLevels();
         notifyPlayer("§7Recording started", true);
      } else {
         notifyPlayer("§cRecording failed to start", true);
      }
   }

   public void stopRecording() {
      ScreenRecorder recorder = ScreenRecorder.getInstance();
      if (!recorder.isRecording()) {
         return;
      }

      File file = recorder.stop();
      if (file != null) {
         notifyPlayer("§7Recording saved: §f" + file.getName(), false);
      }
   }

   public static void onGameSound(float volume) {
      if (!ScreenRecorder.getInstance().isRecording()) {
         return;
      }

      float clamped = Math.max(0.0F, Math.min(1.0F, volume));
      if (clamped > soundLevel) {
         soundLevel = clamped;
      }
   }

   public static float pollWaveLevel(float deltaSeconds) {
      float decay = (float)Math.exp(-deltaSeconds * SOUND_DECAY);
      soundLevel *= decay;
      return soundLevel;
   }

   public static void resetLevels() {
      soundLevel = 0.0F;
   }

   private static void notifyPlayer(String message, boolean actionBar) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client != null && client.player != null) {
         client.player.sendMessage(Text.literal(message), actionBar);
      }
   }
}
