package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.client.ItemHighlighterModule;
import winvi.noxiumvisuals.utils.render.ColorEntityRenderer;
public final class ColorItemStackRenderer {
      private static final int setField88 = 16;
      private static ItemHighlighterModule ny1;

   private ColorItemStackRenderer() {
   }

      public static boolean isGuiHighlightingEnabled() {
      if (!ColorEntityRenderer.isHighlightSuppressed() && !ColorItemStackManager.getPresets().isEmpty()) {
         ItemHighlighterModule itemHighlighterModule = hasMethod890();
         return itemHighlighterModule != null && itemHighlighterModule.isState();
      } else {
         return false;
      }
   }

      public static boolean isHeldItemHighlightingEnabled() {
      if (!ColorEntityRenderer.isHighlightSuppressed() && !ColorItemStackManager.getPresets().isEmpty()) {
         ItemHighlighterModule itemHighlighterModule = hasMethod890();
         return itemHighlighterModule != null && itemHighlighterModule.isState() && itemHighlighterModule.paintHeldItems.isValue();
      } else {
         return false;
      }
   }

      public static Integer getHighlightColor(ItemStack stack) {
      if (!isGuiHighlightingEnabled()) {
         return null;
      } else {
         ColorModuleProvider colorModuleProvider = ColorItemStackManager.findMatchingPreset(stack);
         if (colorModuleProvider == null) {
            return null;
         } else {
            int color = colorModuleProvider.getColor();
            return (color >>> 24 & 0xFF) == 0 ? null : color;
         }
      }
   }

      public static Integer getHeldItemColor(ItemStack stack) {
      if (!isHeldItemHighlightingEnabled()) {
         return null;
      } else {
         ColorModuleProvider colorModuleProvider = ColorItemStackManager.findMatchingPreset(stack);
         return colorModuleProvider == null ? null : colorModuleProvider.getColor();
      }
   }

      public static boolean draw(DrawContext context, float x, float y, ItemStack stack) {
      return draw(context, x, y, 1F, stack);
   }

      public static boolean draw(DrawContext context, float x, float y, float scale, ItemStack stack) {
      Integer integer = getHighlightColor(stack);
      if (integer == null) {
         return false;
      } else {
         int index = Math.round(x);
         int index2 = Math.round(y);
         int index3 = Math.max(1, Math.round(16.0F * scale));
         context.fill(index, index2, index + index3, index2 + index3, integer);
         return true;
      }
   }

      private static ItemHighlighterModule hasMethod890() {
      NoxiumVisuals noxiumVisuals = NoxiumVisuals.getInstance();
      if (noxiumVisuals != null && noxiumVisuals.getModuleProvider() != null) {
         if (ny1 == null) {
            ny1 = noxiumVisuals.getModuleProvider().get(ItemHighlighterModule.class);
         }

         return ny1;
      } else {
         return null;
      }
   }

   static {
      int index = 0;
   }
}
