package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.utils.BetterMinecraftModule;
public final class MatrixAnimationRenderer {
      public static final AnimatedFloat setField40 = new AnimatedFloat(0F);
      public static final AnimatedFloat bocnk = new AnimatedFloat(0F);
      public static final AnimatedFloat pfzcn = new AnimatedFloat(0F);
      public static final AnimatedFloat bzvik = new AnimatedFloat(0F);
      public static final AnimatedFloat jwpza = new AnimatedFloat(0F);
      public static final AnimatedFloat controlField62 = new AnimatedFloat();
      public static BetterMinecraftModule nsbbt;
      public static boolean validateField171;
      public static int wbuiz = -1;
      public static int ebi = -1;
      public static int ebjz;
      public static ItemStack manageField63 = ItemStack.EMPTY;

   public MatrixAnimationRenderer() {
   }

      public static boolean applyChatTransform(DrawContext context, boolean focused, int chatWidth) {
      BetterMinecraftModule betterMinecraftModule = zmodlj();
      if (betterMinecraftModule == null || !betterMinecraftModule.shouldAnimateChat()) {
         setField40.executeMethod910(focused ? 1F : 0F);
         return false;
      } else if (!focused) {
         setField40.executeMethod910(0F);
         return false;
      } else {
         float value = setField40.b26(1F, betterMinecraftModule.getAnimationSpeed());
         if (qasvgy(value)) {
            return false;
         } else {
            MatrixStack matrices = context.getMatrices();
            matrices.push();
            if (betterMinecraftModule.isSlideAnimation()) {
               float width = Math.max(32.0F, chatWidth + 12.0F);
               matrices.translate(-width * (1F - value), 0F, 0F);
            } else {
               x17(matrices, 0F, context.getScaledWindowHeight(), 0.92F + 0.08F * value);
            }

            return true;
         }
      }
   }

      public static void onChatFocusChanged(boolean focused) {
      if (!focused) {
         setField40.executeMethod910(0F);
      }
   }

      public static void onTabVisibilityChanged(boolean visible) {
      if (visible != validateField171) {
         validateField171 = visible;
         bocnk.executeMethod910(visible ? 0F : 1F);
      }
   }

      public static boolean applyTabTransform(DrawContext context, float slideDistance) {
      BetterMinecraftModule betterMinecraftModule = zmodlj();
      if (betterMinecraftModule != null && betterMinecraftModule.shouldAnimateTab()) {
         float value = bocnk.b26(1F, betterMinecraftModule.getAnimationSpeed());
         if (qasvgy(value)) {
            return false;
         } else {
            MatrixStack matrices = context.getMatrices();
            matrices.push();
            if (betterMinecraftModule.isSlideAnimation()) {
               matrices.translate(0F, -Math.max(20.0F, slideDistance) * (1F - value), 0F);
            } else {
               x17(matrices, context.getScaledWindowWidth() / 2.0F, 10.0F, 0.92F + 0.08F * value);
            }

            return true;
         }
      } else {
         bocnk.executeMethod910(1F);
         return false;
      }
   }

      public static boolean applyInventoryTransform(DrawContext context, int x, int y, int width, int height) {
      BetterMinecraftModule betterMinecraftModule = zmodlj();
      if (betterMinecraftModule != null && betterMinecraftModule.shouldAnimateInventory()) {
         float value = pfzcn.b26(1F, betterMinecraftModule.getAnimationSpeed());
         if (qasvgy(value)) {
            return false;
         } else {
            rzicof(context.getMatrices(), betterMinecraftModule, value, x, y, width, height, context.getScaledWindowHeight(), false);
            return true;
         }
      } else {
         pfzcn.executeMethod910(1F);
         return false;
      }
   }

      public static boolean applyInventoryBackgroundCompensation(DrawContext context, int x, int y, int width, int height) {
      BetterMinecraftModule betterMinecraftModule = zmodlj();
      if (betterMinecraftModule != null && betterMinecraftModule.shouldAnimateInventory()) {
         float value = pfzcn.dzc();
         if (qasvgy(value)) {
            return false;
         } else {
            rzicof(context.getMatrices(), betterMinecraftModule, value, x, y, width, height, context.getScaledWindowHeight(), true);
            return true;
         }
      } else {
         return false;
      }
   }

      public static int mapInventoryMouseX(int mouseX, int x, int width) {
      BetterMinecraftModule betterMinecraftModule = zmodlj();
      if (betterMinecraftModule != null && betterMinecraftModule.shouldAnimateInventory() && !betterMinecraftModule.isSlideAnimation()) {
         float value = pfzcn.b26(1F, betterMinecraftModule.getAnimationSpeed());
         if (qasvgy(value)) {
            return mouseX;
         } else {
            float width2 = x + width / 2.0F;
            float value2 = 0.9F + 0.1F * value;
            return Math.round(width2 + (mouseX - width2) / value2);
         }
      } else {
         return mouseX;
      }
   }

      public static int mapInventoryMouseY(int mouseY, int y, int height) {
      BetterMinecraftModule betterMinecraftModule = zmodlj();
      if (betterMinecraftModule != null && betterMinecraftModule.shouldAnimateInventory()) {
         float value = pfzcn.b26(1F, betterMinecraftModule.getAnimationSpeed());
         if (qasvgy(value)) {
            return mouseY;
         } else if (betterMinecraftModule.isSlideAnimation()) {
            int index = cqsg();
            float value2 = stopMethod00(index, y);
            return Math.round(mouseY - value2 * (1F - value));
         } else {
            float height2 = y + height / 2.0F;
            float value3 = 0.9F + 0.1F * value;
            return Math.round(height2 + (mouseY - height2) / value3);
         }
      } else {
         return mouseY;
      }
   }

      public static boolean applyPauseMenuTransform(DrawContext context, float slideDistance) {
      BetterMinecraftModule betterMinecraftModule = zmodlj();
      if (betterMinecraftModule != null && betterMinecraftModule.shouldAnimatePauseMenu()) {
         float value = bzvik.b26(1F, betterMinecraftModule.getAnimationSpeed());
         if (qasvgy(value)) {
            return false;
         } else {
            jyznid(context.getMatrices(), context, betterMinecraftModule, value, slideDistance, false);
            return true;
         }
      } else {
         bzvik.executeMethod910(1F);
         return false;
      }
   }

      public static boolean applyPauseMenuBackgroundCompensation(DrawContext context, float slideDistance) {
      BetterMinecraftModule betterMinecraftModule = zmodlj();
      if (betterMinecraftModule != null && betterMinecraftModule.shouldAnimatePauseMenu()) {
         float value = bzvik.dzc();
         if (qasvgy(value)) {
            return false;
         } else {
            jyznid(context.getMatrices(), context, betterMinecraftModule, value, slideDistance, true);
            return true;
         }
      } else {
         return false;
      }
   }

      public static int mapPauseMenuMouseX(int mouseX, int screenWidth) {
      BetterMinecraftModule betterMinecraftModule = zmodlj();
      if (betterMinecraftModule != null && betterMinecraftModule.shouldAnimatePauseMenu() && !betterMinecraftModule.isSlideAnimation()) {
         float value = bzvik.b26(1F, betterMinecraftModule.getAnimationSpeed());
         if (qasvgy(value)) {
            return mouseX;
         } else {
            float width = screenWidth / 2.0F;
            float value2 = 0.9F + 0.1F * value;
            return Math.round(width + (mouseX - width) / value2);
         }
      } else {
         return mouseX;
      }
   }

      public static int mapPauseMenuMouseY(int mouseY, int screenHeight, float slideDistance) {
      BetterMinecraftModule betterMinecraftModule = zmodlj();
      if (betterMinecraftModule != null && betterMinecraftModule.shouldAnimatePauseMenu()) {
         float value = bzvik.b26(1F, betterMinecraftModule.getAnimationSpeed());
         if (qasvgy(value)) {
            return mouseY;
         } else if (betterMinecraftModule.isSlideAnimation()) {
            float value2 = -Math.max(32.0F, slideDistance) * (1F - value);
            return Math.round(mouseY - value2);
         } else {
            float height = screenHeight / 2.0F;
            float value3 = 0.9F + 0.1F * value;
            return Math.round(height + (mouseY - height) / value3);
         }
      } else {
         return mouseY;
      }
   }

      public static boolean applyItemTooltipTransform(DrawContext context, ItemStack stack, int selectedSlot, int tooltipFade) {
      boolean enabled = stack == null ? !manageField63.isEmpty() : !ItemStack.areItemsAndComponentsEqual(manageField63, stack);
      boolean enabled2 = selectedSlot != ebi || enabled;
      boolean enabled3 = tooltipFade > ebjz + 1;
      if (enabled2 || enabled3) {
         jwpza.executeMethod910(0F);
      }

      if (enabled2) {
         manageField63 = stack == null ? ItemStack.EMPTY : stack.copy();
         ebi = selectedSlot;
      }

      ebjz = tooltipFade;
      BetterMinecraftModule betterMinecraftModule = zmodlj();
      if (betterMinecraftModule == null || !betterMinecraftModule.shouldAnimateItemTooltip()) {
         jwpza.executeMethod910(1F);
         return false;
      } else if (stack != null && !stack.isEmpty() && tooltipFade > 0) {
         float value = jwpza.b26(1F, betterMinecraftModule.getAnimationSpeed());
         if (qasvgy(value)) {
            return false;
         } else {
            MatrixStack matrices = context.getMatrices();
            float width = context.getScaledWindowWidth() / 2.0F;
            float height = context.getScaledWindowHeight() - 50.0F;
            matrices.push();
            if (betterMinecraftModule.isSlideAnimation()) {
               float height2 = context.getScaledWindowHeight() - height + 16.0F;
               matrices.translate(0F, height2 * (1F - value), 0F);
            } else {
               x17(matrices, width, height, 0.92F + 0.08F * value);
            }

            return true;
         }
      } else {
         jwpza.executeMethod910(0F);
         return false;
      }
   }

      public static int animateHotbarSelectionX(int vanillaX, int selectedSlot) {
      BetterMinecraftModule betterMinecraftModule = zmodlj();
      if (betterMinecraftModule != null && betterMinecraftModule.shouldAnimateHotbarSlot()) {
         if (wbuiz == -1) {
            controlField62.executeMethod910((float)selectedSlot);
         } else if (wbuiz != selectedSlot) {
            jwpza.executeMethod910(0F);
         }

         wbuiz = selectedSlot;
         float value = controlField62.b26((float)selectedSlot, betterMinecraftModule.getAnimationSpeed() * 1.35F);
         float value2 = (value - selectedSlot) * 20.0F;
         return Math.abs(value2) < 0.01F ? vanillaX : vanillaX + Math.round(value2);
      } else {
         controlField62.executeMethod910((float)selectedSlot);
         wbuiz = selectedSlot;
         return vanillaX;
      }
   }

      public static void resetInventory() {
      pfzcn.executeMethod910(0F);
   }

      public static void resetPauseMenu() {
      bzvik.executeMethod910(0F);
   }

      public static void resetItemTooltip() {
      jwpza.executeMethod910(0F);
      ebjz = 0;
      ebi = -1;
      manageField63 = ItemStack.EMPTY;
   }

      public static void onModuleEnabled() {
      setField40.executeMethod910(0F);
      bocnk.executeMethod910(0F);
      pfzcn.executeMethod910(0F);
      bzvik.executeMethod910(0F);
      resetItemTooltip();
      controlField62.bbxfds();
      wbuiz = -1;
      validateField171 = false;
   }

      public static void onModuleDisabled() {
      setField40.executeMethod910(0F);
      bocnk.executeMethod910(1F);
      pfzcn.executeMethod910(1F);
      bzvik.executeMethod910(1F);
      jwpza.executeMethod910(1F);
      controlField62.bbxfds();
      wbuiz = -1;
   }

      public static void rzicof(
      MatrixStack matrices, BetterMinecraftModule module, float progress, int x, int y, int width, int height, int screenHeight, boolean inverse
   ) {
      float width2 = x + width / 2.0F;
      float height2 = y + height / 2.0F;
      matrices.push();
      if (module.isSlideAnimation()) {
         float height3 = stopMethod00(screenHeight, y) * (1F - progress);
         matrices.translate(0F, inverse ? -height3 : height3, 0F);
      } else {
         float value = 0.9F + 0.1F * progress;
         x17(matrices, width2, height2, inverse ? 1F / value : value);
      }
   }

      public static void jyznid(MatrixStack matrices, DrawContext context, BetterMinecraftModule module, float progress, float slideDistance, boolean inverse) {
      float width = context.getScaledWindowWidth() / 2.0F;
      float height = context.getScaledWindowHeight() / 2.0F;
      matrices.push();
      if (module.isSlideAnimation()) {
         float value = -Math.max(32.0F, slideDistance) * (1F - progress);
         matrices.translate(0F, inverse ? -value : value, 0F);
      } else {
         float value2 = 0.9F + 0.1F * progress;
         x17(matrices, width, height, inverse ? 1F / value2 : value2);
      }
   }

      public static float stopMethod00(int screenHeight, int inventoryY) {
      return Math.max(32.0F, screenHeight - inventoryY + 8.0F);
   }

      public static int cqsg() {
      MinecraftClient client = MinecraftClient.getInstance();
      return client != null && client.getWindow() != null ? client.getWindow().getScaledHeight() : 1;
   }

      public static BetterMinecraftModule zmodlj() {
      BetterMinecraftModule betterMinecraftModule = nsbbt;
      if (betterMinecraftModule != null) {
         return betterMinecraftModule.isState() ? betterMinecraftModule : null;
      } else {
         try {
            NoxiumVisuals noxiumVisuals = NoxiumVisuals.getInstance();
            if (noxiumVisuals != null && noxiumVisuals.getModuleProvider() != null) {
               nsbbt = noxiumVisuals.getModuleProvider().get(BetterMinecraftModule.class);
               return nsbbt != null && nsbbt.isState() ? nsbbt : null;
            } else {
               return null;
            }
         } catch (Exception exception) {
            return null;
         }
      }
   }

      public static boolean qasvgy(float progress) {
      return progress >= 0.9995F;
   }

      public static float convertMethod82(float value) {
      float value2 = startMethod56(value, 0F, 1F);
      float value3 = 1F - value2;
      return 1F - value3 * value3 * value3;
   }

      public static float startMethod56(float value, float min, float max) {
      return Math.max(min, Math.min(max, value));
   }

      public static void x17(MatrixStack matrices, float x, float y, float scale) {
      matrices.translate(x, y, 0F);
      matrices.scale(scale, scale, 1F);
      matrices.translate(-x, -y, 0F);
   }

      public static long y24(float speed) {
      float value = startMethod56(3080.0F / Math.max(1F, speed), 110.0F, 380.0F);
      return (long)(value * 1000000.0F);
   }

   static {
      int index = 0;
   }
}
