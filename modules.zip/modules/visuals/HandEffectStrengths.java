package winvi.noxiumvisuals.modules.visuals;

public record HandEffectStrengths(
   float glow,
   float outline,
   float opacity
) {

      public float glow() {
      return this.glow;
   }

      public float outline() {
      return this.outline;
   }

      public float opacity() {
      return this.opacity;
   }

}
