package winvi.noxiumvisuals.modules.visuals;

public final class AnimatedFloat {
      public float wzjih;
      public float ggo;
      public float ggp;
      public long getField550;
      public long ggrh;
      public boolean processField13;

   public AnimatedFloat() {
   }

   public AnimatedFloat(float value) {
      this.executeMethod910(value);
   }

      public float b26(float target, float speed) {
      long timestamp = System.nanoTime();
      if (!this.processField13) {
         this.executeMethod910(target);
         return this.wzjih;
      } else {
         this.wzjih = this.svxixj(timestamp);
         if (Float.compare(target, this.ggp) != 0) {
            this.ggo = this.wzjih;
            this.ggp = target;
            this.getField550 = timestamp;
            this.ggrh = MatrixAnimationRenderer.y24(speed);
         }

         this.wzjih = this.svxixj(timestamp);
         return this.wzjih;
      }
   }

      public float dzc() {
      return this.processField13 ? this.wzjih : 0F;
   }

      public float svxixj(long now) {
      if (this.ggrh > 0L && (this.wzjih != this.ggp || this.ggo != this.ggp)) {
         float value = (float)(now - this.getField550) / (float)this.ggrh;
         if (value >= 1F) {
            this.ggo = this.ggp;
            return this.ggp;
         } else {
            return value <= 0F ? this.ggo : this.ggo + (this.ggp - this.ggo) * MatrixAnimationRenderer.convertMethod82(value);
         }
      } else {
         return this.ggp;
      }
   }

      public void executeMethod910(float value) {
      this.wzjih = value;
      this.ggo = value;
      this.ggp = value;
      this.getField550 = System.nanoTime();
      this.ggrh = 0L;
      this.processField13 = true;
   }

      public void bbxfds() {
      this.wzjih = 0F;
      this.ggo = 0F;
      this.ggp = 0F;
      this.getField550 = 0L;
      this.ggrh = 0L;
      this.processField13 = false;
   }

}
