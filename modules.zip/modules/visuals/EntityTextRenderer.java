package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.ui.hud.elements.TargetHUDHud;
public class EntityTextRenderer {

      public static void onTick() {
   }

      public static void render(DrawContext context, RenderTickCounter renderTickCounter) {
      TargetHUDHud.render(context, renderTickCounter);
   }

      public static void onAttack(Entity attackedEntity) {
      if (attackedEntity instanceof LivingEntity) {
         TargetHUDHud targetHUDHud = NoxiumVisuals.getInstance().getDraggableRepository().get(TargetHUDHud.class);
         if (targetHUDHud != null) {
            targetHUDHud.onAttack(attackedEntity);
         }
      }
   }

      public static LivingEntity getLastTarget() {
      return TargetHUDHud.getLastTarget();
   }

}
