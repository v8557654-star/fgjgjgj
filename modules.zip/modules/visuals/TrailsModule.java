package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.awt.Color;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.TextureColorManager;
import winvi.noxiumvisuals.modules.visuals.EntityTrailRenderer;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.systems.internal.ParticleTrailAccess;
import winvi.noxiumvisuals.systems.managers.FriendManager;
import winvi.noxiumvisuals.utils.render.RenderGeometry;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
public class TrailsModule extends Module {
      private static final MinecraftClient ve = MinecraftClient.getInstance();
      public static BooleanSetting trailsFirstPerson = new BooleanSetting(
         "First Person",
         "Show trails in first person"
      )
      .setValue(
         false
      );
      public static NumberSetting trailsLength = new NumberSetting(
         "Length",
         "Trail length"
      )
      .setValue(0.3F)
      .range(0F, 1.5F);
      public static ChoiceSetting trailsStyle;
      public static BooleanSetting trailsOnlyFriends = new BooleanSetting(
         "Only Friends",
         "Show trails only for friends"
      )
      .setValue(false);
      public static BooleanSetting advancedSettings = new BooleanSetting(
         "Advanced Settings",
         "Show advanced settings"
      )
      .setValue(false);
      public static NumberSetting trailsOpacity = new NumberSetting(
         "Opacity",
         "Trail opacity"
      )
      .setValue(1F)
      .range(0.1F, 1F);
      public static NumberSetting trailsFadeStrength = new NumberSetting(
         "Fade Strength",
         "How fast trail fades at the end"
      )
      .setValue(0.93F)
      .range(0.1F, 2.0F);
      public static BooleanSetting useShader = new BooleanSetting(
         "Use Shader",
         "Enable shader overlay on trails"
      )
      .setValue(
         false
      );
      public static ChoiceSetting shaderType;
      public static NumberSetting shaderSpeed = new NumberSetting(
         "Shader Speed",
         "Animation speed of shader"
      )
      .setValue(50.0F)
      .range(1F, 100.0F);
      public static NumberSetting shaderScale = new NumberSetting(
         "Shader Scale",
         "Scale of shader pattern"
      )
      .setValue(5.0F)
      .range(1F, 20.0F);
      public static SettingGroup trailSettings;

   public TrailsModule() {
      super("Trails", ModuleCategory.VISUAL);
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{trailSettings});
   }

      @Override
   public void deactivate() {
      if (ve.world != null) {
         for (PlayerEntity player : ve.world.getPlayers()) {
            ((ParticleTrailAccess)player).noxium$clearPositionHistory();
         }
      }

      super.deactivate();
   }

      @Override
   public void activate() {
      super.activate();
      if (ve.world != null) {
         for (PlayerEntity player : ve.world.getPlayers()) {
            ((ParticleTrailAccess)player).noxium$clearPositionHistory();
         }
      }
   }

      @Override
   public void onTick() {
      if (this.isState()) {
         if (ve.world != null && ve.player != null) {
            this.dgrc();
         }
      }
   }

      private void parseMethod170(long currentTimeMs) {
      Color color = new Color(this.getVisualColor(), true);
      long timestamp = (long)(trailsLength.getValue() * 1000.0F);
      double value = 0.005;

      for (PlayerEntity player2 : ve.world.getPlayers()) {
         if (EntityVisibilityFilter.shouldRender(player2)) {
            List list = ((ParticleTrailAccess)player2).noxium$getTrails();
            boolean enabled = false;
            if (player2 != ve.player
               && (player2.getPos().x != player2.prevX || player2.getPos().z != player2.prevZ)
               && FriendManager.isFriend(player2)) {
               enabled = true;
            }

            if (player2 == ve.player
               && (ve.player.getVelocity().x != 0 || ve.player.getVelocity().z != 0)
               && (trailsFirstPerson.isValue() || !ve.options.getPerspective().isFirstPerson())) {
               enabled = true;
            }

            if (enabled) {
               Vec3d position = RenderGeometry.interpolate(player2);
               if (list.isEmpty()) {
                  Vec3d position2 = new Vec3d(player2.prevX, player2.prevY, player2.prevZ);
                  list.add(new TextureColorManager(position2, position, color, player2.getHeight(), timestamp, currentTimeMs, 0F));
               } else {
                  TextureColorManager textureColorManager = (TextureColorManager)list.get(list.size() - 1);
                  double value2 = textureColorManager.currentPos.distanceTo(position);
                  if (value2 >= value) {
                     list.add(new TextureColorManager(textureColorManager.currentPos, position, color, player2.getHeight(), timestamp, currentTimeMs, textureColorManager.getEndTextureU()));
                  }
               }
            }
         }
      }
   }

      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState()) {
         if (ve.world != null && ve.player != null) {
            MatrixStack matrices = event.getStack();
            float value = event.getPartialTicks();
            long timestamp = System.currentTimeMillis();
            this.parseMethod170(timestamp);
            this.gs1(matrices);
            EntityTrailRenderer.renderBatches(value);
         }
      }
   }

      private void dgrc() {
      long timestamp = System.currentTimeMillis();

      for (PlayerEntity player : ve.world.getPlayers()) {
         List list = ((ParticleTrailAccess)player).noxium$getTrails();

         for (int index = list.size() - 1; index >= 0; index--) {
            if (((TextureColorManager)list.get(index)).shouldRemove(timestamp)) {
               list.remove(index);
            }
         }
      }
   }

      private void gs1(MatrixStack stack) {
      Vec3d camera = ve.gameRenderer.getCamera().getPos();
      double value = 4096.0;

      for (PlayerEntity player2 : ve.world.getPlayers()) {
         if (EntityVisibilityFilter.shouldRender(player2)) {
            boolean enabled = false;
            if (player2 == ve.player) {
               enabled = trailsFirstPerson.isValue() || !ve.options.getPerspective().isFirstPerson();
            } else {
               enabled = !trailsOnlyFriends.isValue() || FriendManager.isFriend(player2);
            }

            if (enabled) {
               double value2 = player2.squaredDistanceTo(camera);
               if (!(value2 > value)) {
                  List list = ((ParticleTrailAccess)player2).noxium$getTrails();
                  if (!list.isEmpty()) {
                     float height = player2.getHeight();
                     EntityTrailRenderer.queueTrails(stack, list, this, height);
                  }
               }
            }
         }
      }
   }

      public int[] getCustomColors() {
      Color color = new Color(this.getVisualColor(), true);
      return new int[]{color.getRGB()};
   }

   static {
      int index = 0;
      ChoiceSetting moduleSettingHandler2 = new ChoiceSetting(
         "Style",
         "Trail rendering style"
      );
      String[] stringArray = new String[2];
      stringArray[0] = "DEFAULT";
      stringArray[1] = "FADE";
      trailsStyle = moduleSettingHandler2.value(stringArray).selected("FADE");
      trailsStyle.withTranslation("trails.style", "trails.style.desc");
      trailsLength.withTranslation("trails.length", "trails.length.desc");
      trailsOpacity.withTranslation("trails.opacity", "trails.opacity.desc");
      trailsFadeStrength.withTranslation("trails.fadestrength", "trails.fadestrength.desc");
      trailsOnlyFriends.withTranslation("trails.onlyfriends", "trails.onlyfriends.desc");
      advancedSettings.withTranslation("trails.advancedsettings", "trails.advancedsettings.desc");
      trailsFirstPerson.withTranslation("trails.firstperson", "trails.firstperson.desc");
      trailsFirstPerson.setVisible(() -> {
         return advancedSettings.isValue();
      });
      useShader.withTranslation("trails.useshader", "trails.useshader.desc");
      ChoiceSetting moduleSettingHandler22 = new ChoiceSetting(
         "Shader Type", "Type of shader effect"
      );
      String[] stringArray2 = new String[5];
      stringArray2[0] = "Wave";
      stringArray2[1] = "Plasma";
      stringArray2[2] = "Fractal";
      stringArray2[3] = "Tunnel";
      stringArray2[4] = "Particles";
      shaderType = moduleSettingHandler22.value(stringArray2).selected("Wave");
      shaderType.withTranslation("trails.shadertype", "trails.shadertype.desc");
      shaderType.setVisible(() -> {
         return useShader.isValue();
      });
      shaderSpeed.withTranslation("trails.shaderspeed", "trails.shaderspeed.desc");
      shaderSpeed.setVisible(() -> {
         return useShader.isValue();
      });
      shaderScale.withTranslation("trails.shaderscale", "trails.shaderscale.desc");
      shaderScale.setVisible(() -> {
         return useShader.isValue();
      });
      SettingGroup moduleSettingProvider3 = new SettingGroup(
         "Trail Settings",
         "Main trail settings"
      );
      ModuleSetting[] moduleProvider3Array = new ModuleSetting[11];
      moduleProvider3Array[0] = trailsStyle;
      moduleProvider3Array[1] = trailsLength;
      moduleProvider3Array[2] = trailsOpacity;
      moduleProvider3Array[3] = trailsFadeStrength;
      moduleProvider3Array[4] = trailsOnlyFriends;
      moduleProvider3Array[5] = useShader;
      moduleProvider3Array[6] = shaderType;
      moduleProvider3Array[7] = shaderSpeed;
      moduleProvider3Array[8] = shaderScale;
      moduleProvider3Array[9] = advancedSettings;
      moduleProvider3Array[10] = trailsFirstPerson;
      trailSettings = moduleSettingProvider3.settings(moduleProvider3Array).setValue(true);
      trailSettings.withTranslation("trails.trailsettings", "trails.trailsettings.desc");
   }
}
