package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.Vec3d;
public record CameraBasis(
   Vec3d right,
   Vec3d up
) {

      public Vec3d right() {
      return this.right;
   }

      public Vec3d up() {
      return this.up;
   }

}
