package winvi.noxiumvisuals.modules.visuals;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.particles.WorldParticleModule;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.ParticleInstance;
import winvi.noxiumvisuals.utils.MatrixEntityProvider;
import winvi.noxiumvisuals.utils.render.WorldParticleBatcher;
import winvi.noxiumvisuals.utils.ParticleCameraRenderer;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.RenderMath;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public final class WorldParticleSprite extends ParticleInstance {
      private static final MinecraftClient calculateField640 = MinecraftClient.getInstance();
      private static final MatrixStack controlField171 = new MatrixStack();
      private static final Identifier gkk = Identifier.of("noxiumvisual", "textures/o163c9wkg/i33quj5pla8.png");
      private static final float l22 = 1.3888888F;
      private static final float startField100 = 0.15F;
      private static final float checkField85 = 0.25F;
      private static final float mlwig = 0.03F;
      private static final int parseField660 = 40;
      private static final int startField40 = 100;
      private static final float executeField83 = 0.3F;
      private static final float gksk = 1F;
      private static final float gkt = 0F;
      private static final int rzswz = 20;
      private final ParticleModuleType dgkef;
      private final int kw;
      private final int[] runField25;
      private final Deque<double[]> y28;
      private final float startField171;
      private final float a19;
      private final float glb;
      private final float vnmei;
      private final float fpxil;
      private final float[] ywanj;
      private final int[] kxynw;
      private double glgn;
      private double calculateField89;
      private double chxot;
      private int glji;
      protected Identifier texture;
      protected int age;
      protected final int maxAge;

   public WorldParticleSprite(float posX, float posY, float posZ, float motionX, float motionY, float motionZ) {
      this(ParticleModuleType.PARTICLE, posX, posY, posZ, motionX, motionY, motionZ);
   }

   public WorldParticleSprite(ParticleModuleType style, float posX, float posY, float posZ, float motionX, float motionY, float motionZ) {
      super(posX, posY, posZ);
      this.dgkef = style;
      this.runField25 = formatMethod760();
      this.kw = this.runField25[0];
      this.texture = ulinxh(style);
      this.motionX = motionX;
      this.motionY = motionY;
      this.motionZ = motionZ;
      if (style == ParticleModuleType.WISP) {
         this.age = RenderMath.random(100, 301);
         this.maxAge = this.age;
         double value = Math.sqrt(motionX * motionX + motionY * motionY + motionZ * motionZ);
         this.startField171 = (float)Math.max(0.02, value);
         this.a19 = RenderMath.random(0.6F, 1.4F);
         this.glb = 0F;
         this.vnmei = 0F;
         this.fpxil = 0F;
         this.glgn = motionX;
         this.calculateField89 = motionY;
         this.chxot = motionZ;
         this.y28 = new ArrayDeque<>();
         this.y28.addFirst(new double[]{posX, posY, posZ});
         this.ywanj = style == ParticleModuleType.WISP ? new float[60] : null;
         this.kxynw = style == ParticleModuleType.WISP ? new int[20] : null;
      } else {
         float value2 = WorldParticleModule.particleLifetime.getValue();
         int index = (int)(value2 * 20.0F);
         int index2 = Math.max(1, index / 4);
         this.age = RenderMath.random(index - index2, index + index2);
         this.maxAge = this.age;
         this.startField171 = 0F;
         this.a19 = 1F;
         ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();
         this.glb = style == ParticleModuleType.CUBE ? threadLocalRandom.nextFloat() * 360.0F : threadLocalRandom.nextFloat(-18.0F, 18.0F);
         this.vnmei = style == ParticleModuleType.PARTICLE ? threadLocalRandom.nextFloat(3.0F, 8.0F) * (threadLocalRandom.nextBoolean() ? 1F : -1F) : 0F;
         this.fpxil = style == ParticleModuleType.PARTICLE ? threadLocalRandom.nextFloat(0.004F, 0.012F) * (threadLocalRandom.nextBoolean() ? 1F : -1F) : 0F;
         this.glgn = 0;
         this.calculateField89 = 0;
         this.chxot = 0;
         this.y28 = null;
         this.ywanj = null;
         this.kxynw = null;
      }
   }

      public ParticleModuleType getStyle() {
      return this.dgkef;
   }

      @Override
   public boolean update(long currentTime, boolean isVisible) {
      return this.dgkef == ParticleModuleType.WISP ? this.updateMethod73(currentTime, isVisible) : this.getMethod12(currentTime, isVisible);
   }

      public boolean tick() {
      return this.update(System.currentTimeMillis(), true);
   }

      public boolean isFrustumVisible() {
      float value = this.dokvpy();
      return this.dgkef == ParticleModuleType.WISP
         ? ParticleCameraRenderer.isFireflyVisible(this.x, this.y, this.z, value)
         : ParticleCameraRenderer.isParticleVisible(this.x, this.y, this.z, value);
   }

      public boolean shouldRender(Vec3d cameraPos, float extendedMaxDistanceSquared) {
      if (this.getSquaredDistanceTo(cameraPos) > extendedMaxDistanceSquared) {
         return false;
      } else {
         boolean enabled = this.isFrustumVisible();
         this.setVisible(enabled);

         return switch (this.dgkef) {
            case PARTICLE, WISP -> enabled || this.initMethod32();
            case CUBE -> enabled;
         };
      }
   }

      public void queueRender(VertexMatrixRenderer event) {
      switch (this.dgkef) {
         case PARTICLE:
            this.bwgnan(event);
            break;
         case CUBE:
            this.setMethod8(event);
            break;
         case WISP:
            this.mqvvgi(event);
      }
   }

      public double getDistanceTo(Vec3d cameraPos) {
      return Math.sqrt(this.getSquaredDistanceTo(cameraPos));
   }

      public double getSquaredDistanceTo(Vec3d cameraPos) {
      double x2 = this.x - cameraPos.x;
      double y2 = this.y - cameraPos.y;
      double z2 = this.z - cameraPos.z;
      return x2 * x2 + y2 * y2 + z2 * z2;
   }

      public int[] getGradientColors() {
      return this.runField25;
   }

      private boolean getMethod12(long currentTime, boolean isVisible) {
      this.age--;
      if (this.age <= 0) {
         return true;
      } else if (this.x26(currentTime, isVisible)) {
         return true;
      } else {
         this.px = this.x;
         this.py = this.y;
         this.pz = this.z;
         float value = WorldParticleModule.speed.getValue();
         this.x = this.x + this.motionX * value;
         this.y = this.y + this.motionY * value;
         this.z = this.z + this.motionZ * value;
         String text = WorldParticleModule.direction.getSelected();
         if (this.dgkef == ParticleModuleType.PARTICLE) {
            this.cxweif(text);
         } else {
            this.motionX *= 0.9F;
            this.motionY *= 0.9F;
            this.motionZ *= 0.9F;
            this.lsddnj(text);
         }

         return false;
      }
   }

      private void cxweif(String directionValue) {
      float value = (float)Math.cos(this.fpxil);
      float value2 = (float)Math.sin(this.fpxil);
      float value3 = this.motionX;
      this.motionX = (value3 * value - this.motionZ * value2) * 0.998F;
      this.motionZ = (value3 * value2 + this.motionZ * value) * 0.998F;
      this.motionY *= 0.98F;
      this.lsddnj(directionValue);
   }

      private void lsddnj(String directionValue) {
      if ("UP".equals(directionValue)) {
         this.motionY += 0.001F;
      } else if ("DOWN".equals(directionValue)) {
         this.motionY -= 0.001F;
      }
   }

      private boolean updateMethod73(long currentTime, boolean isVisible) {
      if (calculateField640.player != null && calculateField640.world != null) {
         double value = calculateField640.player.squaredDistanceTo(this.x, this.y, this.z);
         if (!isVisible) {
            this.age -= 2;
         } else if (value > 10000.0) {
            this.age -= 4;
         } else {
            this.age--;
         }

         if (this.age <= 0) {
            return true;
         } else if (this.x26(currentTime, isVisible)) {
            return true;
         } else {
            this.px = this.x;
            this.py = this.y;
            this.pz = this.z;
            this.setMethod82();
            int index = Math.max(1, (int)WorldParticleModule.wispLength.getValue());
            this.x = this.x + this.motionX;
            this.y = this.y + this.motionY;
            this.z = this.z + this.motionZ;
            this.y28.addFirst(new double[]{this.x, this.y, this.z});

            while (this.y28.size() > index + 20) {
               this.y28.removeLast();
            }

            return false;
         }
      } else {
         return false;
      }
   }

      private boolean x26(long currentTime, boolean isVisible) {
      if (!WorldParticleModule.removeOutOfView.isValue()) {
         return false;
      } else {
         if (!isVisible) {
            if (this.outOfViewTime == -1L) {
               this.outOfViewTime = currentTime;
            } else {
               long timestamp = currentTime - this.outOfViewTime;
               float value = WorldParticleModule.removeDelay.getValue();
               if ((float)timestamp >= value * 1000.0F) {
                  return true;
               }
            }
         } else {
            this.outOfViewTime = -1L;
         }

         return false;
      }
   }

      private float dokvpy() {
      return switch (this.dgkef) {
         case PARTICLE -> WorldParticleModule.particleScale.getValue() / 100.0F;
         case CUBE -> WorldParticleModule.cubeScale.getValue() / 100.0F;
         case WISP -> WorldParticleModule.wispScale.getValue() / 100.0F;
      };
   }

      private boolean initMethod32() {
      return this.rybttm() < 0.3F;
   }

      private float rybttm() {
      return this.maxAge <= 0 ? 0F : (float)this.age / this.maxAge;
   }

      private float getMethod59() {
      float value = this.rybttm();
      float value2 = 1F;
      if (value > 0.8F) {
         value2 = (1F - value) / 0.2F;
      } else if (value < 0.2F) {
         value2 = value / 0.2F;
      }

      return isMethod0(value2);
   }

      private void bwgnan(VertexMatrixRenderer event) {
      if (this.texture != null) {
         MatrixColorHandler matrixColorHandler = this.d27(event);
         int index = matrixColorHandler.gmzt >> 24 & 0xFF;
         if (index <= 0) {
            MatrixEntityProvider.release(matrixColorHandler.gmy);
         } else {
            WorldParticleBatcher.queueOwnedGhostParticle(
               matrixColorHandler.gmy, this.texture, matrixColorHandler.handleField0, index / 255.0F, matrixColorHandler.gmzt, this.runField25.length >= 4, this.runField25
            );
         }
      }
   }

      private MatrixColorHandler d27(VertexMatrixRenderer event) {
      Camera camera = calculateField640.gameRenderer.getCamera();
      float value = event.getPartialTicks();
      double value2 = this.px + (this.x - this.px) * value;
      double value3 = this.py + (this.y - this.py) * value;
      double value4 = this.pz + (this.z - this.pz) * value;
      Matrix4f matrix = createMethod89(event, camera, value2, value3, value4);
      float value5 = (float)(System.currentTimeMillis() - this.creationTime) / 1000.0F;
      matrix.rotate(RotationAxis.POSITIVE_Z.rotationDegrees(this.glb + this.vnmei * value5));
      float value6 = this.getMethod59();
      Vec3d position = camera.getPos();
      double value7 = this.getDistanceTo(position);
      float value8 = WorldParticleModule.maxRenderDistance.getValue();
      float value9 = 8.0F;
      float value10 = value8 - value9;
      if (value7 > value10) {
         float value11 = 1F - (float)((value7 - value10) / value9);
         value6 *= isMethod0(value11);
      }

      int index = Math.max(0, Math.min(255, (int)(255.0F * initMethod82(value6))));
      int index2 = this.kw & 16777215 | index << 24;
      float value12 = WorldParticleModule.particleScale.getValue() / 100.0F;
      return new MatrixColorHandler(matrix, index2, value12);
   }

      private void setMethod8(VertexMatrixRenderer event) {
      if (calculateField640.gameRenderer != null && calculateField640.gameRenderer.getCamera() != null) {
         Vec3d position = interpolateWorldPos(event, this.px, this.py, this.pz, this.x, this.y, this.z);
         float value = this.getMethod59();
         if (!(value <= 0F)) {
            float value2 = this.ebga();
            if (!(value2 <= 0F)) {
               Camera camera = calculateField640.gameRenderer.getCamera();
               Matrix4f matrix = event.getStack().peek().getPositionMatrix();
               int index = this.controlMethod20();
               float value3 = this.glb + (1F - this.rybttm()) * 120.0F;
               float value4 = initMethod82(WorldParticleModule.cubeGlowAlpha.getValue() / 100.0F);
               float value5 = value2 / 2.0F;
               float value6 = value * value4;
               if (value6 > 0F) {
                  Matrix4f matrix2 = jppxah(matrix, position, -camera.getYaw(), camera.getPitch());
                  WorldParticleBatcher.queueOwnedTexturedParticle(matrix2, gkk, value2 * 4.0F, Math.min(1F, value6 * 1.3888888F), index, false, null);
               }

               int index2 = ColorUtils.multAlpha(index, value);
               int index3 = ColorUtils.multAlpha(index, value * 0.4F);
               Matrix4f matrix3 = jppxah(matrix, position, value3, value3 * 0.7F);
               WorldParticleBatcher.queueCubeWireframe(matrix3, value5, index2, WorldParticleModule.cubeDiagonals.isValue(), index3);
            }
         }
      }
   }

      private void mqvvgi(VertexMatrixRenderer event) {
      if (this.y28 != null
         && this.y28.size() >= 2
         && this.ywanj != null
         && this.kxynw != null
         && calculateField640.gameRenderer != null
         && calculateField640.gameRenderer.getCamera() != null) {
         Camera camera = calculateField640.gameRenderer.getCamera();
         Vec3d position = camera.getPos();
         float value = event.getPartialTicks();
         float value2 = this.removeMethod25(0.15F, 0.25F);
         float value3 = WorldParticleModule.maxRenderDistance.getValue();
         float value4 = value3 - 8.0F;
         double value5 = this.getDistanceTo(position);
         if (value5 > value4) {
            value2 *= isMethod0(1F - (float)((value5 - value4) / 8.0));
         }

         if (!(value2 <= 0.01F)) {
            int index = duzugu();
            float value6 = WorldParticleModule.wispScale.getValue() / 100.0F * this.a19;
            int index2 = Math.max(4, Math.min(20, (int)WorldParticleModule.wispLength.getValue()));
            int index3 = Math.min(this.y28.size(), index2);
            double value7 = this.px + (this.x - this.px) * value;
            double value8 = this.py + (this.y - this.py) * value;
            double value9 = this.pz + (this.z - this.pz) * value;
            Iterator iterator2 = this.y28.iterator();

            for (int index4 = 0; index4 < index3 && iterator2.hasNext(); index4++) {
               double[] doubleArray = (double[])iterator2.next();
               int index5 = index4 * 3;
               this.ywanj[index5] = (float)(index4 == 0 ? value7 : doubleArray[0]);
               this.ywanj[index5 + 1] = (float)(index4 == 0 ? value8 : doubleArray[1]);
               this.ywanj[index5 + 2] = (float)(index4 == 0 ? value9 : doubleArray[2]);
               float value10 = (float)index4 / Math.max(1, index3 - 1);
               float value11 = value2 * (float)Math.pow(1F - value10, 2.0);
               if (index4 == 0) {
                  value11 *= 0.28F;
               }

               this.kxynw[index4] = ColorUtils.multAlpha(index, value11);
            }

            WorldParticleBatcher.queueLineGlyph(this.ywanj, this.kxynw, index3, Math.max(0.018F, value6 * 0.045F), 1F);
            float value12 = 0.8F + 0.2F * (float)Math.sin((System.currentTimeMillis() - this.creationTime) / 200.0);
            float value13 = value2 * value12;
            this.startMethod68(event, camera, value7, value8, value9, value6 * 1.7F, index, value13 * 0.55F);
            this.startMethod68(event, camera, value7, value8, value9, value6 * 0.95F, index, value13);
            this.uevzpe(event, camera, value7, value8, value9, value6 * 0.4F, index, value13 * 0.9F);
            this.uevzpe(event, camera, value7, value8, value9, value6 * 0.15F, -1, value13);
         }
      }
   }

      private float ebga() {
      return WorldParticleModule.cubeScale.getValue() / 100.0F * this.getMethod59();
   }

      private int controlMethod20() {
      return WorldParticleModule.isMethod25();
   }

      private void setMethod82() {
      this.glji--;
      if (this.glji <= 0) {
         double value = ThreadLocalRandom.current().nextDouble(0, 6.283185307179586);
         double value2 = (ThreadLocalRandom.current().nextDouble() - 0.5) * 3.141592653589793 * 0.30000001192092896;
         this.glgn = Math.cos(value) * Math.cos(value2) * 1;
         this.calculateField89 = Math.sin(value2) * 0.30000001192092896 + 0;
         this.chxot = Math.sin(value) * Math.cos(value2) * 1;
         this.glji = 40 + ThreadLocalRandom.current().nextInt(Math.max(1, 60));
      }

      this.motionX = (float)(this.motionX + (this.glgn - this.motionX) * 0.029999999329447746);
      this.motionY = (float)(this.motionY + (this.calculateField89 - this.motionY) * 0.029999999329447746);
      this.motionZ = (float)(this.motionZ + (this.chxot - this.motionZ) * 0.029999999329447746);
      double value3 = Math.sqrt(this.motionX * this.motionX + this.motionY * this.motionY + this.motionZ * this.motionZ);
      if (value3 > 0.001) {
         float value4 = Math.max(0.15F, WorldParticleModule.speed.getValue());
         double value5 = this.startField171 * value4;
         this.motionX = (float)(this.motionX / value3 * value5);
         this.motionY = (float)(this.motionY / value3 * value5);
         this.motionZ = (float)(this.motionZ / value3 * value5);
      }
   }

      private float removeMethod25(float fadeIn, float fadeOut) {
      if (this.maxAge <= 0) {
         return 0F;
      } else {
         float value = (float)this.age / this.maxAge;
         if (value > 1F - fadeIn) {
            return Math.max(0F, (1F - value) / Math.max(0.001F, fadeIn));
         } else {
            return value < fadeOut ? Math.max(0F, value / Math.max(0.001F, fadeOut)) : 1F;
         }
      }
   }

      private void uevzpe(VertexMatrixRenderer event, Camera camera, double worldX, double worldY, double worldZ, float size, int color, float alpha) {
      if (!(alpha <= 0F) && !(size <= 0F)) {
         int index = Math.max(0, Math.min(255, (int)(alpha * 255.0F)));
         if (index > 0) {
            int index2 = color & 16777215 | index << 24;
            Matrix4f matrix = createMethod89(event, camera, worldX, worldY, worldZ);
            WorldParticleBatcher.queueFireflyTrail(matrix, size, index2);
         }
      }
   }

      private void startMethod68(VertexMatrixRenderer event, Camera camera, double worldX, double worldY, double worldZ, float size, int color, float alpha) {
      if (!(alpha <= 0F) && !(size <= 0F)) {
         int index = Math.max(0, Math.min(255, (int)(alpha * 255.0F)));
         if (index > 0) {
            int index2 = color & 16777215 | index << 24;
            Matrix4f matrix = createMethod89(event, camera, worldX, worldY, worldZ);
            WorldParticleBatcher.queueFireflyGlow(matrix, size, index2);
         }
      }
   }

      private static Matrix4f createMethod89(VertexMatrixRenderer event, Camera camera, double worldX, double worldY, double worldZ) {
      controlField171.loadIdentity();
      controlField171.peek().getPositionMatrix().set(event.getStack().peek().getPositionMatrix());
      controlField171.translate(worldX, worldY, worldZ);
      controlField171.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
      controlField171.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
      controlField171.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180.0F));
      return MatrixEntityProvider.acquire(controlField171.peek().getPositionMatrix());
   }

      private static Matrix4f jppxah(Matrix4f baseMatrix, Vec3d worldPos, float yRotationDeg, float xRotationDeg) {
      return MatrixEntityProvider.acquire(baseMatrix)
         .translate((float)worldPos.x, (float)worldPos.y, (float)worldPos.z)
         .rotate(RotationAxis.POSITIVE_Y.rotationDegrees(yRotationDeg))
         .rotate(RotationAxis.POSITIVE_X.rotationDegrees(xRotationDeg));
   }

      private static int[] formatMethod760() {
      int[] intArray = new int[4];
      Arrays.fill(intArray, WorldParticleModule.isMethod25());
      return intArray;
   }

      private static Identifier ulinxh(ParticleModuleType style) {
      if (style != ParticleModuleType.PARTICLE) {
         return null;
      } else {
         return WorldParticleModule.AVAILABLE_TEXTURES.isEmpty()
            ? ParticleTextures.STAR
            : WorldParticleModule.AVAILABLE_TEXTURES.get(ThreadLocalRandom.current().nextInt(WorldParticleModule.AVAILABLE_TEXTURES.size()));
      }
   }

      private static int duzugu() {
      return WorldParticleModule.isMethod25();
   }

      private static float initMethod82(float value) {
      return Math.max(0F, Math.min(1F, value));
   }

      private static float isMethod0(float value) {
      float value2 = initMethod82(value);
      return value2 * value2 * (3.0F - 2.0F * value2);
   }

      private static int ecvjkn(int start, int end, float progress) {
      float value = initMethod82(progress);
      int index = start >> 16 & 0xFF;
      int index2 = start >> 8 & 0xFF;
      int index3 = start & 0xFF;
      int index4 = (int)(index + value * ((end >> 16 & 0xFF) - index));
      int index5 = (int)(index2 + value * ((end >> 8 & 0xFF) - index2));
      int index6 = (int)(index3 + value * ((end & 0xFF) - index3));
      return 0xFF000000 | index4 << 16 | index5 << 8 | index6;
   }

      protected static Vec3d interpolateWorldPos(VertexMatrixRenderer event, float prevPosX, float prevPosY, float prevPosZ, float posX, float posY, float posZ) {
      float value = event.getPartialTicks();
      double value2 = prevPosX + (posX - prevPosX) * value;
      double value3 = prevPosY + (posY - prevPosY) * value;
      double value4 = prevPosZ + (posZ - prevPosZ) * value;
      return new Vec3d(value2, value3, value4);
   }

}
