package winvi.noxiumvisuals.modules.visuals;

import java.util.List;
public record ColorModuleBounds(
   int width,
   int height,
   int[][] colors,
   List<ColorModuleStyle> pixels,
   List<VoxelSpan> faceRuns,
   List<VoxelSpan> topRuns,
   List<VoxelSpan> bottomRuns,
   List<VoxelSpan> leftRuns,
   List<VoxelSpan> rightRuns
) {

      public static ColorModuleBounds empty() {
      return new ColorModuleBounds(0, 0, new int[0][0], List.of(), List.of(), List.of(), List.of(), List.of(), List.of());
   }

      public int width() {
      return this.width;
   }

      public int height() {
      return this.height;
   }

      public int[][] colors() {
      return this.colors;
   }

      public List<ColorModuleStyle> pixels() {
      return this.pixels;
   }

      public List<VoxelSpan> faceRuns() {
      return this.faceRuns;
   }

      public List<VoxelSpan> topRuns() {
      return this.topRuns;
   }

      public List<VoxelSpan> bottomRuns() {
      return this.bottomRuns;
   }

      public List<VoxelSpan> leftRuns() {
      return this.leftRuns;
   }

      public List<VoxelSpan> rightRuns() {
      return this.rightRuns;
   }

   static {
      int index = 0;
   }
}
