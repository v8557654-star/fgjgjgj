package winvi.noxiumvisuals.modules.visuals;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.ui.hud.DraggableHudElement;
public final class ModuleLookup {
      private static final ConcurrentMap<Class<? extends Module>, Module> ffx = new ConcurrentHashMap<>();
      private static final ConcurrentMap<Class<? extends DraggableHudElement>, DraggableHudElement> ffy = new ConcurrentHashMap<>();

      public static <T extends Module> T get(Class<T> clazz) {
      return (T)clazz.cast(ffx.computeIfAbsent(clazz, instance -> {
         return NoxiumVisuals.getInstance().getModuleProvider().get((Class<? extends Module>)instance);
      }));
   }

      public static <T extends Module> T get(String module) {
      return NoxiumVisuals.getInstance().getModuleProvider().get(module);
   }

      public static <T extends DraggableHudElement> T getDraggable(Class<T> clazz) {
      return (T)clazz.cast(ffy.computeIfAbsent(clazz, instance -> {
         return NoxiumVisuals.getInstance().getDraggableRepository().get((Class<? extends DraggableHudElement>)instance);
      }));
   }

      public static <T extends DraggableHudElement> T getDraggable(String draggable) {
      return NoxiumVisuals.getInstance().getDraggableRepository().get(draggable);
   }

   private ModuleLookup() {
      throw new UnsupportedOperationException(
         "This is a utility class and cannot be instantiated"
      );
   }

}
