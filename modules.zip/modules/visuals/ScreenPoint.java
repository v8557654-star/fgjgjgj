package winvi.noxiumvisuals.modules.visuals;

public record ScreenPoint(
   float x,
   float y
) {

      public float x() {
      return this.x;
   }

      public float y() {
      return this.y;
   }

   static {
      int index = 0;
   }
}
