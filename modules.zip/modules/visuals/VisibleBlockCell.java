package winvi.noxiumvisuals.modules.visuals;

public class VisibleBlockCell {
      public final BlockPositionRenderRenderer cell;
      public final double distanceSq;

   public VisibleBlockCell(BlockPositionRenderRenderer cell, double distanceSq) {
      this.cell = cell;
      this.distanceSq = distanceSq;
   }

}
