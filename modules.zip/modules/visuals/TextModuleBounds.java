package winvi.noxiumvisuals.modules.visuals;

public record TextModuleBounds(
   float x,
   float y,
   float width,
   float height,
   float textX,
   float fieldY,
   float textWidth
) {

      public float x() {
      return this.x;
   }

      public float y() {
      return this.y;
   }

      public float width() {
      return this.width;
   }

      public float height() {
      return this.height;
   }

      public float textX() {
      return this.textX;
   }

      public float fieldY() {
      return this.fieldY;
   }

      public float textWidth() {
      return this.textWidth;
   }

   static {
      int index = 0;
   }
}
