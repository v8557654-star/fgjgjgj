package winvi.noxiumvisuals.modules.visuals;

import java.util.List;
import net.minecraft.util.math.Vec3d;
public record ModelModuleData(
   List<Vec3d> points,
   Vec3d direction,
   Vec3d surfaceNormal,
   boolean hit,
   Vec3d modelPosition
) {

   public ModelModuleData(List<Vec3d> points, Vec3d direction, Vec3d surfaceNormal, boolean hit) {
      this(points, direction, surfaceNormal, hit, null);
   }

      public Vec3d eae() {
      return this.modelPosition != null ? this.modelPosition : this.points.get(this.points.size() - 1);
   }

      public List<Vec3d> points() {
      return this.points;
   }

      public Vec3d direction() {
      return this.direction;
   }

      public Vec3d surfaceNormal() {
      return this.surfaceNormal;
   }

      public boolean hit() {
      return this.hit;
   }

      public Vec3d modelPosition() {
      return this.modelPosition;
   }

}
