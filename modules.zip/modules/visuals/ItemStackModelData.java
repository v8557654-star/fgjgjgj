package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.item.ItemStack;
public record ItemStackModelData(
   ItemStack modelStack,
   float speed,
   double gravity,
   float airDrag,
   float waterDrag,
   float pitchOffset,
   float spreadOffset,
   ProjectileType modelType
) {

      public ItemStack modelStack() {
      return this.modelStack;
   }

      public float speed() {
      return this.speed;
   }

      public double gravity() {
      return this.gravity;
   }

      public float airDrag() {
      return this.airDrag;
   }

      public float waterDrag() {
      return this.waterDrag;
   }

      public float pitchOffset() {
      return this.pitchOffset;
   }

      public float spreadOffset() {
      return this.spreadOffset;
   }

      public ProjectileType modelType() {
      return this.modelType;
   }

}
