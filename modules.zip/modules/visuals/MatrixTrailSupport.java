package winvi.noxiumvisuals.modules.visuals;

import java.util.List;
import org.joml.Matrix4f;
public final class MatrixTrailSupport {
      public Matrix4f hasField750;
      public List<ColorEntityManager> validateField15;

   public MatrixTrailSupport() {
   }

      public void dyvp(Matrix4f matrix, List<ColorEntityManager> trails) {
      this.hasField750 = matrix;
      this.validateField15 = trails;
   }

      public void yqszze() {
      this.hasField750 = null;
      this.validateField15 = null;
   }

}
