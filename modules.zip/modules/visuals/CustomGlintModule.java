package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.glint.CustomGlintLifecycle;
import winvi.noxiumvisuals.systems.glint.PlayerGlintSupport;
public final class CustomGlintModule extends Module {
      private final BooleanSetting stopField80;
      private final BooleanSetting destroyField43;
      private final NumberSetting trnpe;
      private final NumberSetting eea;
      private final NumberSetting bmzvy;
      private final NumberSetting nnvak;
      private volatile PlayerGlintSupport d15;

   public CustomGlintModule() {
      super("Custom Glint", ModuleCategory.VISUAL);
      this.stopField80 = transformMethod8(
         "Item Glow",
         "Shader glow for enchanted items",
         true
      );
      this.destroyField43 = transformMethod8(
         "Armor Glow",
         "Shader glow for enchanted armor",
         true
      );
      this.trnpe = deleteMethod280(
         "Glow Intensity",
         "Shader glow brightness",
         117,
         0,
         300
      );
      this.eea = deleteMethod280(
         "Glow Spread",
         "Shader glow radius",
         13,
         1,
         100
      );
      this.bmzvy = deleteMethod280(
         "Glow Quality",
         "Number of shader blur passes",
         3,
         1,
         4
      );
      this.nnvak = deleteMethod280(
         "Glow Resolution",
         "Higher values improve performance",
         6,
         2,
         8
      );
      this.d15 = new PlayerGlintSupport();
      this.setup(new ModuleSetting[]{this.stopField80, this.destroyField43, this.trnpe, this.eea, this.bmzvy, this.nnvak});
      this.ufoubw();
   }

      @Override
   public void activate() {
      this.ufoubw();
      CustomGlintLifecycle.forceRefresh();
   }

      @Override
   public void deactivate() {
      CustomGlintLifecycle.forceRefresh();
   }

      public PlayerGlintSupport createRenderConfig() {
      return this.d15;
   }

      public void updateRenderConfig() {
      this.ufoubw();
   }

      private void ufoubw() {
      PlayerGlintSupport playerGlintSupport = new PlayerGlintSupport();
      playerGlintSupport.itemGlintBloomEnabled = this.stopField80.isValue();
      playerGlintSupport.armorGlintBloomEnabled = this.destroyField43.isValue();
      playerGlintSupport.glintBloomIntensity = this.trnpe.getInt();
      playerGlintSupport.glintBloomSpread = this.eea.getInt();
      playerGlintSupport.glintBloomQuality = this.bmzvy.getInt();
      playerGlintSupport.bloomResolutionDivisor = this.nnvak.getInt();
      this.d15 = playerGlintSupport;
   }

      private static BooleanSetting transformMethod8(String name, String description, boolean value) {
      return new BooleanSetting(name, description).setValue(value);
   }

      private static NumberSetting deleteMethod280(String name, String description, int value, int min, int max) {
      return new NumberSetting(name, description).setValue(value).range(min, max);
   }

}
