package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.Vec3d;
public record FragmentVelocity(
   Vec3d velocity,
   float width
) {

      public Vec3d velocity() {
      return this.velocity;
   }

      public float width() {
      return this.width;
   }

}
