package winvi.noxiumvisuals.modules.visuals;

public class HitBubbleParticle {
      public final float x;
      public final float y;
      public final float z;
      public final float yaw;
      public final float pitch;
      public float life;

   public HitBubbleParticle(float x, float y, float z, float yaw, float pitch, float life) {
      this.x = x;
      this.y = y;
      this.z = z;
      this.yaw = yaw;
      this.pitch = pitch;
      this.life = life;
   }

   static {
      int index = 0;
   }
}
