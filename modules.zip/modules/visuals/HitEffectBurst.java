package winvi.noxiumvisuals.modules.visuals;

import java.util.List;
import net.minecraft.util.math.Vec3d;
public record HitEffectBurst(
   Vec3d origin,
   long startedAt,
   long durationMs,
   int color,
   List<FragmentVelocity> fragments
) {

      public Vec3d origin() {
      return this.origin;
   }

      public long startedAt() {
      return this.startedAt;
   }

      public long durationMs() {
      return this.durationMs;
   }

      public int color() {
      return this.color;
   }

      public List<FragmentVelocity> fragments() {
      return this.fragments;
   }

}
