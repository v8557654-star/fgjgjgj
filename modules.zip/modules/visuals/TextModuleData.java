package winvi.noxiumvisuals.modules.visuals;

public record TextModuleData(
   String text,
   boolean selected
) {

      public String text() {
      return this.text;
   }

      public boolean selected() {
      return this.selected;
   }

   static {
      int index = 0;
   }
}
