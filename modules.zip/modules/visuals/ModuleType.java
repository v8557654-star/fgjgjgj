package winvi.noxiumvisuals.modules.visuals;

public enum ModuleType {
      INVENTORY,
      SHULKER,
      SHULKER_INVENTORY;

}
