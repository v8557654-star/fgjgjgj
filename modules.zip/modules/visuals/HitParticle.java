package winvi.noxiumvisuals.modules.visuals;

import java.awt.Color;
import java.util.Arrays;
import net.minecraft.block.AirBlock;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.shape.VoxelShape;
import winvi.noxiumvisuals.modules.particles.HitParticlesModule;
import winvi.noxiumvisuals.utils.ClientPosition;
import winvi.noxiumvisuals.utils.ParticleInstance;
import winvi.noxiumvisuals.utils.ParticlePhysics;
import winvi.noxiumvisuals.utils.render.WorldParticleBatcher;
import winvi.noxiumvisuals.utils.ParticleCameraRenderer;
import winvi.noxiumvisuals.utils.render.RenderMath;
public class HitParticle extends ParticleInstance {
   private final HitParticlesModule this$0;
      float rotationAngle;
      float rotationSpeed;
      long time;
      Identifier texture;
      float alpha;
      float particleScale;
      final long lifeTimeMs;
      final float speedMultiplier;
      protected final int[] gradientColors;

   public HitParticle(final HitParticlesModule this$0, float x, float y, float z, Color color, float rotationAngle, float rotationSpeed) {
      super(x, y, z);
      this.this$0 = this$0;
      this.alpha = 1F;
      this.time = System.currentTimeMillis();
      this.lifeTimeMs = (long)(this$0.q20.getValue() * 1000.0F);
      this.speedMultiplier = 0.55F + (this$0.ddyzb.getValue() - 1F) / 4.0F * 1.1F;
      this.rotationAngle = rotationAngle;
      this.rotationSpeed = rotationSpeed;
      this.particleScale = this$0.updateField311.getValue();
      boolean enabled = this.dyhn();
      this.motionX = RenderMath.random(-0.03F, 0.03F);
      this.motionY = enabled ? RenderMath.random(0.012F, 0.05F) : RenderMath.random(0.004F, 0.03F);
      this.motionZ = RenderMath.random(-0.03F, 0.03F);
      this.gradientColors = new int[4];
      Arrays.fill(this.gradientColors, this$0.getVisualColor());
      if (!this$0.dsv.isEmpty()) {
         this.texture = this$0.dsv.get(HitParticlesModule.dswf.nextInt(this$0.dsv.size()));
      }
   }

      @Override
   public boolean update(long currentTime, boolean isVisible) {
      this.px = this.x;
      this.py = this.y;
      this.pz = this.z;
      ClientPosition clientPosition = this.dyhn()
         ? ParticlePhysics.bounce(this.x, this.y, this.z, this.motionX, this.motionY, this.motionZ, this.speedMultiplier, 0.0018F)
         : ParticlePhysics.drift(this.x, this.y, this.z, this.motionX, this.motionY, this.motionZ, this.speedMultiplier, -6.0E-4F);
      this.x = clientPosition.x();
      this.y = clientPosition.y();
      this.z = clientPosition.z();
      this.motionX = clientPosition.motionX();
      this.motionY = clientPosition.motionY();
      this.motionZ = clientPosition.motionZ();
      long timestamp = currentTime - this.time;
      float value = Math.min(1F, (float)timestamp / (float)this.lifeTimeMs);
      float value2 = 1F;
      float value3 = this.particleScale;
      if (value < 0.2F) {
         value2 = value / 0.2F;
      }

      if (value >= 0.8F) {
         float value4 = 1F - (value - 0.8F) / 0.2F;
         if (this.this$0.opmng.getSelected().equals("ALPHA")) {
            value2 = value4;
            this.alpha = value4;
         } else if (this.this$0.opmng.getSelected().equals("SCALE")) {
            value3 = this.particleScale * value4;
         }
      }

      if (value < 0.2F && this.this$0.opmng.getSelected().equals("SCALE")) {
         value2 = value / 0.2F;
      }

      if (value >= 1F) {
         if (this.this$0.opmng.getSelected().equals("ALPHA")) {
            return value2 <= 0F;
         }

         if (this.this$0.opmng.getSelected().equals("SCALE")) {
            return value3 <= 0F;
         }
      }

      return false;
   }

      public boolean update() {
      return this.update(System.currentTimeMillis(), true);
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (this.this$0.isState()) {
         long timestamp = System.currentTimeMillis();
         long timestamp2 = timestamp - this.time;
         float value = Math.min(1F, (float)timestamp2 / (float)this.lifeTimeMs);
         float value2 = this.particleScale;
         float value3 = 1F;
         if (value < 0.2F) {
            value3 = value / 0.2F;
         }

         if (value >= 0.8F) {
            float value4 = 1F - (value - 0.8F) / 0.2F;
            if (this.this$0.opmng.getSelected().equals("ALPHA")) {
               value3 = value4;
            } else if (this.this$0.opmng.getSelected().equals("SCALE")) {
               value2 = this.particleScale * value4;
            }
         }

         if (value < 0.2F && this.this$0.opmng.getSelected().equals("SCALE")) {
            value3 = value / 0.2F;
         }

         if (!(value3 <= 0F) && !(value2 <= 0F)) {
            if (ParticleCameraRenderer.isParticleVisible(this.getX(), this.getY(), this.getZ(), value2 * 0.07F)) {
               float value5 = 0.07F;
               double value6 = MathHelper.lerp(tickDelta, this.px, this.x);
               double value7 = MathHelper.lerp(tickDelta, this.py, this.y);
               double value8 = MathHelper.lerp(tickDelta, this.pz, this.z);
               matrixStack.push();
               matrixStack.translate(value6, value7, value8);
               matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getYaw()));
               matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getPitch()));
               int client = Math.max(30, MinecraftClient.getInstance().getCurrentFps());
               matrixStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(this.rotationAngle = this.rotationAngle + 1F / client * this.rotationSpeed));
               if (this.texture != null) {
                  WorldParticleBatcher.queueGhostParticle(matrixStack, this.texture, value5 * value2, value3, this.gradientColors[0], true, this.gradientColors);
               }

               matrixStack.pop();
            }
         }
      }
   }

      private boolean dyhn() {
      return !"FLY".equals(this.this$0.convertField74.getSelected());
   }

      private float dyiq() {
      return 0.03F + this.particleScale * 0.012F;
   }

      private boolean yvphfm(double x, double y, double z, float radius) {
      return this.vxttwu(x, y, z)
         || this.vxttwu(x + radius, y, z)
         || this.vxttwu(x - radius, y, z)
         || this.vxttwu(x, y, z + radius)
         || this.vxttwu(x, y, z - radius)
         || this.vxttwu(x, y + radius, z)
         || this.vxttwu(x, y - radius, z);
   }

      private boolean vxttwu(double x, double y, double z) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         BlockPos blockPos = BlockPos.ofFloored(x, y, z);
         BlockState client = MinecraftClient.getInstance().world.getBlockState(blockPos);
         if (!(client.getBlock() instanceof AirBlock) && !client.isAir()) {
            VoxelShape client2 = client.getCollisionShape(MinecraftClient.getInstance().world, blockPos);
            return !client2.isEmpty();
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

}
