package winvi.noxiumvisuals.modules.visuals;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import winvi.noxiumvisuals.modules.Module;
public class ModuleProvider {
      private final List<Module> dgya;
      private final List<Module> dhkb;
      private final Map<Class<? extends Module>, Module> transformField55 = new HashMap<>();
      private final Map<String, Module> validateField48 = new HashMap<>();

   public ModuleProvider(List<Module> modules) {
      this(modules, modules);
   }

   public ModuleProvider(List<Module> modules, List<Module> lookupModules) {
      this.dgya = modules;
      this.dhkb = lookupModules;

      for (Module module : lookupModules) {
         this.transformField55.put((Class<? extends Module>)module.getClass(), module);
         this.validateField48.put(module.getName().toLowerCase(), module);
      }
   }

      public <T extends Module> T get(String name) {
      return (T)this.validateField48.get(name.toLowerCase());
   }

      public <T extends Module> T get(Class<T> clazz) {
      return (T)this.transformField55.get(clazz);
   }

      public List<Module> getModules() {
      return this.dgya;
   }

      public List<Module> getLookupModules() {
      return this.dhkb;
   }

      public Map<Class<? extends Module>, Module> getClassCache() {
      return this.transformField55;
   }

      public Map<String, Module> getNameCache() {
      return this.validateField48;
   }

}
