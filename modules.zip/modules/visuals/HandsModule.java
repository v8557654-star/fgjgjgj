package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.HandEffectStrengths;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.utils.JsonFileRenderer;
import winvi.noxiumvisuals.utils.render.GlassDownsampleHandShader;
import winvi.noxiumvisuals.utils.render.GlitchHandShader;
import winvi.noxiumvisuals.utils.render.OutlineHandShader;
import winvi.noxiumvisuals.utils.render.BlurredMaterialShader;
import winvi.noxiumvisuals.utils.render.GlassCompositeHandShader;
import winvi.noxiumvisuals.utils.render.ColorHandRenderer;
import winvi.noxiumvisuals.utils.render.MaskCompositeRenderer;
import winvi.noxiumvisuals.utils.render.ShaderFramebufferRegistry;
import winvi.noxiumvisuals.utils.render.FullscreenShaderPass;
public class HandsModule extends Module {
      public static final MultiSelectSetting renderMode;
      public static final ChoiceSetting shaderMode;
      private final ChoiceSetting initField950;
      private final NumberSetting zbygf;
      private final NumberSetting calculateField320;
      private final NumberSetting uvkys;
      private final NumberSetting egdz;
      private final BooleanSetting coblh;
      private final BooleanSetting egf;
      private final NumberSetting ffzul;
      private final NumberSetting parseField22;
      private final NumberSetting i17;
      private final NumberSetting j24;
      private final NumberSetting isField53;
      private final NumberSetting egl;
      private final NumberSetting m22;
      private final BooleanSetting jsdat;
      private final ChoiceSetting manageField72;
      private final ColorSetting asayj;
      private final NumberSetting ngfle;
      private final NumberSetting r17;
      private final BooleanSetting egsy;
      private final BooleanSetting processField89;
      private boolean executeField40;
      private static boolean removeField78 = false;
      private static boolean egwf = false;
      private static boolean egxa = false;
      private static boolean startField510 = false;
      private static float egzo = 0F;
      private static float awrxp = 1.2F;
      private static float processField56 = 1F;
      private static final MaskCompositeRenderer computeField610 = new MaskCompositeRenderer();
      private static List<String> ehdl = List.of();
      private static boolean ybhpx;

   public HandsModule() {
      super("Hands", ModuleCategory.VISUAL);
      this.initField950 = new ChoiceSetting(
            "Glow Style",
            "Glow rendering style"
         )
         .value(
            "Soft",
            "Classic"
         )
         .selected("Soft")
         .visible(() -> {
            return renderMode.isSelected("Glow");
         });
      this.zbygf = new NumberSetting(
            "Shader Speed",
            "Animation speed for hands shaders"
         )
         .setValue(1F)
         .range(0F, 2.0F)
         .visible(() -> {
            return renderMode.isSelected("Shader");
         });
      this.calculateField320 = new NumberSetting(
            "Shader Opacity",
            "Shader opacity"
         )
         .setValue(100.0F)
         .range(0F, 100.0F)
         .visible(
            () -> {
               return renderMode.isSelected("Shader")
                  && !shaderMode.isSelected("Glass")
                  && !shaderMode.isSelected("Glitch");
            }
         );
      this.uvkys = new NumberSetting(
            "Smoke Speed",
            "Smoke animation speed"
         )
         .setValue(1F)
         .range(0F, 2.0F)
         .visible(() -> {
            return renderMode.isSelected("Smoke");
         });
      this.egdz = new NumberSetting(
            "Smoke Opacity",
            "Smoke effect opacity"
         )
         .setValue(100.0F)
         .range(0F, 100.0F)
         .visible(() -> {
            return renderMode.isSelected("Smoke");
         });
      this.coblh = new BooleanSetting(
            "Texture Color",
            "Use the rendered item texture color for smoke"
         )
         .setValue(false)
         .visible(() -> {
            return renderMode.isSelected("Smoke");
         });
      this.egf = new BooleanSetting(
            "Outline Only",
            "Emit smoke only along the hand and item contour"
         )
         .setValue(false)
         .visible(() -> {
            return renderMode.isSelected("Smoke");
         });
      this.ffzul = new NumberSetting(
            "Blur Strength",
            "Blur strength for glass hands"
         )
         .setValue(4.0F)
         .range(1, 5)
         .visible(
            () -> {
               return renderMode.isSelected("Shader")
                  && shaderMode.isSelected("Glass");
            }
         );
      this.parseField22 = new NumberSetting(
            "Blur Brightness",
            "Brightness for glass hands blur"
         )
         .setValue(1F)
         .range(0F, 2.0F)
         .visible(
            () -> {
               return renderMode.isSelected("Shader")
                  && shaderMode.isSelected("Glass");
            }
         );
      this.i17 = new NumberSetting(
            "Glitch Amount",
            "Slice and channel shift amount for glitch hands"
         )
         .setValue(0.2F)
         .range(0F, 1F)
         .visible(
            () -> {
               return renderMode.isSelected("Shader")
                  && shaderMode.isSelected("Glitch");
            }
         );
      this.j24 = new NumberSetting(
            "Glow Width",
            "Soft glow blur width"
         )
         .setValue(1.2F)
         .range(0.1F, 5.0F)
         .visible(
            () -> {
               return renderMode.isSelected("Glow")
                  && this.initField950.isSelected("Soft");
            }
         );
      this.isField53 = new NumberSetting(
            "Glow Strength",
            "Soft glow strength"
         )
         .setValue(1F)
         .range(0.01F, 5.0F)
         .visible(
            () -> {
               return renderMode.isSelected("Glow")
                  && this.initField950.isSelected("Soft");
            }
         );
      this.egl = new NumberSetting(
            "Glow Opacity",
            "Soft glow opacity"
         )
         .setValue(1F)
         .range(0F, 1F)
         .visible(
            () -> {
               return renderMode.isSelected("Glow")
                  && this.initField950.isSelected("Soft");
            }
         );
      this.m22 = new NumberSetting(
            "Glow Opacity",
            "Glow opacity"
         )
         .setValue(55.0F)
         .range(0F, 100.0F)
         .visible(
            () -> {
               return renderMode.isSelected("Glow")
                  && this.initField950.isSelected("Classic");
            }
         );
      this.jsdat = new BooleanSetting(
            "Inner Glow",
            "Apply glow inside hands"
         )
         .setValue(false)
         .visible(
            () -> {
               return renderMode.isSelected("Glow")
                  && this.initField950.isSelected("Classic");
            }
         );
      this.manageField72 = new ChoiceSetting(
            "Outline Color Source",
            "Outline color source"
         )
         .value(
            "Visual Color",
            "Custom"
         )
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .selected("Custom")
         .visible(() -> {
            return renderMode.isSelected("Outline");
         });
      this.asayj = new ColorSetting(
            "Outline Color",
            "Custom outline color"
         )
         .setColor(-65536)
         .visible(
            () -> {
               return renderMode.isSelected("Outline")
                  && this.manageField72.isSelected("Custom");
            }
         );
      this.ngfle = new NumberSetting(
            "Glow Intensity",
            "Glow intensity"
         )
         .setValue(3.0F)
         .range(1F, 20.0F)
         .visible(
            () -> {
               return renderMode.isSelected("Glow")
                  && this.initField950.isSelected("Classic");
            }
         );
      this.r17 = new NumberSetting(
            "Outline Thickness",
            "Outline thickness"
         )
         .setValue(2.0F)
         .range(1F, 8.0F)
         .visible(() -> {
            return renderMode.isSelected("Outline");
         });
      this.egsy = new BooleanSetting(
            "Show Vanilla Hand",
            "Keep vanilla hand/item visible under overlay"
         )
         .setValue(true)
         .visible(
            () -> {
               return (
                     !renderMode.isSelected("Shader")
                        || !shaderMode.isSelected("Glass")
                           && !shaderMode.isSelected("Glitch")
                  )
                  && (
                     renderMode.isSelected("Shader")
                        || renderMode.isSelected("Outline")
                        || renderMode.isSelected("Smoke")
                  );
            }
         );
      this.processField89 = new BooleanSetting(
            "Enchantment Glint",
            "Enchantment effect"
         )
         .setValue(false);
      this.executeField40 = false;
      this.showVisualColorSettings(
         () -> {
            return renderMode.isSelected("Glow")
               || renderMode.isSelected("Shader")
               || renderMode.isSelected("Smoke");
         }
      );
      renderMode.displayFormatter(HandsModule::iezljk);
      renderMode.withTranslation("hands.rendermode", "hands.rendermode.desc");
      this.initField950.displayFormatter(HandsModule::ctc);
      this.initField950.withTranslation("hands.glowstyle", "hands.glowstyle.desc");
      shaderMode.displayFormatter(HandsModule::b18);
      shaderMode.withTranslation("hands.shadermode", "hands.shadermode.desc");
      this.zbygf.withTranslation("hands.shaderspeed", "hands.shaderspeed.desc");
      this.calculateField320.withTranslation("hands.shaderopacity", "hands.shaderopacity.desc");
      this.uvkys.withTranslation("hands.smokespeed", "hands.smokespeed.desc");
      this.egdz.withTranslation("hands.smokeopacity", "hands.smokeopacity.desc");
      this.coblh.withTranslation("hands.smoketexturecolor", "hands.smoketexturecolor.desc");
      this.egf.withTranslation("hands.smokeoutlineonly", "hands.smokeoutlineonly.desc");
      this.ffzul.withTranslation("hands.glassstrength", "hands.glassstrength.desc");
      this.parseField22.withTranslation("hands.glassbrightness", "hands.glassbrightness.desc");
      this.i17.withTranslation("hands.glitchamount", "hands.glitchamount.desc");
      this.j24.withTranslation("hands.softglowwidth", "hands.softglowwidth.desc");
      this.isField53.withTranslation("hands.softglowstrength", "hands.softglowstrength.desc");
      this.egl.withTranslation("hands.softglowopacity", "hands.softglowopacity.desc");
      this.m22.withTranslation("hands.itemglowopacity", "hands.itemglowopacity.desc");
      this.jsdat.withTranslation("hands.iteminnerglow", "hands.iteminnerglow.desc");
      this.manageField72.withTranslation("hands.itemoutlinecolorsource", "hands.itemoutlinecolorsource.desc");
      this.asayj.withTranslation("hands.itemoutlinecolor", "hands.itemoutlinecolor.desc");
      this.ngfle.withTranslation("hands.itemglowintensity", "hands.itemglowintensity.desc");
      this.r17.withTranslation("hands.itemoutlinethickness", "hands.itemoutlinethickness.desc");
      this.egsy.withTranslation("hands.showvanillahand", "hands.showvanillahand.desc");
      this.processField89.withTranslation("hands.enableenchantmentglint", "hands.enableenchantmentglint.desc");
      renderMode.onChange(selected -> {
         ovotcz(selected);
         if (!renderMode.isSelected("Smoke")) {
            computeField610.reset();
         }
      });
      shaderMode.onChange(selected -> {
         ovotcz(renderMode.getSelected());
      });
      ovotcz(renderMode.getSelected());
      this.setup(
         new ModuleSetting[]{
            renderMode,
            this.initField950,
            shaderMode,
            this.calculateField320,
            this.zbygf,
            this.uvkys,
            this.egdz,
            this.coblh,
            this.egf,
            this.ffzul,
            this.parseField22,
            this.i17,
            this.j24,
            this.isField53,
            this.egl,
            this.m22,
            this.jsdat,
            this.manageField72,
            this.asayj,
            this.ngfle,
            this.r17,
            this.egsy,
            this.processField89
         }
      );
   }

      private static void ovotcz(List<String> selectedModes) {
      if (!ybhpx && selectedModes != null) {
         ArrayList arrayList = new ArrayList(selectedModes);
         if (arrayList.contains("Smoke")
            && arrayList.contains("Shader")) {
            boolean enabled = !ehdl.contains("Smoke");
            boolean enabled2 = !ehdl.contains("Shader");
            if (enabled && !enabled2) {
               arrayList.remove("Shader");
            } else {
               arrayList.remove("Smoke");
            }
         }

         ybhpx = true;

         try {
            if (!arrayList.equals(selectedModes)) {
               renderMode.setSelected(arrayList);
            }

            ehdl = List.copyOf(arrayList);
            if (!arrayList.contains("Smoke")) {
               computeField610.reset();
            }
         } finally {
            ybhpx = false;
         }
      }
   }

      private static String iezljk(String value) {
      return oofduu("hands.rendermode", value);
   }

      private static String b18(String value) {
      return oofduu("hands.shadermode", value);
   }

      private static String ctc(String value) {
      return oofduu("hands.glowstyle", value);
   }

      private static boolean ctd() {
      return shaderMode.isSelected("Nebula")
         || shaderMode.isSelected("Vortex")
         || shaderMode.isSelected("Mist");
   }

      private static String oofduu(String groupKey, String value) {
      if (value != null && !value.isBlank()) {
         String text = groupKey + "." + value.toLowerCase(Locale.ROOT);
         String text2 = JsonFileRenderer.get(text);
         return text.equals(text2) ? value : text2;
      } else {
         return "";
      }
   }

      public boolean hasGlow() {
      return this.isState() && renderMode.isSelected("Glow");
   }

      public boolean hasShader() {
      return this.isState() && renderMode.isSelected("Shader");
   }

      public boolean hasOutline() {
      return this.isState() && renderMode.isSelected("Outline");
   }

      public boolean hasSmoke() {
      return this.isState() && renderMode.isSelected("Smoke");
   }

      public boolean hasItemOverlay() {
      return this.hasGlow() && this.isClassicGlowStyle();
   }

      public boolean hasGlowPostProcess() {
      return this.hasSoftGlowWork() && !this.usesDirectSoftGlow();
   }

      public boolean usesDirectSoftGlow() {
      return this.hasSoftGlowWork() && !this.hasShader() && !this.hasOutline() && !this.hasSmoke();
   }

      public boolean hasHandPostProcess() {
      return this.hasShader() || this.hasOutline() || this.hasSmoke() || this.hasGlowPostProcess() || this.usesDirectSoftGlow();
   }

      public boolean hasAnyEnabledEffect() {
      return this.hasItemOverlay() || this.hasHandPostProcess();
   }

      public boolean isItemChamsActive() {
      return this.executeField40;
   }

      public void setItemChamsActive(boolean active) {
      this.executeField40 = active;
   }

      public Color getItemGlowColor() {
      Color color = new Color(this.getVisualColor(), true);
      int index = (int)(255.0F * this.getItemGlowOpacity());
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.min(255, Math.max(0, index)));
   }

      public Color getItemOutlineColor() {
      int index = this.resolveVisualOrCustomColor(this.manageField72, this.asayj);
      return new Color(index >> 16 & 0xFF, index >> 8 & 0xFF, index & 0xFF, index >> 24 & 0xFF);
   }

      public float getItemOutlineThickness() {
      return this.r17.getValue();
   }

      public boolean shouldShowVanillaHand() {
      if (!this.hasShader()
         || !shaderMode.isSelected("Glass")
            && !shaderMode.isSelected("Glitch")) {
         return this.hasGlow() && !this.hasShader() && !this.hasOutline() ? true : this.egsy.isValue();
      } else {
         return false;
      }
   }

      public int getItemLayers() {
      return Math.max(3, Math.min(6, (int)(3.0F + this.ngfle.getValue() * 0.15F)));
   }

      public float getItemLayerSize() {
      return 1.2F + this.ngfle.getValue() * 0.4F;
   }

      public float getItemFalloff() {
      return 6.0F + this.ngfle.getValue() * 2.0F;
   }

      public float getItemGlowOpacity() {
      return Math.max(0F, Math.min(1F, this.m22.getValue() / 100.0F));
   }

      public boolean isInnerGlowEnabled() {
      return this.jsdat.isValue();
   }

      public boolean isClassicGlowStyle() {
      return this.initField950.isSelected("Classic");
   }

      public boolean isSoftGlowStyle() {
      return this.initField950.isSelected("Soft");
   }

      public boolean isEnchantmentGlintEnabled() {
      return this.processField89.isValue();
   }

      public int getItemIterations() {
      return Math.max(2, Math.min(5, (int)(this.ngfle.getValue() / 4.0F)));
   }

      public int getSoftGlowIterations() {
      return Math.max(3, Math.min(8, 4 + Math.round(this.getSoftGlowWidth() * 0.7F)));
   }

      public float getSoftGlowStrength() {
      return Math.max(0.01F, Math.min(5.0F, this.isField53.getValue()));
   }

      public float getSoftGlowWidth() {
      return Math.max(0.1F, Math.min(5.0F, this.j24.getValue()));
   }

      public float getSoftGlowOpacity() {
      return Math.max(0F, Math.min(1F, this.egl.getValue()));
   }

      public boolean hasSoftGlow() {
      return this.getSoftGlowStrength() > 0.001F && this.getSoftGlowOpacity() > 0.001F;
   }

      public boolean hasSoftGlowWork() {
      return this.hasGlow() && this.isSoftGlowStyle() && this.hasSoftGlow();
   }

      public int getSoftGlowBatchFrames() {
      return 4;
   }

      public static void setSkipItemChams(boolean skip) {
      removeField78 = skip;
   }

      public static boolean shouldSkipItemChams() {
      return removeField78;
   }

      public static void setCaptureHandsPostProcess(boolean capture) {
      egwf = capture;
   }

      public static boolean isCaptureHandsPostProcess() {
      return egwf;
   }

      public static void captureSceneSnapshot(Framebuffer sourceFbo) {
      ShaderFramebufferRegistry.initShadersIfNeeded();
      if (ShaderFramebufferRegistry.isInitialized() && sourceFbo != null) {
         ShaderFramebufferRegistry.checkFramebuffers();
         SimpleFramebuffer simpleFramebuffer = ShaderFramebufferRegistry.getCopyFbo();
         if (simpleFramebuffer == null) {
            egxa = false;
         } else {
            transformMethod860(sourceFbo, simpleFramebuffer);
            egxa = true;
         }
      } else {
         egxa = false;
      }
   }

      public static void clearCapturedSceneSnapshot() {
      egxa = false;
   }

      private static boolean oixntc() {
      boolean enabled = egxa;
      egxa = false;
      return enabled;
   }

      public Color getClientShaderColor() {
      return new Color(this.getVisualColor(), true);
   }

      public float getShaderOpacity() {
      return Math.max(0F, Math.min(1F, this.calculateField320.getValue() / 100.0F));
   }

      public int getGlassBlurStrength() {
      return Math.max(1, Math.min(5, this.ffzul.getInt()));
   }

      public float getGlassBlurBrightness() {
      return this.parseField22.getValue();
   }

      public float getGlitchAmount() {
      return Math.max(0F, Math.min(1F, this.i17.getValue()));
   }

      public float getShaderSpeed() {
      return Math.max(0F, Math.min(2.0F, this.zbygf.getValue()));
   }

      public float getSmokeSpeed() {
      return Math.max(0F, Math.min(2.0F, this.uvkys.getValue()));
   }

      public float getSmokeOpacity() {
      return Math.max(0F, Math.min(1F, this.egdz.getValue() / 100.0F));
   }

      public boolean shouldUseSmokeTextureColor() {
      return this.coblh.isValue();
   }

      public boolean isSmokeOutlineOnly() {
      return this.egf.isValue();
   }

      public boolean isSkyColorShaderSelected() {
      return ctd();
   }

      @Override
   public void deactivate() {
      computeField610.reset();
   }

      public int getSkyColorShaderStyleIndex() {
      String text = shaderMode.getSelected();

      return switch (text) {
         case "Vortex" -> 1;
         case "Mist" -> 2;
         default -> 0;
      };
   }

      public static void render(float farPlaneDistance) {
      render(farPlaneDistance, MinecraftClient.getInstance().getFramebuffer());
   }

      public static void render(float farPlaneDistance, Framebuffer sourceFbo) {
      ShaderFramebufferRegistry.initShadersIfNeeded();
      if (ShaderFramebufferRegistry.isInitialized() && sourceFbo != null) {
         ShaderFramebufferRegistry.checkFramebuffers();
         destroyMethod2(farPlaneDistance, sourceFbo);
      }
   }

      private static void destroyMethod2(float farPlaneDistance, Framebuffer sourceFbo) {
      Framebuffer client = MinecraftClient.getInstance().getFramebuffer();
      BlurredMaterialShader renderRenderer13 = ShaderFramebufferRegistry.getBlurredShader();
      SimpleFramebuffer simpleFramebuffer = ShaderFramebufferRegistry.getCopyFbo();
      SimpleFramebuffer simpleFramebuffer2 = ShaderFramebufferRegistry.getTintFbo();
      SimpleFramebuffer simpleFramebuffer3 = ShaderFramebufferRegistry.getFbo1();
      SimpleFramebuffer simpleFramebuffer4 = ShaderFramebufferRegistry.getFbo2();
      if (client != null && renderRenderer13 != null && simpleFramebuffer != null && simpleFramebuffer2 != null && simpleFramebuffer3 != null && simpleFramebuffer4 != null) {
         HandsModule handsModule = NoxiumVisuals.getInstance().getModuleProvider().get(HandsModule.class);
         if (handsModule != null && handsModule.hasHandPostProcess()) {
            if (handsModule.usesDirectSoftGlow()) {
               a11(handsModule, sourceFbo);
            } else {
               boolean enabled = !handsModule.shouldShowVanillaHand() && oixntc();
               if (!enabled) {
                  transformMethod860(client, simpleFramebuffer);
               }

               SimpleFramebuffer[] simpleFramebufferArray = new SimpleFramebuffer[]{simpleFramebuffer2, simpleFramebuffer3, simpleFramebuffer4};
               Object object = null;
               if (handsModule.hasSmoke()) {
                  SimpleFramebuffer simpleFramebuffer5 = initMethod44(null, null, simpleFramebufferArray);
                  if (simpleFramebuffer5 != null && getMethod10(sourceFbo, simpleFramebuffer5, handsModule, true)) {
                     object = simpleFramebuffer5;
                  }
               } else {
                  computeField610.reset();
               }

               if (handsModule.hasShader()) {
                  SimpleFramebuffer simpleFramebuffer6 = initMethod44((Framebuffer)object, null, simpleFramebufferArray);
                  if (simpleFramebuffer6 != null && isMethod37(handsModule, simpleFramebuffer, sourceFbo, simpleFramebuffer6, farPlaneDistance, client.textureWidth, client.textureHeight)) {
                     object = ctjc((Framebuffer)object, simpleFramebuffer6, simpleFramebufferArray);
                  }
               }

               if (handsModule.hasOutline()) {
                  SimpleFramebuffer simpleFramebuffer7 = initMethod44((Framebuffer)object, null, simpleFramebufferArray);
                  if (simpleFramebuffer7 != null && j25(handsModule, sourceFbo, sourceFbo, simpleFramebuffer7, false, client.textureWidth, client.textureHeight)) {
                     object = ctjc((Framebuffer)object, simpleFramebuffer7, simpleFramebufferArray);
                  }
               }

               if (handsModule.hasGlowPostProcess() && object != null) {
                  SimpleFramebuffer simpleFramebuffer8 = initMethod44((Framebuffer)object, null, simpleFramebufferArray);
                  if (simpleFramebuffer8 != null && qfgfaj(handsModule, sourceFbo, simpleFramebuffer8)) {
                     object = ctjc((Framebuffer)object, simpleFramebuffer8, simpleFramebufferArray);
                  }
               }

               if (object != null) {
                  uhxlza(client, simpleFramebuffer, (Framebuffer)object, renderRenderer13);
               }
            }
         }
      }
   }

      private static void transformMethod860(Framebuffer sourceFbo, SimpleFramebuffer targetFbo) {
      initMethod38(targetFbo);
      sourceFbo.draw(targetFbo.textureWidth, targetFbo.textureHeight);
      targetFbo.copyDepthFrom(sourceFbo);
   }

      private static void initMethod38(SimpleFramebuffer targetFbo) {
      targetFbo.clear();
      targetFbo.beginWrite(true);
      RenderSystem.clearColor(0F, 0F, 0F, 0F);
      RenderSystem.clear(16640);
   }

      private static Framebuffer ctjc(Framebuffer currentEffectFbo, SimpleFramebuffer layerFbo, SimpleFramebuffer[] workFramebuffers) {
      if (currentEffectFbo == null) {
         return layerFbo;
      } else {
         SimpleFramebuffer simpleFramebuffer = initMethod44(currentEffectFbo, layerFbo, workFramebuffers);
         return simpleFramebuffer != null && parseMethod46(currentEffectFbo, layerFbo, simpleFramebuffer) ? simpleFramebuffer : layerFbo;
      }
   }

      private static SimpleFramebuffer initMethod44(Framebuffer firstExcluded, Framebuffer secondExcluded, SimpleFramebuffer[] workFramebuffers) {
      for (SimpleFramebuffer simpleFramebuffer : workFramebuffers) {
         if (simpleFramebuffer != firstExcluded && simpleFramebuffer != secondExcluded) {
            return simpleFramebuffer;
         }
      }

      return null;
   }

      private static boolean parseMethod46(Framebuffer baseFbo, Framebuffer layerFbo, SimpleFramebuffer targetFbo) {
      FullscreenShaderPass shaderMatrixRenderer3 = ShaderFramebufferRegistry.getHandsLayerCompositeShader();
      if (shaderMatrixRenderer3 != null && baseFbo != null && layerFbo != null && targetFbo != null && targetFbo != baseFbo && targetFbo != layerFbo) {
         initMethod38(targetFbo);
         RenderSystem.disableBlend();
         RenderSystem.disableDepthTest();
         RenderSystem.activeTexture(33984);
         setMethod2(baseFbo.getColorAttachment());
         RenderSystem.activeTexture(33985);
         setMethod2(layerFbo.getColorAttachment());
         RenderSystem.activeTexture(33984);
         shaderMatrixRenderer3.bind();
         shaderMatrixRenderer3.setUniform1i("BaseTexture", 0);
         shaderMatrixRenderer3.setUniform1i("LayerTexture", 1);
         ShaderFramebufferRegistry.drawFullScreenQuad();
         shaderMatrixRenderer3.unbind();
         handleMethod57();
         return true;
      } else {
         return false;
      }
   }

      private static boolean isMethod37(
      HandsModule handsModule, Framebuffer sceneFbo, Framebuffer sourceFbo, SimpleFramebuffer targetFbo, float farPlaneDistance, int width, int height
   ) {
      if (shaderMode.isSelected("Blur")) {
         return calculateMethod53(sceneFbo, sourceFbo, targetFbo);
      } else if (shaderMode.isSelected("Gradient")) {
         return ainugz(handsModule, sourceFbo, targetFbo);
      } else if (shaderMode.isSelected("Reflection")) {
         return processMethod281(handsModule, sceneFbo, sourceFbo, targetFbo);
      } else if (shaderMode.isSelected("Rain Glass")) {
         return hhvtpy(handsModule, sceneFbo, sourceFbo, targetFbo, width, height);
      } else if (shaderMode.isSelected("Glass")) {
         return ctv(sceneFbo, sourceFbo, targetFbo, handsModule);
      } else if (shaderMode.isSelected("Glitch")) {
         return t13(sourceFbo, targetFbo, handsModule, width, height);
      } else if (handsModule != null && handsModule.isSkyColorShaderSelected()) {
         return destroyMethod55(handsModule, sourceFbo, targetFbo, width, height);
      } else if (shaderMode.isSelected("Warp")) {
         return cty(ShaderFramebufferRegistry.getWarpShader(), handsModule, sourceFbo, targetFbo, farPlaneDistance, width, height, 0.5F, true);
      } else {
         return shaderMode.isSelected("Depth Glow")
            ? cty(ShaderFramebufferRegistry.getVolumetricShader(), handsModule, sourceFbo, targetFbo, farPlaneDistance, width, height, 1F, true)
            : cty(ShaderFramebufferRegistry.getWaveShader(), handsModule, sourceFbo, targetFbo, farPlaneDistance, width, height, 1F, true);
      }
   }

      private static boolean calculateMethod53(Framebuffer sceneFbo, Framebuffer sourceFbo, SimpleFramebuffer targetFbo) {
      FullscreenShaderPass shaderMatrixRenderer3 = ShaderFramebufferRegistry.getHandsSoftKawaseDownShader();
      FullscreenShaderPass shaderMatrixRenderer32 = ShaderFramebufferRegistry.getHandsSoftKawaseUpShader();
      FullscreenShaderPass shaderMatrixRenderer33 = ShaderFramebufferRegistry.getHandBlurShader();
      SimpleFramebuffer[] simpleFramebufferArray = ShaderFramebufferRegistry.getHandsGlowFbos();
      if (sceneFbo != null && sourceFbo != null && shaderMatrixRenderer3 != null && shaderMatrixRenderer32 != null && shaderMatrixRenderer33 != null && simpleFramebufferArray != null && simpleFramebufferArray.length >= 3) {
         int color = cucf(sceneFbo.getColorAttachment(), sceneFbo.textureWidth, sceneFbo.textureHeight, simpleFramebufferArray, shaderMatrixRenderer3, shaderMatrixRenderer32, 3.0F);
         if (color == 0) {
            return false;
         } else {
            initMethod38(targetFbo);
            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.activeTexture(33984);
            setMethod2(sceneFbo.getColorAttachment());
            RenderSystem.activeTexture(33985);
            setMethod2(sourceFbo.getColorAttachment());
            RenderSystem.activeTexture(33986);
            setMethod2(color);
            RenderSystem.activeTexture(33984);
            shaderMatrixRenderer33.bind();
            shaderMatrixRenderer33.setUniform1i("SceneTexture", 0);
            shaderMatrixRenderer33.setUniform1i("MaskTexture", 1);
            shaderMatrixRenderer33.setUniform1i("BlurTexture", 2);
            ShaderFramebufferRegistry.drawFullScreenQuad();
            shaderMatrixRenderer33.unbind();
            handleMethod57();
            return true;
         }
      } else {
         return false;
      }
   }

      private static boolean ainugz(HandsModule handsModule, Framebuffer sourceFbo, SimpleFramebuffer targetFbo) {
      FullscreenShaderPass shaderMatrixRenderer3 = ShaderFramebufferRegistry.getHandGradientShader();
      if (shaderMatrixRenderer3 != null && sourceFbo != null) {
         initMethod38(targetFbo);
         RenderSystem.disableBlend();
         RenderSystem.disableDepthTest();
         RenderSystem.activeTexture(33984);
         setMethod2(sourceFbo.getColorAttachment());
         shaderMatrixRenderer3.bind();
         shaderMatrixRenderer3.setUniform1i("MaskTexture", 0);
         shaderMatrixRenderer3.setUniform1f("Opacity", handsModule.getShaderOpacity());
         convertMethod49(shaderMatrixRenderer3, handsModule);
         ShaderFramebufferRegistry.drawFullScreenQuad();
         shaderMatrixRenderer3.unbind();
         handleMethod57();
         return true;
      } else {
         return false;
      }
   }

      private static boolean processMethod281(HandsModule handsModule, Framebuffer sceneFbo, Framebuffer sourceFbo, SimpleFramebuffer targetFbo) {
      FullscreenShaderPass shaderMatrixRenderer3 = ShaderFramebufferRegistry.getHandReflectionShader();
      if (shaderMatrixRenderer3 != null && sceneFbo != null && sourceFbo != null) {
         initMethod38(targetFbo);
         RenderSystem.disableBlend();
         RenderSystem.disableDepthTest();
         RenderSystem.activeTexture(33984);
         setMethod2(sourceFbo.getColorAttachment());
         RenderSystem.activeTexture(33985);
         setMethod2(sceneFbo.getColorAttachment());
         RenderSystem.activeTexture(33984);
         shaderMatrixRenderer3.bind();
         shaderMatrixRenderer3.setUniform1i("MaskTexture", 0);
         shaderMatrixRenderer3.setUniform1i("SceneTexture", 1);
         shaderMatrixRenderer3.setUniform1f("Time", xhymrf(1000.0F) * handsModule.getShaderSpeed());
         shaderMatrixRenderer3.setUniform1f("Distortion", 0.1F);
         shaderMatrixRenderer3.setUniform1f("Opacity", handsModule.getShaderOpacity());
         convertMethod49(shaderMatrixRenderer3, handsModule);
         ShaderFramebufferRegistry.drawFullScreenQuad();
         shaderMatrixRenderer3.unbind();
         handleMethod57();
         return true;
      } else {
         return false;
      }
   }

      private static boolean hhvtpy(HandsModule handsModule, Framebuffer sceneFbo, Framebuffer sourceFbo, SimpleFramebuffer targetFbo, int width, int height) {
      FullscreenShaderPass shaderMatrixRenderer3 = ShaderFramebufferRegistry.getHandRainGlassShader();
      if (shaderMatrixRenderer3 != null && sceneFbo != null && sourceFbo != null) {
         initMethod38(targetFbo);
         RenderSystem.disableBlend();
         RenderSystem.disableDepthTest();
         RenderSystem.activeTexture(33984);
         setMethod2(sceneFbo.getColorAttachment());
         RenderSystem.activeTexture(33985);
         setMethod2(sourceFbo.getColorAttachment());
         RenderSystem.activeTexture(33984);
         shaderMatrixRenderer3.bind();
         shaderMatrixRenderer3.setUniform1i("SceneTexture", 0);
         shaderMatrixRenderer3.setUniform1i("MaskTexture", 1);
         shaderMatrixRenderer3.setUniform2f("Resolution", width, height);
         shaderMatrixRenderer3.setUniform1f("Time", xhymrf(1000.0F) * handsModule.getShaderSpeed());
         shaderMatrixRenderer3.setUniform1f("Opacity", handsModule.getShaderOpacity());
         convertMethod49(shaderMatrixRenderer3, handsModule);
         ShaderFramebufferRegistry.drawFullScreenQuad();
         shaderMatrixRenderer3.unbind();
         handleMethod57();
         return true;
      } else {
         return false;
      }
   }

      private static void convertMethod49(FullscreenShaderPass shader, HandsModule handsModule) {
      int index = handsModule.getVisualColor();
      cuis(shader, "ColorA", index);
      cuis(shader, "ColorB", index);
      cuis(shader, "ColorC", index);
      cuis(shader, "ColorD", index);
   }

      private static boolean getMethod10(Framebuffer sourceFbo, SimpleFramebuffer targetFbo, HandsModule handsModule, boolean clearTarget) {
      return computeField610.render(
         sourceFbo,
         targetFbo,
         handsModule.getClientShaderColor(),
         xhymrf(60.0F) * handsModule.getSmokeSpeed(),
         handsModule.getSmokeOpacity(),
         handsModule.shouldUseSmokeTextureColor(),
         handsModule.isSmokeOutlineOnly(),
         clearTarget
      );
   }

      private static boolean t13(Framebuffer sourceFbo, SimpleFramebuffer targetFbo, HandsModule handsModule, int width, int height) {
      GlitchHandShader handRenderRenderer5 = ShaderFramebufferRegistry.getGlitchShader();
      if (handRenderRenderer5 == null) {
         return false;
      } else {
         initMethod38(targetFbo);
         uxjhpu(sourceFbo);
         handRenderRenderer5.bind();
         handRenderRenderer5.setUniform1i("ColorTexture", 0);
         handRenderRenderer5.setUniform1i("DepthTexture", 1);
         handRenderRenderer5.setUniform1f("time", xhymrf(30.0F) * (handsModule != null ? handsModule.getShaderSpeed() : 1F));
         handRenderRenderer5.setUniform2f("resolution", width, height);
         handRenderRenderer5.setUniform1f(
            "glitchAmount", handsModule != null ? handsModule.getGlitchAmount() : 0.2F
         );
         handRenderRenderer5.setUniform1f("glitchSpeed", 0.6F);
         ShaderFramebufferRegistry.drawFullScreenQuad();
         handRenderRenderer5.unbind();
         handleMethod57();
         return true;
      }
   }

      private static boolean destroyMethod55(HandsModule handsModule, Framebuffer sourceFbo, SimpleFramebuffer targetFbo, int width, int height) {
      ColorHandRenderer colorHandRenderer = ShaderFramebufferRegistry.getHandsSkyColorShader();
      if (colorHandRenderer == null) {
         return false;
      } else {
         initMethod38(targetFbo);
         uxjhpu(sourceFbo);
         SkyColorModule skyColorModule = SkyColorModule.getInstance();
         int index = skyColorModule != null ? skyColorModule.getShaderBaseColor() : -10114561;
         int index2 = skyColorModule != null ? skyColorModule.getShaderAccentColor() : -6501377;
         int index3 = skyColorModule != null ? skyColorModule.getShaderDeepColor() : -15457987;
         colorHandRenderer.bind();
         colorHandRenderer.setUniform1i("ColorTexture", 0);
         colorHandRenderer.setUniform1i("DepthTexture", 1);
         colorHandRenderer.setUniform1f("time", xhymrf(60.0F) * handsModule.getShaderSpeed());
         colorHandRenderer.setUniform2f("resolution", width, height);
         colorHandRenderer.setUniform1i("mode", handsModule.getSkyColorShaderStyleIndex());
         colorHandRenderer.setUniform1i(
            "showVanillaHand", handsModule.shouldShowVanillaHand() ? 1 : 0
         );
         colorHandRenderer.setUniform1f("opacity", handsModule.getShaderOpacity());
         cuis(colorHandRenderer, "baseColor", index);
         cuis(colorHandRenderer, "accentColor", index2);
         cuis(colorHandRenderer, "deepColor", index3);
         ShaderFramebufferRegistry.drawFullScreenQuad();
         colorHandRenderer.unbind();
         handleMethod57();
         return true;
      }
   }

      private static boolean ctv(Framebuffer sceneFbo, Framebuffer sourceFbo, SimpleFramebuffer targetFbo, HandsModule handsModule) {
      GlassCompositeHandShader handRenderRenderer8 = ShaderFramebufferRegistry.getHandsGlassShader();
      GlassDownsampleHandShader handRenderRenderer4 = ShaderFramebufferRegistry.getHandsGlassDownShader();
      SimpleFramebuffer[] simpleFramebufferArray = ShaderFramebufferRegistry.getHandsGlassFbos();
      if (sceneFbo != null && handRenderRenderer8 != null && handRenderRenderer4 != null && simpleFramebufferArray != null && simpleFramebufferArray.length != 0) {
         int index = simpleFramebufferArray.length > 1 ? 1 : 0;
         int index2 = handsModule != null ? handsModule.getGlassBlurStrength() : 3;
         index2 = Math.max(1, Math.min(index2, simpleFramebufferArray.length - index));
         int index3 = index + index2 - 1;
         float value = Math.max(1F, (float)index2);
         float value2 = handsModule != null ? handsModule.getGlassBlurBrightness() : 1F;
         RenderSystem.disableBlend();
         RenderSystem.disableDepthTest();
         int color = sceneFbo.getColorAttachment();
         int color2 = sourceFbo.getColorAttachment();
         tw1(simpleFramebufferArray[index], color, handRenderRenderer4, value);

         for (int index4 = index + 1; index4 <= index3; index4++) {
            tw1(simpleFramebufferArray[index4], simpleFramebufferArray[index4 - 1].getColorAttachment(), handRenderRenderer4, value);
         }

         for (int index5 = index3; index5 > index; index5--) {
            hasMethod5(simpleFramebufferArray[index5 - 1], simpleFramebufferArray[index5].getColorAttachment(), color2, handRenderRenderer8, value, 1F, false);
         }

         hasMethod5(targetFbo, simpleFramebufferArray[index].getColorAttachment(), color2, handRenderRenderer8, value, value2, true);
         handleMethod57();
         return true;
      } else {
         return false;
      }
   }

      private static void tw1(SimpleFramebuffer targetFbo, int sourceTextureId, GlassDownsampleHandShader shader, float offset) {
      initMethod38(targetFbo);
      RenderSystem.activeTexture(33984);
      setMethod2(sourceTextureId);
      shader.bind();
      shader.setUniform1i("inTexture", 0);
      shader.setUniform2f("offset", offset, offset);
      shader.setUniform2f("halfpixel", 1F / targetFbo.textureWidth, 1F / targetFbo.textureHeight);
      shader.setUniform2f("iResolution", targetFbo.textureWidth, targetFbo.textureHeight);
      ShaderFramebufferRegistry.drawFullScreenQuad();
      shader.unbind();
   }

      private static void hasMethod5(
      SimpleFramebuffer targetFbo, int sourceTextureId, int alphaTextureId, GlassCompositeHandShader shader, float offset, float brightness, boolean useOriginalAlpha
   ) {
      initMethod38(targetFbo);
      RenderSystem.activeTexture(33984);
      setMethod2(sourceTextureId);
      RenderSystem.activeTexture(33985);
      setMethod2(alphaTextureId);
      shader.bind();
      shader.setUniform1i("inTexture", 0);
      shader.setUniform1i("textureToCheck", 1);
      shader.setUniform2f("offset", offset, offset);
      shader.setUniform2f("halfpixel", 1F / targetFbo.textureWidth, 1F / targetFbo.textureHeight);
      shader.setUniform2f("iResolution", targetFbo.textureWidth, targetFbo.textureHeight);
      shader.setUniform1f("saturation", brightness);
      shader.setUniform1i("check", useOriginalAlpha ? 1 : 0);
      ShaderFramebufferRegistry.drawFullScreenQuad();
      shader.unbind();
   }

      private static boolean cty(
      FullscreenShaderPass shader,
      HandsModule handsModule,
      Framebuffer sourceFbo,
      SimpleFramebuffer targetFbo,
      float farPlaneDistance,
      int width,
      int height,
      float timeScale,
      boolean useResolution
   ) {
      if (shader == null) {
         return false;
      } else {
         initMethod38(targetFbo);
         uxjhpu(sourceFbo);
         shader.bind();
         shader.setUniform1i("ColorTexture", 0);
         shader.setUniform1i("DepthTexture", 1);
         shader.setUniform1f("time", xhymrf(60.0F) * timeScale * (handsModule != null ? handsModule.getShaderSpeed() : 1F));
         if (useResolution) {
            shader.setUniform2f("resolution", width, height);
         }

         shader.setUniform1f("nearPlane", 0.05F);
         shader.setUniform1f("farPlane", farPlaneDistance);
         shader.setUniform1i(
            "showVanillaHand",
            handsModule != null && handsModule.shouldShowVanillaHand() ? 1 : 0
         );
         eivmwi(handsModule, shader);
         ShaderFramebufferRegistry.drawFullScreenQuad();
         shader.unbind();
         handleMethod57();
         return true;
      }
   }

      private static boolean qfgfaj(HandsModule handsModule, Framebuffer sourceFbo, SimpleFramebuffer targetFbo) {
      FullscreenShaderPass shaderMatrixRenderer3 = ShaderFramebufferRegistry.getHandsSoftKawaseDownShader();
      FullscreenShaderPass shaderMatrixRenderer32 = ShaderFramebufferRegistry.getHandsSoftKawaseUpShader();
      FullscreenShaderPass shaderMatrixRenderer33 = ShaderFramebufferRegistry.getHandsSoftGlowShader();
      SimpleFramebuffer[] simpleFramebufferArray = ShaderFramebufferRegistry.getHandsGlowFbos();
      if (shaderMatrixRenderer3 != null && shaderMatrixRenderer32 != null && shaderMatrixRenderer33 != null && simpleFramebufferArray != null && simpleFramebufferArray.length >= 3) {
         HandEffectStrengths moduleData4 = oitdqp(handsModule);
         if (!(moduleData4.glow() <= 0.001F) && !(moduleData4.opacity() <= 0.001F)) {
            int color3 = cucf(
               sourceFbo.getColorAttachment(), sourceFbo.textureWidth, sourceFbo.textureHeight, simpleFramebufferArray, shaderMatrixRenderer3, shaderMatrixRenderer32, Math.max(0.5F, Math.min(4.0F, moduleData4.outline()))
            );
            if (color3 == 0) {
               return false;
            } else {
               initMethod38(targetFbo);
               RenderSystem.disableBlend();
               RenderSystem.disableDepthTest();
               RenderSystem.activeTexture(33984);
               setMethod2(color3);
               RenderSystem.activeTexture(33985);
               setMethod2(sourceFbo.getColorAttachment());
               RenderSystem.activeTexture(33984);
               Color color4 = new Color(handsModule.getVisualColor(), true);
               float value = 1F + moduleData4.glow() * 1.8F;
               shaderMatrixRenderer33.bind();
               shaderMatrixRenderer33.setUniform1i("BlurredTexture", 0);
               shaderMatrixRenderer33.setUniform1i("MaskTexture", 1);
               shaderMatrixRenderer33.setUniform3f("color", color4.getRed() / 255.0F, color4.getGreen() / 255.0F, color4.getBlue() / 255.0F);
               shaderMatrixRenderer33.setUniform3f("color2", color4.getRed() / 255.0F, color4.getGreen() / 255.0F, color4.getBlue() / 255.0F);
               shaderMatrixRenderer33.setUniform1f("exposure", value);
               shaderMatrixRenderer33.setUniform1f("opacity", moduleData4.opacity());
               shaderMatrixRenderer33.setUniform2f(
                  "texelSize", 1F / sourceFbo.textureWidth, 1F / sourceFbo.textureHeight
               );
               ShaderFramebufferRegistry.drawFullScreenQuad();
               shaderMatrixRenderer33.unbind();
               handleMethod57();
               RenderSystem.defaultBlendFunc();
               return true;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

      private static boolean a11(HandsModule handsModule, Framebuffer sourceFbo) {
      FullscreenShaderPass shaderMatrixRenderer3 = ShaderFramebufferRegistry.getHandsSoftKawaseDownShader();
      FullscreenShaderPass shaderMatrixRenderer32 = ShaderFramebufferRegistry.getHandsSoftKawaseUpShader();
      FullscreenShaderPass shaderMatrixRenderer33 = ShaderFramebufferRegistry.getHandsSoftGlowShader();
      SimpleFramebuffer[] simpleFramebufferArray = ShaderFramebufferRegistry.getHandsGlowFbos();
      Framebuffer client = MinecraftClient.getInstance().getFramebuffer();
      if (shaderMatrixRenderer3 != null && shaderMatrixRenderer32 != null && shaderMatrixRenderer33 != null && simpleFramebufferArray != null && simpleFramebufferArray.length >= 3 && client != null && sourceFbo != null) {
         HandEffectStrengths moduleData4 = oitdqp(handsModule);
         if (!(moduleData4.glow() <= 0.001F) && !(moduleData4.opacity() <= 0.001F)) {
            int color3 = cucf(
               sourceFbo.getColorAttachment(), sourceFbo.textureWidth, sourceFbo.textureHeight, simpleFramebufferArray, shaderMatrixRenderer3, shaderMatrixRenderer32, Math.max(0.5F, Math.min(4.0F, moduleData4.outline()))
            );
            if (color3 == 0) {
               return false;
            } else {
               Color color4 = new Color(handsModule.getVisualColor(), true);
               float value = 1F + moduleData4.glow() * 1.8F;
               client.beginWrite(true);
               RenderSystem.enableBlend();
               RenderSystem.colorMask(true, true, true, false);
               RenderSystem.disableDepthTest();
               RenderSystem.disableCull();
               RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
               RenderSystem.activeTexture(33984);
               setMethod2(color3);
               RenderSystem.activeTexture(33985);
               setMethod2(sourceFbo.getColorAttachment());
               RenderSystem.activeTexture(33984);
               RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
               shaderMatrixRenderer33.bind();
               shaderMatrixRenderer33.setUniform1i("BlurredTexture", 0);
               shaderMatrixRenderer33.setUniform1i("MaskTexture", 1);
               shaderMatrixRenderer33.setUniform3f("color", color4.getRed() / 255.0F, color4.getGreen() / 255.0F, color4.getBlue() / 255.0F);
               shaderMatrixRenderer33.setUniform3f("color2", color4.getRed() / 255.0F, color4.getGreen() / 255.0F, color4.getBlue() / 255.0F);
               shaderMatrixRenderer33.setUniform1f("exposure", value);
               shaderMatrixRenderer33.setUniform1f("opacity", moduleData4.opacity());
               shaderMatrixRenderer33.setUniform2f(
                  "texelSize", 1F / sourceFbo.textureWidth, 1F / sourceFbo.textureHeight
               );
               ShaderFramebufferRegistry.drawFullScreenQuad();
               shaderMatrixRenderer33.unbind();
               RenderSystem.colorMask(true, true, true, true);
               RenderSystem.depthMask(true);
               RenderSystem.enableDepthTest();
               RenderSystem.enableCull();
               RenderSystem.disableBlend();
               RenderSystem.defaultBlendFunc();
               RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
               handleMethod57();
               client.beginWrite(true);
               return true;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

      private static boolean controlMethod40(HandsModule handsModule, Framebuffer baseFbo, Framebuffer sourceFbo, SimpleFramebuffer targetFbo) {
      FullscreenShaderPass shaderMatrixRenderer3 = ShaderFramebufferRegistry.getHandsGlowHShader();
      FullscreenShaderPass shaderMatrixRenderer32 = ShaderFramebufferRegistry.getHandsFastGlowShader();
      SimpleFramebuffer[] simpleFramebufferArray = ShaderFramebufferRegistry.getHandsGlowFbos();
      SimpleFramebuffer simpleFramebuffer = simpleFramebufferArray != null && simpleFramebufferArray.length > 0 ? simpleFramebufferArray[0] : null;
      if (shaderMatrixRenderer3 != null && shaderMatrixRenderer32 != null && simpleFramebuffer != null) {
         float value = handsModule.getItemLayerSize() * (handsModule.getItemLayers() + 1.25F);
         byte byteValue = 1;
         chouht(shaderMatrixRenderer3, simpleFramebuffer, sourceFbo, value, byteValue);
         initMethod38(targetFbo);
         RenderSystem.disableBlend();
         RenderSystem.disableDepthTest();
         RenderSystem.activeTexture(33984);
         setMethod2(baseFbo.getColorAttachment());
         RenderSystem.activeTexture(33985);
         setMethod2(sourceFbo.getColorAttachment());
         RenderSystem.activeTexture(33986);
         setMethod2(simpleFramebuffer.getColorAttachment());
         RenderSystem.activeTexture(33984);
         Color color = handsModule.getItemGlowColor();
         shaderMatrixRenderer32.bind();
         shaderMatrixRenderer32.setUniform1i("BaseTexture", 0);
         shaderMatrixRenderer32.setUniform1i("SourceTexture", 1);
         shaderMatrixRenderer32.setUniform1i("HorizontalGlowTexture", 2);
         shaderMatrixRenderer32.setUniform4f(
            "glowColor",
            color.getRed() / 255.0F,
            color.getGreen() / 255.0F,
            color.getBlue() / 255.0F,
            color.getAlpha() / 255.0F
         );
         shaderMatrixRenderer32.setUniform1f("radius", value);
         shaderMatrixRenderer32.setUniform1f("intensity", 1F + handsModule.getItemGlowOpacity() * 0.35F);
         shaderMatrixRenderer32.setUniform1i("quality", byteValue);
         shaderMatrixRenderer32.setUniform1i("innerGlow", handsModule.isInnerGlowEnabled() ? 1 : 0);
         shaderMatrixRenderer32.setUniform1f("time", xhymrf(60.0F));
         ShaderFramebufferRegistry.drawFullScreenQuad();
         shaderMatrixRenderer32.unbind();
         handleMethod57();
         return true;
      } else {
         return false;
      }
   }

      private static int cucf(
      int sourceTextureId,
      int sourceWidth,
      int sourceHeight,
      SimpleFramebuffer[] glowBuffers,
      FullscreenShaderPass downShader,
      FullscreenShaderPass upShader,
      float upOffset
   ) {
      if (sourceTextureId != 0 && glowBuffers != null && glowBuffers.length >= 3) {
         byte byteValue = 3;
         int index = sourceTextureId;
         int width = sourceWidth;
         int height = sourceHeight;

         for (int index2 = 0; index2 < byteValue; index2++) {
            isMethod97(glowBuffers[index2], index, downShader, width, height, 1F, false);
            index = glowBuffers[index2].getColorAttachment();
            width = glowBuffers[index2].textureWidth;
            height = glowBuffers[index2].textureHeight;
         }

         for (int index3 = byteValue - 1; index3 >= 1; index3--) {
            SimpleFramebuffer simpleFramebuffer = glowBuffers[index3];
            isMethod97(glowBuffers[index3 - 1], index, upShader, simpleFramebuffer.textureWidth, simpleFramebuffer.textureHeight, upOffset, true);
            index = glowBuffers[index3 - 1].getColorAttachment();
         }

         return index;
      } else {
         return 0;
      }
   }

      private static HandEffectStrengths oitdqp(HandsModule handsModule) {
      float value = handsModule.getSoftGlowStrength();
      float width = handsModule.getSoftGlowWidth();
      float value2 = handsModule.getSoftGlowOpacity();
      if (!startField510) {
         egzo = value;
         awrxp = width;
         processField56 = value2;
         startField510 = true;
      } else {
         float value3 = 0.18F;
         egzo = deleteMethod31(egzo, value, value3);
         awrxp = deleteMethod31(awrxp, width, value3);
         processField56 = deleteMethod31(processField56, value2, value3);
      }

      return new HandEffectStrengths(egzo, awrxp, processField56);
   }

      private static float deleteMethod31(float current, float target, float smoothing) {
      return Math.abs(current - target) < 0.001F ? target : current + (target - current) * smoothing;
   }

      private static void isMethod97(
      SimpleFramebuffer targetFbo, int sourceTextureId, FullscreenShaderPass shader, int inputWidth, int inputHeight, float offset, boolean upPass
   ) {
      initMethod38(targetFbo);
      RenderSystem.disableBlend();
      RenderSystem.disableDepthTest();
      RenderSystem.activeTexture(33984);
      setMethod2(sourceTextureId);
      shader.bind();
      shader.setUniform1i("SourceTexture", 0);
      shader.setUniform2f("uOffset", offset, offset);
      shader.setUniform2f("uHalfPixel", 0.5F / inputWidth, 0.5F / inputHeight);
      shader.setUniform2f("uSize", targetFbo.textureWidth, targetFbo.textureHeight);
      if (upPass) {
         shader.setUniform3f("color", 1F, 1F, 1F);
      }

      ShaderFramebufferRegistry.drawFullScreenQuad();
      shader.unbind();
   }

      private static void chouht(FullscreenShaderPass shader, SimpleFramebuffer targetFbo, Framebuffer sourceFbo, float radius, int quality) {
      initMethod38(targetFbo);
      RenderSystem.disableBlend();
      RenderSystem.disableDepthTest();
      RenderSystem.activeTexture(33984);
      setMethod2(sourceFbo.getColorAttachment());
      shader.bind();
      shader.setUniform1i("SourceTexture", 0);
      shader.setUniform1f("radius", radius);
      shader.setUniform1i("quality", quality);
      ShaderFramebufferRegistry.drawFullScreenQuad();
      shader.unbind();
      RenderSystem.activeTexture(33984);
      RenderSystem.bindTexture(0);
   }

      private static void eivmwi(HandsModule handsModule, FullscreenShaderPass shader) {
      if (handsModule == null) {
         shader.setUniform3f("customColor", 1F, 1F, 1F);
         shader.setUniform1f("customAlpha", 1F);
      } else {
         Color color = handsModule.getClientShaderColor();
         shader.setUniform3f(
            "customColor",
            color.getRed() / 255.0F,
            color.getGreen() / 255.0F,
            color.getBlue() / 255.0F
         );
         shader.setUniform1f("customAlpha", handsModule.getShaderOpacity());
      }
   }

      private static void cuis(FullscreenShaderPass shader, String name, int color) {
      shader.setUniform4f(name, (color >> 16 & 0xFF) / 255.0F, (color >> 8 & 0xFF) / 255.0F, (color & 0xFF) / 255.0F, (color >> 24 & 0xFF) / 255.0F);
   }

      private static boolean j25(
      HandsModule handsModule, Framebuffer baseFbo, Framebuffer sourceFbo, SimpleFramebuffer targetFbo, boolean preserveBase, int width, int height
   ) {
      OutlineHandShader handRenderRenderer6 = ShaderFramebufferRegistry.getOutlineShader();
      if (handRenderRenderer6 == null) {
         return false;
      } else {
         initMethod38(targetFbo);
         RenderSystem.disableBlend();
         RenderSystem.disableDepthTest();
         RenderSystem.activeTexture(33984);
         setMethod2(baseFbo.getColorAttachment());
         RenderSystem.activeTexture(33985);
         setMethod2(sourceFbo.getColorAttachment());
         RenderSystem.activeTexture(33986);
         setMethod2(sourceFbo.getDepthAttachment());
         handRenderRenderer6.bind();
         handRenderRenderer6.setUniform1i("ColorTexture", 0);
         handRenderRenderer6.setUniform1i("SourceTexture", 1);
         handRenderRenderer6.setUniform1i("DepthTexture", 2);
         handRenderRenderer6.setUniform2f("resolution", width, height);
         Color color = handsModule.getItemOutlineColor();
         handRenderRenderer6.setUniform3f(
            "customColor",
            color.getRed() / 255.0F,
            color.getGreen() / 255.0F,
            color.getBlue() / 255.0F
         );
         handRenderRenderer6.setUniform1f("customAlpha", color.getAlpha() / 255.0F);
         handRenderRenderer6.setUniform1f("thickness", handsModule.getItemOutlineThickness());
         handRenderRenderer6.setUniform1i("showOriginal", preserveBase && baseFbo != sourceFbo ? 1 : 0);
         ShaderFramebufferRegistry.drawFullScreenQuad();
         handRenderRenderer6.unbind();
         handleMethod57();
         return true;
      }
   }

      private static void uxjhpu(Framebuffer sourceFbo) {
      RenderSystem.disableBlend();
      RenderSystem.disableDepthTest();
      RenderSystem.activeTexture(33984);
      setMethod2(sourceFbo.getColorAttachment());
      RenderSystem.activeTexture(33985);
      setMethod2(sourceFbo.getDepthAttachment());
   }

      private static void uhxlza(Framebuffer mainFbo, Framebuffer sceneFbo, Framebuffer effectFbo, BlurredMaterialShader compositeShader) {
      mainFbo.beginWrite(true);
      RenderSystem.disableBlend();
      RenderSystem.disableDepthTest();
      RenderSystem.activeTexture(33984);
      setMethod2(sceneFbo.getColorAttachment());
      RenderSystem.activeTexture(33985);
      setMethod2(effectFbo.getColorAttachment());
      RenderSystem.activeTexture(33986);
      setMethod2(sceneFbo.getDepthAttachment());
      compositeShader.bind();
      compositeShader.setUniform1i("ColorTexture", 0);
      compositeShader.setUniform1i("OriginalTexture", 0);
      compositeShader.setUniform1i("BlurredTexture", 1);
      compositeShader.setUniform1i("DepthTexture", 2);
      compositeShader.setUniform1f("EffectOpacity", 1F);
      ShaderFramebufferRegistry.drawFullScreenQuad();
      compositeShader.unbind();
      handleMethod57();
      RenderSystem.disableBlend();
      RenderSystem.enableDepthTest();
      RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
      RenderSystem.defaultBlendFunc();
      if (MinecraftClient.getInstance().getFramebuffer() != null) {
         MinecraftClient.getInstance().getFramebuffer().beginWrite(true);
      }
   }

      private static void handleMethod57() {
      RenderSystem.activeTexture(33986);
      RenderSystem.bindTexture(0);
      RenderSystem.activeTexture(33985);
      RenderSystem.bindTexture(0);
      RenderSystem.activeTexture(33984);
      RenderSystem.bindTexture(0);
   }

      private static void setMethod2(int textureId) {
      RenderSystem.bindTexture(textureId);
      GlStateManager._texParameter(3553, 10241, 9729);
      GlStateManager._texParameter(3553, 10240, 9729);
      GlStateManager._texParameter(3553, 10242, 33071);
      GlStateManager._texParameter(3553, 10243, 33071);
   }

      private static float xhymrf(float loopSeconds) {
      long timestamp = Math.max(1L, (long)(loopSeconds * 1E9F));
      return (float)(System.nanoTime() % timestamp) / 1E9F;
   }

   static {
      int index = 0;
      MultiSelectSetting moduleSettingHandler = new MultiSelectSetting(
         "Effects",
         "Hands effect layers"
      );
      String[] stringArray = new String[4];
      stringArray[0] = "Glow";
      stringArray[1] = "Shader";
      stringArray[2] = "Outline";
      stringArray[3] = "Smoke";
      MultiSelectSetting moduleSettingHandler2 = moduleSettingHandler.value(stringArray);
      String[] stringArray2 = new String[1];
      stringArray2[0] = "Glow";
      renderMode = moduleSettingHandler2.selected(stringArray2);
      ChoiceSetting moduleSettingHandler22 = new ChoiceSetting(
         "Hands Shader",
         "Shader selection"
      );
      String[] stringArray3 = new String[12];
      stringArray3[0] = "Glass";
      stringArray3[1] = "Wave";
      stringArray3[2] = "Depth Glow";
      stringArray3[3] = "Warp";
      stringArray3[4] = "Glitch";
      stringArray3[5] = "Nebula";
      stringArray3[6] = "Vortex";
      stringArray3[7] = "Mist";
      stringArray3[8] = "Blur";
      stringArray3[9] = "Gradient";
      stringArray3[10] = "Reflection";
      stringArray3[11] = "Rain Glass";
      shaderMode = moduleSettingHandler22.value(stringArray3)
         .alias(
            "Volumetric",
            "Depth Glow"
         )
         .alias(
            "Veil",
            "Mist"
         )
         .alias(
            "Solid",
            "Gradient"
         )
         .alias(
            "Rain Water",
            "Rain Glass"
         )
         .visible(() -> {
            return renderMode.isSelected("Shader");
         });
   }
}
