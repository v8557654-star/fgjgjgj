package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.utils.*;
import java.util.ArrayList;
import java.util.List;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.utils.ClickFriendModule;
import winvi.noxiumvisuals.modules.manager.CustomChatModule;
import winvi.noxiumvisuals.modules.utils.FakePlayerModule;
import winvi.noxiumvisuals.modules.client.FriendsManagerModule;
import winvi.noxiumvisuals.modules.utils.HitSoundModule;
import winvi.noxiumvisuals.modules.manager.InventoryModule;
import winvi.noxiumvisuals.modules.utils.KillSoundModule;
import winvi.noxiumvisuals.modules.client.SoundsModule;
import winvi.noxiumvisuals.modules.client.ThemeModule;
import winvi.noxiumvisuals.modules.visuals.TimerTnTModule;
public class ModuleRegistry {
      private final List<Module> dkvq = new ArrayList<>();
      private final List<Module> dlun = new ArrayList<>();
      private final ThemeModule checkField96 = new ThemeModule();

      public void setup() {
      this.register(
         new InterfaceModule(),
         new NoRenderModule(),
         new NameProtectModule(),
         new FakePlayerModule(),
         new RPCModule(),
         new SoundsModule(),
         new LiquidGlassModule(),
         new FriendsManagerModule(),
         new ConfigManagerModule(),
         new ItemHighlighterModule(),
         new CustomLoadingScreenModule(),
         new GlobalsModule(),
         new HitSoundModule(),
         new KillSoundModule(),
         new CommandFixModule(),
         new FTHelperModule(),
         new ItemScrollerModule(),
         new CustomSkinModule(),
         new CapeModule(),
         new AspectRatioModule(),
         new ZoomModule(),
         new AutoSprintModule(),
         new ThirdPersonModule(),
         new SmoothnessPersonModule(),
         new ClickFriendModule(),
         new DynamicIslandModule(),
         new ViewModelModule(),
         new BetterMinecraftModule(),
         new SwingAnimationModule(),
         new TotemAnimationModule(),
         new ShieldIndicatorModule(),
         new ArmorDurabilityModule(),
         new ArrowsModule(),
         new TargetHUDModule(),
         new ArmorModule(),
         new InventoryModule(),
         new HotBarModule(),
         new PotionsModule(),
         new CooldownsModule(),
         new ScoreBoardModule(),
         new CoordinatesInfoModule(),
         new InformationHUDModule(),
         new NotificationsModule(),
         new CustomChatModule(),
         new HotkeysModule(),
         new TargetRenderModule(),
         new PickBlowupModule(),
         new FragEffectModule(),
         new HitEffectModule(),
         new DistantAlphaModule(),
         new HitRangeModule(),
         new StableTagModule(),
         new TimerTnTModule(),
         new CrosshairModule(),
         new SpatialAudioModule(),
         new TintModule(),
         new HitTintModule(),
         new ChinaHatModule(),
         new GuiPresenceModule(),
         new RecordModule(),
         new LyricsModule(),
         new CombatJuiceModule(),
         new HitColorModule(),
         new CustomGlintModule(),
         new TorusModule(),
         new JumpCirclesModule(),
         new TrailsModule(),
         new DashTrailModule(),
         new BlinkModule(),
         new GhostNimbModule(),
         new HitBubblesModule(),
         new HitBoxModule(),
         new HitPointModule(),
         new HandsModule(),
         new CustomHandModule(),
         new ShaderPlayerModule(),
         new ShaderCrystalsModule(),
         new SonarModule(),
         new PredictonModule(),
         new PetsModule(),
         new FemboyModModule(),
         new ShadingModule(),
         new AmbienceModule(),
         new CustomFogModule(),
         new SkyColorModule(),
         new BlockHighLightModule(),
         new GPSModule(),
         new WaveEffectModule(),
         new ItemPhysicsModule(),
         new CrystalColorModule(),
         new BadTripModule(),
         new WorldParticleModule(),
         new HitParticlesModule(),
         new TrackParticleModule(),
         new JumpParticlesModule(),
         new TotemParticleModule(),
         new ExperienceParticleModule(),
         new KillParticleModule(),
         new ParticleTrailModule(),
         new DamageParticleModule(),
         new BlockParticleModule()
      );
      this.dlun.clear();
      this.dlun.addAll(this.dkvq);
      this.dlun.add(this.checkField96);

      for (Module module : this.dkvq) {
         module.initializeDefaultValues();
         if (module.isState()) {
            module.setState(false);
         }
      }

      this.checkField96.initializeDefaultValues();
      this.checkField96.setState(true);

      GuiPresenceModule guiPresence = this.getModule(GuiPresenceModule.class);
      if (guiPresence != null) {
         guiPresence.setState(true);
      }
   }

      public void register(Module... module) {
      this.dkvq.addAll(List.of(module));
   }

      public List<Module> modules() {
      return this.dkvq;
   }

      public List<Module> providerModules() {
      return this.dlun;
   }

      public <T extends Module> T getModule(Class<T> moduleClass) {
      for (Module module : this.dlun) {
         if (moduleClass.isInstance(module)) {
            return (T)module;
         }
      }

      return null;
   }

   static {
      int index = 0;
   }
}
