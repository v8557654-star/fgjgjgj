package winvi.noxiumvisuals.modules.visuals;

import java.util.List;
import net.minecraft.util.math.Vec3d;
public record FragEffectBurst(
   Vec3d origin,
   long startedAt,
   long durationMs,
   List<FragEffectFragment> fragments
) {

      public Vec3d origin() {
      return this.origin;
   }

      public long startedAt() {
      return this.startedAt;
   }

      public long durationMs() {
      return this.durationMs;
   }

      public List<FragEffectFragment> fragments() {
      return this.fragments;
   }

}
