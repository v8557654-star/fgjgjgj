package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.entity.model.AllayEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.state.AllayEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.EntityModuleFactory;
import winvi.noxiumvisuals.modules.visuals.ParticleEntityFactory;
import winvi.noxiumvisuals.modules.visuals.ShaderTextureRenderer;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.AttackEntityEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
public class PetsModule extends Module {
      public static final float ALLAY_SCALE = 1.25F;
      public static final float ALLAY_LEFT_OFFSET_X = 0.4F;
      public static final float ALLAY_RIGHT_OFFSET_X = -0.4F;
      public static final float ALLAY_OFFSET_Y = -0.15F;
      public static final float ALLAY_OFFSET_Z = 0F;
      public static final float ALLAY_ROTATE_X = 0F;
      public static final float ALLAY_ROTATE_Y = 0F;
      public static final float ALLAY_ROTATE_Z = 0F;
      public static final float ALLAY_ANIMATION_SPEED = 1F;
      public static final float ALLAY_ANIMATION_STRENGTH = 0.35F;
      public static final Identifier DOG_TEXTURE = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/787nmq_xe.png");
      private static final Identifier foldw = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/xck_ps3.png");
      private static final Identifier addField630 = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/lmiswpfo_yq.png");
      private static final Identifier xahiq = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/f8qlfa0de_c.png");
      private static final Identifier xqfej = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/qcfnjo.png");
      private static final Identifier f22 = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/14olg1.png");
      private static final Identifier nitxw = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/qd6o3vi.png");
      private static final Identifier setField880 = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/qmk_ci.png");
      private static final Identifier removeField45 = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/8tlnrsip.png");
      private static final Identifier mj1 = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/drhasg.png");
      private static final Identifier emkt = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/alratvt_lc.png");
      public static final Identifier ALLAY_TEXTURE = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/p208wz.png");
      static final ItemStack ALLAY_SWORD = new ItemStack(Items.DIAMOND_SWORD);
      static final long ATTACK_FOLLOW_TIMEOUT_MS = 3600L;
      static final long ATTACK_LAUNCH_DURATION_MS = 560L;
      static final long ATTACK_RETURN_DURATION_MS = 920L;
      static PetsModule instance;
      private final ChoiceSetting nwiqx;
      private final ChoiceSetting processField931;
      private final ChoiceSetting clluc;
      private final ChoiceSetting iszwe;
      private final ColorSetting qtnzq;
      private final ChoiceSetting computeField80;
      private final ColorSetting eunnj;
      private final BooleanSetting hzedl;
      private final BooleanSetting txdon;
      private ParticleEntityFactory fiddo;
      private final ShaderTextureRenderer emvh;
      private final AllayEntityRenderState kfzia;
      private AllayEntityModel tarbi;
      private int y25;
      private long yrmdf;
      private long updateField21;
      private long wimfn;
      private Vec3d zhtps;
      private float nd0;
      private float ene;
      private float enf;
      private float engc;
      private float computeField680;
      private float deleteField780;
      private float executeField20;
      private float enk;
      private float xudqq;
      private float createField980;
      private float tsrym;
      private boolean krrgg;

   public PetsModule() {
      super(
         "Pets",
         "Pets",
         ModuleCategory.VISUAL
      );
      this.nwiqx = new ChoiceSetting(
            "Pet",
            "Pet variant"
         )
         .value(
            "Dog",
            "Allay",
            "Dragon"
         )
         .selected("Dog")
         .alias(
            "Ghost",
            "Dragon"
         )
         .onChange(value -> {
            this.checkMethod40();
         });
      this.processField931 = new ChoiceSetting(
            "Shoulder",
            "Allay shoulder"
         )
         .value(
            "Right",
            "Left"
         )
         .selected("Right")
         .visible(this::isAllaySelected);
      this.clluc = new ChoiceSetting(
            "Dog Color",
            "Dog color preset"
         )
         .value(
            "Default",
            "Black",
            "Dark Brown",
            "Chocolate",
            "Gray",
            "Cream",
            "Red",
            "Fawn",
            "Sable",
            "Brindle",
            "Wolf"
         )
         .selected("Default")
         .visible(this::convertMethod341);
      this.iszwe = new ChoiceSetting(
            "Allay Color Source",
            "Allay model color source"
         )
         .value(
            "Visual Color",
            "Custom"
         )
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .selected("Custom")
         .visible(this::isAllaySelected);
      this.qtnzq = new ColorSetting(
            "Allay Color",
            "Custom Allay model color"
         )
         .setColor(-1)
         .presets(-1, -8538113, -8650766, -11930, -33880, -5011201)
         .visible(() -> {
            return this.isAllaySelected() && this.iszwe.isSelected("Custom");
         });
      this.computeField80 = new ChoiceSetting(
            "Dragon Color Source",
            "Dragon texture and trail color source"
         )
         .value(
            "Visual Color",
            "Custom"
         )
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .selected("Custom")
         .visible(this::a14);
      this.eunnj = new ColorSetting(
            "Dragon Color",
            "Custom dragon texture and trail color"
         )
         .setColor(-1)
         .presets(-1, -8538113, -8650766, -11930, -33880, -5011201)
         .visible(() -> {
            return this.a14() && this.computeField80.isSelected("Custom");
         });
      this.hzedl = new BooleanSetting(
            "Animation",
            "Animate the Allay on your shoulder"
         )
         .setValue(true)
         .visible(this::isAllaySelected);
      this.txdon = new BooleanSetting(
            "Attack My Target",
            "Send the pet to the target you attack"
         )
         .setValue(true)
         .visible(() -> {
            return !this.a14();
         });
      this.emvh = new ShaderTextureRenderer();
      this.kfzia = new AllayEntityRenderState();
      this.y25 = -2147483648;
      this.zhtps = new Vec3d(0, 0, 0);
      instance = this;
      this.nwiqx.withTranslation("pets.pet", "pets.pet.desc");
      this.processField931.withTranslation("pets.shoulder", "pets.shoulder.desc");
      this.clluc.withTranslation("pets.dogcolor", "pets.dogcolor.desc");
      this.iszwe.withTranslation("pets.allaycolorsource", "pets.allaycolorsource.desc");
      this.qtnzq.withTranslation("pets.allaycolor", "pets.allaycolor.desc");
      this.computeField80.withTranslation("pets.dragoncolorsource", "pets.dragoncolorsource.desc");
      this.eunnj.withTranslation("pets.dragoncolor", "pets.dragoncolor.desc");
      this.hzedl.withTranslation("pets.animation", "pets.animation.desc");
      this.txdon.withTranslation("pets.attackmytarget", "pets.attackmytarget.desc");
      this.setup(
         new ModuleSetting[]{
            this.nwiqx, this.processField931, this.clluc, this.iszwe, this.qtnzq, this.computeField80, this.eunnj, this.hzedl, this.txdon
         }
      );
   }

      public static PetsModule getInstance() {
      return instance;
   }

      @Override
   public void activate() {
      super.activate();
      this.checkMethod40();
   }

      @Override
   public void deactivate() {
      super.deactivate();
      this.yd0();
      this.emvh.clear();
      this.parseMethod22();
   }

      @Override
   public void onTick() {
      this.checkPet();
      if (this.a14()) {
         this.parseMethod22();
         this.emvh.tick(MinecraftClient.getInstance());
      } else if (this.isAllaySelected() && this.txdon.isValue()) {
         this.uhhisd();
      } else {
         this.parseMethod22();
      }
   }

      @Override
   public boolean hasWorldRenderWork() {
      return this.isState() && (this.a14() || this.isAllaySelected() && this.hasActiveAllayAttackTarget());
   }

      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState() && MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null && event != null) {
         if (this.a14()) {
            int index = this.resolveVisualOrCustomColor(this.computeField80, this.eunnj);
            this.emvh.render(event, index, index, 1F);
         } else if (this.isAllaySelected()) {
            this.bllxvz();
            if (this.tarbi != null) {
               long timestamp = System.currentTimeMillis();
               float value = event.getPartialTicks();
               Entity entity = this.uhhisd();
               if (entity != null) {
                  this.cyg(event, entity, this.h19(entity, value, timestamp), value, timestamp);
               }
            }
         }
      }
   }

   @EventHandler
      public void onAttack(AttackEntityEvent event) {
      if (this.isState() && this.txdon.isValue() && event != null && event.getEntity() instanceof LivingEntity livingEntity) {
         if (!(livingEntity instanceof ParticleEntityFactory) && livingEntity != MinecraftClient.getInstance().player && !livingEntity.isInvisible() && livingEntity.isAlive()) {
            if (this.a14()) {
               this.emvh.focus(livingEntity);
            } else if (this.convertMethod341()) {
               if (this.fiddo != null) {
                  this.fiddo.setTarget(livingEntity);
               }
            } else {
               if (this.isAllaySelected()) {
                  this.e23(livingEntity);
               }
            }
         }
      }
   }

      public boolean shouldRenderShoulderAllay(PlayerEntityRenderState state, PlayerEntity player) {
      if (!this.isState()
         || !this.isAllaySelected()
         || state == null
         || player == null
         || MinecraftClient.getInstance().player == null
         || MinecraftClient.getInstance().world == null) {
         return false;
      } else if (state.spectator || player != MinecraftClient.getInstance().player || !EntityVisibilityFilter.shouldRender(player)) {
         return false;
      } else if (this.hasActiveAllayAttackTarget()) {
         return false;
      } else {
         Perspective client = MinecraftClient.getInstance().options != null
            ? MinecraftClient.getInstance().options.getPerspective()
            : Perspective.FIRST_PERSON;
         return !client.isFirstPerson();
      }
   }

      public boolean isAllaySelected() {
      return this.nwiqx.isSelected("Allay");
   }

      public boolean isAllayLeftShoulder() {
      return this.processField931.isSelected("Left");
   }

      public boolean isAllayAnimationEnabled() {
      return this.hzedl.isValue();
   }

      public float getAllayOffsetX() {
      return this.isAllayLeftShoulder() ? 0.4F : -0.4F;
   }

      public Identifier getDogTexture() {
      String text = this.clluc.getSelected();

      return switch (text) {
         case "Black" -> foldw;
         case "Dark Brown" -> addField630;
         case "Chocolate" -> xahiq;
         case "Gray" -> xqfej;
         case "Cream" -> f22;
         case "Red" -> nitxw;
         case "Fawn" -> setField880;
         case "Sable" -> removeField45;
         case "Brindle" -> mj1;
         case "Wolf" -> emkt;
         default -> DOG_TEXTURE;
      };
   }

      public int getAllayColor() {
      return this.resolveVisualOrCustomColor(this.iszwe, this.qtnzq);
   }

      public void renderAllaySword(AllayEntityModel model, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
      if (MinecraftClient.getInstance().world != null && model != null) {
         Arm arm = this.isAllayLeftShoulder() ? Arm.LEFT : Arm.RIGHT;
         matrices.push();
         model.setArmAngle(arm, matrices);
         matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0F));
         matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F));
         matrices.translate(arm == Arm.LEFT ? -0.0625F : 0.0625F, 0.125F, -0.625F);
         MinecraftClient.getInstance()
            .getItemRenderer()
            .renderItem(
               ALLAY_SWORD,
               arm == Arm.LEFT ? ModelTransformationMode.THIRD_PERSON_LEFT_HAND : ModelTransformationMode.THIRD_PERSON_RIGHT_HAND,
               light,
               OverlayTexture.DEFAULT_UV,
               matrices,
               vertexConsumers,
               MinecraftClient.getInstance().world,
               0
            );
         matrices.pop();
      }
   }

      public boolean hasActiveAllayAttackTarget() {
      return this.uhhisd() != null;
   }

      public void checkPet() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (this.isState() && client.world != null && client.player != null) {
         if (this.convertMethod341()) {
            this.parseMethod22();
            if (this.fiddo == null || !this.fiddo.isAlive() || this.fiddo.isRemoved()) {
               this.ioxmoe();
            }
         } else {
            this.yd0();
         }
      }
   }

      public void onWorldChange() {
      if (this.isState()) {
         this.checkMethod40();
      }
   }

      private boolean convertMethod341() {
      return this.nwiqx.isSelected("Dog");
   }

      private boolean a14() {
      return this.nwiqx.isSelected("Dragon");
   }

      private void checkMethod40() {
      if (this.isState()) {
         if (this.convertMethod341()) {
            this.parseMethod22();
            this.emvh.clear();
            this.ioxmoe();
         } else {
            this.yd0();
            if (this.a14()) {
               this.parseMethod22();
               this.emvh.reset(MinecraftClient.getInstance());
            } else {
               this.emvh.clear();
            }
         }
      }
   }

      private void ioxmoe() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.world != null && client.player != null && this.convertMethod341()) {
         this.yd0();
         this.fiddo = new ParticleEntityFactory(EntityModuleFactory.DOG, client.world);
         this.fiddo.setOwner(client.player);
         this.fiddo.setTamed(true, true);
         this.fiddo.setPosition(client.player.getPos());
         client.world.addEntity(this.fiddo);
      }
   }

      private void yd0() {
      if (this.fiddo != null) {
         this.fiddo.discard();
         this.fiddo = null;
      }
   }

      private void e23(LivingEntity target) {
      long timestamp = System.currentTimeMillis();
      if (this.y25 != target.getId()) {
         this.yrmdf = timestamp;
         this.cikqfb();
      }

      this.y25 = target.getId();
      this.updateField21 = timestamp;
      this.wimfn = 0L;
      this.krrgg = false;
   }

      private Entity uhhisd() {
      if (this.txdon.isValue()
         && MinecraftClient.getInstance().world != null
         && MinecraftClient.getInstance().player != null
         && this.y25 != -2147483648) {
         Entity client = MinecraftClient.getInstance().world.getEntityById(this.y25);
         if (client != null && !client.isRemoved() && client != MinecraftClient.getInstance().player && !(client instanceof ParticleEntityFactory)) {
            if (client instanceof LivingEntity livingEntity && !livingEntity.isAlive()) {
               this.parseMethod22();
               return null;
            } else if (MinecraftClient.getInstance().player.squaredDistanceTo(client) > 4096.0) {
               this.parseMethod22();
               return null;
            } else {
               long timestamp = System.currentTimeMillis();
               if (this.wimfn == 0L && timestamp - this.updateField21 > 3600L) {
                  float value = (float)(timestamp - this.yrmdf) / 1000.0F;
                  this.zhtps = this.cyjs(client, this.bstiel(client, 1F), value);
                  this.wimfn = timestamp;
               }

               if (this.wimfn != 0L && timestamp - this.wimfn > 920L) {
                  this.parseMethod22();
                  return null;
               } else {
                  return client;
               }
            }
         } else {
            this.parseMethod22();
            return null;
         }
      } else {
         return null;
      }
   }

      private void cyg(VertexMatrixRenderer event, Entity target, Vec3d renderPos, float tickDelta, long now) {
      float value = (float)(now - this.yrmdf) / 1000.0F;
      Vec3d position = this.bstiel(target, tickDelta);
      Vec3d height = position.add(0, target.getHeight() * 0.56, 0);
      float value2 = this.kvpbse(renderPos, height);
      float value3 = this.cyth(renderPos, height);
      if (!this.krrgg) {
         this.createField980 = value2;
         this.tsrym = value3;
         this.krrgg = true;
      } else {
         this.createField980 = MathHelper.lerpAngleDegrees(0.32F, this.createField980, value2);
         this.tsrym = MathHelper.lerp(0.24F, this.tsrym, value3);
      }

      float value4 = MathHelper.clamp(MathHelper.wrapDegrees(value2 - this.createField980), -85.0F, 85.0F);
      MatrixStack matrices = event.getStack();
      matrices.push();
      matrices.translate(renderPos.x, renderPos.y, renderPos.z);
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F - this.createField980));
      matrices.scale(1.25F, 1.25F, 1.25F);
      matrices.scale(-1F, -1F, 1F);
      matrices.translate(0F, -1.501F, 0F);
      this.kfzia.age = MinecraftClient.getInstance().player.age + tickDelta + value * 20.0F;
      this.kfzia.limbFrequency = value * 6.4F;
      this.kfzia.limbAmplitudeMultiplier = 0.72F + MathHelper.sin(value * 7.0F + this.executeField20) * 0.12F;
      this.kfzia.yawDegrees = value4;
      this.kfzia.pitch = this.tsrym;
      this.kfzia.invisible = false;
      this.kfzia.invisibleToPlayer = false;
      this.kfzia.hasOutline = false;
      this.kfzia.shaking = false;
      this.kfzia.baby = false;
      this.kfzia.touchingWater = target.isTouchingWater();
      this.kfzia.bodyYaw = this.createField980;
      this.kfzia.baseScale = 1F;
      this.kfzia.ageScale = 1F;
      this.kfzia.pose = target instanceof LivingEntity livingEntity ? livingEntity.getPose() : EntityPose.STANDING;
      this.kfzia.deathTime = 0F;
      this.kfzia.hurt = false;
      this.kfzia.dancing = false;
      this.kfzia.spinning = false;
      this.kfzia.spinningAnimationTicks = 0F;
      this.kfzia.itemHoldAnimationTicks = 0.65F;
      RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
      this.tarbi.setAngles(this.kfzia);
      VertexConsumer vertexConsumer = event.getProvider().getBuffer(this.tarbi.getLayer(ALLAY_TEXTURE));
      this.tarbi.render(matrices, vertexConsumer, 15728880, OverlayTexture.DEFAULT_UV, this.getAllayColor());
      this.renderAllaySword(this.tarbi, matrices, event.getProvider(), 15728880);
      if (event.getProvider() instanceof Immediate immediate) {
         immediate.draw();
      }

      matrices.pop();
   }

      private Vec3d h19(Entity target, float tickDelta, long now) {
      Vec3d position = this.processMethod41(tickDelta);
      Vec3d position2 = this.bstiel(target, tickDelta);
      float value = (float)(now - this.yrmdf) / 1000.0F;
      Vec3d position3 = this.cyjs(target, position2, value);
      if (this.wimfn == 0L) {
         float value2 = MathHelper.clamp((float)(now - this.yrmdf) / 560.0F, 0F, 1F);
         return value2 < 1F ? this.transformMethod40(position, position3, value2) : position3;
      } else {
         float value3 = MathHelper.clamp((float)(now - this.wimfn) / 920.0F, 0F, 1F);
         return this.l12(this.zhtps, position, value3);
      }
   }

      private Vec3d processMethod41(float tickDelta) {
      Vec3d client = this.bstiel(MinecraftClient.getInstance().player, tickDelta);
      float client2 = MathHelper.lerpAngleDegrees(tickDelta, MinecraftClient.getInstance().player.prevBodyYaw, MinecraftClient.getInstance().player.bodyYaw);
      float value = client2 * 0.017453292F;
      Vec3d position = new Vec3d(-MathHelper.sin(value), 0, MathHelper.cos(value));
      Vec3d position2 = new Vec3d(position.z, 0, -position.x);
      double width = (this.isAllayLeftShoulder() ? 1 : -1F) * MinecraftClient.getInstance().player.getWidth() * 0.42;
      double height = MinecraftClient.getInstance().player.getHeight() - (MinecraftClient.getInstance().player.isSneaking() ? 0.38 : 0.24);
      Vec3d position3 = client.add(0, height, 0)
         .add(position2.multiply(width))
         .add(position2.multiply(this.getAllayOffsetX() * 0.65))
         .add(0, -0.0675F, 0)
         .add(position.multiply(0));
      if (this.hzedl.isValue()) {
         float client3 = (MinecraftClient.getInstance().player.age + tickDelta) * 1.3499999F;
         float value2 = MathHelper.sin(client3 * 0.42F) * 0.03F * 0.35F;
         position3 = position3.add(0, value2, 0);
      }

      return position3;
   }

      private Vec3d cyjs(Entity target, Vec3d targetPos, float elapsed) {
      double width = Math.max(0.86, target.getWidth() * 1.05 + 0.46) * this.computeField680;
      double value = this.nd0 * 0.017453292F + elapsed * this.enk * this.xudqq;
      double value2 = Math.sin(elapsed * 1.25F + this.executeField20 * 0.45F) * 0.07;
      double value3 = width + value2;
      double value4 = Math.cos(value) * value3;
      double value5 = Math.sin(value) * value3;
      double height = targetPos.y
         + target.getHeight() * (0.78 + this.deleteField780)
         + Math.sin(elapsed * 2.9F + this.executeField20) * 0.2
         + Math.cos(elapsed * 1.8F + this.executeField20 * 0.8F) * 0.08;
      return new Vec3d(targetPos.x + value4, height, targetPos.z + value5);
   }

      private Vec3d transformMethod40(Vec3d start, Vec3d end, float progress) {
      float value = this.o19(progress);
      Vec3d position = end.subtract(start);
      Vec3d position2 = new Vec3d(position.x, 0, position.z);
      position2 = position2.lengthSquared() < 1E-4 ? new Vec3d(0, 0, 1) : position2.normalize();
      Vec3d position3 = new Vec3d(position2.z, 0, -position2.x).normalize();
      Vec3d position4 = new Vec3d(0, this.enf, 0);
      Vec3d position5 = start.add(position3.multiply(this.ene * 0.52)).add(position4.multiply(0.82));
      Vec3d position6 = end.add(position3.multiply(-this.ene * 0.28)).add(position2.multiply(this.engc * 0.18)).add(position4.multiply(0.58));
      return this.rzstti(start, position5, position6, end, value);
   }

      private Vec3d l12(Vec3d start, Vec3d end, float progress) {
      float value = this.o19(progress);
      Vec3d position = end.subtract(start);
      Vec3d position2 = new Vec3d(position.x, 0, position.z);
      position2 = position2.lengthSquared() < 1E-4 ? new Vec3d(0, 0, 1) : position2.normalize();
      Vec3d position3 = new Vec3d(position2.z, 0, -position2.x).normalize();
      Vec3d position4 = new Vec3d(0, this.enf * 0.72, 0);
      Vec3d position5 = start.add(position3.multiply(-this.ene * 0.24)).add(position4.multiply(0.62));
      Vec3d position6 = end.add(position3.multiply(this.ene * 0.3)).add(position2.multiply(-this.engc * 0.1)).add(position4.multiply(0.22));
      Vec3d position7 = this.rzstti(start, position5, position6, end, value);
      return value > 0.985F ? end : position7;
   }

      private Vec3d rzstti(Vec3d p0, Vec3d p1, Vec3d p2, Vec3d p3, float t) {
      float value = 1F - t;
      double value2 = value * value * value;
      double value3 = 3.0 * value * value * t;
      double value4 = 3.0 * value * t * t;
      double value5 = t * t * t;
      return new Vec3d(
         p0.x * value2 + p1.x * value3 + p2.x * value4 + p3.x * value5,
         p0.y * value2 + p1.y * value3 + p2.y * value4 + p3.y * value5,
         p0.z * value2 + p1.z * value3 + p2.z * value4 + p3.z * value5
      );
   }

      private Vec3d bstiel(Entity entity, float tickDelta) {
      return new Vec3d(
         MathHelper.lerp(tickDelta, entity.prevX, entity.getX()),
         MathHelper.lerp(tickDelta, entity.prevY, entity.getY()),
         MathHelper.lerp(tickDelta, entity.prevZ, entity.getZ())
      );
   }

      private float o19(float value) {
      float value2 = MathHelper.clamp(value, 0F, 1F);
      return value2 * value2 * value2 * (value2 * (value2 * 6.0F - 15.0F) + 10.0F);
   }

      private void bllxvz() {
      if (this.tarbi == null && MinecraftClient.getInstance() != null && MinecraftClient.getInstance().getLoadedEntityModels() != null) {
         this.tarbi = new AllayEntityModel(MinecraftClient.getInstance().getLoadedEntityModels().getModelPart(EntityModelLayers.ALLAY));
      }
   }

      private void cikqfb() {
      this.nd0 = this.yr(0F, 360.0F);
      this.ene = this.yr(-1.1F, 1.1F);
      this.enf = this.yr(0.48F, 0.96F);
      this.engc = this.yr(-0.42F, 0.42F);
      this.computeField680 = this.yr(0.92F, 1.24F);
      this.deleteField780 = this.yr(-0.06F, 0.14F);
      this.executeField20 = this.yr(0F, 6.2831855F);
      this.enk = this.yr(1.7F, 2.45F);
      this.xudqq = Math.random() > 0.5 ? 1F : -1F;
   }

      private float yr(float min, float max) {
      return min + (float)Math.random() * (max - min);
   }

      private float kvpbse(Vec3d from, Vec3d to) {
      double x2 = to.x - from.x;
      double z2 = to.z - from.z;
      return (float)Math.toDegrees(Math.atan2(z2, x2)) - 90.0F;
   }

      private float cyth(Vec3d from, Vec3d to) {
      double x2 = to.x - from.x;
      double y2 = to.y - from.y;
      double z2 = to.z - from.z;
      double value = Math.sqrt(x2 * x2 + z2 * z2);
      return MathHelper.clamp((float)(-Math.toDegrees(Math.atan2(y2, value))), -35.0F, 35.0F);
   }

      private void parseMethod22() {
      this.y25 = -2147483648;
      this.yrmdf = 0L;
      this.updateField21 = 0L;
      this.wimfn = 0L;
      this.zhtps = new Vec3d(0, 0, 0);
      this.createField980 = 0F;
      this.tsrym = 0F;
      this.krrgg = false;
   }

}
