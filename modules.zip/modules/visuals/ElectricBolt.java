package winvi.noxiumvisuals.modules.visuals;

import java.util.List;
import net.minecraft.util.math.Vec3d;
public final class ElectricBolt {
      public List<List<Vec3d>> sbuob;
      public long cnytu;
      public long icktw;
      public double wjtiw;

   public ElectricBolt() {
   }

}
