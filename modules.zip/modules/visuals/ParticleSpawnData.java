package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.Vec3d;
public record ParticleSpawnData(
   Vec3d position,
   float velocityX,
   float velocityY,
   float velocityZ
) {

      public Vec3d position() {
      return this.position;
   }

      public float velocityX() {
      return this.velocityX;
   }

      public float velocityY() {
      return this.velocityY;
   }

      public float velocityZ() {
      return this.velocityZ;
   }

}
