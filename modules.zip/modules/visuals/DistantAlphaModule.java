package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
public final class DistantAlphaModule extends Module {
      private final ChoiceSetting pkcvn;
      private final NumberSetting efi;
      private final NumberSetting efju;
      private final NumberSetting wdhir;

   public DistantAlphaModule() {
      super(
         "Distant Alpha",
         "Bedrock-style camera proximity fade",
         ModuleCategory.VISUAL
      );
      this.pkcvn = new ChoiceSetting(
            "Curve",
            "Distance fade curve"
         )
         .value(
            "Linear",
            "In Circ",
            "Out Circ",
            "In Out Quad",
            "Out Cubic"
         )
         .selected("Out Cubic");
      this.efi = new NumberSetting(
            "Minimum Alpha",
            "Minimum entity visibility"
         )
         .setValue(0.08F)
         .range(0F, 0.5F);
      this.efju = new NumberSetting(
            "Start Distance",
            "Distance where entities become opaque"
         )
         .setValue(1.1F)
         .range(0.5F, 4.0F);
      this.wdhir = new NumberSetting(
            "Full Fade Distance",
            "Distance where entity reaches minimum visibility"
         )
         .setValue(0.15F)
         .range(0F, 1F);
      this.pkcvn.withTranslation("distantalpha.curve", "distantalpha.curve.desc");
      this.efi.withTranslation("distantalpha.minalpha", "distantalpha.minalpha.desc");
      this.efju.withTranslation("distantalpha.startdistance", "distantalpha.startdistance.desc");
      this.wdhir.withTranslation("distantalpha.dissolvedistance", "distantalpha.dissolvedistance.desc");
      this.setup(new ModuleSetting[]{this.pkcvn, this.efi, this.efju, this.wdhir});
   }

      public float getEntityAlpha(Entity entity) {
      if (!this.isState() || entity == null || MinecraftClient.getInstance().getEntityRenderDispatcher().camera == null) {
         return 1F;
      } else if (!EntityVisibilityFilter.shouldRender(entity)) {
         return 1F;
      } else if (entity == MinecraftClient.getInstance().player && MinecraftClient.getInstance().options.getPerspective().isFirstPerson()) {
         return 1F;
      } else {
         Vec3d client = MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getPos();
         Box box = entity.getBoundingBox();
         Vec3d position = new Vec3d(
            MathHelper.clamp(client.x, box.minX, box.maxX),
            MathHelper.clamp(client.y, box.minY, box.maxY),
            MathHelper.clamp(client.z, box.minZ, box.maxZ)
         );
         float value = (float)client.distanceTo(position);
         float value2 = Math.max(0.05F, this.efju.getValue() - this.wdhir.getValue());
         float value3 = MathHelper.clamp((value - this.wdhir.getValue()) / value2, 0F, 1F);
         String text = this.pkcvn.getSelected();

         float value4 = switch (text) {
            case "In Circ" -> 1F - (float)Math.sqrt(Math.max(0F, 1F - value3 * value3));
            case "Out Circ" -> (float)Math.sqrt(
               Math.max(0F, 1F - (value3 - 1F) * (value3 - 1F))
            );
            case "In Out Quad" -> value3 < 0.5F
               ? 2.0F * value3 * value3
               : 1F - (float)Math.pow(-2.0F * value3 + 2.0F, 2.0) * 0.5F;
            case "Out Cubic" -> 1F - (float)Math.pow(1F - value3, 3.0);
            default -> value3;
         };
         return MathHelper.lerp(value4, this.efi.getValue(), 1F);
      }
   }

   static {
      int index = 0;
   }
}
