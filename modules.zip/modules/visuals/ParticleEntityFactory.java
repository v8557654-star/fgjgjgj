package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.DefaultAttributeContainer.Builder;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
public class ParticleEntityFactory extends TameableEntity {
      private final ModuleManager sdxyt = new ModuleManager(0F);
      private final ModuleManager formatField470 = new ModuleManager(0F);
      private final ModuleManager evkr = new ModuleManager(0F);
      private float vl = 0F;
      private boolean checkField690;
      private long sjqsz = 0L;
      public float prevLimbSwingAmount;
      public float limbSwingAmount;
      public float limbSwing;
      private long vo = 0L;
      private boolean p21 = false;
      private long lkwdr = 0L;

   public ParticleEntityFactory(EntityType<? extends TameableEntity> type, World world) {
      super(type, world);
      this.noClip = true;
   }

      public static Builder createDogAttributes() {
      return TameableEntity.createMobAttributes()
         .add(EntityAttributes.MAX_HEALTH, 20.0)
         .add(EntityAttributes.MOVEMENT_SPEED, 0.3)
         .add(EntityAttributes.ATTACK_DAMAGE, 4.0)
         .add(EntityAttributes.FOLLOW_RANGE, 16.0);
   }

      protected void initGoals() {
   }

   @Nullable
      public LivingEntity getOwner() {
      return super.getOwner();
   }

      public void setTarget(@Nullable LivingEntity target) {
      if (target != null && target != this.getTarget()) {
         super.setTarget(target);
         if (this.isOnGround()) {
            this.vo = 0L;
         }
      } else if (target == null) {
         super.setTarget(null);
      }
   }

      public boolean isBreedingItem(ItemStack stack) {
      return false;
   }

   @Nullable
      public ParticleEntityFactory createChild(ServerWorld world, PassiveEntity entity) {
      return null;
   }

      public void tick() {
      super.tick();
      LivingEntity livingEntity = this.getOwner();
      if (livingEntity != null && livingEntity.isAlive()) {
         Vec3d position = livingEntity.getPos();
         LivingEntity livingEntity2 = this.getTarget();
         if (livingEntity2 != null && livingEntity2.isAlive()) {
            double value = livingEntity.squaredDistanceTo(livingEntity2);
            if (value > 25.0) {
               this.setTarget(null);
            }
         }

         if (this.squaredDistanceTo(livingEntity) > 100.0) {
            this.setPosition(position);
            this.setVelocity(Vec3d.ZERO);
         }

         Vec3d position2 = this.getVelocity();
         LivingEntity livingEntity3 = this.getTarget();
         position2 = position2.add(0, -0.08F, 0);
         boolean enabled = false;

         for (int index = 0; index < 3; index++) {
            if (this.getWorld().getBlockState(this.getBlockPos().down(index)).isSolid()) {
               double y2 = this.getBlockPos().down(index).getY() + 1;
               if (this.getY() <= y2 + 0.1 && position2.y <= 0) {
                  this.setPosition(this.getX(), y2, this.getZ());
                  position2 = new Vec3d(position2.x, 0, position2.z);
                  enabled = true;
                  break;
               }
            }
         }

         if (livingEntity3 != null && livingEntity3.isAlive()) {
            Vec3d position3 = livingEntity3.getPos();
            double value2 = this.squaredDistanceTo(livingEntity3);
            long timestamp = System.currentTimeMillis();
            if (value2 < 1.5 && !this.p21) {
               this.p21 = true;
               this.lkwdr = timestamp;
            }

            if (this.p21 && timestamp - this.lkwdr > 500L) {
               this.p21 = false;
            }

            if (this.p21) {
               Vec3d position4 = this.getPos().subtract(position3).normalize();
               position2 = position2.add(position4.multiply(0.08));
            } else {
               Vec3d position5 = position3.subtract(this.getPos()).normalize();
               position2 = position2.add(position5.multiply(0.12));
               boolean enabled2 = enabled && timestamp - this.vo > 3000L;
               if (enabled2 || enabled && livingEntity3.getY() > this.getY() + 0.5) {
                  position2 = new Vec3d(position2.x, 0.42, position2.z);
                  this.vo = timestamp;
               }
            }
         } else {
            double value3 = this.squaredDistanceTo(livingEntity);
            if (value3 > 4.0) {
               Vec3d position6 = position.subtract(this.getPos()).normalize();
               position2 = position2.add(position6.multiply(0.1));
               if (enabled) {
                  double y3 = livingEntity.getY() - this.getY();
                  if (y3 > 0.3) {
                     Vec3d position7 = position6.normalize();
                     boolean enabled3 = false;

                     for (int index2 = 0; index2 <= 1; index2++) {
                        if (this.getWorld()
                           .getBlockState(this.getBlockPos().add((int)position7.x, index2, (int)position7.z))
                           .isSolid()) {
                           enabled3 = true;
                           break;
                        }
                     }

                     if (enabled3 || y3 > 0.5) {
                        position2 = new Vec3d(position2.x, 0.5, position2.z);
                     }
                  }
               }
            } else if (value3 < 0.5) {
               float value4 = (float)(Math.random() * 360.0);
               double value5 = -Math.sin(Math.toRadians(value4)) * 0.1;
               double value6 = Math.cos(Math.toRadians(value4)) * 0.1;
               position2 = position2.add(value5, 0, value6);
            }
         }

         position2 = position2.multiply(0.8, 0.98, 0.8);
         this.setVelocity(position2);
         this.move(MovementType.SELF, position2);
         this.isMethod98();
         this.sdxyt.animate(this.vl, 50.0F);
         LivingEntity livingEntity4 = livingEntity;
         if (livingEntity3 != null && livingEntity3.isAlive()) {
            livingEntity4 = livingEntity3;
         } else if (livingEntity3 != null && !livingEntity3.isAlive()) {
            this.setTarget(null);
         }

         Vec3d position8 = livingEntity4.getEyePos().subtract(this.getPos().add(0, 0.5, 0));
         float value7 = (float)(Math.atan2(position8.z, position8.x) * 180.0 / 3.141592653589793) - 90.0F;
         float value8 = value7 - this.vl;

         while (value8 > 180.0F) {
            value8 -= 360.0F;
         }

         while (value8 < -180.0F) {
            value8 += 360.0F;
         }

         this.formatField470.animate(MathHelper.clamp(value8, -75.0F, 75.0F), 150.0F);
         double value9 = Math.sqrt(position8.x * position8.x + position8.z * position8.z);
         float value10 = -((float)(Math.atan2(position8.y, value9) * 180.0 / 3.141592653589793));
         this.evkr.animate(MathHelper.clamp(value10, -60.0F, 60.0F), 150.0F);
         this.parseMethod83();
         if (!(Math.abs(position2.x) < 0.01) || !(Math.abs(position2.z) < 0.01) || livingEntity3 != null) {
            this.sjqsz = 0L;
         } else if (this.sjqsz == 0L) {
            this.sjqsz = System.currentTimeMillis();
         }

         double value11 = livingEntity.getVelocity().horizontalLength();
         this.checkField690 = this.sjqsz > 0L && System.currentTimeMillis() - this.sjqsz > 2000L && value11 < 0.1;
      } else {
         this.discard();
      }
   }

      private void isMethod98() {
      Vec3d position = this.getVelocity();
      if (Math.abs(position.x) > 0.01 || Math.abs(position.z) > 0.01) {
         double value = Math.atan2(position.z, position.x);
         float value2 = (float)Math.toDegrees(value) - 90.0F;
         float value3 = value2 - this.vl;

         while (value3 > 180.0F) {
            value3 -= 360.0F;
         }

         while (value3 < -180.0F) {
            value3 += 360.0F;
         }

         if (Math.abs(value3) > 120.0F) {
            this.vl = value2;
         } else if (Math.abs(value3) > 60.0F) {
            this.vl += value3 * 0.85F;
         } else {
            this.vl += value3 * 0.7F;
         }
      }
   }

      private void parseMethod83() {
      this.prevLimbSwingAmount = this.limbSwingAmount;
      Vec3d position = this.getVelocity();
      double x2 = position.x;
      double z2 = position.z;
      float value = MathHelper.sqrt((float)(x2 * x2 + z2 * z2)) * 4.0F;
      if (value > 1F) {
         value = 1F;
      }

      this.limbSwingAmount = this.limbSwingAmount + (value - this.limbSwingAmount) * 0.4F;
      this.limbSwing = this.limbSwing + this.limbSwingAmount;
   }

      public float getBodyYaw() {
      return this.sdxyt.get();
   }

      public float getHeadYaw() {
      return this.formatField470.get();
   }

      public float getHeadPitch() {
      return this.evkr.get();
   }

      public float getLimbSwing() {
      return this.limbSwing;
   }

      public float getLimbSwingAmount() {
      return this.limbSwingAmount;
   }

      public boolean isLaying() {
      return this.checkField690;
   }

      public boolean canHit() {
      MinecraftClient client = MinecraftClient.getInstance();
      return client.player != null && client.player == this.getOwner();
   }

      public boolean canBeHitByProjectile() {
      return false;
   }

      public boolean isPushable() {
      return false;
   }

      protected void pushAway(Entity entity) {
   }

      public boolean canAvoidTraps() {
      return true;
   }

      public boolean damage(ServerWorld world, DamageSource source, float amount) {
      return false;
   }

      public ActionResult interactMob(PlayerEntity player, Hand hand) {
      if (player != this.getOwner()) {
         return ActionResult.PASS;
      } else {
         for (int index = 0; index < 7; index++) {
            double value = this.random.nextGaussian() * 0.02;
            double value2 = this.random.nextGaussian() * 0.02;
            double value3 = this.random.nextGaussian() * 0.02;
            this.getWorld()
               .addParticle(
                  ParticleTypes.HEART,
                  this.getX() + this.random.nextFloat() * this.getWidth() * 2.0F - this.getWidth(),
                  this.getY() + 0.5 + this.random.nextFloat() * this.getHeight(),
                  this.getZ() + this.random.nextFloat() * this.getWidth() * 2.0F - this.getWidth(),
                  value,
                  value2,
                  value3
               );
         }

         return ActionResult.SUCCESS;
      }
   }

      public EntityData initialize(ServerWorld world, LocalDifficulty difficulty, SpawnReason spawnReason, @Nullable EntityData entityData) {
      return super.initialize(world, difficulty, spawnReason, entityData);
   }

}
