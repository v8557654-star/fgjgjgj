package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.Vec3d;
public record SonarPulse(
   long startTime,
   Vec3d center
) {

      public long startTime() {
      return this.startTime;
   }

      public Vec3d center() {
      return this.center;
   }

}
