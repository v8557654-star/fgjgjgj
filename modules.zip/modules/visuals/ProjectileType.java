package winvi.noxiumvisuals.modules.visuals;

public enum ProjectileType {
      TRIDENT,
      ARROW,
      PEARL,
      SNOWBALL,
      EGG,
      WIND_CHARGE,
      POTION,
      EXPERIENCE_BOTTLE,
      FIREWORK,
      VOXEL;

}
