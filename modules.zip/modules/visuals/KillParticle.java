package winvi.noxiumvisuals.modules.visuals;

import java.util.Arrays;
import net.minecraft.block.AirBlock;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.shape.VoxelShape;
import winvi.noxiumvisuals.modules.particles.KillParticleModule;
import winvi.noxiumvisuals.utils.ClientPosition;
import winvi.noxiumvisuals.utils.ParticleInstance;
import winvi.noxiumvisuals.utils.ParticlePhysics;
import winvi.noxiumvisuals.utils.render.WorldParticleBatcher;
import winvi.noxiumvisuals.utils.ParticleCameraRenderer;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public class KillParticle extends ParticleInstance {
      protected final Identifier texture = ParticleTextures.FIREFLY_ALT;
      protected long time;
      public final long gft;
      public float xtujh;
      protected final int[] gradientColors;
      public final KillParticleModule v36;

   public KillParticle(float x, float y, float z, KillParticleModule module) {
      super(x, y, z);
      this.v36 = module;
      this.time = System.currentTimeMillis();
      this.gft = (long)(module.qezcs.getValue() * 1000.0F);
      this.xtujh = 10.0F;
      String text = module.transformField2.getSelected();
      if (text.equals("None")) {
         this.motionX = 0F;
         this.motionY = 0F;
         this.motionZ = 0F;
      } else if (module.transformField2.getSelected().equals("FLY")) {
         this.motionX = (float)(Math.random() - 0.5) * 0.1F;
         this.motionY = (float)Math.random() * 0.15F;
         this.motionZ = (float)(Math.random() - 0.5) * 0.1F;
      } else {
         this.motionX = (float)(Math.random() - 0.5) * 0.1F;
         this.motionY = (float)(Math.random() - 0.5) * 0.1F;
         this.motionZ = (float)(Math.random() - 0.5) * 0.1F;
      }

      this.gradientColors = new int[4];
      Arrays.fill(this.gradientColors, module.getVisualColor());
   }

      @Override
   public boolean update(long currentTime, boolean isVisible) {
      this.px = this.x;
      this.py = this.y;
      this.pz = this.z;
      if (!this.v36.transformField2.getSelected().equals("None")) {
         ClientPosition clientPosition = this.v36.transformField2.getSelected().equals("FALL")
            ? ParticlePhysics.bounce(this.x, this.y, this.z, this.motionX, this.motionY, this.motionZ, 1F, 0.0022F)
            : ParticlePhysics.drift(this.x, this.y, this.z, this.motionX, this.motionY, this.motionZ, 1F, 0.0022F);
         this.x = clientPosition.x();
         this.y = clientPosition.y();
         this.z = clientPosition.z();
         this.motionX = clientPosition.motionX();
         this.motionY = clientPosition.motionY();
         this.motionZ = clientPosition.motionZ();
      }

      long timestamp = currentTime - this.time;
      float value = Math.min(1F, (float)timestamp / (float)this.gft);
      return value >= 1F;
   }

      public float dyo() {
      return 0.03F + this.xtujh * 0.012F;
   }

      public boolean pfrznj(double x, double y, double z, float radius) {
      return this.yeyiam(x, y, z)
         || this.yeyiam(x + radius, y, z)
         || this.yeyiam(x - radius, y, z)
         || this.yeyiam(x, y, z + radius)
         || this.yeyiam(x, y, z - radius)
         || this.yeyiam(x, y + radius, z)
         || this.yeyiam(x, y - radius, z);
   }

      public boolean yeyiam(double x, double y, double z) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         BlockPos blockPos = BlockPos.ofFloored(x, y, z);
         BlockState client = MinecraftClient.getInstance().world.getBlockState(blockPos);
         if (!(client.getBlock() instanceof AirBlock) && !client.isAir()) {
            VoxelShape client2 = client.getCollisionShape(MinecraftClient.getInstance().world, blockPos);
            return !client2.isEmpty();
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

      public boolean update() {
      return this.update(System.currentTimeMillis(), true);
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (this.v36.isState()) {
         long timestamp = System.currentTimeMillis();
         long timestamp2 = timestamp - this.time;
         float value = Math.min(1F, (float)timestamp2 / (float)this.gft);
         float value2 = this.xtujh;
         float value3 = 1F;
         if (value < 0.1F) {
            value3 = value / 0.1F;
         }

         if (value >= 0.7F) {
            float value4 = 1F - (value - 0.7F) / 0.3F;
            value3 = value4;
         }

         if (!(value3 <= 0F) && !(value2 <= 0F)) {
            if (ParticleCameraRenderer.isParticleVisible(this.getX(), this.getY(), this.getZ(), value2 * 0.07F)) {
               float value5 = 0.07F;
               float value6 = value5 * value2;
               double value7 = MathHelper.lerp(tickDelta, this.px, this.x);
               double value8 = MathHelper.lerp(tickDelta, this.py, this.y);
               double value9 = MathHelper.lerp(tickDelta, this.pz, this.z);
               matrixStack.push();
               matrixStack.translate(value7, value8, value9);
               matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getYaw()));
               matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getPitch()));
               WorldParticleBatcher.queueGhostParticle(matrixStack, this.texture, value6, value3, this.gradientColors[0], true, this.gradientColors);
               matrixStack.pop();
            }
         }
      }
   }

   static {
      int index = 0;
   }
}
