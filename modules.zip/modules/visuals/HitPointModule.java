package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.HitMarkerPoint;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.AttackEntityEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.MatrixEntityProvider;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
public class HitPointModule extends Module {
      private final Identifier vaxyn;
      private final List<HitMarkerPoint> executeField220;
      private final NumberSetting hasField71;
      private final NumberSetting iw0;
      private final MultiSelectSetting ix;

   public HitPointModule() {
      super("HitPoint", ModuleCategory.VISUAL);
      this.vaxyn = Identifier.of("noxiumvisual", "textures/o163c9wkg/i33quj5pla8.png");
      this.executeField220 = new ArrayList<>();
      this.hasField71 = new NumberSetting(
            "Size",
            "Hit point cube size"
         )
         .setValue(0.18F)
         .range(0.05F, 0.3F);
      this.iw0 = new NumberSetting(
            "Lifetime",
            "Hit point lifetime in seconds"
         )
         .setValue(1F)
         .range(0.2F, 3.0F);
      this.ix = new MultiSelectSetting(
            "Effects",
            "Hit point visual effects"
         )
         .value(
            "Rotation",
            "Glow",
            "Diagonals"
         )
         .selected(
            "Glow",
            "Diagonals"
         );
      this.showVisualColorSettings();
      this.hasField71.withTranslation("hitpoint.size", "hitpoint.size.desc");
      this.iw0.withTranslation("hitpoint.lifetime", "hitpoint.lifetime.desc");
      this.ix.withTranslation("hitpoint.effects", "hitpoint.effects.desc");
      this.setup(new ModuleSetting[]{this.hasField71, this.iw0, this.ix});
   }

      @Override
   public void deactivate() {
      this.executeField220.clear();
   }

   @EventHandler
      public void onAttack(AttackEntityEvent event) {
      if (this.isState() && event.getEntity() != null && EntityVisibilityFilter.shouldRender(event.getEntity())) {
         Vec3d position = null;
         if (MinecraftClient.getInstance().crosshairTarget instanceof EntityHitResult entityHitResult
            && entityHitResult.getType() == Type.ENTITY
            && entityHitResult.getEntity() == event.getEntity()) {
            position = entityHitResult.getPos();
         }

         if (position == null) {
            position = new Vec3d(
               event.getEntity().getX(), event.getEntity().getY() + event.getEntity().getHeight() * 0.5, event.getEntity().getZ()
            );
         }

         this.executeField220.add(new HitMarkerPoint(position, System.currentTimeMillis(), (float)(Math.random() * 360.0)));
      }
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState() && !this.executeField220.isEmpty() && MinecraftClient.getInstance().world != null) {
         long timestamp = System.currentTimeMillis();
         long timestamp2 = Math.max(1L, (long)(this.iw0.getValue() * 1000.0F));
         Iterator iterator2 = this.executeField220.iterator();

         while (iterator2.hasNext()) {
            if (timestamp - ((HitMarkerPoint)iterator2.next()).createdAt() > timestamp2) {
               iterator2.remove();
            }
         }

         if (!this.executeField220.isEmpty()) {
            Camera client = MinecraftClient.getInstance().gameRenderer.getCamera();
            this.duryux(event, client, timestamp, timestamp2);
            this.vt(event, timestamp, timestamp2);
         }
      }
   }

      private void duryux(VertexMatrixRenderer event, Camera camera, long now, long maxLifetimeMs) {
      if (this.ix.isSelected("Glow")) {
         RenderSystem.enableDepthTest();
         RenderSystem.enableBlend();
         RenderSystem.depthMask(false);
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
         RenderSystem.setShaderTexture(0, this.vaxyn);
         RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
         BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

         for (HitMarkerPoint moduleData3 : this.executeField220) {
            float value = this.vx1(now, moduleData3, maxLifetimeMs);
            float value2 = this.processMethod73(value);
            float value3 = this.createMethod43(value) * 4.0F;
            float value4 = value3 / 2.0F;
            int index = this.a13(moduleData3, value);
            int index2 = ColorUtils.multAlpha(index, value2 * 0.4F);
            Matrix4f matrix = this.gelyag(event.getStack().peek().getPositionMatrix(), moduleData3.position(), -camera.getYaw(), camera.getPitch());

            try {
               bufferBuilder.vertex(matrix, -value4, value4, 0F).texture(0F, 1F).color(index2);
               bufferBuilder.vertex(matrix, value4, value4, 0F).texture(1F, 1F).color(index2);
               bufferBuilder.vertex(matrix, value4, -value4, 0F).texture(1F, 0F).color(index2);
               bufferBuilder.vertex(matrix, -value4, -value4, 0F).texture(0F, 0F).color(index2);
            } finally {
               MatrixEntityProvider.release(matrix);
            }
         }

         BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
         RenderSystem.depthMask(true);
      }
   }

      private void vt(VertexMatrixRenderer event, long now, long maxLifetimeMs) {
      RenderSystem.enableBlend();
      RenderSystem.disableCull();
      RenderSystem.depthMask(false);
      RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      RenderSystem.lineWidth(2.0F);
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

      for (HitMarkerPoint moduleData3 : this.executeField220) {
         float value = this.vx1(now, moduleData3, maxLifetimeMs);
         float value2 = this.processMethod73(value);
         float value3 = this.createMethod43(value) / 2.0F;
         float value4 = this.ix.isSelected("Rotation")
            ? moduleData3.baseRotation() + (1F - value) * 120.0F
            : moduleData3.baseRotation();
         int index = this.a13(moduleData3, value);
         int index2 = ColorUtils.multAlpha(index, value2);
         Matrix4f matrix = this.gelyag(event.getStack().peek().getPositionMatrix(), moduleData3.position(), value4, value4 * 0.7F);

         try {
            this.calculateMethod45(bufferBuilder, matrix, value3, index2);
            if (this.ix.isSelected("Diagonals")) {
               int index3 = ColorUtils.multAlpha(index, value2 * 0.4F);
               this.removeMethod0(bufferBuilder, matrix, value3, index3);
            }
         } finally {
            MatrixEntityProvider.release(matrix);
         }
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.depthMask(true);
      RenderSystem.lineWidth(1F);
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.disableBlend();
   }

      private void calculateMethod45(BufferBuilder buffer, Matrix4f matrix, float halfSize, int color) {
      buffer.vertex(matrix, -halfSize, -halfSize, -halfSize).color(color);
      buffer.vertex(matrix, halfSize, -halfSize, -halfSize).color(color);
      buffer.vertex(matrix, halfSize, -halfSize, -halfSize).color(color);
      buffer.vertex(matrix, halfSize, -halfSize, halfSize).color(color);
      buffer.vertex(matrix, halfSize, -halfSize, halfSize).color(color);
      buffer.vertex(matrix, -halfSize, -halfSize, halfSize).color(color);
      buffer.vertex(matrix, -halfSize, -halfSize, halfSize).color(color);
      buffer.vertex(matrix, -halfSize, -halfSize, -halfSize).color(color);
      buffer.vertex(matrix, -halfSize, halfSize, -halfSize).color(color);
      buffer.vertex(matrix, halfSize, halfSize, -halfSize).color(color);
      buffer.vertex(matrix, halfSize, halfSize, -halfSize).color(color);
      buffer.vertex(matrix, halfSize, halfSize, halfSize).color(color);
      buffer.vertex(matrix, halfSize, halfSize, halfSize).color(color);
      buffer.vertex(matrix, -halfSize, halfSize, halfSize).color(color);
      buffer.vertex(matrix, -halfSize, halfSize, halfSize).color(color);
      buffer.vertex(matrix, -halfSize, halfSize, -halfSize).color(color);
      buffer.vertex(matrix, -halfSize, -halfSize, -halfSize).color(color);
      buffer.vertex(matrix, -halfSize, halfSize, -halfSize).color(color);
      buffer.vertex(matrix, halfSize, -halfSize, -halfSize).color(color);
      buffer.vertex(matrix, halfSize, halfSize, -halfSize).color(color);
      buffer.vertex(matrix, halfSize, -halfSize, halfSize).color(color);
      buffer.vertex(matrix, halfSize, halfSize, halfSize).color(color);
      buffer.vertex(matrix, -halfSize, -halfSize, halfSize).color(color);
      buffer.vertex(matrix, -halfSize, halfSize, halfSize).color(color);
   }

      private void removeMethod0(BufferBuilder buffer, Matrix4f matrix, float halfSize, int color) {
      buffer.vertex(matrix, -halfSize, -halfSize, -halfSize).color(color);
      buffer.vertex(matrix, 0F, 0F, 0F).color(color);
      buffer.vertex(matrix, halfSize, -halfSize, -halfSize).color(color);
      buffer.vertex(matrix, 0F, 0F, 0F).color(color);
      buffer.vertex(matrix, halfSize, -halfSize, halfSize).color(color);
      buffer.vertex(matrix, 0F, 0F, 0F).color(color);
      buffer.vertex(matrix, -halfSize, -halfSize, halfSize).color(color);
      buffer.vertex(matrix, 0F, 0F, 0F).color(color);
      buffer.vertex(matrix, -halfSize, halfSize, -halfSize).color(color);
      buffer.vertex(matrix, 0F, 0F, 0F).color(color);
      buffer.vertex(matrix, halfSize, halfSize, -halfSize).color(color);
      buffer.vertex(matrix, 0F, 0F, 0F).color(color);
      buffer.vertex(matrix, halfSize, halfSize, halfSize).color(color);
      buffer.vertex(matrix, 0F, 0F, 0F).color(color);
      buffer.vertex(matrix, -halfSize, halfSize, halfSize).color(color);
      buffer.vertex(matrix, 0F, 0F, 0F).color(color);
   }

      private Matrix4f gelyag(Matrix4f baseMatrix, Vec3d position, float yRotationDeg, float xRotationDeg) {
      return MatrixEntityProvider.acquire(baseMatrix)
         .translate((float)position.x, (float)position.y, (float)position.z)
         .rotate(RotationAxis.POSITIVE_Y.rotationDegrees(yRotationDeg))
         .rotate(RotationAxis.POSITIVE_X.rotationDegrees(xRotationDeg));
   }

      private float vx1(long now, HitMarkerPoint marker, long maxLifetimeMs) {
      return Math.min(1F, (float)(now - marker.createdAt()) / (float)maxLifetimeMs);
   }

      private float processMethod73(float progress) {
      float value = 1F;
      if (progress > 0.8F) {
         value = (1F - progress) / 0.2F;
      } else if (progress < 0.2F) {
         value = progress / 0.2F;
      }

      value = Math.max(0F, Math.min(1F, value));
      return value * value * (3.0F - 2.0F * value);
   }

      private float createMethod43(float progress) {
      return Math.min(this.hasField71.getValue(), 0.3F) * this.processMethod73(progress);
   }

      private int a13(HitMarkerPoint marker, float progress) {
      return this.getVisualColor();
   }

}
