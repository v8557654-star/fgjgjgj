package winvi.noxiumvisuals.modules.visuals;

import java.awt.Color;
import java.util.Arrays;
import net.minecraft.block.AirBlock;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.shape.VoxelShape;
import winvi.noxiumvisuals.modules.particles.TotemParticleModule;
import winvi.noxiumvisuals.utils.ClientPosition;
import winvi.noxiumvisuals.utils.ParticleInstance;
import winvi.noxiumvisuals.utils.ParticlePhysics;
import winvi.noxiumvisuals.utils.render.WorldParticleBatcher;
import winvi.noxiumvisuals.utils.ParticleCameraRenderer;
import winvi.noxiumvisuals.utils.render.RenderMath;
public class TotemParticle extends ParticleInstance {
      float rotationAngle;
      float rotationSpeed;
      long time;
      Color color;
      Identifier glyphTexture;
      TotemParticleModule module;
      protected final int[] gradientColors;
      float speedMultiplier;
      float particleScale;

   public TotemParticle(float x, float y, float z, float rotationAngle, float rotationSpeed, TotemParticleModule module) {
      super(x, y, z);
      this.module = module;
      float value = module.particlesSpeed.getValue();
      this.speedMultiplier = 0.55F + (value - 1F) / 9.0F * 1.55F;
      this.particleScale = module.particlesScale.getValue();
      float value2 = RenderMath.random(0.018F, 0.052F);
      this.motionX = RenderMath.random(-value2, value2);
      this.motionY = RenderMath.random(-0.015F, 0.055F);
      this.motionZ = RenderMath.random(-value2, value2);
      this.time = System.currentTimeMillis();
      this.rotationAngle = rotationAngle;
      this.rotationSpeed = rotationSpeed;
      if (!TotemParticleModule.h15.isEmpty()) {
         this.glyphTexture = TotemParticleModule.h15.get(TotemParticleModule.ui1.nextInt(TotemParticleModule.h15.size()));
      }

      this.gradientColors = new int[4];
      if (module.defaultColors.isValue()) {
         Color color2;
         if (TotemParticleModule.ui1.nextInt(4) == 0) {
            color2 = new Color(
               0.6F + TotemParticleModule.ui1.nextFloat() * 0.2F, 0.6F + TotemParticleModule.ui1.nextFloat() * 0.3F, TotemParticleModule.ui1.nextFloat() * 0.2F
            );
         } else {
            color2 = new Color(
               0.1F + TotemParticleModule.ui1.nextFloat() * 0.2F, 0.4F + TotemParticleModule.ui1.nextFloat() * 0.3F, TotemParticleModule.ui1.nextFloat() * 0.2F
            );
         }

         for (int index = 0; index < 4; index++) {
            this.gradientColors[index] = color2.getRGB();
         }

         this.color = color2;
      } else {
         Arrays.fill(this.gradientColors, module.getVisualColor());
         this.color = new Color(this.gradientColors[0], true);
      }
   }

      @Override
   public boolean update(long currentTime, boolean isVisible) {
      this.px = this.x;
      this.py = this.y;
      this.pz = this.z;
      boolean enabled = this.module.physic.getSelected().equals("BOUNCE");
      ClientPosition clientPosition = enabled
         ? ParticlePhysics.bounce(this.x, this.y, this.z, this.motionX, this.motionY, this.motionZ, this.speedMultiplier, 0.0016F)
         : ParticlePhysics.drift(this.x, this.y, this.z, this.motionX, this.motionY, this.motionZ, this.speedMultiplier, -2.5E-4F);
      this.x = clientPosition.x();
      this.y = clientPosition.y();
      this.z = clientPosition.z();
      this.motionX = clientPosition.motionX();
      this.motionY = clientPosition.motionY();
      this.motionZ = clientPosition.motionZ();
      long timestamp = currentTime - this.time;
      float value = this.module.renderTime.getValue() * 1000.0F;
      float value2 = Math.min(1F, (float)timestamp / value);
      return value2 >= 1F;
   }

      public boolean update() {
      return this.update(System.currentTimeMillis(), true);
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (this.module.isState()) {
         float value = (float)(System.currentTimeMillis() - this.time) / (this.module.renderTime.getValue() * 1000.0F);
         value = MathHelper.clamp(value, 0F, 1F);
         float value2 = 1F;
         float value3 = this.particleScale;
         if (value < 0.1F) {
            float value4 = value / 0.1F;
            value2 = value4;
         }

         if (value >= 0.8F) {
            float value5 = 1F - (value - 0.8F) / 0.2F;
            if (this.module.disappear.getSelected().equals("ALPHA")) {
               value2 *= value5;
            } else if (this.module.disappear.getSelected().equals("SCALE")) {
               value3 = this.particleScale * value5;
            }
         }

         if (!(value2 <= 0F) && !(value3 <= 0F)) {
            if (ParticleCameraRenderer.isParticleVisible(this.getX(), this.getY(), this.getZ(), value3 * 0.07F)) {
               float value6 = 0.07F;
               MinecraftClient client = MinecraftClient.getInstance();
               double value7 = MathHelper.lerp(tickDelta, this.px, this.x);
               double value8 = MathHelper.lerp(tickDelta, this.py, this.y);
               double value9 = MathHelper.lerp(tickDelta, this.pz, this.z);
               matrixStack.push();
               matrixStack.translate(value7, value8, value9);
               matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-client.gameRenderer.getCamera().getYaw()));
               matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.gameRenderer.getCamera().getPitch()));
               int client2 = Math.max(30, MinecraftClient.getInstance().getCurrentFps());
               matrixStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(this.rotationAngle = this.rotationAngle + 1F / client2 * this.rotationSpeed));
               if (this.glyphTexture != null) {
                  WorldParticleBatcher.queueGhostParticle(
                     matrixStack,
                     this.glyphTexture,
                     value6 * value3,
                     value2,
                     this.gradientColors[0],
                     !this.module.defaultColors.isValue(),
                     this.module.defaultColors.isValue() ? null : this.gradientColors
                  );
               }

               matrixStack.pop();
            }
         }
      }
   }

      private float parseMethod24() {
      return 0.03F + this.particleScale * 0.012F;
   }

      private boolean qzaqvx(double x, double y, double z, float radius) {
      return this.processMethod97(x, y, z)
         || this.processMethod97(x + radius, y, z)
         || this.processMethod97(x - radius, y, z)
         || this.processMethod97(x, y, z + radius)
         || this.processMethod97(x, y, z - radius)
         || this.processMethod97(x, y + radius, z)
         || this.processMethod97(x, y - radius, z);
   }

      private boolean processMethod97(double x, double y, double z) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null && client.world != null) {
         BlockPos blockPos = BlockPos.ofFloored(x, y, z);
         BlockState blockState = client.world.getBlockState(blockPos);
         if (!(blockState.getBlock() instanceof AirBlock) && !blockState.isAir()) {
            VoxelShape voxelShape = blockState.getCollisionShape(client.world, blockPos);
            return !voxelShape.isEmpty();
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

}
