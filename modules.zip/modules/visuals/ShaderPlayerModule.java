package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.awt.Color;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.TextureParticleHandler;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.modules.utils.FakePlayerModule;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
import winvi.noxiumvisuals.utils.render.EntityEffectPipeline;
import winvi.noxiumvisuals.utils.render.ShaderFramebufferRegistry;
public class ShaderPlayerModule extends Module {
      private final ChoiceSetting removeField34;
      private final BooleanSetting q23;
      private final NumberSetting havdj;
      private final NumberSetting eos;
      private final NumberSetting executeField250;
      private final NumberSetting computeField43;
      private final BooleanSetting hasField55;

   public ShaderPlayerModule() {
      super("ShaderPlayer", ModuleCategory.VISUAL);
      this.removeField34 = new ChoiceSetting(
            "Style",
            "Shader style applied to the player model"
         )
         .value(
            "Glow",
            "Hologram",
            "Energy",
            "Pulse",
            "Smoke"
         )
         .selected("Energy");
      this.q23 = new BooleanSetting(
            "Glow",
            "Render the outer glow"
         )
         .setValue(true);
      this.havdj = new NumberSetting(
            "Glow Strength",
            "Kawase glow strength"
         )
         .setValue(12.0F)
         .range(4.0F, 20.0F)
         .visible(this.q23::isValue);
      this.eos = new NumberSetting(
            "Fill Alpha",
            "Opacity of the shader on the player model"
         )
         .setValue(0.72F)
         .range(0.1F, 1F);
      this.executeField250 = new NumberSetting(
            "Intensity",
            "Brightness of the selected shader"
         )
         .setValue(0.85F)
         .range(0.2F, 1.5F);
      this.computeField43 = new NumberSetting(
            "Speed",
            "Animation speed of the selected shader"
         )
         .setValue(1F)
         .range(0F, 3.0F);
      this.hasField55 = new BooleanSetting(
            "Thin Outline",
            "Thin outline mode"
         )
         .setValue(false);
      this.showVisualColorSettings();
      this.removeField34.withTranslation("shaderplayer.style", "shaderplayer.style.desc");
      this.q23.withTranslation("shaderplayer.glow", "shaderplayer.glow.desc");
      this.havdj.withTranslation("shaderplayer.glowradius", "shaderplayer.glowradius.desc");
      this.eos.withTranslation("shaderplayer.fillalpha", "shaderplayer.fillalpha.desc");
      this.executeField250.withTranslation("shaderplayer.intensity", "shaderplayer.intensity.desc");
      this.computeField43.withTranslation("shaderplayer.speed", "shaderplayer.speed.desc");
      this.hasField55.withTranslation("shaderplayer.thinoutline", "shaderplayer.thinoutline.desc");
      this.setup(new ModuleSetting[]{this.removeField34, this.q23, this.havdj, this.eos, this.executeField250, this.computeField43, this.hasField55});
   }

      public boolean shouldRenderEntity(Entity entity) {
      if (!this.isState() || entity == null) {
         return false;
      } else if (entity instanceof PlayerEntity && EntityVisibilityFilter.shouldRender(entity)) {
         if (entity instanceof TextureParticleHandler) {
            FakePlayerModule fakePlayerModule = FakePlayerModule.getInstance();
            if (fakePlayerModule != null && fakePlayerModule.isInvisibilityEnabled()) {
               return false;
            }
         }

         return !entity.isRemoved() && entity.isAlive();
      } else {
         return false;
      }
   }

      public Color getColor() {
      return this.dbo(this.getVisualColor());
   }

      public Color getOutlineColor() {
      return this.getColor();
   }

      public int getColorMode() {
      return 0;
   }

      public Color getThemeGradientColor1() {
      return this.getColor();
   }

      public Color getThemeGradientColor2() {
      return this.getColor();
   }

      public Color getThemeGradientColor3() {
      return this.getColor();
   }

      public Color getThemeGradientColor4() {
      return this.getColor();
   }

      public int getThemeGradientColorCount() {
      return 1;
   }

      public float getThemeGradientPhase() {
      return 0F;
   }

      public float getGlowRadius() {
      return this.havdj.getValue();
   }

      public int getGlowEnabled() {
      return this.q23.isValue() ? 1 : 0;
   }

      public float getGlowAlphaMult() {
      return this.getColor().getAlpha() / 255.0F;
   }

      public int getGlowThinOutline() {
      return this.hasField55.isValue() ? 1 : 0;
   }

      public int getEffectStyle() {
      if (this.removeField34.isSelected("Hologram")) {
         return 1;
      } else if (this.removeField34.isSelected("Energy")) {
         return 2;
      } else if (this.removeField34.isSelected("Pulse")) {
         return 3;
      } else {
         return this.removeField34.isSelected("Smoke") ? 4 : 0;
      }
   }

      @Override
   public void deactivate() {
      EntityEffectPipeline framebufferShaderRenderer7 = ShaderFramebufferRegistry.getEntityShader();
      if (framebufferShaderRenderer7 != null) {
         framebufferShaderRenderer7.resetSmokeTrail();
      }
   }

      public float getFillAlpha() {
      return this.eos.getValue();
   }

      public float getEffectIntensity() {
      return this.executeField250.getValue();
   }

      public float getEffectSpeed() {
      return this.computeField43.getValue();
   }

      public float getEffectTime() {
      return (float)(System.currentTimeMillis() % 120000L) / 1000.0F;
   }

      private Color dbo(int rgb) {
      return new Color(rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF, rgb >> 24 & 0xFF);
   }

   static {
      int index = 0;
   }
}
