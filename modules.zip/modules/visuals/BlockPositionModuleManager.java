package winvi.noxiumvisuals.modules.visuals;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.util.math.BlockPos;
public final class BlockPositionModuleManager {
      private static final String qwsas = "Marker";
      private static final List<BlockPositionHandRenderer> tiykt = new ArrayList<>();

      public static List<BlockPositionHandRenderer> getMarkers() {
      return tiykt;
   }

      public static BlockPositionHandRenderer addMarker(String name, BlockPos pos, String dimension) {
      if (pos != null && dimension != null && !dimension.isBlank()) {
         String text = gnjcdg(name);
         if (text.isEmpty()) {
            text = jrepgi();
         }

         BlockPositionHandRenderer blockPositionHandRenderer = findMarker(text, dimension);
         if (blockPositionHandRenderer != null) {
            blockPositionHandRenderer.setX(pos.getX());
            blockPositionHandRenderer.setY(pos.getY());
            blockPositionHandRenderer.setZ(pos.getZ());
            blockPositionHandRenderer.setDimension(dimension);
            return blockPositionHandRenderer;
         } else {
            BlockPositionHandRenderer x = new BlockPositionHandRenderer(text, pos.getX(), pos.getY(), pos.getZ(), dimension);
            tiykt.add(x);
            return x;
         }
      } else {
         return null;
      }
   }

      public static BlockPositionHandRenderer addMarkerAndSave(String name, BlockPos pos, String dimension) {
      BlockPositionHandRenderer blockPositionHandRenderer = addMarker(name, pos, dimension);
      ConfigJsonRenderer.getInstance().save();
      return blockPositionHandRenderer;
   }

      public static void removeMarker(BlockPositionHandRenderer marker) {
      if (marker != null) {
         tiykt.remove(marker);
      }
   }

      public static void removeMarkerAndSave(BlockPositionHandRenderer marker) {
      removeMarker(marker);
      ConfigJsonRenderer.getInstance().save();
   }

      public static void clearMarkers() {
      tiykt.clear();
   }

      public static void clearMarkersAndSave() {
      clearMarkers();
      ConfigJsonRenderer.getInstance().save();
   }

      public static BlockPositionHandRenderer findMarker(String name, String dimension) {
      String text = dkl(name);
      String text2 = dkl(dimension);
      if (!text.isEmpty() && !text2.isEmpty()) {
         for (BlockPositionHandRenderer blockPositionHandRenderer : tiykt) {
            if (dkl(blockPositionHandRenderer.getName()).equals(text) && dkl(blockPositionHandRenderer.getDimension()).equals(text2)) {
               return blockPositionHandRenderer;
            }
         }

         return null;
      } else {
         return null;
      }
   }

      public static void setMarkers(List<BlockPositionHandRenderer> newMarkers) {
      tiykt.clear();
      if (newMarkers != null) {
         for (BlockPositionHandRenderer blockPositionHandRenderer : newMarkers) {
            if (blockPositionHandRenderer != null) {
               String name = gnjcdg(blockPositionHandRenderer.getName());
               String text = setMethod26(blockPositionHandRenderer.getDimension());
               if (!name.isEmpty() && !text.isEmpty()) {
                  BlockPositionHandRenderer blockPositionHandRenderer2 = findMarker(name, text);
                  if (blockPositionHandRenderer2 != null) {
                     blockPositionHandRenderer2.setX(blockPositionHandRenderer.getX());
                     blockPositionHandRenderer2.setY(blockPositionHandRenderer.getY());
                     blockPositionHandRenderer2.setZ(blockPositionHandRenderer.getZ());
                  } else {
                     tiykt.add(new BlockPositionHandRenderer(name, blockPositionHandRenderer.getX(), blockPositionHandRenderer.getY(), blockPositionHandRenderer.getZ(), text));
                  }
               }
            }
         }
      }
   }

      public static String getShortDimensionName(String dimension) {
      String text = setMethod26(dimension);
      if (text.isEmpty()) {
         return "unknown";
      } else {
         String text2 = text.contains(":") ? text.substring(text.indexOf(58) + 1) : text;

         return switch (text2) {
            case "the_nether" -> "nether";
            case "the_end" -> "end";
            default -> text2;
         };
      }
   }

      private static String jrepgi() {
      int index = 1;

      while (true) {
         String text = "Marker " + index;
         if (!ki1(text)) {
            return text;
         }

         index++;
      }
   }

      private static boolean ki1(String name) {
      String text = dkl(name);

      for (BlockPositionHandRenderer blockPositionHandRenderer : tiykt) {
         if (dkl(blockPositionHandRenderer.getName()).equals(text)) {
            return true;
         }
      }

      return false;
   }

      private static String gnjcdg(String name) {
      return name == null ? "" : name.trim();
   }

      private static String setMethod26(String dimension) {
      return dimension == null ? "" : dimension.trim();
   }

      private static String dkl(String value) {
      return value == null ? "" : value.toLowerCase(Locale.ROOT).trim();
   }

   private BlockPositionModuleManager() {
      throw new UnsupportedOperationException(
         "This is a utility class and cannot be instantiated"
      );
   }

}
