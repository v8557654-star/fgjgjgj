package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
public class BlockPositionHandRenderer {
      private String fcc;
      private int d22;
      private int acymm;
      private int f23;
      private String handleField26;

      public BlockPos toBlockPos() {
      return new BlockPos(this.d22, this.acymm, this.f23);
   }

      public Vec3d toCenterPos() {
      return new Vec3d(this.d22 + 0.5, this.acymm + 0.5, this.f23 + 0.5);
   }

      public Vec3d toRenderPos() {
      return new Vec3d(this.d22 + 0.5, this.acymm + 1.05, this.f23 + 0.5);
   }

      public String getName() {
      return this.fcc;
   }

      public int getX() {
      return this.d22;
   }

      public int getY() {
      return this.acymm;
   }

      public int getZ() {
      return this.f23;
   }

      public String getDimension() {
      return this.handleField26;
   }

      public void setName(String name) {
      this.fcc = name;
   }

      public void setX(int x) {
      this.d22 = x;
   }

      public void setY(int y) {
      this.acymm = y;
   }

      public void setZ(int z) {
      this.f23 = z;
   }

      public void setDimension(String dimension) {
      this.handleField26 = dimension;
   }

   public BlockPositionHandRenderer() {
   }

   public BlockPositionHandRenderer(String name, int x, int y, int z, String dimension) {
      this.fcc = name;
      this.d22 = x;
      this.acymm = y;
      this.f23 = z;
      this.handleField26 = dimension;
   }

}
