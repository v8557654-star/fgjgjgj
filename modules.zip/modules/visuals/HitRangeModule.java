package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
import winvi.noxiumvisuals.utils.render.SdfRingRenderer;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
public class HitRangeModule extends Module {
      private static final int eiy = -47803;
      private static final int z24 = 72;
      private static final double llqic = 6.283185307179586;
      private final NumberSetting ejb;
      private final NumberSetting ejca;
      private final NumberSetting ejdk;
      private final BooleanSetting wltjo;
      private final BooleanSetting setField51;
      private final BooleanSetting phmia;
      private float ejh;
      private float i19;
      private long convertField250;

   public HitRangeModule() {
      super("Hit Range", ModuleCategory.VISUAL);
      this.ejb = new NumberSetting(
            "Radius",
            "Displayed hit range radius"
         )
         .range(2.5F, 6.0F)
         .setValue(3.32F);
      this.ejca = new NumberSetting(
            "Thickness",
            "Ring thickness"
         )
         .range(0.02F, 0.25F)
         .setValue(0.07F);
      this.ejdk = new NumberSetting(
            "Rotation Speed",
            "Segment rotation speed"
         )
         .range(0.05F, 2.0F)
         .setValue(0.55F);
      this.wltjo = new BooleanSetting(
            "Reactive",
            "React when a visible player enters the range"
         )
         .setValue(true);
      this.setField51 = new BooleanSetting(
            "Target Marker",
            "Point toward the nearest visible player in range"
         )
         .setValue(true)
         .visible(this.wltjo::isValue);
      this.phmia = new BooleanSetting(
            "Hide Behind Blocks",
            "Hide the ring behind terrain"
         )
         .setValue(true);
      this.convertField250 = System.nanoTime();
      this.showVisualColorSettings();
      this.ejb.withTranslation("hitrange.radius", "hitrange.radius.desc");
      this.ejca.withTranslation("hitrange.thickness", "hitrange.thickness.desc");
      this.ejdk.withTranslation("hitrange.rotationspeed", "hitrange.rotationspeed.desc");
      this.wltjo.withTranslation("hitrange.reactive", "hitrange.reactive.desc");
      this.setField51.withTranslation("hitrange.targetmarker", "hitrange.targetmarker.desc");
      this.phmia.withTranslation("hitrange.depthtest", "hitrange.depthtest.desc");
      this.setup(new ModuleSetting[]{this.ejb, this.ejca, this.ejdk, this.wltjo, this.setField51, this.phmia});
   }

      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         float value = this.h17();
         this.ejh = (this.ejh + this.ejdk.getValue() * 90.0F * value) % 360.0F;
         PlayerEntity player2 = this.wltjo.isValue() ? this.g18(this.ejb.getValue()) : null;
         float value2 = player2 == null ? 0F : 1F;
         float value3 = 1F - (float)Math.exp(-9.0F * value);
         this.i19 = this.i19 + (value2 - this.i19) * value3;
         int index = this.getVisualColor();
         int index2 = this.wltjo.isValue() ? ColorUtils.overCol(index, -47803, this.i19) : index;
         float value4 = 0.86F + 0.14F * (float)Math.sin(System.nanoTime() / 1E9 * 4.0);
         float value5 = this.ejb.getValue();
         float value6 = this.ejca.getValue();
         Vec3d client = MinecraftClient.getInstance().player.getLerpedPos(event.getPartialTicks()).add(0, 0.025, 0);
         this.b19(event, client, value5, value6, index2, value4);
         this.wc0(client, value5, value6, index2, this.phmia.isValue());
         if (player2 != null && this.setField51.isValue()) {
            this.d16(client, player2.getLerpedPos(event.getPartialTicks()), value5, value6, index2, this.phmia.isValue());
         }
      }
   }

      private void b19(VertexMatrixRenderer event, Vec3d origin, float radius, float thickness, int color, float pulse) {
      float value = radius / 0.82F;
      MatrixStack matrices = event.getStack();
      matrices.push();

      try {
         matrices.translate(origin.x, origin.y, origin.z);
         matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0F));
         matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(this.ejh));
         int index = ColorUtils.multAlpha(color, 0.11F * pulse);
         SdfRingRenderer.draw(matrices, value, Math.max(thickness * 3.2F, 0.09F), index, index, index, index, this.phmia.isValue());
         int index2 = ColorUtils.multAlpha(color, 0.62F);
         int index3 = ColorUtils.multAlpha(color, 0.96F);
         SdfRingRenderer.draw(matrices, value, thickness, index3, index2, index3, index2, this.phmia.isValue());
      } finally {
         matrices.pop();
      }
   }

      private void wc0(Vec3d origin, float radius, float thickness, int color, boolean depth) {
      double value = Math.toRadians(this.ejh);
      double value2 = Math.max(0.018, thickness * 0.32);
      int index = ColorUtils.multAlpha(color, 0.78F);

      for (int index2 = 0; index2 < 72; index2++) {
         if (index2 / 3 % 2 == 0) {
            double value3 = value + 6.283185307179586 * index2 / 72.0;
            double value4 = value + 6.283185307179586 * (index2 + 1) / 72.0;
            this.ejygmd(origin, radius - value2, radius + value2, value3, value4, index, depth);
         }
      }
   }

      private void d16(Vec3d origin, Vec3d target, float radius, float thickness, int color, boolean depth) {
      double value = Math.atan2(target.z - origin.z, target.x - origin.x);
      double value2 = 0.075;
      double value3 = radius - Math.max(0.12, thickness * 1.8);
      double value4 = radius + Math.max(0.18, thickness * 2.5);
      int index = ColorUtils.multAlpha(ColorUtils.overCol(color, -1, 0.32F), 0.96F);
      this.ejygmd(origin, value3, value4, value - value2, value + value2, index, depth);
   }

      private void ejygmd(Vec3d origin, double innerRadius, double outerRadius, double startAngle, double endAngle, int color, boolean depth) {
      Vec3d position = this.addMethod40(origin, outerRadius, startAngle);
      Vec3d position2 = this.addMethod40(origin, outerRadius, endAngle);
      Vec3d position3 = this.addMethod40(origin, innerRadius, endAngle);
      Vec3d position4 = this.addMethod40(origin, innerRadius, startAngle);
      WorldShapeRenderer.drawQuad(position, position2, position3, position4, color, depth);
   }

      private Vec3d addMethod40(Vec3d origin, double radius, double angle) {
      return new Vec3d(origin.x + Math.cos(angle) * radius, origin.y + 0.002, origin.z + Math.sin(angle) * radius);
   }

      private PlayerEntity g18(float range) {
      PlayerEntity player2 = null;
      double value = range * range;

      for (PlayerEntity player3 : MinecraftClient.getInstance().world.getPlayers()) {
         if (player3 != MinecraftClient.getInstance().player
            && player3.isAlive()
            && !player3.isSpectator()
            && EntityVisibilityFilter.shouldRender(player3)
            && !(Math.abs(player3.getY() - MinecraftClient.getInstance().player.getY()) > 3.0)) {
            double client = MinecraftClient.getInstance().player.squaredDistanceTo(player3);
            if (client <= value) {
               value = client;
               player2 = player3;
            }
         }
      }

      return player2;
   }

      private float h17() {
      long timestamp = System.nanoTime();
      float value = Math.min(0.05F, Math.max(0F, (float)(timestamp - this.convertField250) / 1E9F));
      this.convertField250 = timestamp;
      return value;
   }

}
