package winvi.noxiumvisuals.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.visuals.JumpCirclesModule;
import winvi.noxiumvisuals.ui.hud.DraggableHudElement;
import winvi.noxiumvisuals.utils.render.SdfRingRenderer;
public class JumpCircleRenderer {
   private final JumpCirclesModule this$0;
      public final Vec3d ghz;
      public final double checkField5;
      public final long stopField95;
      public float gic;
      public final float controlField75;
      public long gie;
      public final PlayerEntity hasField720;
      public final float manageField351;

   public JumpCircleRenderer(final JumpCirclesModule jumpCirclesModule, Vec3d position, PlayerEntity player) {
      this.this$0 = jumpCirclesModule;
      this.ghz = position;
      this.hasField720 = player;
      this.manageField351 = jumpCirclesModule.nezqg.getValue();
      this.checkField5 = player.getVelocity().getY();
      this.gic = 0F;
      this.controlField75 = (float)Math.toRadians(jumpCirclesModule.kl.getValue());
      this.stopField95 = System.currentTimeMillis();
      this.gie = this.stopField95;
   }

      public boolean isExpired(long currentTimeMs) {
      float value = (float)(currentTimeMs - this.stopField95) / 1000.0F;
      return value > this.sghxlu();
   }

      public float sghxlu() {
      return this.manageField351;
   }

      public Vec3d fsddrl() {
      return new Vec3d(this.ghz.x, this.ghz.y - this.checkField5, this.ghz.z);
   }

      public void render(MatrixStack matrixStack, double cameraX, double cameraY, double cameraZ, long currentTimeMs) {
      double x2 = this.ghz.x;
      double value = this.ghz.y - this.checkField5;
      double z2 = this.ghz.z;
      matrixStack.push();
      matrixStack.translate(x2, value, z2);
      this.wssgqe(currentTimeMs);
      this.getMethod36(matrixStack, 0, 0, 0, currentTimeMs);
      matrixStack.pop();
   }

      public void wssgqe(long currentTimeMs) {
      float value = (float)(currentTimeMs - this.gie) / 1000.0F;
      this.gie = currentTimeMs;
      value = Math.min(value, 0.1F);
      float value2 = this.this$0.nezqg.getValue();
      float value3 = (float)(currentTimeMs - this.stopField95) / 1000.0F;
      float value4 = MathHelper.clamp((value2 - value3) / value2, 0F, 1F);
      if (value4 > 0.3F) {
         float value5 = 0.016666668F;
         float value6 = value / value5;
         this.gic = this.gic - this.controlField75 * value6;
      } else {
         float value7 = value4 / 0.3F;
         float value8 = 0.016666668F;
         float value9 = value / value8;
         this.gic = this.gic + this.controlField75 * value9 * value7;
      }
   }

      public void getMethod36(MatrixStack modelMatrix, double x, double y, double z, long currentTimeMs) {
      short shortValue = 255;
      float value = this.this$0.nezqg.getValue();
      RenderSystem.disableCull();
      RenderSystem.enableBlend();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
      RenderSystem.setShaderTexture(0, this.this$0.isMethod840());
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      float value2 = (float)(currentTimeMs - this.stopField95) / 1000.0F;
      float value3 = this.this$0.kk.getValue() / 100.0F;
      float value4 = value * 0.25F;
      float value5 = value * 0.5F;
      float value6 = value * 0.25F;
      float value7 = 1F;
      float value8;
      if (value2 < value4) {
         float value9 = value2 / value4;
         value9 = (float)Math.pow(value9, 0.6);
         float value10 = this.this$0.calculateMethod42(value9);
         value8 = value3 * value10;
         value7 = value9;
      } else if (value2 < value4 + value5) {
         value8 = value3;
         value7 = 1F;
      } else {
         float value11 = (value2 - value4 - value5) / value6;
         value11 = (float)Math.pow(value11, 1.4);
         float value12 = 1F - value11;
         value8 = value3 * (0.7F + value12 * 0.3F);
         value7 = value12;
      }

      float value13 = DraggableHudElement.getGlobalGlowAnimationProgress();
      Color color = new Color(this.this$0.getVisualColor(), true);
      Color color2;
      Color color3;
      Color color4;
      Color color5;
      if (value13 < 0.25F) {
         float value14 = value13 / 0.25F;
         color2 = JumpCirclesModule.convertMethod340(color, color, value14);
         color3 = JumpCirclesModule.convertMethod340(color, color, value14);
         color4 = JumpCirclesModule.convertMethod340(color, color, value14);
         color5 = JumpCirclesModule.convertMethod340(color, color, value14);
      } else if (value13 < 0.5F) {
         float value15 = (value13 - 0.25F) / 0.25F;
         color2 = JumpCirclesModule.convertMethod340(color, color, value15);
         color3 = JumpCirclesModule.convertMethod340(color, color, value15);
         color4 = JumpCirclesModule.convertMethod340(color, color, value15);
         color5 = JumpCirclesModule.convertMethod340(color, color, value15);
      } else if (value13 < 0.75F) {
         float value16 = (value13 - 0.5F) / 0.25F;
         color2 = JumpCirclesModule.convertMethod340(color, color, value16);
         color3 = JumpCirclesModule.convertMethod340(color, color, value16);
         color4 = JumpCirclesModule.convertMethod340(color, color, value16);
         color5 = JumpCirclesModule.convertMethod340(color, color, value16);
      } else {
         float value17 = (value13 - 0.75F) / 0.25F;
         color2 = JumpCirclesModule.convertMethod340(color, color, value17);
         color3 = JumpCirclesModule.convertMethod340(color, color, value17);
         color4 = JumpCirclesModule.convertMethod340(color, color, value17);
         color5 = JumpCirclesModule.convertMethod340(color, color, value17);
      }

      int index = (int)(shortValue * value7);
      modelMatrix.push();
      modelMatrix.translate(x, y, z);
      modelMatrix.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0F));
      modelMatrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float)Math.toDegrees(this.gic)));
      Matrix4f matrix = modelMatrix.peek().getPositionMatrix();
      if ("CIRCLE".equals(this.this$0.h18.getSelected())) {
         float value18 = Math.max(0.025F, value8 * 0.12F);
         SdfRingRenderer.draw(
            modelMatrix,
            value8,
            value18,
            color2.getRGB() & 16777215 | index << 24,
            color3.getRGB() & 16777215 | index << 24,
            color4.getRGB() & 16777215 | index << 24,
            color5.getRGB() & 16777215 | index << 24
         );
         modelMatrix.pop();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableBlend();
         RenderSystem.enableCull();
         RenderSystem.depthMask(true);
         RenderSystem.disableDepthTest();
      } else {
         float value19 = MathHelper.clamp(value2 / value, 0F, 1F);
         BufferBuilder bufferBuilder = this.eaa(matrix, value8, value19, color2, color3, color4, color5, index);
         modelMatrix.pop();
         BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableBlend();
         RenderSystem.enableCull();
         RenderSystem.depthMask(true);
         RenderSystem.disableDepthTest();
         RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
         RenderSystem.setShaderTexture(0, 0);
      }
   }

      public BufferBuilder eaa(Matrix4f matrix, float radius, float lifeProgress, Color topLeft, Color topRight, Color bottomRight, Color bottomLeft, int alpha) {
      float value = this.this$0.km3.getValue();
      if (value <= 0.001F) {
         BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
         this.dpfnpj(bufferBuilder, matrix, 0F, 1F, radius, lifeProgress, 0F, topLeft, topRight, bottomRight, bottomLeft, alpha);
         this.dpfnpj(bufferBuilder, matrix, 1F, 1F, radius, lifeProgress, 0F, topLeft, topRight, bottomRight, bottomLeft, alpha);
         this.dpfnpj(bufferBuilder, matrix, 1F, 0F, radius, lifeProgress, 0F, topLeft, topRight, bottomRight, bottomLeft, alpha);
         this.dpfnpj(bufferBuilder, matrix, 0F, 0F, radius, lifeProgress, 0F, topLeft, topRight, bottomRight, bottomLeft, alpha);
         return bufferBuilder;
      } else {
         byte byteValue = 12;
         BufferBuilder bufferBuilder2 = Tessellator.getInstance().begin(DrawMode.TRIANGLES, VertexFormats.POSITION_TEXTURE_COLOR);

         for (int index = 0; index < byteValue; index++) {
            float value2 = (float)index / byteValue;
            float value3 = (float)(index + 1) / byteValue;

            for (int index2 = 0; index2 < byteValue; index2++) {
               float value4 = (float)index2 / byteValue;
               float value5 = (float)(index2 + 1) / byteValue;
               this.dpfnpj(bufferBuilder2, matrix, value4, value2, radius, lifeProgress, value, topLeft, topRight, bottomRight, bottomLeft, alpha);
               this.dpfnpj(bufferBuilder2, matrix, value5, value2, radius, lifeProgress, value, topLeft, topRight, bottomRight, bottomLeft, alpha);
               this.dpfnpj(bufferBuilder2, matrix, value5, value3, radius, lifeProgress, value, topLeft, topRight, bottomRight, bottomLeft, alpha);
               this.dpfnpj(bufferBuilder2, matrix, value4, value2, radius, lifeProgress, value, topLeft, topRight, bottomRight, bottomLeft, alpha);
               this.dpfnpj(bufferBuilder2, matrix, value5, value3, radius, lifeProgress, value, topLeft, topRight, bottomRight, bottomLeft, alpha);
               this.dpfnpj(bufferBuilder2, matrix, value4, value3, radius, lifeProgress, value, topLeft, topRight, bottomRight, bottomLeft, alpha);
            }
         }

         return bufferBuilder2;
      }
   }

      public void dpfnpj(
      BufferBuilder buffer,
      Matrix4f matrix,
      float u,
      float v,
      float radius,
      float lifeProgress,
      float strength,
      Color topLeft,
      Color topRight,
      Color bottomRight,
      Color bottomLeft,
      int alpha
   ) {
      float value = u * 2.0F - 1F;
      float value2 = v * 2.0F - 1F;
      float value3 = Math.min(1F, (float)Math.sqrt(value * value + value2 * value2) * 0.70710677F);
      float value4 = MathHelper.clamp(lifeProgress * 1.35F, 0F, 1.2F);
      float value5 = value3 - value4;
      float value6 = (float)Math.exp(-(value5 * value5) / 0.035F);
      float value7 = 1F + strength * value6 * (float)Math.sin(3.141592653589793 * lifeProgress) * 0.32F;
      float value8 = value * radius * value7;
      float value9 = value2 * radius * value7;
      Color color2 = JumpCirclesModule.convertMethod340(bottomLeft, bottomRight, u);
      Color color3 = JumpCirclesModule.convertMethod340(topLeft, topRight, u);
      Color color4 = JumpCirclesModule.convertMethod340(color2, color3, v);
      buffer.vertex(matrix, value8, value9, 0F).texture(u, v).color(color4.getRed(), color4.getGreen(), color4.getBlue(), alpha);
   }

}
