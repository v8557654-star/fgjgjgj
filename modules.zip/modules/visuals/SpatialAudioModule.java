package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.utils.SoundAudioRenderer;
public class SpatialAudioModule extends Module {
      private final ChoiceSetting zlzvu;
      private final BooleanSetting executeField991;
      private final BooleanSetting pq;
      private final BooleanSetting txffd;
      private final NumberSetting isField230;

   public SpatialAudioModule() {
      super("Spatial Audio", ModuleCategory.VISUAL);
      this.zlzvu = new ChoiceSetting(
            "Quality",
            "Environment sampling quality"
         )
         .value(
            "Performance",
            "Quality"
         )
         .selected("Performance");
      this.executeField991 = new BooleanSetting(
            "Room Reverb",
            "Add reflections in enclosed spaces"
         )
         .setValue(true);
      this.pq = new BooleanSetting(
            "Occlusion",
            "Muffle high frequencies in enclosed spaces"
         )
         .setValue(true);
      this.txffd = new BooleanSetting(
            "Tone Compensation",
            "Subtly adapt sound tone to the room"
         )
         .setValue(true);
      this.isField230 = new NumberSetting(
            "Effect Strength",
            "Strength of spatial sound processing"
         )
         .setValue(0.8F)
         .range(0F, 1.5F);
      this.zlzvu.withTranslation("spatialaudio.quality", "spatialaudio.quality.desc");
      this.executeField991.withTranslation("spatialaudio.reverb", "spatialaudio.reverb.desc");
      this.pq.withTranslation("spatialaudio.occlusion", "spatialaudio.occlusion.desc");
      this.txffd.withTranslation("spatialaudio.tone", "spatialaudio.tone.desc");
      this.isField230.withTranslation("spatialaudio.intensity", "spatialaudio.intensity.desc");
      this.setup(new ModuleSetting[]{this.zlzvu, this.executeField991, this.pq, this.txffd, this.isField230});
   }

      @Override
   public void activate() {
      this.initMethod12();
   }

      @Override
   public void deactivate() {
      SoundAudioRenderer.getInstance().disable();
   }

      @Override
   public void onTick() {
      this.initMethod12();
   }

      private void initMethod12() {
      SoundAudioRenderer.getInstance()
         .update(
            MinecraftClient.getInstance(),
            this.zlzvu.isSelected("Quality"),
            this.executeField991.isValue(),
            this.pq.isValue(),
            this.txffd.isValue(),
            this.isField230.getValue()
         );
   }

}
