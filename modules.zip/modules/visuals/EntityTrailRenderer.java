package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.TrailsModule;


import winvi.noxiumvisuals.utils.render.UiRenderUtils;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
import winvi.noxiumvisuals.utils.render.RenderStateGuard;
import winvi.noxiumvisuals.utils.render.ShaderRegistry;
import winvi.noxiumvisuals.utils.render.BaseShaderRenderer;
import winvi.noxiumvisuals.utils.render.ParticleOutlineShader;
import winvi.noxiumvisuals.utils.render.FractalOutlineShader;
import winvi.noxiumvisuals.utils.render.PlasmaOutlineShader;
import winvi.noxiumvisuals.utils.render.TunnelOutlineShader;
import winvi.noxiumvisuals.utils.render.AudioOutlineShader;
import winvi.noxiumvisuals.utils.render.WaveOutlineShader;
import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
public class EntityTrailRenderer {
      private static final MinecraftClient destroyField18 = MinecraftClient.getInstance();
      private static final List<TextureMatrixTransformer> uy0 = new ArrayList<>();
      private static final Matrix4f parseField34 = new Matrix4f();
      private static final MatrixStack startField80 = new MatrixStack();
      private static int evb;
      private static float jmknf = 0F;
      private static long destroyField131 = System.nanoTime();

      public static void queueTrails(MatrixStack stack, List<TextureColorManager> trails, TrailsModule module, float entityHeight) {

      if (!trails.isEmpty()) {
         TextureMatrixTransformer textureMatrixTransformer;
         if (evb < uy0.size()) {
            textureMatrixTransformer = uy0.get(evb);
         } else {
            textureMatrixTransformer = new TextureMatrixTransformer();
            uy0.add(textureMatrixTransformer);
         }

         textureMatrixTransformer.transformMethod93(stack.peek().getPositionMatrix(), trails, module, entityHeight);
         evb++;
      }
   }

      public static void renderBatches(float tickDelta) {

      long timestamp = System.nanoTime();
      float value = (float)(timestamp - destroyField131) / 1E9F;
      destroyField131 = timestamp;
      jmknf += value * 20.0F;
      if (evb > 0) {
         long timestamp2 = System.currentTimeMillis();

         try {
            for (int index = 0; index < evb; index++) {
               nlxupv(uy0.get(index), timestamp2);
            }

            processMethod51(tickDelta);
            checkMethod560(tickDelta);
         } finally {
            evb = 0;
         }
      }
   }

      private static void processMethod51(float tickDelta) {

      RenderSystem.disableCull();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.blendFunc(770, 1);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      short shortValue = 255;

      for (int index = 0; index < evb; index++) {
         TextureMatrixTransformer textureMatrixTransformer = uy0.get(index);
         TrailsModule trailsModule = textureMatrixTransformer.m30;
         Matrix4f matrix = textureMatrixTransformer.zbnvu;
         List list = textureMatrixTransformer.mtyjn;
         int index2 = textureMatrixTransformer.processField75;
         if (index2 >= 2) {
            float value = Math.max(0.1F, textureMatrixTransformer.eam());
            String text = TrailsModule.trailsStyle.getSelected();
            if (text.equals("FADE")) {
               BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);

               for (int index3 = 0; index3 < index2 - 1; index3++) {
                  TextureColorSupport textureColorSupport = (TextureColorSupport)list.get(index3);
                  TextureColorSupport textureColorSupport2 = (TextureColorSupport)list.get(index3 + 1);
                  Vec3d position = textureColorSupport.eolcge();
                  Vec3d position2 = textureColorSupport2.eolcge();
                  float value2 = textureColorSupport.eaph();
                  float value3 = textureColorSupport2.eaph();
                  int index4 = textureColorSupport.executeMethod57();
                  int index5 = textureColorSupport2.executeMethod57();
                  float x2 = (float)position.x;
                  float y2 = (float)position.y;
                  float z2 = (float)position.z;
                  float x3 = (float)position2.x;
                  float y3 = (float)position2.y;
                  float z3 = (float)position2.z;
                  int index6 = (int)(controlMethod210(0F, value) * value2);
                  int index7 = (int)(controlMethod210(value / 2.0F, value) * value2);
                  int index8 = (int)(controlMethod210(value, value) * value2);
                  int index9 = (int)(controlMethod210(0F, value) * value3);
                  int index10 = (int)(controlMethod210(value / 2.0F, value) * value3);
                  int index11 = (int)(controlMethod210(value, value) * value3);
                  bufferBuilder.vertex(matrix, x2, y2, z2).color(index4 >> 16 & 0xFF, index4 >> 8 & 0xFF, index4 & 0xFF, index6);
                  bufferBuilder.vertex(matrix, x3, y3, z3).color(index5 >> 16 & 0xFF, index5 >> 8 & 0xFF, index5 & 0xFF, index9);
                  bufferBuilder.vertex(matrix, x3, y3 + value / 2.0F, z3).color(index5 >> 16 & 0xFF, index5 >> 8 & 0xFF, index5 & 0xFF, index10);
                  bufferBuilder.vertex(matrix, x2, y2 + value / 2.0F, z2).color(index4 >> 16 & 0xFF, index4 >> 8 & 0xFF, index4 & 0xFF, index7);
                  bufferBuilder.vertex(matrix, x2, y2 + value / 2.0F, z2).color(index4 >> 16 & 0xFF, index4 >> 8 & 0xFF, index4 & 0xFF, index7);
                  bufferBuilder.vertex(matrix, x3, y3 + value / 2.0F, z3).color(index5 >> 16 & 0xFF, index5 >> 8 & 0xFF, index5 & 0xFF, index10);
                  bufferBuilder.vertex(matrix, x3, y3 + value, z3).color(index5 >> 16 & 0xFF, index5 >> 8 & 0xFF, index5 & 0xFF, index11);
                  bufferBuilder.vertex(matrix, x2, y2 + value, z2).color(index4 >> 16 & 0xFF, index4 >> 8 & 0xFF, index4 & 0xFF, index8);
               }

               try {
                  UiRenderUtils.endBuilding(bufferBuilder);
               } catch (IllegalStateException illegalStateException) {
               }
            } else {
               BufferBuilder bufferBuilder2 = Tessellator.getInstance().begin(DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);

               for (int index12 = 0; index12 < index2; index12++) {
                  TextureColorSupport textureColorSupport3 = (TextureColorSupport)list.get(index12);
                  Vec3d position3 = textureColorSupport3.eolcge();
                  float value4 = textureColorSupport3.eaph();
                  float value5 = value4 * shortValue;
                  int index13 = textureColorSupport3.executeMethod57();
                  float x4 = (float)position3.x;
                  float y4 = (float)position3.y;
                  float value6 = y4 + value;
                  float z4 = (float)position3.z;
                  int index14 = (int)value5;
                  int index15 = (int)value5;
                  bufferBuilder2.vertex(matrix, x4, value6, z4).color(index13 >> 16 & 0xFF, index13 >> 8 & 0xFF, index13 & 0xFF, index15);
                  bufferBuilder2.vertex(matrix, x4, y4, z4).color(index13 >> 16 & 0xFF, index13 >> 8 & 0xFF, index13 & 0xFF, index14);
               }

               try {
                  UiRenderUtils.endBuilding(bufferBuilder2);
               } catch (IllegalStateException illegalStateException2) {
               }
            }

            if (TrailsModule.useShader.isValue()) {
               rqhayz(textureMatrixTransformer, value, text, list, index2);
            }
         }
      }

      RenderSystem.disableBlend();
      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
   }

      private static void rqhayz(TextureMatrixTransformer data, float trailHeight, String style, List<TextureColorSupport> points, int pointCount) {

      TrailsModule trailsModule = data.m30;
      Matrix4f matrix = data.zbnvu;
      Object object = null;
      String text = TrailsModule.shaderType.getSelected();

      object = switch (text) {
         case "Wave" -> ShaderRegistry.highlighterShaderWave;
         case "Audio" -> ShaderRegistry.highlighterShaderAudio;
         case "Plasma" -> ShaderRegistry.highlighterShaderPlasma;
         case "Fractal" -> ShaderRegistry.highlighterShaderFractal;
         case "Tunnel" -> ShaderRegistry.highlighterShaderTunnel;
         case "Particles" -> ShaderRegistry.highlighterShaderParticles;
         default -> ShaderRegistry.highlighterShaderWave;
      };
      if (object != null) {
         int index = pointCount - 1;
         if (index > 0) {
            Color color2 = new Color(trailsModule.getVisualColor(), true);
            float value = color2.getRed() / 255.0F;
            float value2 = color2.getGreen() / 255.0F;
            float value3 = color2.getBlue() / 255.0F;
            float value4 = color2.getRed() / 255.0F;
            float value5 = color2.getGreen() / 255.0F;
            float value6 = color2.getBlue() / 255.0F;
            float value7 = color2.getRed() / 255.0F;
            float value8 = color2.getGreen() / 255.0F;
            float value9 = color2.getBlue() / 255.0F;
            float value10 = color2.getRed() / 255.0F;
            float value11 = color2.getGreen() / 255.0F;
            float value12 = color2.getBlue() / 255.0F;
            float value13 = TrailsModule.trailsOpacity.getValue();
            float value14 = 500.0F / TrailsModule.shaderSpeed.getValue();
            float value15 = 5.0F / TrailsModule.shaderScale.getValue();
            if (object instanceof WaveOutlineShader) {
               ((WaveOutlineShader)object).updateUniforms(jmknf, value14, value15, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13);
            } else if (object instanceof AudioOutlineShader) {
               ((AudioOutlineShader)object).updateUniforms(jmknf, value14, value15, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13);
            } else if (object instanceof PlasmaOutlineShader) {
               ((PlasmaOutlineShader)object)
                  .updateUniforms(jmknf, value14, value15, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13);
            } else if (object instanceof FractalOutlineShader) {
               ((FractalOutlineShader)object)
                  .updateUniforms(jmknf, value14, value15, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13);
            } else if (object instanceof TunnelOutlineShader) {
               ((TunnelOutlineShader)object)
                  .updateUniforms(jmknf, value14, value15, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13);
            } else if (object instanceof ParticleOutlineShader) {
               ((ParticleOutlineShader)object).updateUniforms(jmknf, value14, value15, value, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13);
            }

            RenderSystem.disableCull();
            RenderSystem.enableBlend();
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.blendFunc(770, 1);
            Matrix4f matrix2 = RenderStateGuard.pushModelView(matrix);

            try {
               ((BaseShaderRenderer)object).use();
               BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
               Matrix4f matrix3 = parseField34;
               float value16 = 1F;
               float value17 = 1F;
               float value18 = 1F;
               if (style.equals("FADE")) {
                  for (int index2 = 0; index2 < pointCount - 1; index2++) {
                     TextureColorSupport textureColorSupport = (TextureColorSupport)points.get(index2);
                     TextureColorSupport textureColorSupport2 = (TextureColorSupport)points.get(index2 + 1);
                     Vec3d position = textureColorSupport.eolcge();
                     Vec3d position2 = textureColorSupport2.eolcge();
                     float value19 = textureColorSupport.eaph();
                     float value20 = textureColorSupport2.eaph();
                     float x2 = (float)position.x;
                     float y2 = (float)position.y;
                     float z2 = (float)position.z;
                     float x3 = (float)position2.x;
                     float y3 = (float)position2.y;
                     float z3 = (float)position2.z;
                     float height = controlMethod210(0F, trailHeight) / 255.0F * value19;
                     float height2 = controlMethod210(trailHeight / 2.0F, trailHeight) / 255.0F * value19;
                     float height3 = controlMethod210(trailHeight, trailHeight) / 255.0F * value19;
                     float height4 = controlMethod210(0F, trailHeight) / 255.0F * value20;
                     float height5 = controlMethod210(trailHeight / 2.0F, trailHeight) / 255.0F * value20;
                     float height6 = controlMethod210(trailHeight, trailHeight) / 255.0F * value20;
                     float value21 = textureColorSupport.earw();
                     float value22 = textureColorSupport2.earw();
                     bufferBuilder.vertex(matrix3, x2, y2, z2).texture(value21, 0F).color(value16, value17, value18, height);
                     bufferBuilder.vertex(matrix3, x3, y3, z3).texture(value22, 0F).color(value16, value17, value18, height4);
                     bufferBuilder.vertex(matrix3, x3, y3 + trailHeight / 2.0F, z3).texture(value22, 0.5F).color(value16, value17, value18, height5);
                     bufferBuilder.vertex(matrix3, x2, y2 + trailHeight / 2.0F, z2).texture(value21, 0.5F).color(value16, value17, value18, height2);
                     bufferBuilder.vertex(matrix3, x2, y2 + trailHeight / 2.0F, z2).texture(value21, 0.5F).color(value16, value17, value18, height2);
                     bufferBuilder.vertex(matrix3, x3, y3 + trailHeight / 2.0F, z3).texture(value22, 0.5F).color(value16, value17, value18, height5);
                     bufferBuilder.vertex(matrix3, x3, y3 + trailHeight, z3).texture(value22, 1F).color(value16, value17, value18, height6);
                     bufferBuilder.vertex(matrix3, x2, y2 + trailHeight, z2).texture(value21, 1F).color(value16, value17, value18, height3);
                  }
               } else {
                  for (int index3 = 0; index3 < pointCount - 1; index3++) {
                     TextureColorSupport textureColorSupport3 = (TextureColorSupport)points.get(index3);
                     TextureColorSupport textureColorSupport4 = (TextureColorSupport)points.get(index3 + 1);
                     Vec3d position3 = textureColorSupport3.eolcge();
                     Vec3d position4 = textureColorSupport4.eolcge();
                     float value23 = textureColorSupport3.eaph();
                     float value24 = textureColorSupport4.eaph();
                     float x4 = (float)position3.x;
                     float y4 = (float)position3.y;
                     float z4 = (float)position3.z;
                     float x5 = (float)position4.x;
                     float y5 = (float)position4.y;
                     float z5 = (float)position4.z;
                     float value25 = textureColorSupport3.earw();
                     float value26 = textureColorSupport4.earw();
                     bufferBuilder.vertex(matrix3, x4, y4 + trailHeight, z4).texture(value25, 1F).color(value16, value17, value18, value23);
                     bufferBuilder.vertex(matrix3, x4, y4, z4).texture(value25, 0F).color(value16, value17, value18, value23);
                     bufferBuilder.vertex(matrix3, x5, y5, z5).texture(value26, 0F).color(value16, value17, value18, value24);
                     bufferBuilder.vertex(matrix3, x5, y5 + trailHeight, z5).texture(value26, 1F).color(value16, value17, value18, value24);
                  }
               }

               try {
                  BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
               } catch (IllegalStateException illegalStateException) {
               }
            } finally {
               RenderStateGuard.popModelView(matrix2);
               RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
               RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
               RenderSystem.disableCull();
               RenderSystem.enableBlend();
               RenderSystem.enableDepthTest();
               RenderSystem.depthMask(false);
               RenderSystem.blendFunc(770, 1);
            }
         }
      }
   }

      private static void checkMethod560(float tickDelta) {

      GL11.glHint(3154, 4354);
      RenderSystem.enableBlend();
      RenderSystem.disableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
      RenderSystem.setShader(ShaderProgramKeys.RENDERTYPE_LINES);

      for (int index = 0; index < evb; index++) {
         TextureMatrixTransformer textureMatrixTransformer = uy0.get(index);
         List list = textureMatrixTransformer.mtyjn;
         int index2 = textureMatrixTransformer.processField75;
         if (index2 >= 2) {
            RenderSystem.lineWidth(3.0F);
            float value = Math.max(0.1F, textureMatrixTransformer.eam());
            BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.LINES, VertexFormats.LINES);
            MatrixStack matrices = startField80;
            matrices.peek().getPositionMatrix().set(textureMatrixTransformer.zbnvu);
            Entry entry = matrices.peek();

            for (int index3 = 0; index3 < index2 - 1; index3++) {
               TextureColorSupport textureColorSupport = (TextureColorSupport)list.get(index3);
               TextureColorSupport textureColorSupport2 = (TextureColorSupport)list.get(index3 + 1);
               Vec3d position = textureColorSupport.eolcge();
               Vec3d position2 = textureColorSupport2.eolcge();
               float value2 = textureColorSupport.eaph();
               float value3 = textureColorSupport2.eaph();
               float value4 = 0F;
               float value5 = 0F;
               int index4 = textureColorSupport.executeMethod57();
               int index5 = textureColorSupport2.executeMethod57();
               float value6 = (value2 + value3) / 2.0F;
               int index6 = ((index4 >> 16 & 0xFF) + (index5 >> 16 & 0xFF)) / 2;
               int index7 = ((index4 >> 8 & 0xFF) + (index5 >> 8 & 0xFF)) / 2;
               int index8 = ((index4 & 0xFF) + (index5 & 0xFF)) / 2;
               int index9 = (int)(value6 * 255.0F);
               int index10 = index9 << 24 | index6 << 16 | index7 << 8 | index8;
               WorldShapeRenderer.vertexLine(
                  entry,
                  bufferBuilder,
                  (float)position.x,
                  (float)(position.y + value4),
                  (float)position.z,
                  (float)position2.x,
                  (float)(position2.y + value5),
                  (float)position2.z,
                  index10,
                  index10
               );
               WorldShapeRenderer.vertexLine(
                  entry,
                  bufferBuilder,
                  (float)position.x,
                  (float)(position.y + value),
                  (float)position.z,
                  (float)position2.x,
                  (float)(position2.y + value),
                  (float)position2.z,
                  index10,
                  index10
               );
            }

            try {
               UiRenderUtils.endBuilding(bufferBuilder);
            } catch (IllegalStateException illegalStateException) {
            }
         }
      }

      RenderSystem.lineWidth(1F);
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }

      private static int controlMethod210(float yOffset, float height) {

      float height2 = yOffset / height;
      if (height2 <= 0.5F) {
         float value = 1F - height2 / 0.5F;
         return (int)(Math.pow(value, 0.8) * 255.0);
      } else {
         float value2 = (height2 - 0.5F) / 0.5F;
         return (int)(Math.pow(value2, 0.8) * 255.0);
      }
   }

      private static int stopMethod34(TrailsModule module) {

      return module.getVisualColor();
   }

      private static void nlxupv(TextureMatrixTransformer data, long currentTimeMs) {

      List list = data.calculateField49;
      data.processField75 = 0;
      if (!list.isEmpty()) {
         TextureColorManager textureColorManager = (TextureColorManager)list.get(0);
         float value = textureColorManager.getProgress(currentTimeMs);
         data.startMethod10(textureColorManager.getStartPos(), 0F, stopMethod34(data.m30), textureColorManager.getStartTextureU());

         for (TextureColorManager textureColorManager2 : (Iterable<TextureColorManager>)(Iterable<?>) (list)) {
            float value2 = textureColorManager2.getProgress(currentTimeMs);
            data.startMethod10(textureColorManager2.currentPos, textureColorManager2.getAlpha(currentTimeMs), stopMethod34(data.m30), textureColorManager2.getEndTextureU());
         }
      }
   }

}
