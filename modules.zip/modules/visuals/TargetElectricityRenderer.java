package winvi.noxiumvisuals.modules.visuals;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector4i;
import winvi.noxiumvisuals.utils.render.RenderGeometry;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
public final class TargetElectricityRenderer {
      private static final int ckksa = 10;
      private static final int calculateField570 = 2;
      private static final int eln = 4;
      private static final long lo2 = 150L;
      private static final int deleteField66 = 14;
      private static final float elqt = 0.7F;
      private static final float cxckp = 0.3F;
      private static final float wmrzb = 0F;
      private static final float addField9 = 0F;
      private static final float elua = 3.0F;
      private final Random elv = new Random();
      private final ElectricBolt[] stopField45 = new ElectricBolt[10];
      private int elx;
      private int processField8;
      private long elzl;
      private float formatField70;

      public void reset() {
      for (int index = 0; index < this.elx; index++) {
         this.stopField45[index] = null;
      }

      this.elx = 0;
      this.processField8 = 0;
      this.elzl = 0L;
      this.formatField70 = 0F;
   }

      public void render(LivingEntity target, float anim, int glowColor, double rotationRadians) {
      if (target != null && !(anim <= 0.01F)) {
         boolean enabled = anim + 0.001F < this.formatField70;
         float value = enabled ? anim : 1F;
         this.formatField70 = anim;
         Vec3d position = RenderGeometry.interpolate(target);
         long timestamp = System.currentTimeMillis();
         if (!enabled && timestamp - this.elzl > 150L && this.elx < 10) {
            int index = 2 + this.elv.nextInt(3);

            for (int index2 = 0; index2 < index && this.elx < 10; index2++) {
               long timestamp2 = timestamp + index2 * 18L + this.elv.nextInt(13);
               this.stopField45[this.elx++] = this.bzlxjk(target, 0.7F, 0F, 0F, rotationRadians, timestamp2, this.processField8++);
            }

            this.elzl = timestamp;
         }

         for (int index3 = 0; index3 < this.elx; index3++) {
            ElectricBolt moduleSupport2 = this.stopField45[index3];
            if (timestamp >= moduleSupport2.cnytu) {
               if (timestamp - moduleSupport2.cnytu > moduleSupport2.icktw) {
                  this.stopField45[index3] = this.stopField45[--this.elx];
                  this.stopField45[this.elx] = null;
                  index3--;
               } else {
                  float value2 = (float)(timestamp - moduleSupport2.cnytu) / (float)moduleSupport2.icktw;
                  float value3 = value2 < 0.78F ? 1F : Math.max(0F, (1F - value2) / 0.22F);
                  float value4 = 0.76F + 0.24F * Math.abs((float)Math.sin(timestamp * 0.045 + moduleSupport2.wjtiw));
                  float value5 = value * value3 * value4;
                  if (!(value5 <= 0.02F)) {
                     this.lxjvvs(moduleSupport2, position, timestamp, value5, 0.3F, 3.0F, glowColor);
                  }
               }
            }
         }
      } else {
         this.reset();
      }
   }

      private void lxjvvs(ElectricBolt bolt, Vec3d basePos, long now, float boltAlpha, float glow, float thickness, int glowColor) {
      int index = glowColor & 16777215;
      int index2 = transformMethod160(16777215, (int)(boltAlpha * 255.0F));
      int index3 = transformMethod160(index, (int)(boltAlpha * 145.0F * glow));

      for (int index4 = 0; index4 < bolt.sbuob.size(); index4++) {
         List list = bolt.sbuob.get(index4);
         Vec3d position = null;
         float value = 0F;

         for (int index5 = 0; index5 < list.size(); index5++) {
            Vec3d position2 = (Vec3d)list.get(index5);
            Vec3d position3 = this.kafleq(position2, basePos, index5, list.size(), index4, now, bolt.wjtiw);
            float value2 = Math.min(1F, index5 / 3.0F);
            if (glow > 0.01F && index5 > 0 && index5 % 2 == 1) {
               float value3 = 0.11F + thickness * 0.035F;
               this.xq(position3, value3, index3);
            }

            if (position != null) {
               if (glow > 0.01F) {
                  int index6 = transformMethod160(index, (int)(boltAlpha * 41.0F * glow * value));
                  int index7 = transformMethod160(index, (int)(boltAlpha * 41.0F * glow * value2));
                  int index8 = transformMethod160(index, (int)(boltAlpha * 102.0F * glow * value));
                  int index9 = transformMethod160(index, (int)(boltAlpha * 102.0F * glow * value2));
                  WorldShapeRenderer.drawLine(null, position, position3, index6, index7, thickness * 3.75F, true);
                  WorldShapeRenderer.drawLine(null, position, position3, index8, index9, thickness * 1.8F, true);
               }

               WorldShapeRenderer.drawLine(position, position3, index2, thickness, true);
            }

            position = position3;
            value = value2;
         }
      }
   }

      private Vec3d kafleq(Vec3d localPoint, Vec3d basePos, int pointIndex, int pointCount, int pathIndex, long now, double seed) {
      double value = (double)pointIndex / Math.max(1, pointCount - 1);
      double value2 = Math.sin(3.141592653589793 * value);
      double value3 = now * 0.055 + seed + pointIndex * 1.91 + pathIndex * 2.47;
      double value4 = Math.sin(value3) * 0.018 * value2;
      double value5 = (0.5 + 0.5 * Math.sin(value3 * 1.37 + 1.2)) * 0.014 * value2;
      double value6 = Math.sqrt(localPoint.x * localPoint.x + localPoint.z * localPoint.z);
      double value7 = value6 > 1E-5 ? localPoint.x / value6 : 0;
      double value8 = value6 > 1E-5 ? localPoint.z / value6 : 0;
      return basePos.add(localPoint.x + value7 * value5, localPoint.y + value4, localPoint.z + value8 * value5);
   }

      private void xq(Vec3d pos, float scale, int color) {
      Camera client = MinecraftClient.getInstance().getEntityRenderDispatcher().camera;
      Vec3d position = pos.subtract(client.getPos());
      MatrixStack matrices = new MatrixStack();
      matrices.push();
      matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(client.getYaw() + 180.0F));
      matrices.translate(position.x, position.y, position.z);
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-client.getYaw()));
      matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
      Entry entry = matrices.peek().copy();
      WorldShapeRenderer.drawTexture(entry, ParticleTextures.BLOOM, -scale / 2.0F, -scale / 2.0F, scale, scale, new Vector4i(color), true, true);
      matrices.pop();
   }

      private ElectricBolt bzlxjk(
      LivingEntity target, float lengthSetting, float centering, float distance, double rotationRadians, long spawnTime, int sequence
   ) {
      double width = target.getWidth() * 0.5 + 0.05 + distance;
      int index = Math.floorMod(sequence, 3);
      double value = 6.283185307179586 * index / 3.0 + (this.elv.nextDouble() - 0.5) * 0.36;
      double value2 = rotationRadians + value;
      double height = target.getHeight() * 0.5 * (1 - centering * 0.9);
      double value3 = lengthSetting * (0.7 + this.elv.nextDouble() * 0.6);
      double value4 = Math.max(0, height - Math.min(height, value3 * 0.5));
      double value5 = Math.sin(rotationRadians * 1.35 - sequence * 0.35 - index * 0.25);
      value5 = Math.max(-1F, Math.min(1, value5 + (this.elv.nextDouble() - 0.5) * 0.22));
      double height2 = target.getHeight() * 0.5 + value5 * value4;
      ElectricBolt moduleSupport2 = new ElectricBolt();
      int index2 = 3 + this.elv.nextInt(4);
      moduleSupport2.sbuob = new ArrayList<>(index2);

      for (int index3 = 0; index3 < index2; index3++) {
         double value6 = index3 == 0 ? value3 * (0.85 + this.elv.nextDouble() * 0.4) : value3 * (0.22 + this.elv.nextDouble() * 0.78);
         double value7 = this.runMethod00(index3 == 0);
         moduleSupport2.sbuob.add(this.t15(width, value2, height2, value6, value7, (this.elv.nextBoolean() ? 1 : -1F) * (0.14 + this.elv.nextDouble() * 0.22)));
      }

      moduleSupport2.cnytu = spawnTime;
      moduleSupport2.icktw = 180L + this.elv.nextInt(180);
      moduleSupport2.wjtiw = this.elv.nextDouble() * 256.0;
      return moduleSupport2;
   }

      private double runMethod00(boolean primary) {
      if (!primary && !(this.elv.nextFloat() < 0.7F)) {
         return this.elv.nextDouble() * 3.141592653589793 * 2.0;
      } else {
         double value = this.elv.nextBoolean() ? 0 : 3.141592653589793;
         return value + (this.elv.nextDouble() - 0.5) * 1.2;
      }
   }

      private List<Vec3d> t15(double radius, double startAngle, double startHeight, double length, double directionAngle, double curve) {
      double value = this.elv.nextDouble() * 128.0;
      int index = this.elv.nextInt(8);
      double value2 = length * 0.13;
      double value3 = Math.sin(directionAngle);
      double value4 = Math.cos(directionAngle);
      double value5 = length * (0.08 + this.elv.nextDouble() * 0.2);
      Vec3d position = new Vec3d(Math.cos(startAngle), 0, Math.sin(startAngle));
      Vec3d position2 = new Vec3d(-Math.sin(startAngle), 0, Math.cos(startAngle));
      ArrayList arrayList = new ArrayList(15);

      for (int index2 = 0; index2 <= 14; index2++) {
         double value6 = index2 / 14.0;
         double value7 = value6 * 2.0 - 1;
         double value8 = Math.sin(3.141592653589793 * value6);
         double value9 = (cxvg(value7 * 13.0 + value * 0.7) - 0.5) * value2 * 0.7 * value8;
         double value10 = fwcxqq(value7, value, index) * value2 * 1.55 * value8;
         double value11 = Math.abs(cxvg(value7 * 16.0 + value + index * 9.0) - 0.5) * value2 * 0.85 * value8;
         double value12 = value6 * value6 * (3.0 - 2.0 * value6);
         double value13 = Math.max(0, (value6 - 0.68) / 0.32);
         double value14 = value13 * value13;
         double value15 = (value5 + length * (0.05 + Math.abs(curve) * 0.35)) * value14;
         double value16 = radius - Math.min(0.12, length * 0.1);
         double value17 = Math.max(value16, radius + value5 * value12 + value11 - value15);
         double value18 = value4 * length * value6 * 0.78 + value9;
         Vec3d position3 = position.multiply(value17).add(position2.multiply(value18));
         arrayList.add(position3.add(0, startHeight + value3 * length * value6 + value10, 0));
      }

      return arrayList;
   }

      private static double fwcxqq(double x, double time, int index) {
      double value = x18(time * (1 + (8.0 - index) / 4.0) + index / 7.0 + index / 8.0) * 0.13 - 0.065;
      value *= 1.5;
      double value2 = value * 2.0 + (1 - x * x) * value;
      double value3 = executeMethod241(Math.floor(time * 3.0 + index));
      value2 += Math.sin(x * 1.6 + time * 3.0 + value3 * 3.5 + index * 80.0) / 3.0;
      value3 = executeMethod241(Math.floor(time * 2.0));
      value2 += cxvg(x * 6.0 + time + value3 * (10.5 + index * 8.0)) / 5.0;
      return value2 * (1 - Math.min(1, Math.abs(x) / 2.4));
   }

      private static double cxvg(double value) {
      double value2 = Math.floor(value);
      double value3 = x18(value);
      double value4 = value3 * value3 * (3.0 - 2.0 * value3);
      return executeMethod241(value2) + (executeMethod241(value2 + 1) - executeMethod241(value2)) * value4;
   }

      private static double executeMethod241(double value) {
      return x18(Math.sin(value * 12.0) * 42119.0);
   }

      private static double x18(double value) {
      return value - Math.floor(value);
   }

      private static int transformMethod160(int rgb, int alpha) {
      int index = Math.max(0, Math.min(255, alpha));
      return index << 24 | rgb & 16777215;
   }

}
