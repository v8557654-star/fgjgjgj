package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
public class GhostNimbModule extends Module {
      public NumberSetting length;
      public NumberSetting startSize;
      public NumberSetting endSize;
      public NumberSetting animationSpeed;
      public NumberSetting brightness;
      public BooleanSetting onlyFriends;
      final SettingGroup visualSettings;

   public GhostNimbModule() {
      super("Ghost Nimb", ModuleCategory.VISUAL);
      this.length = new NumberSetting(
            "Length",
            "Soul length"
         )
         .setValue(100.0F)
         .range(5.0F, 100.0F);
      this.length.withTranslation("ghostnimb.length", "ghostnimb.length.desc");
      this.startSize = new NumberSetting(
            "Start Size",
            "Start particle size"
         )
         .setValue(25.0F)
         .range(1F, 100.0F);
      this.startSize.withTranslation("ghostnimb.startsize", "ghostnimb.startsize.desc");
      this.endSize = new NumberSetting(
            "End Size",
            "End particle size"
         )
         .setValue(20.0F)
         .range(1F, 100.0F);
      this.endSize.withTranslation("ghostnimb.endsize", "ghostnimb.endsize.desc");
      this.animationSpeed = new NumberSetting(
            "Animation Speed",
            "Speed of particle animation"
         )
         .setValue(0.1F)
         .range(0.1F, 5.0F);
      this.animationSpeed.withTranslation("ghostnimb.animationspeed", "ghostnimb.animationspeed.desc");
      this.brightness = new NumberSetting(
            "Brightness",
            "Ghost brightness intensity"
         )
         .setValue(0F)
         .range(0F, 100.0F);
      this.brightness.withTranslation("ghostnimb.brightness", "ghostnimb.brightness.desc");
      this.onlyFriends = new BooleanSetting(
            "Only Friends",
            "Show halo on yourself and friends"
         )
         .setValue(false);
      this.onlyFriends.withTranslation("ghostnimb.onlyfriends", "ghostnimb.onlyfriends.desc");
      this.visualSettings = new SettingGroup(
            "Visual Settings",
            "Visual settings for Ghost Nimb"
         )
         .settings(this.length, this.startSize, this.endSize, this.animationSpeed, this.brightness, this.onlyFriends)
         .setValue(true);
      this.visualSettings.withTranslation("ghostnimb.visualsettings", "ghostnimb.visualsettings.desc");
      this.showVisualColorSettings();
      this.setState(true);
      this.setup(new ModuleSetting[]{this.visualSettings});
   }

      @Override
   public void activate() {
   }

      @Override
   public void deactivate() {
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
   }

      @Override
   public boolean hasWorldRenderWork() {
      return false;
   }

}
