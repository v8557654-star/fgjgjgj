package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.Util;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.settings.ActionSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.TextSetting;
import winvi.noxiumvisuals.systems.config.TextureSoundRenderer;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.utils.lyrics.LyricsEngine;
import winvi.noxiumvisuals.utils.lyrics.SpotifyAuth;

public class LyricsModule extends Module {
   private static LyricsModule instance;
   public final ChoiceSetting service;
   public final TextSetting token;
   public final TextSetting clientId;
   public final ChoiceSetting font;
   public final NumberSetting size;
   public final NumberSetting lineSpacing;
   public final NumberSetting fade;
   public final BooleanSetting showTitle;
   public final ChoiceSetting colorMode;
   public final ColorSetting colorA;
   public final ColorSetting colorB;
   public final BooleanSetting bloom;
   public final NumberSetting bloomRadius;
   public final NumberSetting bloomIntensity;

   public LyricsModule() {
      super("Lyrics", ModuleCategory.VISUAL);
      instance = this;
      this.service = new ChoiceSetting(
         "Service",
         "Where the music is playing"
      ).value(new String[]{"Spotify", "Yandex Music", "YouTube Music"}).selected("Spotify");
      this.service.withTranslation("lyrics.service", "lyrics.service.desc");
      this.token = new TextSetting(
         "Access Token",
         "Spotify Web API access token with currently-playing scope"
      ).visible(() -> this.service.getSelected().equals("Spotify"));
      this.token.withTranslation("lyrics.token", "lyrics.token.desc");
      this.clientId = new TextSetting(
         "Client ID",
         "Your Spotify application Client ID (used for one-click authorization)"
      )
      .setText(SpotifyAuth.DEFAULT_CLIENT_ID)
      .visible(() -> this.service.getSelected().equals("Spotify"));
      this.clientId.withTranslation("lyrics.clientid", "lyrics.clientid.desc");
      this.font = new ChoiceSetting(
         "Font",
         "Lyrics font weight"
      ).value(new String[]{"Regular", "Medium", "Semibold", "Bold"}).selected("Semibold");
      this.font.withTranslation("lyrics.font", "lyrics.font.desc");
      this.size = new NumberSetting(
         "Size",
         "Lyrics text size"
      )
      .range(10, 48)
      .setValue(26.0F)
      .displayFormatter(value -> String.valueOf((int)Math.round(value)));
      this.size.withTranslation("lyrics.size", "lyrics.size.desc");
      this.lineSpacing = new NumberSetting(
         "Line Spacing",
         "Vertical gap between lines"
      )
      .range(0, 16)
      .setValue(5.0F)
      .displayFormatter(value -> String.valueOf((int)Math.round(value)));
      this.lineSpacing.withTranslation("lyrics.linespacing", "lyrics.linespacing.desc");
      this.fade = new NumberSetting(
         "Fade",
         "How long a line fades out before the next one"
      )
      .range(50, 500)
      .setValue(220.0F)
      .displayFormatter(value -> String.valueOf((int)Math.round(value)) + " ms");
      this.fade.withTranslation("lyrics.fade", "lyrics.fade.desc");
      this.showTitle = new BooleanSetting(
         "Show Title",
         "Show the track name above the lyrics"
      )
      .setValue(false);
      this.showTitle.withTranslation("lyrics.showtitle", "lyrics.showtitle.desc");
      this.colorMode = new ChoiceSetting(
         "Color Mode",
         "How lyric colors are chosen"
      ).value(new String[]{"Solid", "Gradient", "Adaptive"}).selected("Gradient");
      this.colorMode.withTranslation("lyrics.colormode", "lyrics.colormode.desc");
      this.colorA = new ColorSetting(
         "Primary Color",
         "Main lyric color"
      )
      .value(0xFFFF6EC8);
      this.colorA.withTranslation("lyrics.colora", "lyrics.colora.desc");
      this.colorA.setVisible(() -> !this.colorMode.getSelected().equals("Adaptive"));
      this.colorB = new ColorSetting(
         "Secondary Color",
         "Second color of the gradient"
      )
      .value(0xFF5CE1FF);
      this.colorB.withTranslation("lyrics.colorb", "lyrics.colorb.desc");
      this.colorB.setVisible(() -> this.colorMode.getSelected().equals("Gradient"));
      this.bloom = new BooleanSetting(
         "Bloom",
         "Glow behind the lyrics"
      )
      .setValue(true);
      this.bloom.withTranslation("lyrics.bloom", "lyrics.bloom.desc");
      this.bloomRadius = new NumberSetting(
         "Bloom Radius",
         "Radius of the glow"
      )
      .range(1, 10)
      .setValue(4.0F)
      .displayFormatter(value -> String.valueOf((int)Math.round(value)))
      .visible(this.bloom::isValue);
      this.bloomRadius.withTranslation("lyrics.bloomradius", "lyrics.bloomradius.desc");
      this.bloomIntensity = new NumberSetting(
         "Bloom Intensity",
         "Strength of the glow"
      )
      .range(5, 100)
      .setValue(35.0F)
      .displayFormatter(value -> String.valueOf((int)Math.round(value)))
      .visible(this.bloom::isValue);
      this.bloomIntensity.withTranslation("lyrics.bloomintensity", "lyrics.bloomintensity.desc");
      ActionSetting openFolder = new ActionSetting(
         "Lyrics Cache",
         "Open the folder with cached lyrics"
      )
      .setButtonName("Open")
      .setRunnable(() -> {
         Util.getOperatingSystem().open(TextureSoundRenderer.ROOT.resolve("lyrics").toFile());
      });
      openFolder.withTranslation("lyrics.openfolder", "lyrics.openfolder.desc");
      ActionSetting connect = new ActionSetting(
         "Connect Spotify",
         "Authorize via browser, the session is remembered for 180 days"
      )
      .setButtonName("Connect")
      .setRunnable(() -> SpotifyAuth.connect(this.clientId.getText()))
      .visible(() -> this.service.getSelected().equals("Spotify"));
      connect.withTranslation("lyrics.connect", "lyrics.connect.desc");
      ActionSetting disconnect = new ActionSetting(
         "Disconnect Spotify",
         "Forget the saved authorization"
      )
      .setButtonName("Disconnect")
      .setRunnable(SpotifyAuth::disconnect)
      .visible(() -> this.service.getSelected().equals("Spotify") && SpotifyAuth.isAuthorized());
      disconnect.withTranslation("lyrics.disconnect", "lyrics.disconnect.desc");
      this.setup(
         new ModuleSetting[]{
            this.service,
            this.clientId,
            this.token,
            connect,
            disconnect,
            this.font,
            this.size,
            this.lineSpacing,
            this.fade,
            this.showTitle,
            this.colorMode,
            this.colorA,
            this.colorB,
            this.bloom,
            this.bloomRadius,
            this.bloomIntensity,
            openFolder
         }
      );
   }

   public static LyricsModule get() {
      return instance;
   }

   private String resolveToken() {
      if (this.service.getSelected().equals("Spotify")) {
         String oauth = SpotifyAuth.accessToken(this.token.getText());
         return oauth == null || oauth.isEmpty() ? this.token.getText() : oauth;
      }

      return this.token.getText();
   }

   @EventHandler
   public void onClientTick(ClientTickEvent event) {
      LyricsEngine engine = LyricsEngine.getInstance();
      if (engine.isServiceActive()) {
         engine.update(this.service.getSelected(), this.resolveToken());
      }
   }

   @Override
   public void activate() {
      SpotifyAuth.setClientId(this.clientId.getText());
      SpotifyAuth.load();
      LyricsEngine.getInstance().start(this.service.getSelected(), this.resolveToken());
   }

   @Override
   public void deactivate() {
      LyricsEngine.getInstance().stop();
   }
}
