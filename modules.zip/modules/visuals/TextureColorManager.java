package winvi.noxiumvisuals.modules.visuals;

import java.awt.Color;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.visuals.TrailsModule;
public class TextureColorManager {
      private final Vec3d initField70;
      public Vec3d currentPos;
      private final Color isField330;
      public final float entityHeight;
      private final long initField870;
      private final long elzng;
      private final float tvzzf;
      private final float pycwo;
      private long sjssq = -1L;
      private float gka = 0F;
      private float gkbd = 1F;

   public TextureColorManager(Vec3d from, Vec3d to, Color color, float entityHeight, long maxLifetimeMs, long creationTimeMs, float startTextureU) {
      this.initField70 = from;
      this.currentPos = to;
      this.isField330 = color;
      this.entityHeight = entityHeight;
      this.initField870 = creationTimeMs;
      this.elzng = maxLifetimeMs;
      this.tvzzf = startTextureU;
      this.pycwo = startTextureU + (float)from.distanceTo(to);
   }

      public Vec3d interpolate(float pt) {
      double value = this.initField70.x + (this.currentPos.x - this.initField70.x) * pt;
      double value2 = this.initField70.y + (this.currentPos.y - this.initField70.y) * pt;
      double value3 = this.initField70.z + (this.currentPos.z - this.initField70.z) * pt;
      return new Vec3d(value, value2, value3);
   }

      public Vec3d getStartPos() {
      return this.initField70;
   }

      public Color color() {
      return this.isField330;
   }

      public float getStartTextureU() {
      return this.tvzzf;
   }

      public float getEndTextureU() {
      return this.pycwo;
   }

      private void updateMethod5(long currentTime) {
      if (currentTime != this.sjssq) {
         this.sjssq = currentTime;
         long timestamp = currentTime - this.initField870;
         this.gka = Math.min(1F, (float)timestamp / (float)this.elzng);
         float value = 1F - this.gka;
         float value2 = TrailsModule.trailsFadeStrength.getValue();
         float value3 = (float)Math.pow(value, value2);
         float value4 = TrailsModule.trailsOpacity.getValue();
         this.gkbd = Math.max(0F, Math.min(1F, value3 * value4));
      }
   }

      public float getProgress() {
      this.updateMethod5(System.currentTimeMillis());
      return this.gka;
   }

      public float getProgress(long currentTime) {
      this.updateMethod5(currentTime);
      return this.gka;
   }

      public float getAlpha() {
      this.updateMethod5(System.currentTimeMillis());
      return this.gkbd;
   }

      public float getAlpha(long currentTime) {
      this.updateMethod5(currentTime);
      return this.gkbd;
   }

      public boolean shouldRemove(long currentTime) {
      return currentTime - this.initField870 >= this.elzng;
   }

      public float getEntityHeight() {
      return this.entityHeight;
   }

}
