package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.FragmentVelocity;
import winvi.noxiumvisuals.modules.visuals.HitEffectBurst;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.AttackEntityEvent;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.TextEventRenderer;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
import winvi.noxiumvisuals.utils.render.UiRenderUtils;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
import winvi.noxiumvisuals.utils.render.MatrixEntityRenderer;
public final class HitEffectModule extends Module {
      private static final Identifier iwatd = Identifier.of("noxiumvisual", "textures/wfubox433/fbot7ap.png");
      private final NumberSetting pbaij;
      private final NumberSetting eik;
      private final List<HitEffectBurst> abxlo;
      private final Random eimr;
      private long kbabl;
      private int manageField460;
      private int eipi;
      private long formatField85;
      private boolean tnawq;
      private boolean handleField96;

   public HitEffectModule() {
      super(
         "Hit Effect",
         "Monochrome flash and fragment burst on hit",
         ModuleCategory.VISUAL
      );
      this.pbaij = new NumberSetting(
            "Particles",
            "Amount of hit fragments"
         )
         .setValue(120.0F)
         .range(20.0F, 300.0F);
      this.eik = new NumberSetting(
            "Duration",
            "Hit effect duration in seconds"
         )
         .setValue(0.65F)
         .range(0.2F, 1.5F);
      this.abxlo = new ArrayList<>();
      this.eimr = new Random();
      this.eipi = -2147483648;
      this.showVisualColorSettings();
      this.pbaij.withTranslation("hiteffect.particles", "hiteffect.particles.desc");
      this.eik.withTranslation("hiteffect.duration", "hiteffect.duration.desc");
      this.setup(new ModuleSetting[]{this.pbaij, this.eik});
   }

      @Override
   public void activate() {
      this.xjlqgj();
      super.activate();
   }

      @Override
   public void deactivate() {
      this.abxlo.clear();
      this.kbabl = 0L;
      super.deactivate();
   }

   @EventHandler
      public void onAttack(AttackEntityEvent event) {
      if (this.isState()
         && event.getEntity() instanceof LivingEntity livingEntity
         && livingEntity != MinecraftClient.getInstance().player
         && EntityVisibilityFilter.shouldRender(livingEntity)) {
         long timestamp = System.currentTimeMillis();
         if (this.eipi != livingEntity.getId() || timestamp - this.formatField85 >= 70L) {
            this.eipi = livingEntity.getId();
            this.formatField85 = timestamp;
            this.kbabl = timestamp;
            this.manageField460 = this.getVisualColor();
            this.abxlo.add(this.cvps(livingEntity, timestamp, this.manageField460));
         }
      }
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      this.xjlqgj();
      long timestamp = System.currentTimeMillis();
      this.abxlo.removeIf(burst -> {
         return timestamp - burst.startedAt() >= burst.durationMs();
      });
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState() && !this.abxlo.isEmpty()) {
         long timestamp = System.currentTimeMillis();
         Iterator iterator2 = this.abxlo.iterator();

         while (iterator2.hasNext()) {
            HitEffectBurst colorModuleStyle3 = (HitEffectBurst)iterator2.next();
            float value = MathHelper.clamp((float)(timestamp - colorModuleStyle3.startedAt()) / (float)colorModuleStyle3.durationMs(), 0F, 1F);
            if (value >= 1F) {
               iterator2.remove();
            } else {
               float value2 = (float)(timestamp - colorModuleStyle3.startedAt()) / 1000.0F;
               float value3 = tsthnp(Math.min(1F, value * 5.0F)) * (1F - tsthnp(value));
               int index = ColorUtils.multAlpha(colorModuleStyle3.color(), value3 * 0.9F);

               for (FragmentVelocity moduleBounds2 : colorModuleStyle3.fragments()) {
                  Vec3d position = new Vec3d(0, -1.35F * value2 * value2, 0);
                  Vec3d position2 = colorModuleStyle3.origin().add(moduleBounds2.velocity().multiply(value2)).add(position);
                  Vec3d position3 = position2.subtract(moduleBounds2.velocity().multiply(0.025));
                  WorldShapeRenderer.drawLine(position3, position2, index, moduleBounds2.width(), true);
               }
            }
         }
      }
   }

   @EventHandler
      public void onDraw(TextEventRenderer event) {
      if (this.isState() && this.kbabl != 0L) {
         float value = Math.max(1F, this.eik.getValue() * 1000.0F);
         float value2 = MathHelper.clamp((float)(System.currentTimeMillis() - this.kbabl) / value, 0F, 1F);
         if (value2 >= 1F) {
            this.kbabl = 0L;
         } else {
            float value3 = tsthnp(Math.min(1F, value2 * 6.0F));
            float value4 = 1F - tsthnp(value2);
            int index = ColorUtils.multAlpha(this.manageField460, value3 * value4 * 0.34F);
            float width = MatrixEntityRenderer.getVirtualWidth();
            float height = MatrixEntityRenderer.getVirtualHeight();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.depthMask(false);
            UiRenderUtils.drawTexturedQuad(event.getDrawContext().getMatrices(), iwatd, 0F, width, 0F, height, 0F, 1F, 0F, 1F, index);
            RenderSystem.depthMask(true);
            RenderSystem.disableBlend();
         }
      }
   }

      @Override
   public boolean hasWorldRenderWork() {
      return this.isState() && !this.abxlo.isEmpty();
   }

      private HitEffectBurst cvps(LivingEntity entity, long now, int color) {
      Vec3d height = entity.getPos().add(0, entity.getHeight() * 0.52, 0);
      int index = Math.max(1, this.pbaij.getInt());
      ArrayList arrayList = new ArrayList(index);

      for (int index2 = 0; index2 < index; index2++) {
         double value = this.eimr.nextDouble() * 3.141592653589793 * 2.0;
         double value2 = this.eimr.nextDouble() * 1.25 - 0.22;
         double value3 = 0.45 + this.eimr.nextDouble() * 1.25;
         Vec3d position = new Vec3d(Math.sin(value) * value3, value2, Math.cos(value) * value3);
         arrayList.add(new FragmentVelocity(position, 1.2F + this.eimr.nextFloat() * 1.4F));
      }

      return new HitEffectBurst(height, now, (long)(this.eik.getValue() * 1000.0F), color, arrayList);
   }

      private void xjlqgj() {
      if (!this.tnawq) {
         if (!RenderSystem.isOnRenderThread()) {
            if (!this.handleField96) {
               this.handleField96 = true;
               RenderSystem.recordRenderCall(this::xjlqgj);
            }
         } else {
            this.handleField96 = false;
            MinecraftClient.getInstance().getTextureManager().getTexture(iwatd).setFilter(true, false);
            this.tnawq = true;
         }
      }
   }

      private static float tsthnp(float value) {
      float value2 = MathHelper.clamp(value, 0F, 1F);
      return value2 * value2 * (3.0F - 2.0F * value2);
   }

}
