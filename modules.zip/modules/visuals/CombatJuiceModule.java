package winvi.noxiumvisuals.modules.visuals;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import org.lwjgl.glfw.GLFW;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.systems.events.AnimationEventProvider;
import winvi.noxiumvisuals.systems.events.AttackEntityEvent;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.HeldItemTransformEvent;
import winvi.noxiumvisuals.systems.events.MatrixItemStackManager;
import winvi.noxiumvisuals.systems.events.RenderEventData;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.combat.ShakeManager;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;

public class CombatJuiceModule extends Module {
   private static final MinecraftClient CLIENT = MinecraftClient.getInstance();
   private static final Random RANDOM = Random.create();
   private static final int TRAIL_MAX_SAMPLES = 72;
   private static CombatJuiceModule instance;
   public final NumberSetting sharpness;
   public final BooleanSetting smartSlash;
   public final BooleanSetting swordShield;
   public final BooleanSetting shake;
   public final NumberSetting shakeIntensity;
   public final BooleanSetting trail;
   public final NumberSetting trailLifetime;
   public final ColorSetting trailColorA;
   public final ColorSetting trailColorB;
   public final BooleanSetting sparks;
   public final ChoiceSetting sparkShape;
   public final NumberSetting sparkCount;
   public final ColorSetting sparkColor;
   public final BooleanSetting critReplace;
   public final BooleanSetting swoosh;
   public final NumberSetting swooshVolume;
   public final BooleanSetting hitSfx;
   public final NumberSetting hitVolume;
   public final BooleanSetting layeredCrit;
   public final BooleanSetting shockwave;
   public final BooleanSetting smoke;
   private final List<TrailSample> trailSamples = new ArrayList<>();
   private final List<Spark> sparksList = new ArrayList<>();
   private final List<Ring> rings = new ArrayList<>();
   private final List<SmokePuff> smokeList = new ArrayList<>();
   private final List<PendingTask> pending = new ArrayList<>();
   private int slashIndex;
   private float shieldProgress;
   private long shieldLastMs;
   private long lastRenderMs;
   private long lastSmokeMs;

   public CombatJuiceModule() {
      super("Combat Juice", ModuleCategory.VISUAL);
      instance = this;
      this.sharpness = new NumberSetting(
         "Sharpness",
         "Makes swing animations faster and snappier"
      )
      .range(0.0F, 1.0F)
      .setValue(0.55F)
      .displayFormatter(value -> String.valueOf((int)Math.round(value * 100.0F)) + "%");
      this.sharpness.withTranslation("combatjuice.sharpness", "combatjuice.sharpness.desc");
      this.smartSlash = new BooleanSetting(
         "Smart Slash",
         "Alternate swing direction on every attack"
      )
      .setValue(true);
      this.smartSlash.withTranslation("combatjuice.smartslash", "combatjuice.smartslash.desc");
      this.swordShield = new BooleanSetting(
         "Sword Shielding",
         "Guard pose while holding the use key with a melee weapon"
      )
      .setValue(true);
      this.swordShield.withTranslation("combatjuice.swordshield", "combatjuice.swordshield.desc");
      this.shake = new BooleanSetting(
         "Screen Shake",
         "Camera shake on hits and kills"
      )
      .setValue(true);
      this.shake.withTranslation("combatjuice.shake", "combatjuice.shake.desc");
      this.shakeIntensity = new NumberSetting(
         "Shake Intensity",
         "Strength of the camera shake"
      )
      .range(10, 100)
      .setValue(55.0F)
      .displayFormatter(value -> String.valueOf((int)Math.round(value)) + "%")
      .visible(this.shake::isValue);
      this.shakeIntensity.withTranslation("combatjuice.shakeintensity", "combatjuice.shakeintensity.desc");
      this.trail = new BooleanSetting(
         "Weapon Trail",
         "Neon ribbon following your weapon swings"
      )
      .setValue(true);
      this.trail.withTranslation("combatjuice.trail", "combatjuice.trail.desc");
      this.trailLifetime = new NumberSetting(
         "Trail Lifetime",
         "How long the trail stays visible"
      )
      .range(100, 250)
      .setValue(220.0F)
      .displayFormatter(value -> String.valueOf((int)Math.round(value)) + " ms")
      .visible(this.trail::isValue);
      this.trailLifetime.withTranslation("combatjuice.traillifetime", "combatjuice.traillifetime.desc");
      this.trailColorA = new ColorSetting(
         "Trail Color Start",
         "First color of the trail gradient"
      )
      .value(0xFFFF5CD8);
      this.trailColorA.withTranslation("combatjuice.trailcolora", "combatjuice.trailcolora.desc");
      this.trailColorA.setVisible(this.trail::isValue);
      this.trailColorB = new ColorSetting(
         "Trail Color End",
         "Second color of the trail gradient"
      )
      .value(0xFF5CE1FF);
      this.trailColorB.withTranslation("combatjuice.trailcolorb", "combatjuice.trailcolorb.desc");
      this.trailColorB.setVisible(this.trail::isValue);
      this.sparks = new BooleanSetting(
         "Hit Sparks",
         "Particles bursting out of the target"
      )
      .setValue(true);
      this.sparks.withTranslation("combatjuice.sparks", "combatjuice.sparks.desc");
      this.sparkShape = new ChoiceSetting(
         "Spark Shape",
         "Shape of the hit particles"
      ).value(new String[]{"Lines", "Diamond", "Sphere"}).selected("Lines");
      this.sparkShape.withTranslation("combatjuice.sparkshape", "combatjuice.sparkshape.desc");
      this.sparkShape.setVisible(this.sparks::isValue);
      this.sparkCount = new NumberSetting(
         "Spark Count",
         "How many particles spawn per hit"
      )
      .range(2, 14)
      .setValue(6.0F)
      .displayFormatter(value -> String.valueOf((int)Math.round(value)))
      .visible(this.sparks::isValue);
      this.sparkCount.withTranslation("combatjuice.sparkcount", "combatjuice.sparkcount.desc");
      this.sparkColor = new ColorSetting(
         "Spark Color",
         "Color of the hit particles"
      )
      .value(0xFFFFD35C);
      this.sparkColor.withTranslation("combatjuice.sparkcolor", "combatjuice.sparkcolor.desc");
      this.sparkColor.setVisible(this.sparks::isValue);
      this.critReplace = new BooleanSetting(
         "Crit Replacer",
         "Replace vanilla critical hit stars with custom sparks"
      )
      .setValue(true);
      this.critReplace.withTranslation("combatjuice.critreplace", "combatjuice.critreplace.desc");
      this.swoosh = new BooleanSetting(
         "Swoosh",
         "Play a swoosh when pressing attack with a melee weapon"
      )
      .setValue(true);
      this.swoosh.withTranslation("combatjuice.swoosh", "combatjuice.swoosh.desc");
      this.swooshVolume = new NumberSetting(
         "Swoosh Volume",
         "Volume of the swing sound"
      )
      .range(0, 100)
      .setValue(70.0F)
      .displayFormatter(value -> String.valueOf((int)Math.round(value)) + "%")
      .visible(this.swoosh::isValue);
      this.swooshVolume.withTranslation("combatjuice.swooshvolume", "combatjuice.swooshvolume.desc");
      this.hitSfx = new BooleanSetting(
         "Hit Sounds",
         "Layered impact sounds on every hit"
      )
      .setValue(true);
      this.hitSfx.withTranslation("combatjuice.hitsfx", "combatjuice.hitsfx.desc");
      this.hitVolume = new NumberSetting(
         "Hit Volume",
         "Volume of the impact sounds"
      )
      .range(0, 100)
      .setValue(70.0F)
      .displayFormatter(value -> String.valueOf((int)Math.round(value)) + "%")
      .visible(this.hitSfx::isValue);
      this.hitVolume.withTranslation("combatjuice.hitvolume", "combatjuice.hitvolume.desc");
      this.layeredCrit = new BooleanSetting(
         "Layered Crit",
         "Add a bass layer to critical hits"
      )
      .setValue(true);
      this.layeredCrit.withTranslation("combatjuice.layeredcrit", "combatjuice.layeredcrit.desc");
      this.layeredCrit.setVisible(this.hitSfx::isValue);
      this.shockwave = new BooleanSetting(
         "Shockwave",
         "Expanding ring at the impact point"
      )
      .setValue(true);
      this.shockwave.withTranslation("combatjuice.shockwave", "combatjuice.shockwave.desc");
      this.smoke = new BooleanSetting(
         "Hit Smoke",
         "Volumetric smoke clouds around the target on impact"
      )
      .setValue(true);
      this.smoke.withTranslation("combatjuice.smoke", "combatjuice.smoke.desc");
      this.setup(
         new ModuleSetting[]{
            this.sharpness,
            this.smartSlash,
            this.swordShield,
            this.shake,
            this.shakeIntensity,
            this.trail,
            this.trailLifetime,
            this.trailColorA,
            this.trailColorB,
            this.sparks,
            this.sparkShape,
            this.sparkCount,
            this.sparkColor,
            this.critReplace,
            this.swoosh,
            this.swooshVolume,
            this.hitSfx,
            this.hitVolume,
             this.layeredCrit,
             this.shockwave,
             this.smoke
          }
       );
   }

   public static CombatJuiceModule get() {
      return instance;
   }

   public static boolean shouldSuppressCritParticles(ParticleEffect effect) {
      CombatJuiceModule module = instance;
      return module != null
         && module.isState()
         && module.critReplace.isValue()
         && (effect == ParticleTypes.CRIT || effect == ParticleTypes.ENCHANTED_HIT);
   }

   @Override
   public void deactivate() {
      this.trailSamples.clear();
      this.sparksList.clear();
      this.rings.clear();
      this.smokeList.clear();
      this.pending.clear();
      this.slashIndex = 0;
      this.shieldProgress = 0.0F;
      this.shieldLastMs = 0L;
      ShakeManager.reset();
   }

   @EventHandler
   public void onAnimation(AnimationEventProvider event) {
      if (!this.isState()) {
         return;
      }

      float sharpness = this.sharpness.getValue();
      if (sharpness <= 0.0F) {
         return;
      }

      event.setAnimation(1.0F - 0.75F * sharpness);
      event.cancel();
   }

   @EventHandler
   public void onRenderData(RenderEventData event) {
      if (!this.isState()) {
         return;
      }

      if (event.type() == InputUtil.Type.MOUSE
         && event.key() == GLFW.GLFW_MOUSE_BUTTON_LEFT
         && event.action() == 1
         && event.screen() == null
         && CLIENT.world != null
         && CLIENT.player != null
         && isMelee(CLIENT.player.getMainHandStack())) {
         this.slashIndex++;
         if (this.swoosh.isValue()) {
            float volume = this.swooshVolume.getValue() / 100.0F;
            if (volume > 0.0F) {
               CLIENT.getSoundManager()
                  .play(
                     PositionedSoundInstance.master(
                        SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP,
                        volume,
                        0.92F + RANDOM.nextFloat() * 0.16F
                     )
                  );
            }
         }
      }
   }

   @EventHandler
   public void onAttack(AttackEntityEvent event) {
      if (!this.isState() || CLIENT.world == null || CLIENT.player == null) {
         return;
      }

      Entity target = event.getEntity();
      boolean critical = isCritical(CLIENT.player);
      Vec3d hitPos = target != null ? target.getPos().add(0.0, target.getHeight() * 0.55, 0.0) : CLIENT.player.getPos().add(0.0, 1.0, 0.0);
      long now = System.currentTimeMillis();

      if (this.sparks.isValue()) {
         this.spawnSparks(hitPos, critical, now);
      }

      if (this.shockwave.isValue() && target != null) {
         this.rings.add(new Ring(target.getPos(), now));
      }

      if (this.smoke.isValue() && target != null) {
         this.spawnSmoke(target, critical, now);
      }

      if (this.shake.isValue()) {
         float intensity = this.shakeIntensity.getValue() / 100.0F;
         ShakeManager.addTrauma((critical ? 0.55F : 0.35F) * intensity);
      }

      if (this.hitSfx.isValue()) {
         float volume = this.hitVolume.getValue() / 100.0F;
         if (volume > 0.0F) {
            Vec3d soundPos = target != null ? target.getPos() : CLIENT.player.getPos();
            if (critical && this.layeredCrit.isValue()) {
               playAt(soundPos, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, volume, 1.06F);
               playAt(soundPos, SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), volume * 0.9F, 0.45F);
               playAt(soundPos, SoundEvents.BLOCK_ANVIL_LAND, volume * 0.55F, 1.55F);
               playAt(soundPos, SoundEvents.BLOCK_GLASS_BREAK, volume * 0.6F, 1.3F);
            } else if (critical) {
               playAt(soundPos, SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, volume, 1.0F);
            } else {
               playAt(soundPos, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, volume * 0.8F, 0.95F + RANDOM.nextFloat() * 0.1F);
            }
         }
      }

      if (target != null) {
         Entity captured = target;
         this.schedule(170L, () -> {
            if (!isDefeated(captured)) {
               return;
            }

            if (this.shake.isValue()) {
               ShakeManager.addTrauma(this.shakeIntensity.getValue() / 100.0F);
            }

            Vec3d deathPos = captured.getPos();
            if (this.hitSfx.isValue()) {
               float volume = this.hitVolume.getValue() / 100.0F;
               if (volume > 0.0F) {
                  playAt(deathPos, SoundEvents.BLOCK_ANVIL_LAND, volume, 0.72F);
               }
            }

            if (this.sparks.isValue()) {
               this.spawnSparks(deathPos.add(0.0, 0.6, 0.0), true, System.currentTimeMillis());
            }
         });
      }
   }

   @EventHandler
   public void onItemTransform(HeldItemTransformEvent event) {
      if (!this.isState() || !this.swordShield.isValue() || event.getHand() != Hand.MAIN_HAND || !isMelee(event.getStack())) {
         return;
      }

      long now = System.currentTimeMillis();
      float delta = this.shieldLastMs == 0L ? 0.05F : Math.min(0.1F, (now - this.shieldLastMs) / 1000.0F);
      this.shieldLastMs = now;
      boolean held = CLIENT.options != null
         && CLIENT.options.useKey.isPressed()
         && CLIENT.player != null
         && !CLIENT.player.isUsingItem()
         && isMelee(CLIENT.player.getMainHandStack());
      float target = held ? 1.0F : 0.0F;
      this.shieldProgress += (target - this.shieldProgress) * Math.min(1.0F, delta * 16.0F);
      if (this.shieldProgress > 0.02F) {
         float progress = this.shieldProgress;
         MatrixStack matrices = event.getMatrices();
         matrices.translate(0.16 * progress, -0.14 * progress, 0.1 * progress);
         matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-36.0F * progress));
         matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-16.0F * progress));
      }
   }

   @EventHandler
   public void onSwingTransform(MatrixItemStackManager event) {
      if (!this.isState() || !this.smartSlash.isValue() || event.getHand() != Hand.MAIN_HAND || !isMelee(event.getStack())) {
         return;
      }

      float swing = event.getSwingProgress();
      if (swing <= 0.0F) {
         return;
      }

      int direction = switch (Math.floorMod(this.slashIndex, 3)) {
         case 0 -> -1;
         case 1 -> 1;
         default -> -2;
      };
      MatrixStack matrices = event.getMatrices();
      matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(direction * 44.0F * swing));
      matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(direction * 14.0F * swing));
   }

   @EventHandler
   public void onClientTick(ClientTickEvent event) {
      if (this.pending.isEmpty()) {
         return;
      }

      long now = System.currentTimeMillis();
      Iterator<PendingTask> iterator = this.pending.iterator();

      while (iterator.hasNext()) {
         PendingTask task = iterator.next();
         if (now >= task.timeMs) {
            iterator.remove();

            try {
               task.action.run();
            } catch (Exception exception) {
            }
         }
      }
   }

   @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (!this.isState() || CLIENT.world == null || CLIENT.player == null) {
         return;
      }

      long now = System.currentTimeMillis();
      if (this.trail.isValue()) {
         this.sampleTrail(now, event.getPartialTicks());
      }

      this.renderTrail(now);
      this.updateSparks(now);
      this.updateRings(now);
      this.updateSmoke(now);
   }

   @Override
   public boolean hasWorldRenderWork() {
      return this.isState()
         && (this.trail.isValue() || this.sparks.isValue() || this.shockwave.isValue() || this.smoke.isValue());
   }

   private void sampleTrail(long now, float partialTicks) {
      ClientPlayerEntity player = CLIENT.player;
      float swing = player.getHandSwingProgress(partialTicks);
      if (swing <= 0.02F || !isMelee(player.getMainHandStack())) {
         return;
      }

      Vec3d base = player.getLerpedPos(partialTicks).add(0.0, 1.1, 0.0);
      double yaw = Math.toRadians(CLIENT.gameRenderer.getCamera().getYaw());
      Vec3d forward = new Vec3d(-Math.sin(yaw), 0.0, Math.cos(yaw));
      Vec3d right = new Vec3d(-forward.z, 0.0, forward.x);
      double angle = Math.toRadians(-70.0 + 140.0 * swing);
      double cos = Math.cos(angle);
      double sin = Math.sin(angle);
      Vec3d arc = forward.multiply(cos).add(right.multiply(sin));
      double lift = 0.12 + Math.sin(swing * Math.PI) * 0.38;
      Vec3d tip = base.add(arc.x * 0.8, lift, arc.z * 0.8);
      this.trailSamples.add(new TrailSample(tip, now));
      if (this.trailSamples.size() > TRAIL_MAX_SAMPLES) {
         this.trailSamples.remove(0);
      }
   }

   private void renderTrail(long now) {
      if (!this.trail.isValue()) {
         this.trailSamples.clear();
         return;
      }

      long lifetime = (long)this.trailLifetime.getValue();
      this.trailSamples.removeIf(sample -> now - sample.timeMs > lifetime);
      int count = this.trailSamples.size();
      if (count < 2) {
         return;
      }

      Vec3d camera = CLIENT.gameRenderer.getCamera().getPos();
      int colorA = this.trailColorA.getColor();
      int colorB = this.trailColorB.getColor();

      for (int index = 1; index < count; index++) {
         TrailSample previous = this.trailSamples.get(index - 1);
         TrailSample current = this.trailSamples.get(index);
         long age = now - current.timeMs;
         if (age >= lifetime) {
            continue;
         }

         float fade = 1.0F - age / (float)lifetime;
         Vec3d segment = current.pos.subtract(previous.pos);
         if (segment.lengthSquared() < 1.0E-6) {
            continue;
         }

         Vec3d middle = current.pos.add(previous.pos).multiply(0.5);
         Vec3d toCamera = camera.subtract(middle);
         Vec3d side = segment.crossProduct(toCamera);
         double sideLength = side.length();
         if (sideLength < 1.0E-6) {
            continue;
         }

         double width = 0.08 * (0.35 + 0.65 * fade);
         side = side.multiply(width / sideLength);
         float progress = index / (float)(count - 1);
         int color = ColorUtils.multAlpha(ColorUtils.overCol(colorA, colorB, progress), 0.9F * fade * fade);
         WorldShapeRenderer.drawQuad(
            previous.pos.subtract(side),
            previous.pos.add(side),
            current.pos.add(side),
            current.pos.subtract(side),
            color,
            false
         );
      }
   }

   private void spawnSparks(Vec3d origin, boolean critical, long now) {
      int count = (int)this.sparkCount.getValue() * (critical ? 2 : 1);
      int baseColor = this.sparkColor.getColor();
      int color = critical ? ColorUtils.overCol(baseColor, 0xFFFFFFFF, 0.35F) : baseColor;
      float speedBoost = critical ? 1.5F : 1.0F;

      for (int index = 0; index < count; index++) {
         Vec3d direction = randomUnitVector();
         Vec3d velocity = direction.multiply((1.4F + RANDOM.nextFloat() * 1.8F) * speedBoost);
         long life = 280L + (long)(RANDOM.nextFloat() * 260.0F) + (critical ? 140L : 0L);
         this.sparksList.add(new Spark(origin, velocity, now, life, color));
      }

      if (this.sparksList.size() > 128) {
         this.sparksList.remove(0);
      }
   }

   private void updateSparks(long now) {
      if (this.sparksList.isEmpty() || !this.sparks.isValue()) {
         this.sparksList.clear();
         return;
      }

      long deltaMs = this.lastRenderMs == 0L ? 16L : now - this.lastRenderMs;
      this.lastRenderMs = now;
      float delta = Math.min(0.05F, Math.max(0.001F, deltaMs / 1000.0F));
      String shape = this.sparkShape.getSelected();
      Vec3d camera = CLIENT.gameRenderer.getCamera().getPos();
      double yaw = Math.toRadians(CLIENT.gameRenderer.getCamera().getYaw());
      Vec3d rightAxis = new Vec3d(-Math.cos(yaw), 0.0, -Math.sin(yaw));
      Vec3d upAxis = new Vec3d(0.0, 1.0, 0.0);

      Iterator<Spark> iterator = this.sparksList.iterator();

      while (iterator.hasNext()) {
         Spark spark = iterator.next();
         long age = now - spark.bornMs;
         if (age >= spark.lifeMs) {
            iterator.remove();
            continue;
         }

         spark.velocity = spark.velocity.add(0.0, -5.5 * delta, 0.0).multiply(1.0 - Math.min(0.9F, 1.7F * delta));
         spark.pos = spark.pos.add(spark.velocity.multiply(delta));
         float fade = 1.0F - age / (float)spark.lifeMs;
         int color = ColorUtils.multAlpha(spark.color, fade * fade);
         if (spark.pos.squaredDistanceTo(camera) > 2500.0) {
            continue;
         }

         this.drawSpark(shape, spark, color, fade, rightAxis, upAxis);
      }
   }

   private void drawSpark(String shape, Spark spark, int color, float fade, Vec3d rightAxis, Vec3d upAxis) {
      switch (shape) {
         case "Diamond" -> {
            double size = 0.05 + 0.06 * fade;
            Vec3d up = upAxis.multiply(size);
            Vec3d right = rightAxis.multiply(size);
            WorldShapeRenderer.drawLine(spark.pos.add(up), spark.pos.add(right), color, 2.0F, false);
            WorldShapeRenderer.drawLine(spark.pos.add(right), spark.pos.subtract(up), color, 2.0F, false);
            WorldShapeRenderer.drawLine(spark.pos.subtract(up), spark.pos.subtract(right), color, 2.0F, false);
            WorldShapeRenderer.drawLine(spark.pos.subtract(right), spark.pos.add(up), color, 2.0F, false);
         }
         case "Sphere" -> {
            double radius = 0.045 + 0.055 * fade;
            drawRing(spark.pos, radius, 8, color, rightAxis, upAxis);
            drawHorizontalRing(spark.pos, radius, 8, color);
         }
         default -> {
            Vec3d end = spark.pos.add(spark.velocity.multiply(0.055));
            WorldShapeRenderer.drawLine(spark.pos, end, color, 2.0F + fade, false);
         }
      }
   }

   private static void drawRing(Vec3d center, double radius, int segments, int color, Vec3d rightAxis, Vec3d upAxis) {
      Vec3d previous = null;

      for (int index = 0; index <= segments; index++) {
         double angle = index / (double)segments * Math.PI * 2.0;
         Vec3d offset = rightAxis.multiply(Math.cos(angle) * radius).add(upAxis.multiply(Math.sin(angle) * radius));
         Vec3d point = center.add(offset);
         if (previous != null) {
            WorldShapeRenderer.drawLine(previous, point, color, 1.5F, false);
         }

         previous = point;
      }
   }

   private static void drawHorizontalRing(Vec3d center, double radius, int segments, int color) {
      Vec3d previous = null;

      for (int index = 0; index <= segments; index++) {
         double angle = index / (double)segments * Math.PI * 2.0;
         Vec3d point = center.add(Math.cos(angle) * radius, 0.0, Math.sin(angle) * radius);
         if (previous != null) {
            WorldShapeRenderer.drawLine(previous, point, color, 1.5F, false);
         }

         previous = point;
      }
   }

   private void updateRings(long now) {
      if (this.rings.isEmpty() || !this.shockwave.isValue()) {
         this.rings.clear();
         return;
      }

      int color = ColorUtils.getClientColor();
      Iterator<Ring> iterator = this.rings.iterator();

      while (iterator.hasNext()) {
         Ring ring = iterator.next();
         long age = now - ring.bornMs;
         long life = 380L;
         if (age >= life) {
            iterator.remove();
            continue;
         }

         float progress = age / (float)life;
         double radius = 1.35 * (1.0 - (1.0 - progress) * (1.0 - progress));
         int ringColor = ColorUtils.multAlpha(color, (1.0F - progress) * 0.85F);
         drawHorizontalRing(ring.center.add(0.0, 0.04, 0.0), radius, 24, ringColor);
      }
   }

   private void spawnSmoke(Entity target, boolean critical, long now) {
      Box box = target.getBoundingBox().expand(0.12);
      int count = 5 + (critical ? 3 : 0);
      int color = ColorUtils.overCol(0xFFBFBFBF, this.trailColorB.getColor(), 0.18F);

      for (int index = 0; index < count; index++) {
         Vec3d pos = new Vec3d(
            box.minX + RANDOM.nextDouble() * (box.maxX - box.minX),
            box.minY + RANDOM.nextDouble() * (box.maxY - box.minY),
            box.minZ + RANDOM.nextDouble() * (box.maxZ - box.minZ)
         );
         Vec3d velocity = new Vec3d(
            (RANDOM.nextFloat() - 0.5F) * 0.5F,
            0.15F + RANDOM.nextFloat() * 0.3F,
            (RANDOM.nextFloat() - 0.5F) * 0.5F
         );
         long life = 650L + (long)(RANDOM.nextFloat() * 400.0F);
         double size = 0.15 + RANDOM.nextFloat() * 0.13;
         float angle = RANDOM.nextFloat() * (float)(Math.PI * 2.0);
         this.smokeList.add(new SmokePuff(pos, velocity, now, life, size, angle, color));
      }

      while (this.smokeList.size() > 48) {
         this.smokeList.remove(0);
      }
   }

   private void updateSmoke(long now) {
      if (this.smokeList.isEmpty() || !this.smoke.isValue()) {
         this.smokeList.clear();
         return;
      }

      long deltaMs = this.lastSmokeMs == 0L ? 16L : now - this.lastSmokeMs;
      this.lastSmokeMs = now;
      float delta = Math.min(0.05F, Math.max(0.001F, deltaMs / 1000.0F));
      Vec3d camera = CLIENT.gameRenderer.getCamera().getPos();
      Iterator<SmokePuff> iterator = this.smokeList.iterator();

      while (iterator.hasNext()) {
         SmokePuff puff = iterator.next();
         long age = now - puff.bornMs;
         if (age >= puff.lifeMs) {
            iterator.remove();
            continue;
         }

         puff.pos = puff.pos.add(puff.velocity.multiply(delta));
         puff.velocity = puff.velocity.multiply(1.0 - Math.min(0.6F, 0.8F * delta));
         float progress = age / (float)puff.lifeMs;
         if (puff.pos.squaredDistanceTo(camera) > 2500.0) {
            continue;
         }

         this.drawSmoke(puff, progress, camera);
      }
   }

   private void drawSmoke(SmokePuff puff, float progress, Vec3d camera) {
      Vec3d toCamera = camera.subtract(puff.pos);
      double distance = toCamera.length();
      if (distance < 1.0E-3) {
         return;
      }

      toCamera = toCamera.multiply(1.0 / distance);
      Vec3d rightAxis = toCamera.crossProduct(new Vec3d(0.0, 1.0, 0.0));
      if (rightAxis.lengthSquared() < 1.0E-4) {
         rightAxis = new Vec3d(1.0, 0.0, 0.0);
      }

      rightAxis = rightAxis.normalize();
      Vec3d upAxis = rightAxis.crossProduct(toCamera).normalize();
      double cos = Math.cos(puff.angle);
      double sin = Math.sin(puff.angle);
      Vec3d spinRight = rightAxis.multiply(cos).add(upAxis.multiply(sin));
      Vec3d spinUp = upAxis.multiply(cos).subtract(rightAxis.multiply(sin));
      double size = puff.baseSize * (0.5 + 1.3 * progress);
      float appear = Math.min(1.0F, progress * 6.0F);
      float alpha = appear * (1.0F - progress) * 0.34F;
      if (alpha <= 0.01F) {
         return;
      }

      drawSmokeQuad(puff.pos, spinRight.multiply(size), spinUp.multiply(size), puff.color, alpha);
      drawSmokeQuad(puff.pos, spinUp.multiply(size), toCamera.multiply(size), ColorUtils.multAlpha(puff.color, 0.85F), alpha);
      drawSmokeQuad(puff.pos, spinRight.multiply(size), new Vec3d(0.0, size, 0.0), ColorUtils.multAlpha(puff.color, 0.7F), alpha);
   }

   private static void drawSmokeQuad(Vec3d center, Vec3d right, Vec3d up, int color, float alpha) {
      int fade = ColorUtils.multAlpha(color, alpha);
      WorldShapeRenderer.drawQuad(
         center.subtract(right).subtract(up),
         center.add(right).subtract(up),
         center.add(right).add(up),
         center.subtract(right).add(up),
         fade,
         false
      );
   }

   private void schedule(long delayMs, Runnable action) {
      this.pending.add(new PendingTask(System.currentTimeMillis() + delayMs, action));
      if (this.pending.size() > 32) {
         this.pending.remove(0);
      }
   }

   private static void playAt(Vec3d position, SoundEvent sound, float volume, float pitch) {
      if (CLIENT.getSoundManager() == null) {
         return;
      }

      CLIENT.getSoundManager()
         .play(
            new PositionedSoundInstance(
               sound,
               SoundCategory.PLAYERS,
               volume,
               pitch,
               Random.create(),
               position.x,
               position.y,
               position.z
            )
         );
   }

   private static boolean isMelee(ItemStack stack) {
      if (stack == null || stack.isEmpty()) {
         return false;
      }

      return stack.getItem() instanceof SwordItem || stack.getItem() instanceof AxeItem || stack.getItem() instanceof MaceItem;
   }

   private static boolean isCritical(ClientPlayerEntity player) {
      return player.fallDistance > 0.0F
         && !player.isOnGround()
         && !player.isClimbing()
         && !player.isTouchingWater()
         && !player.hasStatusEffect(StatusEffects.BLINDNESS)
         && !player.hasVehicle();
   }

   private static boolean isDefeated(Entity entity) {
      if (entity.isRemoved()) {
         return true;
      }

      return entity instanceof LivingEntity living && living.getHealth() + living.getAbsorptionAmount() <= 0.0F;
   }

   private static Vec3d randomUnitVector() {
      double theta = RANDOM.nextDouble() * Math.PI * 2.0;
      double phi = Math.acos(2.0 * RANDOM.nextDouble() - 1.0);
      return new Vec3d(
         Math.sin(phi) * Math.cos(theta),
         Math.sin(phi) * Math.sin(theta),
         Math.cos(phi)
      );
   }

   private static final class TrailSample {
      private final Vec3d pos;
      private final long timeMs;

      private TrailSample(Vec3d pos, long timeMs) {
         this.pos = pos;
         this.timeMs = timeMs;
      }
   }

   private static final class Spark {
      private Vec3d pos;
      private Vec3d velocity;
      private final long bornMs;
      private final long lifeMs;
      private final int color;

      private Spark(Vec3d pos, Vec3d velocity, long bornMs, long lifeMs, int color) {
         this.pos = pos;
         this.velocity = velocity;
         this.bornMs = bornMs;
         this.lifeMs = lifeMs;
         this.color = color;
      }
   }

   private static final class Ring {
      private final Vec3d center;
      private final long bornMs;

      private Ring(Vec3d center, long bornMs) {
         this.center = center;
         this.bornMs = bornMs;
      }
   }

   private static final class SmokePuff {
      private Vec3d pos;
      private Vec3d velocity;
      private final long bornMs;
      private final long lifeMs;
      private final double baseSize;
      private final float angle;
      private final int color;

      private SmokePuff(Vec3d pos, Vec3d velocity, long bornMs, long lifeMs, double baseSize, float angle, int color) {
         this.pos = pos;
         this.velocity = velocity;
         this.bornMs = bornMs;
         this.lifeMs = lifeMs;
         this.baseSize = baseSize;
         this.angle = angle;
         this.color = color;
      }
   }

   private static final class PendingTask {
      private final long timeMs;
      private final Runnable action;

      private PendingTask(long timeMs, Runnable action) {
         this.timeMs = timeMs;
         this.action = action;
      }
   }
}
