package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector4i;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.TextureParticleHandler;
import winvi.noxiumvisuals.modules.visuals.HitBubbleParticle;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.ui.hud.DraggableHudElement;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
import winvi.noxiumvisuals.utils.render.SdfRingRenderer;
import winvi.noxiumvisuals.utils.render.UiRenderUtils;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
public class HitBubblesModule extends Module {
      private static final int ehxb = 12;
      private final ChoiceSetting ehyx;
      private final ChoiceSetting removeField9;
      private final NumberSetting a12;
      private final NumberSetting getField24;
      private final NumberSetting parseField63;
      private final SettingGroup kgttl;
      private static final List<HitBubbleParticle> klgfg = new ArrayList<>();
      private static long if0 = 0L;
      private static long whybh = System.currentTimeMillis();

      public static HitBubblesModule getInstance() {
      return ModuleLookup.get(HitBubblesModule.class);
   }

   public HitBubblesModule() {
      super("Hit Bubbles", ModuleCategory.VISUAL);
      this.ehyx = new ChoiceSetting(
            "Style",
            "Style"
         )
         .value(ParticleTextures.getAvailableHitBubbleStyleNames())
         .selected("SHOCKWAVE");
      this.ehyx.withTranslation("hitbubbles.style", "hitbubbles.style.desc");
      this.a12 = new NumberSetting(
            "Life Time",
            "Bubble lifetime in seconds"
         )
         .setValue(1F)
         .range(0.5F, 5.0F);
      this.a12.withTranslation("hitbubbles.lifetime", "hitbubbles.lifetime.desc");
      this.removeField9 = new ChoiceSetting(
            "Animation",
            "Animation preset"
         )
         .value(
            "Smooth",
            "Bounce",
            "Elastic",
            "Pop"
         )
         .selected("Bounce");
      this.removeField9.withTranslation("hitbubbles.animation", "hitbubbles.animation.desc");
      this.getField24 = new NumberSetting(
            "Scale",
            "Scale"
         )
         .setValue(50.0F)
         .range(10.0F, 50.0F);
      this.getField24.withTranslation("hitbubbles.scale", "hitbubbles.scale.desc");
      this.parseField63 = new NumberSetting(
            "Speed",
            "Animation speed"
         )
         .setValue(1F)
         .range(0.1F, 3.0F);
      this.parseField63.withTranslation("hitbubbles.speed", "hitbubbles.speed.desc");
      this.kgttl = new SettingGroup(
            "Visual Settings",
            "Visual settings for hit bubbles"
         )
         .settings(this.ehyx, this.removeField9, this.a12, this.getField24, this.parseField63)
         .setValue(true);
      this.kgttl.withTranslation("hitbubbles.visualsettings", "hitbubbles.visualsettings.desc");
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{this.kgttl});
   }

      @Override
   public void deactivate() {
      super.deactivate();
      klgfg.clear();
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState()) {
         long timestamp = System.currentTimeMillis();
         float value = Math.min((float)(timestamp - whybh) / 1000.0F, 0.1F);
         whybh = timestamp;

         for (HitBubbleParticle moduleSupport5 : klgfg) {
            moduleSupport5.life += value;
         }

         this.render(event.getStack(), event.getPartialTicks());
      }
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         float value = this.a12.getValue();

         for (int index = klgfg.size() - 1; index >= 0; index--) {
            HitBubbleParticle moduleSupport5 = klgfg.get(index);
            if (moduleSupport5.life > value) {
               klgfg.remove(index);
            } else {
               matrixStack.push();
               matrixStack.translate(moduleSupport5.x, moduleSupport5.y, moduleSupport5.z);
               matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(moduleSupport5.yaw));
               matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(moduleSupport5.pitch));
               float value2 = -moduleSupport5.life * 60.0F * this.parseField63.getValue();
               float value3 = moduleSupport5.life / value;
               this.cdxjnu(matrixStack, value2, value3);
               matrixStack.pop();
            }
         }
      }
   }

      private void cdxjnu(MatrixStack matrices, float angle, float factor) {
      float value = 0.25F;
      float value2 = 0.5F;
      float value3 = 0.25F;
      float value4 = 1F;
      float value5 = 1F;
      if (factor < value) {
         float value6 = factor / value;
         value6 = (float)Math.pow(value6, 0.7);
         value5 = this.jxfqga(value6);
         value4 = value6;
      } else if (factor < value + value2) {
         value5 = 1F;
         value4 = 1F;
      } else {
         float value7 = (factor - value - value2) / value3;
         value7 = (float)Math.pow(value7, 1.3);
         float value8 = 1F - value7;
         value5 = 0.7F + value8 * 0.3F;
         value4 = value8;
      }

      matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(angle));
      float value9 = Math.min(50.0F, Math.max(10.0F, this.getField24.getValue()));
      float value10 = 2.0F * (value9 / 100.0F);
      float value11 = value10 * value5;
      Entry entry = matrices.peek().copy();
      float value12 = DraggableHudElement.getGlobalGlowAnimationProgress();
      Color color = new Color(this.getVisualColor(), true);
      Color color2;
      Color color3;
      Color color4;
      Color color5;
      if (value12 < 0.25F) {
         float value13 = value12 / 0.25F;
         color2 = cvlp(color, color, value13);
         color3 = cvlp(color, color, value13);
         color4 = cvlp(color, color, value13);
         color5 = cvlp(color, color, value13);
      } else if (value12 < 0.5F) {
         float value14 = (value12 - 0.25F) / 0.25F;
         color2 = cvlp(color, color, value14);
         color3 = cvlp(color, color, value14);
         color4 = cvlp(color, color, value14);
         color5 = cvlp(color, color, value14);
      } else if (value12 < 0.75F) {
         float value15 = (value12 - 0.5F) / 0.25F;
         color2 = cvlp(color, color, value15);
         color3 = cvlp(color, color, value15);
         color4 = cvlp(color, color, value15);
         color5 = cvlp(color, color, value15);
      } else {
         float value16 = (value12 - 0.75F) / 0.25F;
         color2 = cvlp(color, color, value16);
         color3 = cvlp(color, color, value16);
         color4 = cvlp(color, color, value16);
         color5 = cvlp(color, color, value16);
      }

      value4 = Math.max(0F, Math.min(1F, value4));
      int color6 = UiRenderUtils.applyOpacity(color2, value4).getRGB();
      int color7 = UiRenderUtils.applyOpacity(color3, value4).getRGB();
      int color8 = UiRenderUtils.applyOpacity(color4, value4).getRGB();
      int color9 = UiRenderUtils.applyOpacity(color5, value4).getRGB();
      if (this.initMethod310()) {
         float value17 = value11 * 0.5F;
         SdfRingRenderer.draw(matrices, value17, Math.max(0.025F, value17 * 0.12F), color6, color7, color8, color9);
      } else {
         Identifier identifier = ParticleTextures.getJumpCircleTexture(this.ehyx.getSelected());
         Vector4i vector4i = new Vector4i(color6, color7, color8, color9);
         WorldShapeRenderer.drawTexture(entry, identifier, -value11 / 2.0F, -value11 / 2.0F, value11, value11, vector4i, true, true);
      }
   }

      private boolean initMethod310() {
      return this.ehyx != null && this.ehyx.isSelected("SHOCKWAVE");
   }

      private static Color cvlp(Color start, Color end, float t) {
      int index = (int)(start.getRed() + t * (end.getRed() - start.getRed()));
      int index2 = (int)(start.getGreen() + t * (end.getGreen() - start.getGreen()));
      int index3 = (int)(start.getBlue() + t * (end.getBlue() - start.getBlue()));
      return new Color(index, index2, index3);
   }

      public static void onHit(LivingEntity target) {
      if (MinecraftClient.getInstance().player != null && EntityVisibilityFilter.shouldRender(target)) {
         HitBubblesModule hitBubblesModule = getInstance();
         if (hitBubblesModule != null && hitBubblesModule.isState()) {
            long timestamp = System.currentTimeMillis();
            if (timestamp - if0 >= 150L) {
               if0 = timestamp;
               float client = MinecraftClient.getInstance().player.getYaw();
               float client2 = MinecraftClient.getInstance().player.getPitch();
               double value = 5.0;
               Vec3d position = vm(client, client2, value);
               if (position != null) {
                  while (klgfg.size() >= 12) {
                     klgfg.removeFirst();
                  }

                  klgfg.add(new HitBubbleParticle((float)position.x, (float)position.y, (float)position.z, -client, client2, 0F));
               }
            }
         }
      }
   }

      private static Vec3d vm(float yaw, float pitch, double distance) {
      Vec3d height = MinecraftClient.getInstance()
         .player
         .getPos()
         .add(0, MinecraftClient.getInstance().player.getEyeHeight(MinecraftClient.getInstance().player.getPose()), 0);
      Vec3d position = initMethod73(pitch, yaw);
      Vec3d position2 = height.add(position.multiply(distance));
      double value = distance * distance;
      Box client = MinecraftClient.getInstance().player.getBoundingBox().stretch(position.multiply(distance)).expand(1, 1, 1);
      EntityHitResult client2 = ProjectileUtil.raycast(MinecraftClient.getInstance().player, height, position2, client, entity -> {
         if (entity.isSpectator() || !EntityVisibilityFilter.shouldRender(entity)) {
            return false;
         } else {
            return entity instanceof TextureParticleHandler ? true : entity.canHit();
         }
      }, value);
      return client2 != null && client2.getEntity() instanceof LivingEntity livingEntity && EntityVisibilityFilter.shouldRender(livingEntity) ? client2.getPos() : null;
   }

      private static Vec3d initMethod73(float pitch, float yaw) {
      float value = (float)Math.cos(-yaw * 0.017453292F - 3.141592653589793);
      float value2 = (float)Math.sin(-yaw * 0.017453292F - 3.141592653589793);
      float value3 = (float)(-Math.cos(-pitch * 0.017453292F));
      float value4 = (float)Math.sin(-pitch * 0.017453292F);
      return new Vec3d(value2 * value3, value4, value * value3);
   }

      private float jxfqga(float progress) {
      String text = this.removeField9.getSelected();

      return switch (text) {
         case "Bounce" -> {
            float value = 7.5625F;
            float value2 = 2.75F;
            if (progress < 1F / value2) {
               yield value * progress * progress;
            } else if (progress < 2.0F / value2) {
               float value3 = progress - 1.5F / value2;
               yield value * value3 * value3 + 0.75F;
            } else if (progress < 2.5F / value2) {
               float value4 = progress - 2.25F / value2;
               yield value * value4 * value4 + 0.9375F;
            } else {
               float value5 = progress - 2.625F / value2;
               yield value * value5 * value5 + 0.984375F;
            }
         }
         case "Elastic" -> {
            if (progress != 0F && progress != 1F) {
               float value6 = 2.0943952F;
               yield (float)(Math.pow(2.0, -10.0F * progress) * Math.sin((progress * 10.0F - 0.75) * value6) + 1);
            } else {
               yield progress;
            }
         }
         case "Pop" -> progress < 0.5F
            ? (float)(Math.pow(2.0, 20.0F * progress - 10.0F) * Math.sin((20.0F * progress - 11.125) * 3.141592653589793 / 4.5))
            : (float)(1 - Math.pow(2.0, -20.0F * progress + 10.0F) * Math.sin((20.0F * progress - 11.125) * 3.141592653589793 / 4.5));
         default -> progress;
      };
   }

   static {
      int index = 0;
   }
}
