package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class ChinaHatModule extends Module {
      public final NumberSetting alpha;
      public final NumberSetting height;
      public final NumberSetting tipHeight;
      public final NumberSetting baseRadius;
      public final BooleanSetting advancedSettings;
      public final BooleanSetting onlyFriends;
      public final BooleanSetting useShader;
      public final ChoiceSetting shaderType;
      public final NumberSetting shaderSpeed;
      public final NumberSetting shaderScale;

   public ChinaHatModule() {
      super("China Hat", ModuleCategory.VISUAL);
      this.alpha = new NumberSetting(
            "Alpha",
            "Transparency"
         )
         .setValue(70.0F)
         .range(10.0F, 100.0F);
      this.alpha.withTranslation("chinahat.alpha", "chinahat.alpha.desc");
      this.height = new NumberSetting(
            "Height",
            "Y position offset"
         )
         .setValue(40.0F)
         .range(0F, 100.0F);
      this.height.withTranslation("chinahat.height", "chinahat.height.desc");
      this.onlyFriends = new BooleanSetting(
            "Only Friends",
            "Show china hat on yourself and friends"
         )
         .setValue(false);
      this.onlyFriends.withTranslation("chinahat.onlyfriends", "chinahat.onlyfriends.desc");
      this.useShader = new BooleanSetting(
            "Use Shader",
            "Use shader effect"
         )
         .setValue(false);
      this.useShader.withTranslation("chinahat.useshader", "chinahat.useshader.desc");
      this.shaderType = new ChoiceSetting(
            "Shader Type",
            "Shader effect type"
         )
         .value(
            "Wave",
            "Plasma",
            "Fractal",
            "Tunnel",
            "Particles"
         )
         .visible(() -> {
            return this.useShader.isValue();
         });
      this.shaderType.withTranslation("chinahat.shadertype", "chinahat.shadertype.desc");
      this.shaderSpeed = new NumberSetting(
            "Shader Speed",
            "Shader animation speed"
         )
         .setValue(1F)
         .range(0.1F, 5.0F)
         .visible(() -> {
            return this.useShader.isValue();
         });
      this.shaderSpeed.withTranslation("chinahat.shaderspeed", "chinahat.shaderspeed.desc");
      this.shaderScale = new NumberSetting(
            "Shader Scale",
            "Shader pattern scale"
         )
         .setValue(1F)
         .range(0.1F, 10.0F)
         .visible(() -> {
            return this.useShader.isValue();
         });
      this.shaderScale.withTranslation("chinahat.shaderscale", "chinahat.shaderscale.desc");
      this.advancedSettings = new BooleanSetting(
            "Advanced Settings",
            "Show advanced settings"
         )
         .setValue(false);
      this.advancedSettings.withTranslation("chinahat.advancedsettings", "chinahat.advancedsettings.desc");
      this.tipHeight = new NumberSetting(
            "Tip Height",
            "Height of the tip"
         )
         .setValue(26.0F)
         .range(10.0F, 100.0F);
      this.tipHeight.withTranslation("chinahat.tipheight", "chinahat.tipheight.desc");
      this.tipHeight.setVisible(() -> {
         return this.advancedSettings.isValue();
      });
      this.baseRadius = new NumberSetting(
            "Base Radius",
            "Radius of the base"
         )
         .setValue(51.0F)
         .range(10.0F, 100.0F);
      this.baseRadius.withTranslation("chinahat.baseradius", "chinahat.baseradius.desc");
      this.baseRadius.setVisible(() -> {
         return this.advancedSettings.isValue();
      });
      this.showVisualColorSettings();
      this.setup(
         new ModuleSetting[]{
            this.alpha,
            this.height,
            this.onlyFriends,
            this.useShader,
            this.shaderType,
            this.shaderSpeed,
            this.shaderScale,
            this.advancedSettings,
            this.tipHeight,
            this.baseRadius
         }
      );
   }

}
