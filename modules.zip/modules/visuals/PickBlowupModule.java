package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.ItemEntity;
import net.minecraft.network.packet.s2c.play.ItemPickupAnimationS2CPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.PickFragment;
import winvi.noxiumvisuals.modules.visuals.ColorModuleSupport;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.PacketEventProvider;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.systems.events.EventDirection;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
public final class PickBlowupModule extends Module {
      public static final long wxlzh = 1650L;
      public static final int shayw = 48;
      public static final int destroyField64 = 48;
      public static final int executeField57 = 28;
      public final List<ColorModuleSupport> entd;
      public final Random nu0;

   public PickBlowupModule() {
      super(
         "PickBlowup",
         "Pickup energy burst",
         ModuleCategory.VISUAL
      );
      this.entd = new ArrayList<>();
      this.nu0 = new Random(123947126L);
      this.showVisualColorSettings();
   }

      @Override
   public void deactivate() {
      this.entd.clear();
      super.deactivate();
   }

   @EventHandler
      public void onPacket(PacketEventProvider event) {
      if (this.isState()
         && event.getType() == EventDirection.RECEIVE
         && MinecraftClient.getInstance().player != null
         && MinecraftClient.getInstance().world != null) {
         if (event.getPacket() instanceof ItemPickupAnimationS2CPacket itemPickupAnimationS2CPacket
            && itemPickupAnimationS2CPacket.getCollectorEntityId() == MinecraftClient.getInstance().player.getId()
            && MinecraftClient.getInstance().world.getEntityById(itemPickupAnimationS2CPacket.getEntityId()) instanceof ItemEntity itemEntity
            && !itemEntity.getStack().isEmpty()) {
            this.entd.add(new ColorModuleSupport(this, itemEntity.getPos().add(0, 0.01, 0), System.currentTimeMillis(), this.sdinxh()));
         }
      }
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      long timestamp = System.currentTimeMillis();
      this.entd.removeIf(effect -> {
         return timestamp - effect.dgsgb >= 1650L;
      });
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState() && !this.entd.isEmpty()) {
         long timestamp = System.currentTimeMillis();
         Iterator iterator2 = this.entd.iterator();

         while (iterator2.hasNext()) {
            ColorModuleSupport colorModuleSupport = (ColorModuleSupport)iterator2.next();
            float value = MathHelper.clamp((float)(timestamp - colorModuleSupport.dgsgb) / 1650.0F, 0F, 1F);
            if (value >= 1F) {
               iterator2.remove();
            } else {
               this.olqifi(colorModuleSupport, value);
            }
         }
      }
   }

      @Override
   public boolean hasWorldRenderWork() {
      return this.isState() && !this.entd.isEmpty();
   }

      public void olqifi(ColorModuleSupport effect, float progress) {
      float value = this.ccqlow(Math.min(1F, progress * 8.0F));
      float value2 = 1F - this.ccqlow(progress);
      float value3 = value * value2;
      float value4 = this.stopMethod97(progress);
      float value5 = MathHelper.lerp(value4, 0.07F, 0.68F);
      Vec3d position = effect.bdvaa.add(0, 0.025 + Math.sin(progress * 3.141592653589793) * 0.11, 0);
      this.czac(position, value5 * 1.08F, effect.stopField12, value3 * 0.16F, 5.5F);
      this.czac(position, value5, effect.stopField12, value3 * 0.88F, 1.75F);
      this.czac(position.add(0, 0.035, 0), value5 * 0.78F, ColorUtils.overCol(effect.stopField12, -1, 0.62F), value3 * 0.72F, 1.15F);
      this.cyw(effect, progress, value3);

      for (PickFragment moduleRange7 : effect.manageField750) {
         float value6 = MathHelper.clamp((progress - moduleRange7.delay()) / (1F - moduleRange7.delay()), 0F, 1F);
         if (!(value6 <= 0F) && !(value6 >= 1F)) {
            float value7 = (1F - this.ccqlow(value6)) * value3;
            Vec3d position2 = this.initMethod77(effect.bdvaa, moduleRange7, value6);
            Vec3d position3 = this.initMethod77(effect.bdvaa, moduleRange7, Math.max(0F, value6 - 0.075F));
            int index = ColorUtils.overCol(effect.stopField12, -1, moduleRange7.whiteMix());
            WorldShapeRenderer.drawLine(position3, position2, ColorUtils.multAlpha(index, value7 * 0.2F), 4.0F, true);
            WorldShapeRenderer.drawLine(position3, position2, ColorUtils.multAlpha(index, value7), 1.25F, true);
         }
      }
   }

      public void cyw(ColorModuleSupport effect, float progress, float alpha) {
      float value = progress * 3.1415927F * 3.4F;

      for (int index = 0; index < 3; index++) {
         Vec3d position = null;

         for (int index2 = 0; index2 <= 28; index2++) {
            float value2 = index2 / 28.0F;
            float value3 = (float)Math.sin(value2 * 3.141592653589793);
            float value4 = MathHelper.lerp(value2, 0.31F, 0.035F) * (0.88F + 0.12F * (float)Math.sin(value2 * 3.141592653589793 * 4.0 + value));
            double value5 = value + index * 3.141592653589793 * 2.0 / 3.0 + value2 * 3.141592653589793 * 3.25;
            Vec3d position2 = effect.bdvaa.add(Math.sin(value5) * value4, 0.04 + value2 * 1.08, Math.cos(value5) * value4);
            if (position != null) {
               int index3 = ColorUtils.overCol(effect.stopField12, -1, value2 * 0.72F);
               float value6 = alpha * value3;
               WorldShapeRenderer.drawLine(position, position2, ColorUtils.multAlpha(index3, value6 * 0.14F), 5.0F, true);
               WorldShapeRenderer.drawLine(position, position2, ColorUtils.multAlpha(index3, value6 * 0.82F), 1.35F, true);
            }

            position = position2;
         }
      }
   }

      public Vec3d initMethod77(Vec3d origin, PickFragment spark, float progress) {
      double value = spark.angle() + spark.turn() * progress;
      double value2 = MathHelper.lerp(progress, spark.startRadius(), spark.endRadius());
      double value3 = spark.lift() * this.stopMethod97(progress) + Math.sin(progress * 3.141592653589793) * 0.08;
      return origin.add(Math.sin(value) * value2, value3, Math.cos(value) * value2);
   }

      public float ccqlow(float value) {
      value = MathHelper.clamp(value, 0F, 1F);
      return value * value * (3.0F - 2.0F * value);
   }

      public float stopMethod97(float value) {
      value = MathHelper.clamp(value, 0F, 1F);
      float value2 = 1F - value;
      return 1F - value2 * value2 * value2;
   }

      public void czac(Vec3d origin, float radius, int color, float alpha, float width) {
      Vec3d position = null;
      int index = ColorUtils.multAlpha(color, alpha);

      for (int index2 = 0; index2 <= 48; index2++) {
         double value = 6.283185307179586 * index2 / 48.0;
         Vec3d position2 = origin.add(Math.sin(value) * radius, 0, Math.cos(value) * radius);
         if (position != null) {
            WorldShapeRenderer.drawLine(position, position2, index, width, true);
         }

         position = position2;
      }
   }

      public int sdinxh() {
      return this.getVisualColor();
   }

}
