package winvi.noxiumvisuals.modules.visuals;

public record VoxelSpan(
   int fixed,
   int start,
   int end
) {

      public int fixed() {
      return this.fixed;
   }

      public int start() {
      return this.start;
   }

      public int end() {
      return this.end;
   }

}
