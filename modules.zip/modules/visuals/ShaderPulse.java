package winvi.noxiumvisuals.modules.visuals;

public record ShaderPulse(
   long startedAt
) {

      public long startedAt() {
      return this.startedAt;
   }

}
