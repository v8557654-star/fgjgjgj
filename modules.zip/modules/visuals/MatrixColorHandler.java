package winvi.noxiumvisuals.modules.visuals;

import org.joml.Matrix4f;
public final class MatrixColorHandler {
      public final Matrix4f gmy;
      public final int gmzt;
      public final float handleField0;

   public MatrixColorHandler(Matrix4f matrix, int color, float scale) {
      this.gmy = matrix;
      this.gmzt = color;
      this.handleField0 = scale;
   }

}
