package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.StableTagEntry;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.network.OnlinePlayer;
import winvi.noxiumvisuals.utils.network.OnlinePresenceClient;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
import winvi.noxiumvisuals.utils.render.WorldTextRenderer;
public class StableTagModule extends Module {
      private static final long pt0 = 1000L;
      private final NumberSetting deleteField36;
      private final NumberSetting runField65;
      private final NumberSetting w21;
      private final BooleanSetting knneg;
      private final Map<UUID, StableTagEntry> controlField87;
      private final List<PlayerEntity> zruvm;

   public StableTagModule() {
      super("StableTag", ModuleCategory.VISUAL);
      this.deleteField36 = new NumberSetting(
            "Size",
            "World-space scale of player tags"
         )
         .range(0.5F, 1.5F)
         .setValue(1F);
      this.runField65 = new NumberSetting(
            "Opacity",
            "Tag background opacity"
         )
         .range(0.2F, 1F)
         .setValue(0.92F);
      this.w21 = new NumberSetting(
            "Distance",
            "Maximum tag render distance"
         )
         .range(16, 128)
         .setValue(64.0F);
      this.knneg = new BooleanSetting(
            "Self",
            "Show your tag in third person"
         )
         .setValue(false);
      this.controlField87 = new HashMap<>();
      this.zruvm = new ArrayList<>();
      this.setup(new ModuleSetting[]{this.deleteField36, this.runField65, this.w21, this.knneg});
   }

      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         double value = this.w21.getValue() * this.w21.getValue();
         this.zruvm.clear();

         for (PlayerEntity player2 : MinecraftClient.getInstance().world.getPlayers()) {
            if (this.itbfdw(player2, value)) {
               this.zruvm.add(player2);
            }
         }

         this.zruvm.sort(Comparator.<PlayerEntity>comparingDouble(player -> {
            return MinecraftClient.getInstance().player.squaredDistanceTo(player);
         }).reversed());
         float value2 = event.getPartialTicks();
         GlobalsModule globalsModule = NoxiumVisuals.getInstance().getModuleProvider().get(GlobalsModule.class);
         OnlinePresenceClient playerTextFactory = OnlinePresenceClient.getInstance();
         boolean enabled = globalsModule != null && globalsModule.shouldShowAvatar() && playerTextFactory.isConnected();

         for (PlayerEntity player3 : this.zruvm) {
            Vec3d height = player3.getLerpedPos(value2).add(0, player3.getHeight() + 0.48, 0);
            String text = null;
            String text2 = null;
            if (enabled && player3.getGameProfile() != null) {
               String name = player3.getGameProfile().getName();
               OnlinePlayer player4 = playerTextFactory.getPlayerByNickname(name);
               if (player4 != null) {
                  text = name;
                  text2 = player4.role();
               }
            }

            WorldTextRenderer.renderSimple(
               event, height, this.setMethod301(player3), 0.0105F * this.deleteField36.getValue(), this.runField65.getValue(), 0, text, text2
            );
         }

         long timestamp = System.currentTimeMillis() - 2000L;
         this.controlField87.entrySet().removeIf(entry -> {
            return entry.getValue().capturedAt() < timestamp;
         });
      }
   }

      private boolean itbfdw(PlayerEntity player, double maxDistanceSquared) {
      if (player == null || !player.isAlive() || player.isSpectator() || !EntityVisibilityFilter.shouldRender(player)) {
         return false;
      } else if (player == MinecraftClient.getInstance().player) {
         return this.knneg.isValue() && !MinecraftClient.getInstance().options.getPerspective().isFirstPerson();
      } else {
         return MinecraftClient.getInstance().player.squaredDistanceTo(player) > maxDistanceSquared
            ? false
            : MinecraftClient.getInstance().worldRenderer.frustum == null
               || MinecraftClient.getInstance().worldRenderer.frustum.isVisible(player.getBoundingBox().expand(0.5, 1, 0.5));
      }
   }

      public void captureLabel(UUID playerUuid, Text label) {
      if (playerUuid != null && label != null) {
         if (!label.getString().isBlank()) {
            this.controlField87.put(playerUuid, new StableTagEntry(label.copy(), System.currentTimeMillis()));
         }
      }
   }

      @Override
   public void deactivate() {
      this.controlField87.clear();
   }

      private Text setMethod301(PlayerEntity player) {
      StableTagEntry textModuleData3 = this.controlField87.get(player.getUuid());
      if (textModuleData3 != null && System.currentTimeMillis() - textModuleData3.capturedAt() <= 1000L) {
         return textModuleData3.text();
      } else {
         Text textComponent = player.getDisplayName();
         return textComponent.getString().isBlank() ? player.getName() : textComponent;
      }
   }

}
