package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.text.MutableText;
public record ContainerNotification(
   ModuleType type,
   MutableText text
) {

      public ModuleType type() {
      return this.type;
   }

      public MutableText text() {
      return this.text;
   }

   static {
      int index = 0;
   }
}
