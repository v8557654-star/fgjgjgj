package winvi.noxiumvisuals.modules.visuals;

import java.util.Random;
public final class ModuleTransformer {
      public long parseField76;
      public long hw0;
      public long wvwjq;
      public boolean formatField91;

   public ModuleTransformer() {
   }

      void reset(long firstFlipAt) {
      this.parseField76 = firstFlipAt;
      this.hw0 = 0L;
      this.wvwjq = 0L;
      this.formatField91 = false;
   }

      float sample(long now, Random random) {
      if (!this.formatField91 && now >= this.parseField76) {
         this.formatField91 = true;
         this.hw0 = now;
         this.wvwjq = 420L + random.nextInt(180);
      }

      if (!this.formatField91) {
         return 0F;
      } else {
         float value = (float)(now - this.hw0) / (float)this.wvwjq;
         if (value >= 1F) {
            this.formatField91 = false;
            this.parseField76 = now + 1600L + random.nextInt(550);
            return 0F;
         } else {
            return ShaderVertexRenderer.transformMethod10(value);
         }
      }
   }

}
