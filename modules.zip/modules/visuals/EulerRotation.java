package winvi.noxiumvisuals.modules.visuals;

public record EulerRotation(
   float yaw,
   float pitch,
   float roll
) {

      public float yaw() {
      return this.yaw;
   }

      public float pitch() {
      return this.pitch;
   }

      public float roll() {
      return this.roll;
   }

}
