package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.Vec3d;
public final class TorusPulse {
      public final Vec3d gjds;
      public final float je;
      public final float naxat;
      public final long g30;
      public final float msyif;
      public final float i28;

   public TorusPulse(Vec3d position, float yaw, float pitch, float lifeTime, float scale) {
      this.gjds = position;
      this.je = yaw;
      this.naxat = pitch;
      this.msyif = lifeTime;
      this.i28 = scale;
      this.g30 = System.currentTimeMillis();
   }

      public boolean g31(long now) {
      return (float)(now - this.g30) >= this.msyif;
   }

      public float sicozm(long now) {
      return Math.min(1F, Math.max(0F, (float)(now - this.g30) / this.msyif));
   }

      public float executeMethod990(float progress) {
      float value = 1F - (float)Math.pow(1F - progress, 3.0);
      return this.i28 * (0.6F + 2.0F * value);
   }

      public float deleteMethod380(float progress) {
      return this.i28 * 0.4F * (1F - progress * progress * progress);
   }

}
