package winvi.noxiumvisuals.modules.visuals;

public record PredictionBox(
   float x,
   float y,
   float z,
   float width,
   float height,
   float depth
) {

      public float x() {
      return this.x;
   }

      public float y() {
      return this.y;
   }

      public float z() {
      return this.z;
   }

      public float width() {
      return this.width;
   }

      public float height() {
      return this.height;
   }

      public float depth() {
      return this.depth;
   }

   static {
      int index = 0;
   }
}
