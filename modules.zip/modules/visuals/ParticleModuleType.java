package winvi.noxiumvisuals.modules.visuals;

public enum ParticleModuleType {
      PARTICLE,
      CUBE,
      WISP;

}
