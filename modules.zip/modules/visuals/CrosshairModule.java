package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.utils.render.RoundedRectBatcher;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
import winvi.noxiumvisuals.utils.render.UiRenderUtils;
public final class CrosshairModule extends Module {
      private final ChoiceSetting deleteField62;
      private final NumberSetting exekd;
      private final BooleanSetting prgrm;
      private final ChoiceSetting ecve;
      private final ColorSetting parseField190;
      private final BooleanSetting omscn;
      private final NumberSetting handleField450;
      private final BooleanSetting eczp;
      private final ChoiceSetting transformField940;
      private final ColorSetting db1;
      private final NumberSetting computeField0;
      private final NumberSetting hppmq;
      private final BooleanSetting getField31;
      private final NumberSetting edf;
      private final NumberSetting createField75;
      private final BooleanSetting manageField67;
      private final NumberSetting epckd;
      private final BooleanSetting j20;
      private final ChoiceSetting ypjve;
      private final NumberSetting edl;
      private final NumberSetting edmj;
      private final NumberSetting getField66;
      private final NumberSetting vdmer;
      private final NumberSetting dp0;
      private final NumberSetting convertField350;
      private final NumberSetting deleteField72;
      private final NumberSetting edsf;
      private final NumberSetting xsgkb;
      private float ffudi;
      private int isField86;
      private long edwb;

   public CrosshairModule() {
      super(
         "Crosshair",
         "Custom crosshair",
         ModuleCategory.VISUAL
      );
      this.deleteField62 = new ChoiceSetting(
            "Mode",
            "Crosshair style"
         )
         .value(
            "Custom",
            "Circle"
         )
         .selected("Custom");
      this.exekd = new NumberSetting(
            "Opacity",
            "Crosshair opacity"
         )
         .setValue(1F)
         .range(0.1F, 1F);
      this.prgrm = new BooleanSetting(
            "Target Highlight",
            "Change color while aiming at a living target"
         )
         .setValue(true);
      this.ecve = new ChoiceSetting(
            "Target Color Source",
            "Color used while aiming at a target"
         )
         .value(
            "Visual Color",
            "Custom"
         )
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .selected("Custom")
         .visible(this.prgrm::isValue);
      this.parseField190 = new ColorSetting(
            "Target Color",
            "Custom color used while aiming at a target"
         )
         .setColor(-46261)
         .presets(-46261, -34235, -11930, -1)
         .visible(() -> {
            return this.prgrm.isValue() && this.ecve.isSelected("Custom");
         });
      this.omscn = new BooleanSetting(
            "Smooth Target Color",
            "Smoothly blend the target color"
         )
         .setValue(true)
         .visible(this.prgrm::isValue);
      this.handleField450 = new NumberSetting(
            "Color Speed",
            "Target color transition speed"
         )
         .setValue(18.0F)
         .range(2.0F, 40.0F)
         .visible(() -> {
            return this.prgrm.isValue() && this.omscn.isValue();
         });
      this.eczp = new BooleanSetting(
            "Outline",
            "Draw a crosshair outline"
         )
         .setValue(true);
      this.transformField940 = new ChoiceSetting(
            "Outline Color Source",
            "Crosshair outline color source"
         )
         .value(
            "Visual Color",
            "Custom"
         )
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .selected("Custom")
         .visible(this.eczp::isValue);
      this.db1 = new ColorSetting(
            "Outline Color",
            "Custom crosshair outline color"
         )
         .setColor(-16777216)
         .presets(-16777216, -1, -14670804, -9659651)
         .visible(() -> {
            return this.eczp.isValue() && this.transformField940.isSelected("Custom");
         });
      this.computeField0 = new NumberSetting(
            "Outline Opacity",
            "Outline opacity"
         )
         .setValue(0.85F)
         .range(0.05F, 1F)
         .visible(() -> {
            return this.eczp.isValue() && this.wvxwgg();
         });
      this.hppmq = new NumberSetting(
            "Outline Width",
            "Custom crosshair outline width"
         )
         .setValue(0.5F)
         .range(0.25F, 2.5F)
         .visible(() -> {
            return this.eczp.isValue() && this.wvxwgg();
         });
      this.getField31 = new BooleanSetting(
            "Hit Animation",
            "Animate the crosshair while swinging"
         )
         .setValue(true);
      this.edf = new NumberSetting(
            "Animation Strength",
            "Swing animation distance"
         )
         .setValue(1F)
         .range(0.1F, 2.5F)
         .visible(this.getField31::isValue);
      this.createField75 = new NumberSetting(
            "Animation Speed",
            "Swing animation smoothing speed"
         )
         .setValue(20.0F)
         .range(5.0F, 40.0F)
         .visible(this.getField31::isValue);
      this.manageField67 = new BooleanSetting(
            "Dot",
            "Render a center dot"
         )
         .setValue(true)
         .visible(this::wvxwgg);
      this.epckd = new NumberSetting(
            "Dot Size",
            "Center dot size"
         )
         .setValue(1F)
         .range(0.5F, 4.0F)
         .visible(() -> {
            return this.wvxwgg() && this.manageField67.isValue();
         });
      this.j20 = new BooleanSetting(
            "T Crosshair",
            "Hide the upper crosshair arm"
         )
         .setValue(false)
         .visible(this::wvxwgg);
      this.ypjve = new ChoiceSetting(
            "Arm Shape",
            "Square or rounded crosshair arms"
         )
         .value(
            "Square",
            "Round"
         )
         .selected("Square")
         .visible(this::wvxwgg);
      this.edl = new NumberSetting(
            "Width",
            "Horizontal arm length"
         )
         .setValue(5.0F)
         .range(0F, 15.0F)
         .visible(this::wvxwgg);
      this.edmj = new NumberSetting(
            "Height",
            "Vertical arm length"
         )
         .setValue(5.0F)
         .range(0F, 15.0F)
         .visible(this::wvxwgg);
      this.getField66 = new NumberSetting(
            "Gap",
            "Distance from the center"
         )
         .setValue(3.0F)
         .range(0F, 12.0F)
         .visible(this::wvxwgg);
      this.vdmer = new NumberSetting(
            "Thickness",
            "Crosshair arm thickness"
         )
         .setValue(1F)
         .range(0.5F, 6.0F)
         .visible(this::wvxwgg);
      this.dp0 = new NumberSetting(
            "Circle Size",
            "Circular crosshair diameter"
         )
         .setValue(7.0F)
         .range(4.0F, 20.0F)
         .visible(this::csb);
      this.convertField350 = new NumberSetting(
            "Circle Thickness",
            "Circular crosshair ring thickness"
         )
         .setValue(1.15F)
         .range(0.5F, 4.0F)
         .visible(this::csb);
      this.deleteField72 = new NumberSetting(
            "Circle Background",
            "Circular outline opacity"
         )
         .setValue(0.18F)
         .range(0F, 1F)
         .visible(() -> {
            return this.csb() && this.eczp.isValue();
         });
      this.edsf = new NumberSetting(
            "Offset X",
            "Horizontal crosshair offset"
         )
         .setValue(0F)
         .range(-10.0F, 10.0F);
      this.xsgkb = new NumberSetting(
            "Offset Y",
            "Vertical crosshair offset"
         )
         .setValue(0F)
         .range(-10.0F, 10.0F);
      this.showVisualColorSettings();
      this.csc();
      this.setup(
         new ModuleSetting[]{
            this.deleteField62,
            this.exekd,
            this.prgrm,
            this.ecve,
            this.parseField190,
            this.omscn,
            this.handleField450,
            this.eczp,
            this.transformField940,
            this.db1,
            this.computeField0,
            this.hppmq,
            this.getField31,
            this.edf,
            this.createField75,
            this.manageField67,
            this.epckd,
            this.j20,
            this.ypjve,
            this.edl,
            this.edmj,
            this.getField66,
            this.vdmer,
            this.dp0,
            this.convertField350,
            this.deleteField72,
            this.edsf,
            this.xsgkb
         }
      );
   }

      public boolean shouldReplaceVanilla() {
      return this.isState()
         && MinecraftClient.getInstance().player != null
         && MinecraftClient.getInstance().options != null
         && MinecraftClient.getInstance().options.getPerspective() == Perspective.FIRST_PERSON
         && !MinecraftClient.getInstance().options.hudHidden;
   }

      public void render(DrawContext context, float tickDelta) {
      if (this.shouldReplaceVanilla()) {
         float client = MinecraftClient.getInstance().player.getHandSwingProgress(tickDelta);
         float value = this.getField31.isValue() ? MathHelper.sin(client * client * 3.1415927F) : 0F;
         float value2 = this.stopMethod35(value);
         int index = this.checkMethod67(value2);
         float width = MinecraftClient.getInstance().getWindow().getScaledWidth() * 0.5F + this.edsf.getValue();
         float height = MinecraftClient.getInstance().getWindow().getScaledHeight() * 0.5F + this.xsgkb.getValue();
         if (this.wvxwgg()) {
            this.jldbaj(context, width, height, index);
         } else {
            this.setMethod10(context, width, height, index);
         }
      }
   }

      @Override
   public void activate() {
      this.ffudi = 0F;
      this.isField86 = this.rw0();
      this.edwb = System.nanoTime();
   }

      @Override
   public void deactivate() {
      this.ffudi = 0F;
      this.isField86 = 0;
      this.edwb = 0L;
   }

      private void jldbaj(DrawContext context, float centerX, float centerY, int color) {
      float value = this.edl.getValue();
      float value2 = this.edmj.getValue();
      float value3 = this.vdmer.getValue();
      float value4 = this.getField66.getValue() + this.ffudi * 7.0F * this.edf.getValue();
      if (this.manageField67.isValue()) {
         float value5 = this.epckd.getValue();
         this.nslsov(context, centerX - value5 * 0.5F, centerY - value5 * 0.5F, value5, value5, color, true);
      }

      if (!this.j20.isValue() && value2 > 0F) {
         this.nslsov(context, centerX - value3 * 0.5F, centerY - value4 - value2, value3, value2, color, false);
      }

      if (value2 > 0F) {
         this.nslsov(context, centerX - value3 * 0.5F, centerY + value4, value3, value2, color, false);
      }

      if (value > 0F) {
         this.nslsov(context, centerX - value4 - value, centerY - value3 * 0.5F, value, value3, color, false);
         this.nslsov(context, centerX + value4, centerY - value3 * 0.5F, value, value3, color, false);
      }
   }

      private void setMethod10(DrawContext context, float centerX, float centerY, int color) {
      float value = this.edf.getValue();
      float value2 = this.dp0.getValue() + this.ffudi * value;
      float value3 = Math.min(this.convertField350.getValue(), value2 * 0.5F);
      float value4 = centerX - value2 * 0.5F;
      float value5 = centerY - value2 * 0.5F;
      float value6 = this.getField31.isValue() ? MathHelper.clamp(1F - this.ffudi * value * 0.72F, 0.08F, 1F) : 1F;
      RoundedRectBatcher.flushRoundedRects();
      if (this.eczp.isValue() && this.deleteField72.getValue() > 0F) {
         int index = ColorUtils.multAlpha(this.crxy(), this.deleteField72.getValue());
         UiRenderUtils.drawRadialProgress(context.getMatrices(), value4, value5, value2, value3, 1F, index);
      }

      UiRenderUtils.drawRadialProgress(context.getMatrices(), value4, value5, value2, value3, value6, color);
   }

      private void nslsov(DrawContext context, float x, float y, float shapeWidth, float shapeHeight, int color, boolean forceRound) {
      boolean enabled = forceRound || this.ypjve.isSelected("Round");
      if (this.eczp.isValue()) {
         float value = this.hppmq.getValue();
         int index = ColorUtils.multAlpha(this.crxy(), this.computeField0.getValue());
         this.initMethod27(context, x - value, y - value, shapeWidth + value * 2.0F, shapeHeight + value * 2.0F, index, enabled);
      }

      this.initMethod27(context, x, y, shapeWidth, shapeHeight, color, enabled);
   }

      private void initMethod27(DrawContext context, float x, float y, float width, float height, int color, boolean rounded) {
      if (!rounded) {
         UiRenderUtils.drawRect(context.getMatrices(), x, y, width, height, color);
      } else {
         float width2 = Math.min(width, height) * 0.5F;
         UiRenderUtils.drawRoundedRect(context.getMatrices(), x, y, width, height, width2, width2, width2, width2, color);
      }
   }

      private float stopMethod35(float target) {
      long timestamp = System.nanoTime();
      float value = this.edwb == 0L ? 0.016666668F : Math.min((float)(timestamp - this.edwb) / 1E9F, 0.05F);
      this.edwb = timestamp;
      float value2 = 1F - (float)Math.exp(-this.createField75.getValue() * value);
      this.ffudi = MathHelper.lerp(value2, this.ffudi, target);
      return value;
   }

      private int checkMethod67(float deltaSeconds) {
      int index = this.sgwfgx() && this.prgrm.isValue() ? this.resolveVisualOrCustomColor(this.ecve, this.parseField190) : this.rw0();
      index = ColorUtils.multAlpha(index, this.exekd.getValue());
      if (this.omscn.isValue() && this.prgrm.isValue()) {
         if (this.isField86 == 0) {
            this.isField86 = index;
         }

         float value = 1F - (float)Math.exp(-this.handleField450.getValue() * deltaSeconds);
         this.isField86 = this.zecevo(this.isField86, index, value);
         return this.isField86;
      } else {
         this.isField86 = index;
         return index;
      }
   }

      private int rw0() {
      return this.getVisualColor();
   }

      private int crxy() {
      return this.resolveVisualOrCustomColor(this.transformField940, this.db1);
   }

      private boolean sgwfgx() {
      return MinecraftClient.getInstance().crosshairTarget instanceof EntityHitResult entityHitResult
         && entityHitResult.getEntity() instanceof LivingEntity livingEntity
         && EntityVisibilityFilter.shouldRender(livingEntity)
         && livingEntity.isAlive();
   }

      private int zecevo(int from, int to, float progress) {
      int index = Math.round((float)MathHelper.lerp(progress, from >>> 24 & 0xFF, to >>> 24 & 0xFF));
      int index2 = Math.round((float)MathHelper.lerp(progress, from >>> 16 & 0xFF, to >>> 16 & 0xFF));
      int index3 = Math.round((float)MathHelper.lerp(progress, from >>> 8 & 0xFF, to >>> 8 & 0xFF));
      int index4 = Math.round((float)MathHelper.lerp(progress, from & 0xFF, to & 0xFF));
      return index << 24 | index2 << 16 | index3 << 8 | index4;
   }

      private boolean wvxwgg() {
      return this.deleteField62.isSelected("Custom");
   }

      private boolean csb() {
      return this.deleteField62.isSelected("Circle");
   }

      private void csc() {
      this.deleteField62.withTranslation("crosshair.mode", "crosshair.mode.desc");
      this.exekd.withTranslation("crosshair.opacity", "crosshair.opacity.desc");
      this.prgrm.withTranslation("crosshair.targethighlight", "crosshair.targethighlight.desc");
      this.ecve.withTranslation("crosshair.targetcolorsource", "crosshair.targetcolorsource.desc");
      this.parseField190.withTranslation("crosshair.targetcolor", "crosshair.targetcolor.desc");
      this.omscn.withTranslation("crosshair.smoothtarget", "crosshair.smoothtarget.desc");
      this.handleField450.withTranslation("crosshair.colorspeed", "crosshair.colorspeed.desc");
      this.eczp.withTranslation("crosshair.outline", "crosshair.outline.desc");
      this.transformField940.withTranslation("crosshair.outlinecolorsource", "crosshair.outlinecolorsource.desc");
      this.db1.withTranslation("crosshair.outlinecolor", "crosshair.outlinecolor.desc");
      this.computeField0.withTranslation("crosshair.outlineopacity", "crosshair.outlineopacity.desc");
      this.hppmq.withTranslation("crosshair.outlinewidth", "crosshair.outlinewidth.desc");
      this.getField31.withTranslation("crosshair.animation", "crosshair.animation.desc");
      this.edf.withTranslation("crosshair.animationstrength", "crosshair.animationstrength.desc");
      this.createField75.withTranslation("crosshair.animationspeed", "crosshair.animationspeed.desc");
      this.manageField67.withTranslation("crosshair.dot", "crosshair.dot.desc");
      this.epckd.withTranslation("crosshair.dotsize", "crosshair.dotsize.desc");
      this.j20.withTranslation("crosshair.tcrosshair", "crosshair.tcrosshair.desc");
      this.ypjve.withTranslation("crosshair.armshape", "crosshair.armshape.desc");
      this.edl.withTranslation("crosshair.width", "crosshair.width.desc");
      this.edmj.withTranslation("crosshair.height", "crosshair.height.desc");
      this.getField66.withTranslation("crosshair.gap", "crosshair.gap.desc");
      this.vdmer.withTranslation("crosshair.thickness", "crosshair.thickness.desc");
      this.dp0.withTranslation("crosshair.circlesize", "crosshair.circlesize.desc");
      this.convertField350.withTranslation("crosshair.circlethickness", "crosshair.circlethickness.desc");
      this.deleteField72.withTranslation("crosshair.circlebackground", "crosshair.circlebackground.desc");
      this.edsf.withTranslation("crosshair.offsetx", "crosshair.offsetx.desc");
      this.xsgkb.withTranslation("crosshair.offsety", "crosshair.offsety.desc");
   }

   static {
      int index = 0;
   }
}
