package winvi.noxiumvisuals.modules.visuals;

import java.awt.Color;
import net.minecraft.util.math.Vec3d;
public class ColorEntityManager {
      private final Vec3d ztpzv;
      public Vec3d currentPos;
      private final Color removeField940;
      public final float entityHeight;
      private final long initField41;
      private final long gb0;
      private long stopField22 = -1L;
      private float xdszv = 0F;
      private float ryryd = 1F;

   public ColorEntityManager(Vec3d from, Vec3d to, Color color, float entityHeight, long maxLifetimeMs) {
      this.ztpzv = from;
      this.currentPos = to;
      this.removeField940 = color;
      this.entityHeight = entityHeight;
      this.initField41 = System.currentTimeMillis();
      this.gb0 = maxLifetimeMs;
   }

      public Vec3d interpolate(float pt) {
      double value = this.ztpzv.x + (this.currentPos.x - this.ztpzv.x) * pt;
      double value2 = this.ztpzv.y + (this.currentPos.y - this.ztpzv.y) * pt;
      double value3 = this.ztpzv.z + (this.currentPos.z - this.ztpzv.z) * pt;
      return new Vec3d(value, value2, value3);
   }

      public Color color() {
      return this.removeField940;
   }

      private void dyu() {
      long timestamp = System.currentTimeMillis();
      if (timestamp != this.stopField22) {
         this.stopField22 = timestamp;
         long timestamp2 = timestamp - this.initField41;
         this.xdszv = Math.min(1F, (float)timestamp2 / (float)this.gb0);
         this.ryryd = 1F - this.xdszv;
      }
   }

      public float getProgress() {
      this.dyu();
      return this.xdszv;
   }

      public float getAlpha() {
      this.dyu();
      return this.ryryd;
   }

      public boolean shouldRemove(long currentTime) {
      return currentTime - this.initField41 >= this.gb0;
   }

      public float getEntityHeight() {
      return this.entityHeight;
   }

}
