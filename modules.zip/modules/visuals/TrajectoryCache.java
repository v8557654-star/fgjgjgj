package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.Vec3d;
public final class TrajectoryCache {
      public Object ip0;
      public long jlian;
      public double gir;
      public double isField78;
      public double t25;
      public float lfwvx;
      public float updateField510;
      public int knmau;
      public float gix;
      public double giy;
      public float gizi;
      public float jkstl;
      public float b27;
      public ModelModuleData validateField36;

   public TrajectoryCache() {
   }

      public boolean ouzoia(Object world, long worldTick, Vec3d eyePosition, float pitch, float yaw, int maxSteps, ItemStackModelData profile) {
      return this.validateField36 != null
         && this.ip0 == world
         && this.jlian == worldTick
         && this.gir == eyePosition.x
         && this.isField78 == eyePosition.y
         && this.t25 == eyePosition.z
         && this.lfwvx == pitch
         && this.updateField510 == yaw
         && this.knmau == maxSteps
         && this.gix == profile.speed()
         && this.giy == profile.gravity()
         && this.gizi == profile.airDrag()
         && this.jkstl == profile.waterDrag()
         && this.b27 == profile.spreadOffset();
   }

      public void smcdyz(Object world, long worldTick, Vec3d eyePosition, float pitch, float yaw, int maxSteps, ItemStackModelData profile, ModelModuleData prediction) {
      this.ip0 = world;
      this.jlian = worldTick;
      this.gir = eyePosition.x;
      this.isField78 = eyePosition.y;
      this.t25 = eyePosition.z;
      this.lfwvx = pitch;
      this.updateField510 = yaw;
      this.knmau = maxSteps;
      this.gix = profile.speed();
      this.giy = profile.gravity();
      this.gizi = profile.airDrag();
      this.jkstl = profile.waterDrag();
      this.b27 = profile.spreadOffset();
      this.validateField36 = prediction;
   }

}
