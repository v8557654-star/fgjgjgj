package winvi.noxiumvisuals.modules.visuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import winvi.noxiumvisuals.systems.config.TextureSoundRenderer;
import winvi.noxiumvisuals.utils.render.ColoredLogger;
public class ColorConfigRenderer {
      private static final int nr = 1728033607;
      private static ColorConfigRenderer runField28;
      private final Gson zgdbl = new GsonBuilder().setPrettyPrinting().create();
      private final Path dnu;

   private ColorConfigRenderer() {
      Path path = TextureSoundRenderer.DATA_DIR;

      try {
         Files.createDirectories(path);
      } catch (IOException ioexception) {
         ColoredLogger.error(
            "Failed to create item highlighter config directory", ioexception
         );
      }

      this.dnu = path.resolve("itemhighlighter.file");
      this.ckup(
         this.dnu,
         Paths.get("Noxiumvisual", "configs", "itemhighlighter.file"),
         Paths.get("noxiumvisual", "configs", "itemhighlighter.file"),
         Paths.get("winvi", "files", "itemhighlighter.file"),
         Paths.get("noxiumvisual", "files", "itemhighlighter.file")
      );
   }

      public static ColorConfigRenderer getInstance() {
      if (runField28 == null) {
         runField28 = new ColorConfigRenderer();
      }

      return runField28;
   }

      public void save() {
      try {
         JsonArray jsonArray = new JsonArray();

         for (ColorModuleProvider colorModuleProvider : ColorItemStackManager.getPresets()) {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("query", colorModuleProvider.getQuery());
            jsonObject.addProperty("color", colorModuleProvider.getColor());
            jsonArray.add(jsonObject);
         }

         Files.writeString(this.dnu, this.zgdbl.toJson(jsonArray), StandardCharsets.UTF_8);
      } catch (IOException ioexception) {
         ColoredLogger.error("ItemHighlightConfig save failed", ioexception);
      }
   }

      public void load() {
      try {
         if (!Files.exists(this.dnu)) {
            return;
         }

         String text = Files.readString(this.dnu, StandardCharsets.UTF_8);
         JsonArray jsonArray = JsonParser.parseString(text).getAsJsonArray();
         ArrayList arrayList = new ArrayList();

         for (int index = 0; index < jsonArray.size(); index++) {
            JsonElement jsonElement = jsonArray.get(index);
            if (jsonElement.isJsonObject()) {
               JsonObject jsonObject = jsonElement.getAsJsonObject();
               String text2 = jsonObject.has("query") ? jsonObject.get("query").getAsString() : "";
               int index2 = jsonObject.has("color") ? jsonObject.get("color").getAsInt() : 1728033607;
               if (!text2.isBlank()) {
                  arrayList.add(new ColorModuleProvider(text2, index2));
               }
            }
         }

         ColorItemStackManager.setPresets(arrayList);
      } catch (Exception exception) {
         ColoredLogger.error("ItemHighlightConfig load failed", exception);
      }
   }

      private void ckup(Path target, Path... legacyPaths) {
      if (!Files.exists(target)) {
         for (Path path : legacyPaths) {
            if (Files.exists(path)) {
               try {
                  Files.copy(path, target, StandardCopyOption.REPLACE_EXISTING);
                  return;
               } catch (IOException ioexception) {
                  ColoredLogger.error("Failed to migrate legacy item highlighter config from " + path, ioexception);
               }
            }
         }
      }
   }

   static {
      int index = 0;
   }
}
