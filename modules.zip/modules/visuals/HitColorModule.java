package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.AnimationModuleSupport;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.AttackEntityEvent;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.internal.OverlayReloadListener;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
public class HitColorModule extends Module {
      public final ChoiceSetting target;
      public final NumberSetting alpha;
      private final Map<LivingEntity, AnimationModuleSupport> ih1;

   public HitColorModule() {
      super("Hit Color", ModuleCategory.VISUAL);
      this.target = new ChoiceSetting(
            "Target",
            "What should be colored"
         )
         .value(
            "Armor",
            "Player",
            "Armor & Player"
         )
         .selected("Armor & Player");
      this.target.withTranslation("hitcolor.target", "hitcolor.target.desc");
      this.alpha = new NumberSetting(
            "Alpha",
            "Transparency"
         )
         .setValue(100.0F)
         .range(10.0F, 100.0F);
      this.alpha.withTranslation("hitcolor.alpha", "hitcolor.alpha.desc");
      this.ih1 = new HashMap<>();
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{this.target, this.alpha});
   }

      @Override
   public void activate() {
      super.activate();
   }

      @Override
   public void deactivate() {
      super.deactivate();
      this.ih1.clear();
      OverlayReloadListener.callEvent();
   }

   @EventHandler
      public void onAttack(AttackEntityEvent e) {
      if (this.isState()) {
         if (e.getEntity() instanceof LivingEntity livingEntity && EntityVisibilityFilter.shouldRender(livingEntity)) {
            this.ih1.put(livingEntity, new AnimationModuleSupport(System.currentTimeMillis()));
            OverlayReloadListener.callEvent();
         }
      }
   }

   @EventHandler
      public void onTick(ClientTickEvent e) {
      if (this.isState()) {
         boolean enabled = false;
         Iterator iterator2 = this.ih1.entrySet().iterator();

         while (iterator2.hasNext()) {
            Entry entry = (Entry)iterator2.next();
            LivingEntity livingEntity = (LivingEntity)entry.getKey();
            AnimationModuleSupport animationModuleSupport = (AnimationModuleSupport)entry.getValue();
            if (!livingEntity.isRemoved() && livingEntity.isAlive() && EntityVisibilityFilter.shouldRender(livingEntity)) {
               long timestamp = System.currentTimeMillis() - animationModuleSupport.hitTime;
               float value = 100.0F;
               if ((float)timestamp < value) {
                  animationModuleSupport.fadeInProgress = MathHelper.clamp((float)timestamp / value, 0F, 1F);
                  animationModuleSupport.fadeInProgress = (float)(1 - Math.pow(1 - animationModuleSupport.fadeInProgress, 3.0));
                  enabled = true;
               } else {
                  animationModuleSupport.fadeInProgress = 1F;
               }

               float value2 = 200.0F;
               float value3 = 800.0F;
               if ((float)timestamp > value2) {
                  float value4 = (float)timestamp - value2;
                  float value5 = 1F - value4 / value3;
                  animationModuleSupport.animationProgress = MathHelper.clamp(value5, 0F, 1F);
                  enabled = true;
                  if (animationModuleSupport.animationProgress <= 0F) {
                     iterator2.remove();
                  }
               } else {
                  animationModuleSupport.animationProgress = 1F;
               }
            } else {
               iterator2.remove();
               enabled = true;
            }
         }

         if (enabled) {
            OverlayReloadListener.callEvent();
         }
      }
   }

      public boolean shouldChangeColor(LivingEntity entity) {
      return !this.isState() ? false : EntityVisibilityFilter.shouldRender(entity) && this.ih1.containsKey(entity);
   }

      public boolean shouldColorArmor() {
      return this.target.isSelected("Armor")
         || this.target.isSelected("Armor & Player");
   }

      public boolean shouldColorPlayer() {
      return this.target.isSelected("Player")
         || this.target.isSelected("Armor & Player");
   }

      public float getAnimationProgress(LivingEntity entity) {
      if (this.isState() && EntityVisibilityFilter.shouldRender(entity)) {
         AnimationModuleSupport animationModuleSupport = this.ih1.get(entity);
         if (animationModuleSupport == null) {
            return 0F;
         } else {
            float value = animationModuleSupport.animationProgress;
            return value * animationModuleSupport.fadeInProgress;
         }
      } else {
         return 0F;
      }
   }

      public boolean shouldChangeColorByPosition(double x, double y, double z) {
      if (!this.isState()) {
         return false;
      } else {
         for (Entry entry : this.ih1.entrySet()) {
            LivingEntity livingEntity = (LivingEntity)entry.getKey();
            if (EntityVisibilityFilter.shouldRender(livingEntity)) {
               double x2 = Math.sqrt(
                  Math.pow(x - livingEntity.getX(), 2.0) + Math.pow(y - livingEntity.getY(), 2.0) + Math.pow(z - livingEntity.getZ(), 2.0)
               );
               if (x2 < 2.0) {
                  return true;
               }
            }
         }

         return false;
      }
   }

      public int getHitColor() {
      return this.getHitColor(1F);
   }

      public int getHitColor(float animationProgress) {
      int index = this.getVisualColor();
      float value = this.alpha.getValue() / 100.0F * animationProgress;
      int index2 = (int)(value * 255.0F) << 24;
      return index & 16777215 | index2;
   }

}
