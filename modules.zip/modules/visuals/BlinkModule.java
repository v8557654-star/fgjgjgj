package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.EntityPlayerProvider;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
public class BlinkModule extends Module {
      private static final MinecraftClient ecl = MinecraftClient.getInstance();
      private static final long ecmr = 500L;
      private static final int qnjtm = 5;
      private static BlinkModule o18;
      private final List<EntityPlayerProvider> stopField99;
      private Vec3d convertField72;
      public static ChoiceSetting style;
      public static ChoiceSetting triggerMode;
      public static BooleanSetting firstPerson = new BooleanSetting(
         "First Person",
         "Show in first person"
      )
      .setValue(true);
      public static BooleanSetting dashedOutline = new BooleanSetting(
         "Dashed Outline",
         "Use dashed outline"
      )
      .setValue(
         false
      );
      public static BooleanSetting animateDash = new BooleanSetting(
         "Animate Dash",
         "Animate dashed outline"
      )
      .setValue(
         true
      );
      public static NumberSetting myLifetime = new NumberSetting(
         "My Lifetime",
         "Lifetime for my own blink snapshots (seconds)"
      )
      .range(0.1F, 5.0F)
      .setValue(0.6F);
      private float obcru;

   public BlinkModule() {
      super(
         "Blink",
         "Visual Blink",
         ModuleCategory.VISUAL
      );
      this.stopField99 = new ArrayList<>();
      this.obcru = 0F;
      this.showVisualColorSettings();
      style.withTranslation("blink.style", "blink.style.desc");
      triggerMode.withTranslation("blink.trigger", "blink.trigger.desc");
      firstPerson.withTranslation("blink.firstperson", "blink.firstperson.desc");
      dashedOutline.withTranslation("blink.dashedoutline", "blink.dashedoutline.desc");
      animateDash.withTranslation("blink.animatedash", "blink.animatedash.desc");
      myLifetime.withTranslation("blink.mylifetime", "blink.mylifetime.desc");
      this.setup(new ModuleSetting[]{style, triggerMode, firstPerson, dashedOutline, animateDash, myLifetime});
      o18 = this;
   }

      public static BlinkModule getInstance() {
      return o18;
   }

      @Override
   public void activate() {
      super.activate();
      this.checkMethod25();
   }

      @Override
   public void deactivate() {
      super.deactivate();
      this.checkMethod25();
   }

      @Override
   public void onTick() {
      if (this.isState() && ecl.world != null && ecl.player != null) {
         long timestamp = System.currentTimeMillis();
         long timestamp2 = this.crdk();
         this.creu(this.stopField99, timestamp2, timestamp);
         ClientPlayerEntity player2 = ecl.player;
         Vec3d position = player2.getPos();
         Vec3d position2 = this.convertField72;
         this.convertField72 = position;
         if (this.removeMethod38(player2)) {
            boolean enabled = triggerMode.isSelected("Always")
               || !player2.isOnGround() && player2.getVelocity().y > 0;
            if (enabled) {
               if (position2 == null || !(position.distanceTo(position2) < 0.3)) {
                  if (!this.stopField99.isEmpty()) {
                     EntityPlayerProvider entityPlayerProvider = this.stopField99.get(this.stopField99.size() - 1);
                     if (timestamp - entityPlayerProvider.creationTime < 500L) {
                        return;
                     }
                  }

                  Vec3d position3 = position2 != null ? position2 : position;
                  this.stopField99.add(new EntityPlayerProvider(player2, timestamp, position3));
                  aqkmjw(this.stopField99, 5);
               }
            }
         }
      }
   }

      @Override
   public boolean hasWorldRenderWork() {
      return !this.stopField99.isEmpty() && (firstPerson.isValue() || !ecl.options.getPerspective().isFirstPerson());
   }

      private void checkMethod25() {
      this.stopField99.clear();
      this.convertField72 = null;
      this.obcru = 0F;
   }

      private long crdk() {
      return (long)(myLifetime.getValue() * 1000.0F);
   }

      private void creu(List<EntityPlayerProvider> snapshots, long lifetimeMs, long currentTimeMs) {
      for (int index = snapshots.size() - 1; index >= 0; index--) {
         if (((EntityPlayerProvider)snapshots.get(index)).isExpired(lifetimeMs, currentTimeMs)) {
            snapshots.remove(index);
         }
      }
   }

      private static void aqkmjw(List<EntityPlayerProvider> snapshots, int maxSnapshots) {
      int index = snapshots.size() - maxSnapshots;
      if (index > 0) {
         snapshots.subList(0, index).clear();
      }
   }

      private boolean removeMethod38(PlayerEntity player) {
      return EntityVisibilityFilter.shouldRender(player) && (firstPerson.isValue() || !ecl.options.getPerspective().isFirstPerson());
   }

      public List<EntityPlayerProvider> getAllSnapshots() {
      return new ArrayList<>(this.stopField99);
   }

      public boolean isBlinkSnapshot(OtherClientPlayerEntity entity) {
      return false;
   }

      public float getSnapshotAlpha(OtherClientPlayerEntity entity) {
      return 1F;
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState() && ecl.world != null && ecl.player != null && !this.stopField99.isEmpty()) {
         if (firstPerson.isValue() || !ecl.options.getPerspective().isFirstPerson()) {
            long timestamp = System.currentTimeMillis();
            long timestamp2 = this.crdk();
            if (animateDash.isValue()
               && dashedOutline.isValue()
               && style.isSelected("Player")) {
               this.obcru += 0.02F;
               if (this.obcru > 1F) {
                  this.obcru = 0F;
               }
            }

            MatrixStack matrices = event.getStack();
            boolean enabled = style.isSelected("Player");
            int index = this.crp();

            for (EntityPlayerProvider entityPlayerProvider : this.stopField99) {
               float value = entityPlayerProvider.getAlpha(timestamp2, timestamp);
               if (!(value <= 0F)) {
                  int index2 = index & 16777215 | (int)(value * 255.0F) << 24;
                  if (enabled) {
                     this.ri0(matrices, entityPlayerProvider, index2);
                  } else {
                     this.initMethod7(entityPlayerProvider, index2);
                  }
               }
            }
         }
      }
   }

      private void initMethod7(EntityPlayerProvider snapshot, int color) {
      Box box = new Box(
         snapshot.position.x - 0.3,
         snapshot.position.y,
         snapshot.position.z - 0.3,
         snapshot.position.x + 0.3,
         snapshot.position.y + 1.8,
         snapshot.position.z + 0.3
      );
      WorldShapeRenderer.drawBox(box, color, 1F, true, true, true);
   }

      private void ri0(MatrixStack matrices, EntityPlayerProvider snapshot, int color) {
      matrices.push();
      matrices.translate(snapshot.position.x, snapshot.position.y, snapshot.position.z);
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F - snapshot.bodyYaw));
      float value = snapshot.limbPos;
      float value2 = snapshot.limbSpeed;
      float value3 = MathHelper.cos(value * 0.6662F + 3.1415927F) * 2.0F * value2 * 0.5F;
      float value4 = MathHelper.cos(value * 0.6662F) * 2.0F * value2 * 0.5F;
      float value5 = MathHelper.cos(value * 0.6662F) * 1.4F * value2;
      float value6 = MathHelper.cos(value * 0.6662F + 3.1415927F) * 1.4F * value2;
      float value7 = -(snapshot.headYaw - snapshot.bodyYaw);
      this.k12(matrices, 0F, 1.95F, 0F, 0.5F, 0.5F, 0.5F, value7, snapshot.pitch, color);
      this.crjx(matrices, 0F, 1.45F, 0F, 0.5F, 0.7F, 0.25F, 0F, color);
      this.crjx(matrices, -0.375F, 1.45F, 0F, 0.25F, 0.7F, 0.25F, value3, color);
      this.crjx(matrices, 0.375F, 1.45F, 0F, 0.25F, 0.7F, 0.25F, value4, color);
      this.crjx(matrices, -0.125F, 0.75F, 0F, 0.25F, 0.75F, 0.25F, value5, color);
      this.crjx(matrices, 0.125F, 0.75F, 0F, 0.25F, 0.75F, 0.25F, value6, color);
      matrices.pop();
   }

      private void crjx(MatrixStack matrices, float pivotX, float pivotY, float pivotZ, float sizeX, float sizeY, float sizeZ, float pitch, int color) {
      matrices.push();
      matrices.translate(pivotX, pivotY, pivotZ);
      if (pitch != 0F) {
         matrices.multiply(RotationAxis.POSITIVE_X.rotation(pitch));
      }

      float value = sizeX / 2.0F;
      float value2 = sizeZ / 2.0F;
      this.rmohme(matrices, -value, -sizeY, -value2, value, 0F, value2, color, true);
      matrices.pop();
   }

      private void k12(
      MatrixStack matrices, float pivotX, float pivotY, float pivotZ, float sizeX, float sizeY, float sizeZ, float headYaw, float headPitch, int color
   ) {
      matrices.push();
      matrices.translate(pivotX, pivotY, pivotZ);
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(headYaw));
      matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(headPitch));
      float value = sizeX / 2.0F;
      float value2 = sizeZ / 2.0F;
      this.rmohme(matrices, -value, -sizeY, -value2, value, 0F, value2, color, true);
      matrices.pop();
   }

      private void rmohme(MatrixStack matrices, float x1, float y1, float z1, float x2, float y2, float z2, int color, boolean doFill) {
      Matrix4f matrix = matrices.peek().getPositionMatrix();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.lineWidth(1.5F);
      int index = color >> 16 & 0xFF;
      int index2 = color >> 8 & 0xFF;
      int index3 = color & 0xFF;
      int index4 = color >> 24 & 0xFF;
      Tessellator tessellator = Tessellator.getInstance();
      if (doFill) {
         this.rm(tessellator, matrix, x1, y1, z1, x2, y2, z2, index, index2, index3, index4 / 4);
      }

      RenderSystem.setShader(ShaderProgramKeys.RENDERTYPE_LINES);
      BufferBuilder bufferBuilder = tessellator.begin(DrawMode.LINES, VertexFormats.LINES);
      if (dashedOutline.isValue()) {
         float value = 0.05F;
         float value2 = 0.025F;
         this.cron(bufferBuilder, matrix, x1, y1, z1, x2, y1, z1, index, index2, index3, index4, value, value2);
         this.cron(bufferBuilder, matrix, x2, y1, z1, x2, y1, z2, index, index2, index3, index4, value, value2);
         this.cron(bufferBuilder, matrix, x2, y1, z2, x1, y1, z2, index, index2, index3, index4, value, value2);
         this.cron(bufferBuilder, matrix, x1, y1, z2, x1, y1, z1, index, index2, index3, index4, value, value2);
         this.cron(bufferBuilder, matrix, x1, y2, z1, x2, y2, z1, index, index2, index3, index4, value, value2);
         this.cron(bufferBuilder, matrix, x2, y2, z1, x2, y2, z2, index, index2, index3, index4, value, value2);
         this.cron(bufferBuilder, matrix, x2, y2, z2, x1, y2, z2, index, index2, index3, index4, value, value2);
         this.cron(bufferBuilder, matrix, x1, y2, z2, x1, y2, z1, index, index2, index3, index4, value, value2);
         this.cron(bufferBuilder, matrix, x1, y1, z1, x1, y2, z1, index, index2, index3, index4, value, value2);
         this.cron(bufferBuilder, matrix, x2, y1, z1, x2, y2, z1, index, index2, index3, index4, value, value2);
         this.cron(bufferBuilder, matrix, x2, y1, z2, x2, y2, z2, index, index2, index3, index4, value, value2);
         this.cron(bufferBuilder, matrix, x1, y1, z2, x1, y2, z2, index, index2, index3, index4, value, value2);
      } else {
         this.destroyMethod841(bufferBuilder, matrix, x1, y1, z1, x2, y1, z1, index, index2, index3, index4);
         this.destroyMethod841(bufferBuilder, matrix, x2, y1, z1, x2, y1, z2, index, index2, index3, index4);
         this.destroyMethod841(bufferBuilder, matrix, x2, y1, z2, x1, y1, z2, index, index2, index3, index4);
         this.destroyMethod841(bufferBuilder, matrix, x1, y1, z2, x1, y1, z1, index, index2, index3, index4);
         this.destroyMethod841(bufferBuilder, matrix, x1, y2, z1, x2, y2, z1, index, index2, index3, index4);
         this.destroyMethod841(bufferBuilder, matrix, x2, y2, z1, x2, y2, z2, index, index2, index3, index4);
         this.destroyMethod841(bufferBuilder, matrix, x2, y2, z2, x1, y2, z2, index, index2, index3, index4);
         this.destroyMethod841(bufferBuilder, matrix, x1, y2, z2, x1, y2, z1, index, index2, index3, index4);
         this.destroyMethod841(bufferBuilder, matrix, x1, y1, z1, x1, y2, z1, index, index2, index3, index4);
         this.destroyMethod841(bufferBuilder, matrix, x2, y1, z1, x2, y2, z1, index, index2, index3, index4);
         this.destroyMethod841(bufferBuilder, matrix, x2, y1, z2, x2, y2, z2, index, index2, index3, index4);
         this.destroyMethod841(bufferBuilder, matrix, x1, y1, z2, x1, y2, z2, index, index2, index3, index4);
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.lineWidth(1F);
      RenderSystem.depthMask(true);
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }

      private void rm(Tessellator tessellator, Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, int r, int g, int b, int a) {
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      BufferBuilder bufferBuilder = tessellator.begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      int index = a << 24 | r << 16 | g << 8 | b;
      bufferBuilder.vertex(matrix, x1, y1, z1).color(index);
      bufferBuilder.vertex(matrix, x2, y1, z1).color(index);
      bufferBuilder.vertex(matrix, x2, y1, z2).color(index);
      bufferBuilder.vertex(matrix, x1, y1, z2).color(index);
      bufferBuilder.vertex(matrix, x1, y2, z1).color(index);
      bufferBuilder.vertex(matrix, x1, y2, z2).color(index);
      bufferBuilder.vertex(matrix, x2, y2, z2).color(index);
      bufferBuilder.vertex(matrix, x2, y2, z1).color(index);
      bufferBuilder.vertex(matrix, x1, y1, z1).color(index);
      bufferBuilder.vertex(matrix, x1, y2, z1).color(index);
      bufferBuilder.vertex(matrix, x2, y2, z1).color(index);
      bufferBuilder.vertex(matrix, x2, y1, z1).color(index);
      bufferBuilder.vertex(matrix, x1, y1, z2).color(index);
      bufferBuilder.vertex(matrix, x2, y1, z2).color(index);
      bufferBuilder.vertex(matrix, x2, y2, z2).color(index);
      bufferBuilder.vertex(matrix, x1, y2, z2).color(index);
      bufferBuilder.vertex(matrix, x1, y1, z1).color(index);
      bufferBuilder.vertex(matrix, x1, y1, z2).color(index);
      bufferBuilder.vertex(matrix, x1, y2, z2).color(index);
      bufferBuilder.vertex(matrix, x1, y2, z1).color(index);
      bufferBuilder.vertex(matrix, x2, y1, z1).color(index);
      bufferBuilder.vertex(matrix, x2, y2, z1).color(index);
      bufferBuilder.vertex(matrix, x2, y2, z2).color(index);
      bufferBuilder.vertex(matrix, x2, y1, z2).color(index);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
   }

      private void destroyMethod841(BufferBuilder buffer, Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, int r, int g, int b, int a) {
      float value = x2 - x1;
      float value2 = y2 - y1;
      float value3 = z2 - z1;
      float value4 = value * value + value2 * value2 + value3 * value3;
      if (!(value4 <= 1E-8F)) {
         float value5 = MathHelper.inverseSqrt(value4);
         value *= value5;
         value2 *= value5;
         value3 *= value5;
         buffer.vertex(matrix, x1, y1, z1).color(r, g, b, a).normal(value, value2, value3);
         buffer.vertex(matrix, x2, y2, z2).color(r, g, b, a).normal(value, value2, value3);
      }
   }

      private void cron(
      BufferBuilder buffer,
      Matrix4f matrix,
      float x1,
      float y1,
      float z1,
      float x2,
      float y2,
      float z2,
      int r,
      int g,
      int b,
      int a,
      float dashLength,
      float gapLength
   ) {
      double value = x2 - x1;
      double value2 = y2 - y1;
      double value3 = z2 - z1;
      double value4 = Math.sqrt(value * value + value2 * value2 + value3 * value3);
      if (!(value4 < 0.001)) {
         double value5 = dashLength + gapLength;
         int index = (int)(value4 / value5);
         double value6 = this.obcru * value5;

         for (int index2 = 0; index2 <= index; index2++) {
            double value7 = (index2 * value5 - value6) / value4;
            double value8 = Math.min((index2 * value5 + dashLength - value6) / value4, 1);
            if (!(value8 < 0)) {
               if (value7 >= 1) {
                  break;
               }

               value7 = Math.max(value7, 0);
               float value9 = (float)(x1 + value * value7);
               float value10 = (float)(y1 + value2 * value7);
               float value11 = (float)(z1 + value3 * value7);
               float value12 = (float)(x1 + value * value8);
               float value13 = (float)(y1 + value2 * value8);
               float value14 = (float)(z1 + value3 * value8);
               float value15 = value12 - value9;
               float value16 = value13 - value10;
               float value17 = value14 - value11;
               float value18 = value15 * value15 + value16 * value16 + value17 * value17;
               if (!(value18 <= 1E-8F)) {
                  float value19 = MathHelper.inverseSqrt(value18);
                  value15 *= value19;
                  value16 *= value19;
                  value17 *= value19;
                  buffer.vertex(matrix, value9, value10, value11).color(r, g, b, a).normal(value15, value16, value17);
                  buffer.vertex(matrix, value12, value13, value14).color(r, g, b, a).normal(value15, value16, value17);
               }
            }
         }
      }
   }

      private int crp() {
      return this.getVisualColor();
   }

   static {
      int index = 0;
      ChoiceSetting moduleSettingHandler2 = new ChoiceSetting(
         "Style", "Render style"
      );
      String[] stringArray = new String[2];
      stringArray[0] = "Box";
      stringArray[1] = "Player";
      style = moduleSettingHandler2.value(stringArray).selected("Box");
      ChoiceSetting moduleSettingHandler22 = new ChoiceSetting(
         "Trigger",
         "When to create snapshots"
      );
      String[] stringArray2 = new String[2];
      stringArray2[0] = "Always";
      stringArray2[1] = "Jump Only";
      triggerMode = moduleSettingHandler22.value(stringArray2).selected("Always");
      dashedOutline.visible(() -> {
         return style.isSelected("Player");
      });
      animateDash.visible(() -> {
         return dashedOutline.isValue() && style.isSelected("Player");
      });
   }
}
