package winvi.noxiumvisuals.modules.visuals;

import java.util.List;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.utils.EasingManager;
public class WavePropagation {
      public final EasingManager animation = new EasingManager(0);
      public final Vec3d origin;
      public final List<VisibleBlockCell> cachedCells;
      public boolean active = true;

   public WavePropagation(Vec3d origin, List<VisibleBlockCell> cachedCells) {
      this.origin = origin;
      this.cachedCells = cachedCells;
   }

}
