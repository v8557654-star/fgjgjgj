package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.model.ModelWithArms;
import net.minecraft.client.render.entity.model.ModelWithHead;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
public class TaksaPetModel extends Model implements ModelWithArms, ModelWithHead {
      public ModelPart head = this.root.getChild("head");
      public ModelPart body = this.root.getChild("body");
      public ModelPart neck = this.root.getChild("neck");
      public ModelPart chest = this.body.getChild("chest");
      public ModelPart back = this.body.getChild("back");
      public ModelPart frontLeftLeg = this.root.getChild("front_left_leg");
      public ModelPart frontRightLeg = this.root.getChild("front_right_leg");
      public ModelPart leftBackLeg = this.root.getChild("left_back_leg");
      public ModelPart rightBackLeg = this.root.getChild("right_back_leg");
      public ModelPart tail = this.root.getChild("tail");
      public ModelPart leftEar = this.head.getChild("left_ear");
      public ModelPart rightEar = this.head.getChild("right_ear");

   public TaksaPetModel() {
      super(getTaksa().createModel(), RenderLayer::getEntityTranslucent);
   }

      public static TexturedModelData getTaksa() {
      ModelData modelData = new ModelData();
      ModelPartData modelPartData = modelData.getRoot();
      ModelPartData modelPartData2 = modelPartData.addChild(
         "head",
         ModelPartBuilder.create()
            .uv(0, 0)
            .cuboid(-3.0F, -3.0F, -4.0F, 6.0F, 6.0F, 4.0F, Dilation.NONE)
            .uv(21, 0)
            .cuboid(-1.5F, 0F, -7.0F, 3.0F, 3.0F, 3.0F, Dilation.NONE),
         ModelTransform.pivot(0F, 10.5F, -6.8F)
      );
      modelPartData2.addChild(
         "left_ear",
         ModelPartBuilder.create()
            .uv(32, 4)
            .cuboid(0F, -5.0F, -1.5F, 1F, 3.0F, 3.0F, Dilation.NONE)
            .uv(34, 1)
            .cuboid(0F, -5.5F, -0.75F, 1F, 1F, 1.5F, Dilation.NONE),
         ModelTransform.pivot(3.0F, 3.0F, -2.0F)
      );
      modelPartData2.addChild(
         "right_ear",
         ModelPartBuilder.create()
            .uv(32, 4)
            .cuboid(-1F, -5.0F, -1.5F, 1F, 3.0F, 3.0F, Dilation.NONE)
            .uv(34, 1)
            .cuboid(-1F, -5.5F, -0.75F, 1F, 1F, 1.5F, Dilation.NONE),
         ModelTransform.pivot(-3.0F, 3.0F, -2.0F)
      );
      modelPartData.addChild(
         "neck",
         ModelPartBuilder.create().uv(32, 13).cuboid(-2.95F, -1F, -4.0F, 5.9F, 5.0F, 6.0F, Dilation.NONE),
         ModelTransform.of(0F, 10.5F, -5.0F, -0.43633232F, 0F, 0F)
      );
      ModelPartData modelPartData3 = modelPartData.addChild("body", ModelPartBuilder.create(), ModelTransform.pivot(0F, 13.5F, -5.0F));
      modelPartData3.addChild(
         "chest",
         ModelPartBuilder.create().uv(32, 13).cuboid(-4.0F, -3.5F, -3.0F, 8.0F, 7.0F, 6.0F, Dilation.NONE),
         ModelTransform.pivot(0F, 0F, 3.0F)
      );
      modelPartData3.addChild(
         "back",
         ModelPartBuilder.create().uv(3, 19).cuboid(-3.0F, -3.0F, -0.5F, 6.0F, 6.0F, 11.0F, Dilation.NONE),
         ModelTransform.pivot(0F, -0.5F, 5.5F)
      );
      modelPartData.addChild(
         "front_left_leg",
         ModelPartBuilder.create().uv(42, 0).cuboid(-1F, 0F, -1F, 2.0F, 5.0F, 2.0F, Dilation.NONE),
         ModelTransform.pivot(1.5F, 16.0F, -3.0F)
      );
      modelPartData.addChild(
         "front_right_leg",
         ModelPartBuilder.create().uv(42, 0).mirrored().cuboid(-1F, 0F, -1F, 2.0F, 5.0F, 2.0F, Dilation.NONE),
         ModelTransform.pivot(-1.5F, 16.0F, -3.0F)
      );
      modelPartData.addChild(
         "left_back_leg",
         ModelPartBuilder.create().uv(52, 0).cuboid(-1F, 0F, -1F, 2.0F, 5.0F, 2.0F, Dilation.NONE),
         ModelTransform.pivot(1.5F, 16.0F, 9.0F)
      );
      modelPartData.addChild(
         "right_back_leg",
         ModelPartBuilder.create().uv(52, 0).mirrored().cuboid(-1F, 0F, -1F, 2.0F, 5.0F, 2.0F, Dilation.NONE),
         ModelTransform.pivot(-1.5F, 16.0F, 9.0F)
      );
      modelPartData.addChild(
         "tail",
         ModelPartBuilder.create().uv(2, 12).cuboid(-1F, 2.0F, -1F, 2.0F, 8.0F, 2.0F, Dilation.NONE),
         ModelTransform.of(0F, 9.0F, 10.0F, 0.3926991F, 0F, 0F)
      );
      return TexturedModelData.of(modelData, 60, 36);
   }

      public void setAngles(LivingEntityRenderState state) {
   }

      public void setRotationAngles(float ageInTicks, ParticleEntityFactory entity) {
      this.head.yaw = entity.getHeadYaw() * 0.017453292F;
      this.head.pitch = entity.getHeadPitch() * 0.017453292F;
      float value = entity.getLimbSwing();
      float value2 = entity.getLimbSwingAmount();
      this.frontLeftLeg.pitch = (float)Math.cos(value * 0.6662F) * 1F * value2;
      this.frontRightLeg.pitch = (float)Math.cos(value * 0.6662F + 3.1415927F) * 1F * value2;
      this.leftBackLeg.pitch = (float)Math.cos(value * 0.6662F + 3.1415927F) * 1F * value2;
      this.rightBackLeg.pitch = (float)Math.cos(value * 0.6662F) * 1F * value2;
      if (entity.isLaying()) {
         this.frontLeftLeg.pitch = (float)Math.toRadians(-90.0F);
         this.frontRightLeg.pitch = (float)Math.toRadians(-90.0F);
         this.leftBackLeg.pitch = (float)Math.toRadians(90.0);
         this.rightBackLeg.pitch = (float)Math.toRadians(90.0);
         this.frontLeftLeg.yaw = (float)Math.toRadians(-22.0F);
         this.frontRightLeg.yaw = (float)Math.toRadians(22.0);
         this.leftBackLeg.yaw = (float)Math.toRadians(22.0);
         this.rightBackLeg.yaw = (float)Math.toRadians(-22.0F);
      } else {
         this.frontLeftLeg.yaw = 0F;
         this.frontRightLeg.yaw = 0F;
         this.leftBackLeg.yaw = 0F;
         this.rightBackLeg.yaw = 0F;
      }

      this.tail.pitch = (float)Math.toRadians(entity.isLaying() ? 45.0 : 22.0);
      this.tail.roll = (float)(Math.toRadians(-22.5F) + 0.39269909262657166 + (float)Math.cos(ageInTicks * 0.15F) * 0.3F);
      this.leftEar.roll = 0F;
      this.rightEar.roll = 0F;
      this.leftEar.pitch = 0F;
      this.rightEar.pitch = 0F;
   }

      public void setArmAngle(Arm arm, MatrixStack matrices) {
   }

      public ModelPart getHead() {
      return this.head;
   }

}
