package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.Vec3d;
public final class TextureColorSupport {
      public Vec3d hqimq;
      public float amgia;
      public int gjrx;
      public float gjs;

   public TextureColorSupport() {
   }

      public void qdyxrh(Vec3d pos, float alpha, int color, float textureU) {
      this.hqimq = pos;
      this.amgia = alpha;
      this.gjrx = color;
      this.gjs = textureU;
   }

      public Vec3d eolcge() {
      return this.hqimq;
   }

      public float eaph() {
      return this.amgia;
   }

      public int executeMethod57() {
      return this.gjrx;
   }

      public float earw() {
      return this.gjs;
   }

}
