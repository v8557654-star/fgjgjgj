package winvi.noxiumvisuals.modules.visuals;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.visuals.TrailsModule;
public final class TextureMatrixTransformer {
      public final Matrix4f zbnvu = new Matrix4f();
      public final List<TextureColorSupport> mtyjn = new ArrayList<>();
      public List<TextureColorManager> calculateField49;
      public TrailsModule m30;
      public float icfxo;
      public int processField75;

   public TextureMatrixTransformer() {
   }

      public void transformMethod93(Matrix4f matrix, List<TextureColorManager> trails, TrailsModule module, float entityHeight) {
      this.zbnvu.set(matrix);
      this.calculateField49 = trails;
      this.m30 = module;
      this.icfxo = entityHeight;
      this.processField75 = 0;
   }

      public void startMethod10(Vec3d pos, float alpha, int color, float textureU) {
      TextureColorSupport textureColorSupport;
      if (this.processField75 < this.mtyjn.size()) {
         textureColorSupport = this.mtyjn.get(this.processField75);
      } else {
         textureColorSupport = new TextureColorSupport();
         this.mtyjn.add(textureColorSupport);
      }

      textureColorSupport.qdyxrh(pos, alpha, color, textureU);
      this.processField75++;
   }

      public float eam() {
      return this.icfxo;
   }

}
