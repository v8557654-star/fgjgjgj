package winvi.noxiumvisuals.modules.visuals;

public record ColorModuleStyle(
   int x,
   int y,
   int color
) {

      public int x() {
      return this.x;
   }

      public int y() {
      return this.y;
   }

      public int color() {
      return this.color;
   }

   static {
      int index = 0;
   }
}
