package winvi.noxiumvisuals.modules.visuals;

public class ModuleManager {
      private float removeField18;
      private float removeField252;
      private float evhf;

   public ModuleManager(float initialValue) {
      this.removeField18 = initialValue;
      this.removeField252 = initialValue;
      this.evhf = 1F;
   }

      public void animate(float target, float speed) {
      this.removeField252 = target;
      this.evhf = speed;
   }

      public void update() {
      if (Math.abs(this.removeField18 - this.removeField252) < 0.001F) {
         this.removeField18 = this.removeField252;
      } else {
         float value = (this.removeField252 - this.removeField18) / this.evhf;
         this.removeField18 += value;
      }
   }

      public float get() {
      this.update();
      return this.removeField18;
   }

      public void set(float value) {
      this.removeField18 = value;
      this.removeField252 = value;
   }

}
