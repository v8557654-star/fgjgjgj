package winvi.noxiumvisuals.modules.visuals;

public record PredictionBounds(
   float minX,
   float minY,
   float minZ,
   float maxX,
   float maxY,
   float maxZ
) {

      public float minX() {
      return this.minX;
   }

      public float minY() {
      return this.minY;
   }

      public float minZ() {
      return this.minZ;
   }

      public float maxX() {
      return this.maxX;
   }

      public float maxY() {
      return this.maxY;
   }

      public float maxZ() {
      return this.maxZ;
   }

   static {
      int index = 0;
   }
}
