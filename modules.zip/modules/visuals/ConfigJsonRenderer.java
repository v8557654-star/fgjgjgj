package winvi.noxiumvisuals.modules.visuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import net.minecraft.world.World;
import winvi.noxiumvisuals.systems.config.TextureSoundRenderer;
import winvi.noxiumvisuals.utils.render.ColoredLogger;
public class ConfigJsonRenderer {
      private static ConfigJsonRenderer manageField44;
      private final Gson fca = new GsonBuilder().setPrettyPrinting().create();
      private final Path cb0;

   private ConfigJsonRenderer() {
      Path path = TextureSoundRenderer.DATA_DIR;

      try {
         Files.createDirectories(path);
      } catch (IOException ioexception) {
         ColoredLogger.error(
            "Failed to create GPS config directory", ioexception
         );
      }

      this.cb0 = path.resolve("gps.file");
   }

      public static ConfigJsonRenderer getInstance() {
      if (manageField44 == null) {
         manageField44 = new ConfigJsonRenderer();
      }

      return manageField44;
   }

      public void save() {
      try {
         JsonArray jsonArray = new JsonArray();

         for (BlockPositionHandRenderer blockPositionHandRenderer : BlockPositionModuleManager.getMarkers()) {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("name", blockPositionHandRenderer.getName());
            jsonObject.addProperty("x", blockPositionHandRenderer.getX());
            jsonObject.addProperty("y", blockPositionHandRenderer.getY());
            jsonObject.addProperty("z", blockPositionHandRenderer.getZ());
            jsonObject.addProperty("dimension", blockPositionHandRenderer.getDimension());
            jsonArray.add(jsonObject);
         }

         Files.writeString(this.cb0, this.fca.toJson(jsonArray), StandardCharsets.UTF_8);
      } catch (IOException ioexception) {
         ColoredLogger.error("GpsConfig save failed", ioexception);
      }
   }

      public void load() {
      try {
         if (!Files.exists(this.cb0)) {
            return;
         }

         String text = Files.readString(this.cb0, StandardCharsets.UTF_8);
         JsonArray jsonArray = JsonParser.parseString(text).getAsJsonArray();
         ArrayList arrayList = new ArrayList();

         for (int index = 0; index < jsonArray.size(); index++) {
            JsonElement jsonElement = jsonArray.get(index);
            if (jsonElement.isJsonObject()) {
               JsonObject jsonObject = jsonElement.getAsJsonObject();
               String text2 = jsonObject.has("name") ? jsonObject.get("name").getAsString() : "";
               int index2 = jsonObject.has("x") ? jsonObject.get("x").getAsInt() : 0;
               int index3 = jsonObject.has("y") ? jsonObject.get("y").getAsInt() : 0;
               int index4 = jsonObject.has("z") ? jsonObject.get("z").getAsInt() : 0;
               String text3 = jsonObject.has("dimension") ? jsonObject.get("dimension").getAsString() : World.OVERWORLD.getValue().toString();
               if (!text2.isBlank()) {
                  arrayList.add(new BlockPositionHandRenderer(text2, index2, index3, index4, text3));
               }
            }
         }

         BlockPositionModuleManager.setMarkers(arrayList);
      } catch (Exception exception) {
         ColoredLogger.error("GpsConfig load failed", exception);
      }
   }

}
