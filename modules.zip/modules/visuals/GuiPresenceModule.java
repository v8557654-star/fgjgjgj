package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.ui.gui.CustomScreenManager;
import winvi.noxiumvisuals.utils.network.GuiPresenceStore;
import winvi.noxiumvisuals.utils.network.OnlinePresenceClient;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
import winvi.noxiumvisuals.utils.render.GuiPresenceRenderer;

public class GuiPresenceModule extends Module {
      public final BooleanSetting share;
      public final BooleanSetting showCursor;
      public final NumberSetting distance;
      public final NumberSetting scale;

   private boolean lastOpen;
   private double lastCursorX;
   private double lastCursorY;
   private long lastSentAt;

   public GuiPresenceModule() {
      super("GuiPresence", ModuleCategory.VISUAL);
      this.share = new BooleanSetting(
            "Share",
            "Broadcast your open menu to other players"
         )
         .setValue(true);
      this.share.withTranslation("guipresence.share", "guipresence.share.desc");
      this.showCursor = new BooleanSetting(
            "Cursor",
            "Show cursor position on the panel"
         )
         .setValue(true);
      this.showCursor.withTranslation("guipresence.cursor", "guipresence.cursor.desc");
      this.distance = new NumberSetting(
            "Distance",
            "Maximum render distance"
         )
         .setValue(32.0F)
         .range(4, 64);
      this.distance.withTranslation("guipresence.distance", "guipresence.distance.desc");
      this.scale = new NumberSetting(
            "Scale",
            "Panel size"
         )
         .setValue(1.0F)
         .range(0.5F, 2.0F)
         .displayFormatter(value -> String.format(java.util.Locale.US, "%.1f", value));
      this.scale.withTranslation("guipresence.scale", "guipresence.scale.desc");
      this.setup(
         new ModuleSetting[]{
            this.share,
            this.showCursor,
            this.distance,
            this.scale
         }
      );
   }

      @Override
   public void setState(boolean state) {
      super.setState(true);
   }

      @Override
   public void onTick() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client == null || client.player == null || client.world == null) {
         return;
      }

      boolean open = this.isLocalMenuOpen();
      double cursorX = open ? cursorFraction(true) : 0.0;
      double cursorY = open ? cursorFraction(false) : 0.0;
      long now = System.currentTimeMillis();
      boolean stateChanged = open != this.lastOpen;
      boolean cursorMoved = open
         && (Math.abs(cursorX - this.lastCursorX) > 0.004 || Math.abs(cursorY - this.lastCursorY) > 0.004);
      boolean heartbeat = now - this.lastSentAt >= (open ? 400L : 5000L);
      if (stateChanged || cursorMoved || heartbeat) {
         OnlinePresenceClient.getInstance().sendGuiState(open, cursorX, cursorY);
         this.lastOpen = open;
         this.lastCursorX = cursorX;
         this.lastCursorY = cursorY;
         this.lastSentAt = now;
      }
   }

      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (event == null || client == null || client.player == null || client.world == null) {
         return;
      }

      float maxDistance = this.distance.getValue();
      double maxDistanceSquared = (double)maxDistance * (double)maxDistance;
      boolean firstPerson = client.options.getPerspective().isFirstPerson();

      for (PlayerEntity player : client.world.getPlayers()) {
         double cursorX;
         double cursorY;
         if (player == client.player) {
            if (firstPerson || !this.isLocalMenuOpen()) {
               continue;
            }

            cursorX = cursorFraction(true);
            cursorY = cursorFraction(false);
         } else {
            if (!EntityVisibilityFilter.shouldRender(player) || client.player.squaredDistanceTo(player) > maxDistanceSquared) {
               continue;
            }

            GuiPresenceStore.State state = GuiPresenceStore.get(player.getGameProfile().getName());
            if (state == null) {
               continue;
            }

            cursorX = state.cursorX();
            cursorY = state.cursorY();
         }

         GuiPresenceRenderer.render(event, player, this.showCursor.isValue(), cursorX, cursorY, this.scale.getValue());
      }
   }

      public boolean isLocalMenuOpen() {
      if (!this.share.isValue()) {
         return false;
      }

      MinecraftClient client = MinecraftClient.getInstance();
      if (client == null) {
         return false;
      }

      return client.currentScreen != null || CustomScreenManager.isOpen();
   }

      private static double cursorFraction(boolean horizontal) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client == null || client.getWindow() == null || client.mouse == null) {
         return 0.0;
      }

      double limit = horizontal
         ? client.getWindow().getFramebufferWidth()
         : client.getWindow().getFramebufferHeight();
      double value = horizontal ? client.mouse.getX() : client.mouse.getY();
      if (limit <= 0.0) {
         return 0.0;
      }

      return MathHelper.clamp(value / limit, 0.0, 1.0);
   }
}
