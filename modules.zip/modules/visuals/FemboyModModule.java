package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class FemboyModModule extends Module {
      public static final float EARS_Y_OFFSET = 0.25F;
      public static final float EARS_Z_OFFSET = 0F;
      public static final float EARS_WIDTH = 1F;
      public static final float TAIL_ATTACH_HEIGHT = 1.5F;
      public static final float TAIL_REACTION = 1.5F;
      public static final float TAIL_OPACITY = 1F;
      public final SettingGroup ears;
      public final NumberSetting earsSpread;
      public final NumberSetting earsSize;
      public final NumberSetting earsTilt;
      public final NumberSetting earsPSize;
      public final NumberSetting earsDensity;
      public final BooleanSetting earsF5Only;
      public final SettingGroup tail;
      public final NumberSetting tailLength;
      public final NumberSetting tailStartSize;
      public final NumberSetting tailEndSize;
      public final NumberSetting tailCurve;
      public final NumberSetting tailSway;
      public final BooleanSetting tailF5Only;

   public FemboyModModule() {
      super(
         "Femboy mod",
         "Femboy mod",
         ModuleCategory.VISUAL
      );
      this.ears = new SettingGroup(
            "Ears",
            "Configure the ears"
         )
         .setValue(true);
      this.earsSpread = new NumberSetting(
            "Ear Spacing",
            "Distance between the ears"
         )
         .setValue(0.15F)
         .range(0F, 1F);
      this.earsSize = new NumberSetting(
            "Ear Size",
            "Overall ear size"
         )
         .setValue(0.25F)
         .range(0.1F, 1.5F);
      this.earsTilt = new NumberSetting(
            "Ear Tilt",
            "Outward ear tilt"
         )
         .setValue(-25.0F)
         .range(-80.0F, 0F);
      this.earsPSize = new NumberSetting(
            "Particle Size",
            "Size of ear particles"
         )
         .setValue(0.3F)
         .range(0.02F, 0.5F);
      this.earsDensity = new NumberSetting(
            "Density",
            "Number of particles per ear edge"
         )
         .setValue(10.0F)
         .range(5.0F, 20.0F);
      this.earsF5Only = new BooleanSetting(
            "F5 Only",
            "Show ears only in third person"
         )
         .setValue(false);
      this.tail = new SettingGroup(
            "Tail",
            "Configure the tail"
         )
         .setValue(true);
      this.tailLength = new NumberSetting(
            "Tail Length",
            "Length of the tail"
         )
         .setValue(1.6F)
         .range(0.5F, 2.0F);
      this.tailStartSize = new NumberSetting(
            "Start Size",
            "Particle size at the tail base"
         )
         .setValue(0.3F)
         .range(0.05F, 1F);
      this.tailEndSize = new NumberSetting(
            "End Size",
            "Particle size at the tail tip"
         )
         .setValue(0.8F)
         .range(0.02F, 1F);
      this.tailCurve = new NumberSetting(
            "Curve",
            "Tail curvature"
         )
         .setValue(0F)
         .range(-1F, 1F);
      this.tailSway = new NumberSetting(
            "Sway",
            "Tail sway intensity"
         )
         .setValue(1.5F)
         .range(0F, 1.5F);
      this.tailF5Only = new BooleanSetting(
            "Tail F5 Only",
            "Show tail only in third person"
         )
         .setValue(false);
      this.showVisualColorSettings(() -> {
         return this.ears.isValue() || this.tail.isValue();
      });
      this.ears.settings(this.earsSpread, this.earsSize, this.earsTilt, this.earsPSize, this.earsDensity, this.earsF5Only);
      this.tail.settings(this.tailLength, this.tailStartSize, this.tailEndSize, this.tailCurve, this.tailSway, this.tailF5Only);
      this.setup(new ModuleSetting[]{this.ears, this.tail});
   }

}
