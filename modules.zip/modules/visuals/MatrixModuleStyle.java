package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
public record MatrixModuleStyle(
   Matrix4f matrix,
   Vec3d origin,
   TrajectoryBasis basis,
   float scale,
   float alpha
) {

      public Matrix4f matrix() {
      return this.matrix;
   }

      public Vec3d origin() {
      return this.origin;
   }

      public TrajectoryBasis basis() {
      return this.basis;
   }

      public float scale() {
      return this.scale;
   }

      public float alpha() {
      return this.alpha;
   }

}
