package winvi.noxiumvisuals.modules.visuals;

public record HorizontalSpan(
   int row,
   int xStart,
   int xEnd
) {

      public int row() {
      return this.row;
   }

      public int xStart() {
      return this.xStart;
   }

      public int xEnd() {
      return this.xEnd;
   }

}
