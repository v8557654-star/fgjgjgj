package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import winvi.noxiumvisuals.modules.visuals.CameraBasis;
import winvi.noxiumvisuals.modules.visuals.MatrixColorStyle;
import winvi.noxiumvisuals.modules.visuals.ModulePosition;
import winvi.noxiumvisuals.modules.visuals.HorizontalSpan;
import winvi.noxiumvisuals.modules.visuals.EulerRotation;
import winvi.noxiumvisuals.modules.visuals.VectorModuleSupport;
import winvi.noxiumvisuals.modules.visuals.ShaderVertexRenderer;
import winvi.noxiumvisuals.modules.visuals.TargetElectricityRenderer;


import winvi.noxiumvisuals.utils.render.EasingRenderRenderer;
import winvi.noxiumvisuals.utils.render.RenderProvider;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.RenderGeometry;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
import winvi.noxiumvisuals.utils.render.RenderStateGuard;
import winvi.noxiumvisuals.utils.render.ShaderRegistry;
import winvi.noxiumvisuals.utils.render.BaseShaderRenderer;
import winvi.noxiumvisuals.utils.render.ParticleOutlineShader;
import winvi.noxiumvisuals.utils.render.FractalOutlineShader;
import winvi.noxiumvisuals.utils.render.PlasmaOutlineShader;
import winvi.noxiumvisuals.utils.render.TunnelOutlineShader;
import winvi.noxiumvisuals.utils.render.AudioOutlineShader;
import winvi.noxiumvisuals.utils.render.WaveOutlineShader;
import winvi.noxiumvisuals.utils.render.WorldParticleBatcher;
import winvi.noxiumvisuals.utils.ParticleCameraRenderer;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.managers.FriendManager;
import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4i;
import org.lwjgl.opengl.GL11;
public class TargetRenderModule extends Module {
      public static TargetRenderModule INSTANCE;
      private static final float[] destroyField17 = new float[361];
      private static final float[] ckuyl = new float[361];
      private static final float qhvyu = 1.6F;
      private static final int addField551 = 5;
      private static final float convertField78 = 60.0F;
      private static final float erasj = 1F;
      private static final float qg1 = 1F;
      private static final float uaikd = 0.5F;
      private static final int eqi = 16;
      private static final int setField56 = 4;
      private static final float umxte = (float) (Math.PI / 4);
      private static final float ql0 = (float)Math.sin(0.7853981852531433);
      private static final float sphvd = (float)Math.cos(0.7853981852531433);
      private static final float qn0 = 0.062F;
      private static final float knjrp = 0.38F;
      private static final long eqpx = 850L;
      private static final long njuoy = 650L;
      private static final long lopsi = 520L;
      private static final String[] computeField39 = new String[]{".............###", "............####", "...........#####", "..........#####.", ".........#####..", "........#####...", "..##...#####....", "..###.#####.....", "...#######......", "...######.......", "....####........", "...######.......", "..###.####......", "####....##......", "###.............", "###............."};
      private static final boolean[][] destroyField531 = dcse();
      private static final HorizontalSpan[] runField51 = ct0();
      private final EasingRenderRenderer vcgyu;
      private final TargetElectricityRenderer xodaa;
      private final ShaderVertexRenderer mgsus;
      private LivingEntity destroyField20;
      private LivingEntity destroyField97;
      private long sbmeq;
      private long b21;
      private boolean sidbi;
      private boolean d19;
      private float brrun;
      private float processField30;
      private long g20;
      private int convertField75;
      private Vec3d i21;
      private double convertField740;
      private float validateField260;
      private float xxvug;
      private float jkepg;
      private float rn0;
      private float jqxxn;
      private float sailx;
      private long zskjl;
      private final Vec3d[] ajrho;
      private final float[] erse;
      private final float[] rt;
      private final float[] pvnrk;
      private final MultiSelectSetting yemhc;
      public final ChoiceSetting targetEspType;
      public final NumberSetting speed;
      private final NumberSetting processField910;
      private final NumberSetting lpknt;
      private final NumberSetting erye;
      private final NumberSetting z26;
      private final ChoiceSetting gecnb;
      private final NumberSetting removeField900;
      private final BooleanSetting qgqkd;
      public final NumberSetting crystalNumSides;
      public final NumberSetting crystalSize;
      private final BooleanSetting owpnd;
      private final NumberSetting nazom;
      private final NumberSetting esf;
      public final BooleanSetting whiteCrystals;
      public final ChoiceSetting crystalLayout;
      public final ChoiceSetting crystalRotation;
      public final ChoiceSetting crystalPosition;
      public final BooleanSetting colorOnHit;
      public final ChoiceSetting hitColorMode;
      public final ColorSetting hitColor;
      public final BooleanSetting whiteOutline;
      public final NumberSetting circleRadius;
      private final NumberSetting haydz;
      public final ChoiceSetting texture;
      public final NumberSetting cubeSize;
      private final BooleanSetting handleField790;
      private final SettingGroup destroyField54;
      private final SettingGroup gcmvl;
      private final SettingGroup runField700;
      private final SettingGroup ayfvr;
      private final SettingGroup m24;
      private final SettingGroup pakmn;
      private final SettingGroup removeField80;
      private final SettingGroup espy;
      private final SettingGroup q24;
      private final NumberSetting r19;
      private final NumberSetting removeField42;
      private final NumberSetting t16;
      private final NumberSetting esu;
      private final NumberSetting v29;
      private final NumberSetting sw1;
      private final BooleanSetting esx;
      private final NumberSetting esyh;
      private final BooleanSetting transformField34;
      private final ChoiceSetting ta0;
      private final NumberSetting lmmwt;
      private final NumberSetting c26;
      private final ChoiceSetting stopField6;
      private final ColorSetting hboho;
      private final NumberSetting bmjvi;
      private long g21;
      private int[] computeField36;
      private int stopField40;
      private final List<VectorModuleSupport> j27;
      private float processField100;
      private float initField40;
      private float m25;
      private long tn1;
      private long mpgsl;
      private float p20;
      private float convertField81;
      private int xbocl;
      private float swchf;
      private long tt;
      private int controlField430;
      private static final long destroyField480 = 350L;
      private float w22;
      private int gxpqk;

   public TargetRenderModule() {
      super(
         "Target Render",
         "Target Render",
         ModuleCategory.VISUAL
      );
      this.vcgyu = new EasingRenderRenderer(400L, 0F, RenderProvider.CUBIC_OUT);
      this.xodaa = new TargetElectricityRenderer();
      this.mgsus = new ShaderVertexRenderer();
      this.sbmeq = 0L;
      this.b21 = 0L;
      this.sidbi = false;
      this.d19 = false;
      this.brrun = 1F;
      this.processField30 = 0F;
      this.g20 = 0L;
      this.convertField75 = -1;
      this.i21 = Vec3d.ZERO;
      this.convertField740 = 0;
      this.validateField260 = 0F;
      this.xxvug = 0F;
      this.jkepg = 0F;
      this.rn0 = 0F;
      this.jqxxn = 0F;
      this.sailx = 0F;
      this.zskjl = 0L;
      this.ajrho = new Vec3d[8];
      this.erse = new float[8];
      this.rt = new float[8];
      this.pvnrk = new float[8];
      this.targetEspType = new ChoiceSetting(
            "Effect Style",
            "Selects the visual effect around the target"
         )
         .value(
            "Texture",
            "Circle",
            "Ghosts",
            "Crystals",
            "Ghost Circle",
            "Firefly Circle",
            "Sword",
            "Cube",
            "Lightning",
            "Hologram"
         )
         .selected("Firefly Circle");
      this.targetEspType.withTranslation("targetesp.targetesptype", "targetesp.targetesptype.desc");
      this.speed = new NumberSetting(
            "Speed",
            "Target render animation speed"
         )
         .setValue(1F)
         .range(1F, 10.0F);
      this.speed.withTranslation("targetesp.speed", "targetesp.speed.desc");
      this.handleField790 = new BooleanSetting(
            "Advanced Settings",
            "Show advanced settings"
         )
         .setValue(true);
      this.handleField790.withTranslation("targetesp.advancedsettings", "targetesp.advancedsettings.desc");
      this.colorOnHit = new BooleanSetting(
            "Color On Hit",
            "Change color when target is hit"
         )
         .setValue(true)
         .visible(() -> {

            return !this.targetEspType.isSelected("Lightning");
         });
      this.colorOnHit.withTranslation("targetesp.coloronhit", "targetesp.coloronhit.desc");
      this.hitColorMode = new ChoiceSetting(
            "Hit Color Source",
            "Color source used when the target is hit"
         )
         .value(
            "Visual Color",
            "Custom"
         )
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .selected("Custom")
         .visible(
            () -> {

               return this.colorOnHit.isValue()
                  && !this.targetEspType.isSelected("Lightning");
            }
         );
      this.hitColorMode.withTranslation("targetesp.hitcolorsource", "targetesp.hitcolorsource.desc");
      this.hitColor = new ColorSetting(
            "Hit Color",
            "Custom color used when the target is hit"
         )
         .setColor(-65536)
         .visible(
            () -> {

               return this.colorOnHit.isValue()
                  && !this.targetEspType.isSelected("Lightning")
                  && this.hitColorMode.isSelected("Custom");
            }
         );
      this.hitColor.withTranslation("targetesp.hitcolor", "targetesp.hitcolor.desc");
      this.yemhc = new MultiSelectSetting(
            "Target Type",
            "Filters the entire list of targets by type"
         )
         .value(
            "Players",
            "Mobs",
            "Friends"
         )
         .selected(
            "Players",
            "Mobs"
         );
      this.yemhc.withTranslation("targetesp.targettype", "targetesp.targettype.desc");
      this.yemhc.visible(() -> {

         return this.handleField790.isValue();
      });
      this.processField910 = new NumberSetting(
            "Length",
            "Ghost length"
         )
         .setValue(12.0F)
         .range(1, 20);
      this.processField910.withTranslation("targetesp.length", "targetesp.length.desc");
      this.lpknt = new NumberSetting(
            "Start Size",
            "Start size"
         )
         .setValue(0.35F)
         .range(0.05F, 1F);
      this.lpknt.withTranslation("targetesp.startsize", "targetesp.startsize.desc");
      this.lpknt.visible(() -> {

         return this.handleField790.isValue();
      });
      this.erye = new NumberSetting(
            "End Size",
            "End size"
         )
         .setValue(0.08F)
         .range(0.03F, 0.7F);
      this.erye.withTranslation("targetesp.endsize", "targetesp.endsize.desc");
      this.erye.visible(() -> {

         return this.handleField790.isValue();
      });
      this.z26 = new NumberSetting(
            "Brightness",
            "Ghost brightness intensity"
         )
         .setValue(100.0F)
         .range(0F, 100.0F);
      this.z26.withTranslation("targetesp.ghostbrightness", "targetesp.ghostbrightness.desc");
      this.z26.visible(() -> {

         return this.handleField790.isValue();
      });
      this.gecnb = new ChoiceSetting(
            "Ghost Trajectory",
            "Ghost trajectory pattern"
         )
         .value(
            "Helix",
            "Orbit",
            "Chaos"
         )
         .selected("Orbit");
      this.gecnb.withTranslation("targetesp.ghosttrajectory", "targetesp.ghosttrajectory.desc");
      this.gecnb.visible(() -> {

         return this.handleField790.isValue();
      });
      this.removeField900 = new NumberSetting(
            "Ghost Count",
            "Number of ghost spirals"
         )
         .setValue(3.0F)
         .range(1, 6);
      this.removeField900.withTranslation("targetesp.ghostcount", "targetesp.ghostcount.desc");
      this.removeField900.visible(() -> {

         return this.handleField790.isValue();
      });
      this.qgqkd = new BooleanSetting(
            "Pulse",
            "Crystal pulse"
         )
         .setValue(true);
      this.qgqkd.withTranslation("targetesp.pulse", "targetesp.pulse.desc");
      this.crystalNumSides = new NumberSetting(
            "Sides",
            "Number of sides"
         )
         .setValue(4.0F)
         .range(4.0F, 24.0F);
      this.crystalNumSides.withTranslation("targetesp.sides", "targetesp.sides.desc");
      this.crystalSize = new NumberSetting(
            "Size",
            "Crystal size"
         )
         .setValue(0.3F)
         .range(0.05F, 0.4F);
      this.crystalSize.withTranslation("targetesp.size", "targetesp.size.desc");
      this.crystalSize.visible(() -> {

         return this.handleField790.isValue();
      });
      this.owpnd = new BooleanSetting(
            "Crystal Glow",
            "Crystal glow"
         )
         .setValue(true);
      this.owpnd.withTranslation("targetesp.crystalglow", "targetesp.crystalglow.desc");
      this.nazom = new NumberSetting(
            "Crystal Glow Size",
            "Crystal glow size"
         )
         .setValue(2.0F)
         .range(1F, 5.0F);
      this.nazom.withTranslation("targetesp.crystalglowsize", "targetesp.crystalglowsize.desc");
      this.esf = new NumberSetting(
            "Glow Transparency",
            "Glow transparency"
         )
         .setValue(0.3F)
         .range(0.1F, 1F);
      this.esf.withTranslation("targetesp.crystalglowtransparency", "targetesp.crystalglowtransparency.desc");
      this.esf.visible(() -> {

         return this.handleField790.isValue();
      });
      this.whiteCrystals = new BooleanSetting(
            "White Crystals",
            "Makes crystals white with colored glow"
         )
         .setValue(true);
      this.whiteCrystals.withTranslation("targetesp.whitecrystals", "targetesp.whitecrystals.desc");
      this.crystalLayout = new ChoiceSetting(
            "Crystal Direction",
            "Crystal direction style"
         )
         .value("To Center", "Up")
         .selected("Up");
      this.crystalLayout.withTranslation("targetesp.crystallayout", "targetesp.crystallayout.desc");
      this.crystalLayout.visible(() -> {

         return this.handleField790.isValue();
      });
      this.crystalRotation = new ChoiceSetting(
            "Crystal Rotation",
            "Crystal rotation style"
         )
         .value(
            "Orbit",
            "Spiral",
            "Wave"
         )
         .selected("Orbit");
      this.crystalRotation.withTranslation("targetesp.crystalrotation", "targetesp.crystalrotation.desc");
      this.crystalRotation.visible(() -> {

         return this.handleField790.isValue();
      });
      this.crystalPosition = new ChoiceSetting(
            "Crystal Position",
            "Crystal vertical position style"
         )
         .value(
            "Wave",
            "Flat"
         )
         .selected("Wave");
      this.crystalPosition.withTranslation("targetesp.crystalposition", "targetesp.crystalposition.desc");
      this.crystalPosition.visible(() -> {

         return this.handleField790.isValue();
      });
      this.whiteOutline = new BooleanSetting(
            "White Outline",
            "Makes circle outline always white"
         )
         .setValue(true);
      this.whiteOutline.withTranslation("targetesp.whiteoutline", "targetesp.whiteoutline.desc");
      this.circleRadius = new NumberSetting(
            "Circle Radius",
            "Circle radius"
         )
         .setValue(0.8F)
         .range(0.5F, 3.0F);
      this.circleRadius.withTranslation("targetesp.circleradius", "targetesp.circleradius.desc");
      this.haydz = new NumberSetting(
            "Lifetime",
            "Effect lifetime in seconds"
         )
         .setValue(5.0F)
         .range(1F, 30.0F);
      this.haydz.withTranslation("targetesp.lifetime", "targetesp.lifetime.desc");
      this.texture = new ChoiceSetting(
            "Texture",
            "Cube texture"
         )
         .value(
            "LEGACY",
            "MARKER",
            "PORTAL",
            "CRUMPS",
            "WAVE",
            "TORNADO",
            "DRIVE",
            "LINE",
            "TRUMB"
         )
         .selected("MARKER");
      this.texture.withTranslation("targetesp.texture", "targetesp.texture.desc");
      this.cubeSize = new NumberSetting(
            "Cube Size",
            "Cube size"
         )
         .setValue(1.8F)
         .range(1F, 4.0F);
      this.cubeSize.withTranslation("targetesp.cubesize", "targetesp.cubesize.desc");
      this.destroyField54 = new SettingGroup(
            "Cube Settings",
            "Cube settings"
         )
         .settings(this.texture, this.cubeSize)
         .setValue(true)
         .visible(() -> {

            return "Texture".equalsIgnoreCase(this.targetEspType.getSelected());
         });
      this.destroyField54.withTranslation("targetesp.cubesettings", "targetesp.cubesettings.desc");
      this.gcmvl = new SettingGroup(
            "Circle Settings",
            "Circle settings"
         )
         .settings(this.whiteOutline, this.circleRadius)
         .setValue(true)
         .visible(() -> {

            return "Circle".equalsIgnoreCase(this.targetEspType.getSelected());
         });
      this.gcmvl.withTranslation("targetesp.circlesettings", "targetesp.circlesettings.desc");
      this.runField700 = new SettingGroup(
            "Ghost Settings",
            "Ghost settings"
         )
         .settings(this.processField910, this.lpknt, this.erye, this.z26, this.gecnb, this.removeField900)
         .setValue(true)
         .visible(() -> {

            return "Ghosts".equalsIgnoreCase(this.targetEspType.getSelected());
         });
      this.runField700.withTranslation("targetesp.ghostsettings", "targetesp.ghostsettings.desc");
      this.esyh = new NumberSetting(
            "Player Crystal Distance",
            "Crystal distance for players only"
         )
         .setValue(0.7F)
         .range(0.3F, 2.0F);
      this.esyh.withTranslation("targetesp.crystaldistanceforplayers", "targetesp.crystaldistanceforplayers.desc");
      this.esyh
         .visible(
            () -> {

               return "Crystals".equalsIgnoreCase(this.targetEspType.getSelected())
                  && this.handleField790.isValue();
            }
         );
      this.transformField34 = new BooleanSetting(
            "Use Shader",
            "Use shader effect for crystals"
         )
         .setValue(false);
      this.transformField34.withTranslation("targetesp.crystaluseshader", "targetesp.crystaluseshader.desc");
      this.transformField34
         .visible(
            () -> {

               return "Crystals".equalsIgnoreCase(this.targetEspType.getSelected())
                  && this.handleField790.isValue();
            }
         );
      this.ta0 = new ChoiceSetting(
            "Shader Type",
            "Shader effect type"
         )
         .value(
            "Wave",
            "Plasma",
            "Fractal",
            "Tunnel",
            "Particles"
         )
         .selected("Wave");
      this.ta0.withTranslation("targetesp.crystalshadertype", "targetesp.crystalshadertype.desc");
      this.ta0
         .visible(
            () -> {

               return "Crystals".equalsIgnoreCase(this.targetEspType.getSelected())
                  && this.transformField34.isValue()
                  && this.handleField790.isValue();
            }
         );
      this.lmmwt = new NumberSetting(
            "Shader Speed",
            "Shader animation speed"
         )
         .setValue(1F)
         .range(0.1F, 5.0F);
      this.lmmwt.withTranslation("targetesp.crystalshaderspeed", "targetesp.crystalshaderspeed.desc");
      this.lmmwt
         .visible(
            () -> {

               return "Crystals".equalsIgnoreCase(this.targetEspType.getSelected())
                  && this.transformField34.isValue()
                  && this.handleField790.isValue();
            }
         );
      this.c26 = new NumberSetting(
            "Shader Scale",
            "Shader pattern scale"
         )
         .setValue(1F)
         .range(0.1F, 10.0F);
      this.c26.withTranslation("targetesp.crystalshaderscale", "targetesp.crystalshaderscale.desc");
      this.c26
         .visible(
            () -> {

               return "Crystals".equalsIgnoreCase(this.targetEspType.getSelected())
                  && this.transformField34.isValue()
                  && this.handleField790.isValue();
            }
         );
      this.ayfvr = new SettingGroup(
            "Crystal Settings",
            "Crystal settings"
         )
         .settings(
            this.crystalSize,
            this.esf,
            this.whiteCrystals,
            this.crystalLayout,
            this.crystalRotation,
            this.crystalPosition,
            this.transformField34,
            this.ta0,
            this.lmmwt,
            this.c26
         )
         .setValue(true)
         .visible(() -> {

            return "Crystals".equalsIgnoreCase(this.targetEspType.getSelected());
         });
      this.ayfvr.withTranslation("targetesp.crystalsettings", "targetesp.crystalsettings.desc");
      this.r19 = new NumberSetting(
            "Firefly Circle Size",
            "Firefly particle size"
         )
         .setValue(0.4F)
         .range(0.3F, 1F);
      this.r19.withTranslation("targetesp.fireflycirclesize", "targetesp.fireflycirclesize.desc");
      this.m24 = new SettingGroup(
            "Firefly Circle Settings",
            "Firefly circle settings"
         )
         .settings(this.r19)
         .setValue(true)
         .visible(() -> {

            return "Firefly Circle".equalsIgnoreCase(this.targetEspType.getSelected());
         });
      this.m24.withTranslation("targetesp.fireflycirclesettings", "targetesp.fireflycirclesettings.desc");
      this.removeField42 = new NumberSetting(
            "Cube Size",
            "Corner cube size"
         )
         .setValue(0.8F)
         .range(0.35F, 2.0F);
      this.removeField42.withTranslation("targetesp.cornercubesize", "targetesp.cornercubesize.desc");
      this.t16 = new NumberSetting(
            "Thickness",
            "Corner cube edge thickness"
         )
         .setValue(1F)
         .range(0.35F, 2.0F);
      this.t16.withTranslation("targetesp.cornercubethickness", "targetesp.cornercubethickness.desc");
      this.removeField80 = new SettingGroup(
            "Cube Settings",
            "Corner cube settings"
         )
         .settings(this.removeField42, this.t16)
         .setValue(true)
         .visible(() -> {

            return "Cube".equalsIgnoreCase(this.targetEspType.getSelected());
         });
      this.removeField80.withTranslation("targetesp.cornercubesettings", "targetesp.cornercubesettings.desc");
      this.esu = new NumberSetting(
            "Sword Size",
            "Sword size"
         )
         .setValue(1F)
         .range(0.3F, 2.0F);
      this.esu.withTranslation("targetesp.swordsize", "targetesp.swordsize.desc");
      this.v29 = new NumberSetting(
            "Sword Distance",
            "Distance from target"
         )
         .setValue(0.38F)
         .range(0F, 2.0F);
      this.v29.withTranslation("targetesp.sworddistance", "targetesp.sworddistance.desc");
      this.sw1 = new NumberSetting(
            "Sword Transparency",
            "Sword transparency"
         )
         .setValue(1F)
         .range(0.05F, 1F);
      this.sw1.withTranslation("targetesp.swordtransparency", "targetesp.swordtransparency.desc");
      this.esx = new BooleanSetting(
            "Sword Outline",
            "Draw sword outline"
         )
         .setValue(true);
      this.esx.withTranslation("targetesp.swordoutline", "targetesp.swordoutline.desc");
      this.pakmn = new SettingGroup(
            "Sword Settings",
            "Sword settings"
         )
         .settings(this.esu, this.v29, this.sw1, this.esx)
         .setValue(true)
         .visible(() -> {

            return "Sword".equalsIgnoreCase(this.targetEspType.getSelected());
         });
      this.pakmn.withTranslation("targetesp.swordsettings", "targetesp.swordsettings.desc");
      this.stopField6 = new ChoiceSetting(
            "Lightning Color Source",
            "Lightning glow color source"
         )
         .value(
            "Visual Color",
            "Custom"
         )
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .selected("Custom");
      this.stopField6.withTranslation("targetesp.lightningcolorsource", "targetesp.lightningcolorsource.desc");
      this.hboho = new ColorSetting(
            "Glow Color",
            "Custom lightning glow color"
         )
         .setColor(-1)
         .visible(() -> {

            return this.stopField6.isSelected("Custom");
         });
      this.hboho.withTranslation("targetesp.lightningglowcolor", "targetesp.lightningglowcolor.desc");
      this.espy = new SettingGroup(
            "Lightning Settings",
            "Lightning settings"
         )
         .settings(this.stopField6, this.hboho)
         .setValue(true)
         .visible(() -> {

            return "Lightning".equalsIgnoreCase(this.targetEspType.getSelected());
         });
      this.espy.withTranslation("targetesp.lightningsettings", "targetesp.lightningsettings.desc");
      this.bmjvi = new NumberSetting(
            "Hologram Size",
            "Hologram world-space size"
         )
         .setValue(1F)
         .range(0.5F, 2.0F);
      this.bmjvi.withTranslation("targetesp.hologramsize", "targetesp.hologramsize.desc");
      this.q24 = new SettingGroup(
            "Hologram Settings",
            "Hologram settings"
         )
         .settings(this.bmjvi)
         .setValue(true)
         .visible(() -> {

            return "Hologram".equalsIgnoreCase(this.targetEspType.getSelected());
         });
      this.q24.withTranslation("targetesp.hologramsettings", "targetesp.hologramsettings.desc");
      this.g21 = 0L;
      this.computeField36 = new int[360];
      this.stopField40 = Integer.MIN_VALUE;
      this.j27 = new ArrayList<>();
      this.processField100 = 0F;
      this.initField40 = 0F;
      this.m25 = 0F;
      this.tn1 = System.currentTimeMillis();
      this.mpgsl = System.currentTimeMillis();
      this.p20 = 0F;
      this.convertField81 = 0F;
      this.xbocl = 0;
      this.swchf = 0F;
      this.tt = 0L;
      this.controlField430 = 0;
      this.w22 = 0F;
      this.gxpqk = 0;
      this.showVisualColorSettings(() -> {

         return !this.targetEspType.isSelected("Lightning");
      });
      INSTANCE = this;
      this.setup(
         new ModuleSetting[]{
            this.targetEspType,
            this.speed,
            this.handleField790,
            this.colorOnHit,
            this.hitColorMode,
            this.hitColor,
            this.yemhc,
            this.haydz,
            this.destroyField54,
            this.gcmvl,
            this.runField700,
            this.ayfvr,
            this.esyh,
            this.m24,
            this.pakmn,
            this.removeField80,
            this.espy,
            this.q24
         }
      );
      this.addMethod14();
   }

      @Override
   public void deactivate() {

      this.destroyField20 = null;
      this.destroyField97 = null;
      this.b21 = 0L;
      this.j27.clear();
      this.uoqsan();
      this.convertMethod75();
      this.b22();
      this.xodaa.reset();
      this.w22 = 0F;
      this.gxpqk = 0;
      this.hkvvkj();
      this.processField30 = 0F;
      this.p20 = 0F;
      super.deactivate();
   }

   @EventHandler
      public void onTick(ClientTickEvent e) {

      this.addMethod14();
      this.destroyField20 = this.mndvkh();
      if (this.destroyField20 != null) {
         if (this.destroyField97 != this.destroyField20) {
            this.sbmeq = System.currentTimeMillis();
            this.sidbi = true;
            this.d19 = false;
            this.j27.clear();
            this.initMethod24();
            this.hkvvkj();
            this.convertMethod75();
            this.b22();
         }

         this.b21 = 0L;
         this.destroyField97 = this.destroyField20;
      } else if (this.destroyField97 == null || this.destroyField97.isAlive() && !this.destroyField97.isRemoved()) {
         if (this.destroyField97 != null && this.destroyField20 == null && this.b21 == 0L) {
            this.b21 = System.currentTimeMillis();
         }
      } else {
         this.ddt(this.destroyField97);
         this.sidbi = false;
         this.d19 = true;
         this.destroyField20 = null;
      }

      if (this.b21 > 0L && this.sidbi && !this.d19 && this.destroyField20 == null) {
         long timestamp = System.currentTimeMillis();
         long timestamp2 = timestamp - this.b21;
         float value = this.haydz.getValue() * 1000.0F;
         if ((float)timestamp2 > value) {
            this.ddt(this.destroyField97);
            this.d19 = true;
            this.sidbi = false;
         }
      }
   }

      private LivingEntity mndvkh() {

      if (MinecraftClient.getInstance().world != null && MinecraftClient.getInstance().player != null) {
         if (MinecraftClient.getInstance().crosshairTarget instanceof EntityHitResult entityHitResult && entityHitResult.getEntity() instanceof LivingEntity livingEntity) {
            if (livingEntity == MinecraftClient.getInstance().player) {
               return null;
            }

            if (!livingEntity.isAlive() || livingEntity.isRemoved()) {
               return null;
            }

            if (livingEntity.isInvisible()) {
               return null;
            }

            if (livingEntity.hasStatusEffect(StatusEffects.INVISIBILITY)) {
               return null;
            }

            if (!MinecraftClient.getInstance().player.canSee(livingEntity)) {
               return null;
            }

            if (this.destroyMethod390(livingEntity)) {
               return livingEntity;
            }
         }

         return null;
      } else {
         return null;
      }
   }

      private void addMethod14() {

      String text = this.targetEspType.getSelected();
      if ("Sphere".equalsIgnoreCase(text)
         || "Spiral".equalsIgnoreCase(text)) {
         this.targetEspType.updateSelected("Firefly Circle");
      }
   }

      private boolean destroyMethod390(LivingEntity livingEntity) {

      if (livingEntity instanceof PlayerEntity player) {
         return FriendManager.isFriend(player) && this.yemhc.isSelected("Friends")
            ? true
            : this.yemhc.isSelected("Players");
      } else {
         return livingEntity instanceof MobEntity && this.yemhc.isSelected("Mobs");
      }
   }

      public void onAttack(LivingEntity attackedEntity) {

      if (this.isState() && attackedEntity != null && attackedEntity != MinecraftClient.getInstance().player && EntityVisibilityFilter.shouldRender(attackedEntity)) {
         if (attackedEntity.isAlive() && !attackedEntity.isRemoved()) {
            if (this.destroyMethod390(attackedEntity)) {
               this.destroyField20 = attackedEntity;
               if (this.destroyField97 != attackedEntity) {
                  this.sbmeq = System.currentTimeMillis();
                  this.j27.clear();
                  this.initMethod24();
                  this.hkvvkj();
                  this.convertMethod75();
                  this.b22();
               }

               this.b21 = 0L;
               this.destroyField97 = attackedEntity;
               this.sidbi = true;
               this.d19 = false;
            }
         }
      }
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer e) {

      if (!"Crystals".equalsIgnoreCase(this.targetEspType.getSelected())
         && !this.j27.isEmpty()) {
         this.j27.clear();
      }

      if (!"Lightning".equalsIgnoreCase(this.targetEspType.getSelected())) {
         this.xodaa.reset();
      }

      this.vcgyu.update(this.destroyField20 != null || this.sidbi && !this.d19);
      float value = this.vcgyu.getValue();
      boolean enabled = "Cube".equalsIgnoreCase(this.targetEspType.getSelected());
      boolean enabled2 = enabled && this.destroyField97 != null && this.u26(this.destroyField97);
      if (this.destroyField97 != null && (value > 0.01F || enabled2) && (this.sidbi || this.d19 || enabled2)) {
         this.dfom(this.destroyField97);
         if ("Texture".equalsIgnoreCase(this.targetEspType.getSelected())) {
            this.mudyqs(this.destroyField97);
         }

         if (!EntityVisibilityFilter.shouldRender(this.destroyField97) || this.destroyField97.hasStatusEffect(StatusEffects.INVISIBILITY)) {
            return;
         }

         double x = ParticleCameraRenderer.getDistanceSquaredToCamera(
            (float)this.destroyField97.getX(), (float)this.destroyField97.getY(), (float)this.destroyField97.getZ()
         );
         if (x > 4096.0) {
            return;
         }

         long timestamp = System.currentTimeMillis();
         if (timestamp != this.g21) {
            this.g21 = timestamp;
            this.dciv(timestamp);
         }

         float value2 = 0F;
         if (this.colorOnHit.isValue() && this.initField40 > 0F) {
            value2 = this.initField40;
         }

         float value3 = 1F;
         if (!this.d19 && this.sidbi) {
            long timestamp2 = System.currentTimeMillis();
            long timestamp3 = timestamp2 - this.sbmeq;
            float value4 = 500.0F;
            value3 = Math.min(1F, (float)timestamp3 / value4);
            value3 = (float)Math.pow(value3, 0.6);
         }

         float value5 = value;
         if (!this.d19
            && !"Crystals".equalsIgnoreCase(this.targetEspType.getSelected())
            && !"Ghost Circle".equalsIgnoreCase(this.targetEspType.getSelected())) {
            value5 = value * value3;
         }

         if (!this.d19) {
            value5 = Math.max(0.1F, value5);
         }

         int index = this.handleMethod51();
         float value6 = this.eq(this.lpknt, 0.05F, 1F);
         float value7 = this.eq(this.erye, 0.03F, 0.7F);
         float value8 = this.parseMethod38();
         String text = this.targetEspType.getSelected();
         switch (text) {
            case "Texture":
               this.dcu(this.destroyField97, value5, value2, this.texture.getSelected(), this.cubeSize.getValue(), value8);
               break;
            case "Circle":
               this.uahkmv(e.getStack(), this.destroyField97, value5, value2, this.whiteOutline.isValue(), false, 2.0F, this.circleRadius.getValue(), value8);
               break;
            case "Ghosts":
               this.ek(this.destroyField97, value5, value2, index, value6, value7, value8, this.z26.getValue(), this.es0(), (int)this.removeField900.getValue());
               break;
            case "Crystals":
               boolean enabled3 = "Up".equalsIgnoreCase(this.crystalLayout.getSelected());
               String text2 = this.crystalRotation.getSelected();
               String text3 = this.crystalPosition.getSelected();
               float value9 = this.destroyField97 instanceof PlayerEntity ? this.esyh.getValue() : 0.7F;
               this.dfm(
                  e,
                  this.destroyField97,
                  value9,
                  this.crystalSize.getValue(),
                  value8,
                  value5,
                  this.whiteCrystals.isValue(),
                  enabled3,
                  this.esf.getValue(),
                  text2,
                  text3
               );
               break;
            case "Ghost Circle":
               this.svquie(e, value5, value2);
               break;
            case "Firefly Circle":
               this.runMethod41(e, value5, value2);
               break;
            case "Sword":
               this.dz(e, this.destroyField97, value5, value2, value8);
               break;
            case "Cube":
               this.utuxpc(e, this.destroyField97, value5, value2, value8);
               break;
            case "Lightning":
               this.xodaa.render(this.destroyField97, value5, this.resolveVisualOrCustomColor(this.stopField6, this.hboho), this.parseMethod67(value8));
               break;
            case "Hologram":
               if (!MinecraftClient.getInstance().options.hudHidden) {
                  this.mgsus.render(e, this.destroyField97, value5, this.processMethod200(0, 360, value2), -1, this.bmjvi.getValue());
               }
         }
      }

      if (this.destroyField97 != null && this.destroyField20 == null && value < 0.01F && !enabled2) {
         this.sidbi = false;
         this.d19 = false;
         this.destroyField97 = null;
         this.sbmeq = 0L;
         this.b21 = 0L;
         this.j27.clear();
         this.hkvvkj();
         this.convertMethod75();
         this.b22();
         this.xodaa.reset();
      }
   }

      @Override
   public boolean hasWorldRenderWork() {

      if (this.destroyField20 != null) {
         return true;
      } else if (this.destroyField97 == null) {
         return false;
      } else {
         return "Cube".equalsIgnoreCase(this.targetEspType.getSelected())
               && this.u26(this.destroyField97)
            ? true
            : (this.sidbi || this.d19) && this.vcgyu.getValue() > 0.001F;
      }
   }

      private void dciv(long currentTime) {

      int index = this.getVisualColor();
      if (index != this.stopField40) {
         Arrays.fill(this.computeField36, index);
         this.stopField40 = index;
      }
   }

      private int checkMethod21(int angle) {

      return this.computeField36[Math.abs(angle) % 360];
   }

      private void mudyqs(LivingEntity currentTarget) {

      if (MinecraftClient.getInstance().player != null && currentTarget != null) {
         boolean client = MinecraftClient.getInstance().player.canSee(currentTarget);
         float value = client ? 1F : 0F;
         float value2 = 0.05F;
         if (this.brrun < value) {
            this.brrun = Math.min(value, this.brrun + value2);
         } else if (this.brrun > value) {
            this.brrun = Math.max(value, this.brrun - value2);
         }
      } else {
         this.brrun = Math.max(0F, this.brrun - 0.05F);
      }
   }

      private void uoqsan() {

      this.brrun = 1F;
   }

      private void initMethod24() {

      long timestamp = System.currentTimeMillis();
      this.mpgsl = timestamp;
      this.tn1 = timestamp;
   }

      private float parseMethod38() {

      float value = this.speed.getValue();
      float value2 = MathHelper.clamp(value, 1F, 10.0F);
      if (value2 != value) {
         this.speed.setValueSilently(value2);
      }

      return value2;
   }

      private float transformMethod890(float speed) {

      return MathHelper.clamp(speed, 1F, 10.0F);
   }

      private float gvylif(float speed) {

      return this.processField30 * 60.0F * this.transformMethod890(speed);
   }

      private double parseMethod67(float speed) {

      return Math.toRadians(this.gvylif(speed));
   }

      private float dcr(float speed) {

      float value = this.gvylif(speed) % 360.0F;
      if (value < 0F) {
         value += 360.0F;
      }

      return value / 360.0F;
   }

      private static boolean[][] dcse() {

      boolean[][] booleanArrayArray = new boolean[computeField39.length][16];

      for (int index = 0; index < computeField39.length; index++) {
         String text = computeField39[index];

         for (int index2 = 0; index2 < Math.min(text.length(), 16); index2++) {
            booleanArrayArray[index][index2] = text.charAt(index2) == '#';
         }
      }

      return booleanArrayArray;
   }

      private static HorizontalSpan[] ct0() {

      ArrayList<HorizontalSpan> arrayList = new ArrayList<>();

      for (int index = 0; index < computeField39.length; index++) {
         String text = computeField39[index];
         int index2 = 0;

         while (index2 < text.length()) {
            while (index2 < text.length() && text.charAt(index2) != '#') {
               index2++;
            }

            int index3 = index2;

            while (index2 < text.length() && text.charAt(index2) == '#') {
               index2++;
            }

            if (index3 < index2) {
               arrayList.add(new HorizontalSpan(index, index3, index2));
            }
         }
      }

      return arrayList.toArray(new HorizontalSpan[0]);
   }

      private void dcu(LivingEntity currentTarget, float anim, float red, String selectedTexture, float baseSize, float speed) {

      if (!(this.brrun <= 0.01F)) {
         float value = baseSize * anim;
         Camera client = MinecraftClient.getInstance().getEntityRenderDispatcher().camera;
         Vec3d position = client.getPos();
         Vec3d position2 = RenderGeometry.interpolate(currentTarget);
         Vec3d height = new Vec3d(position2.x, position2.y + currentTarget.getHeight() / 2.0, position2.z);
         Vec3d position3 = height.subtract(position);
         MatrixStack matrices = new MatrixStack();
         matrices.push();
         matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
         matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(client.getYaw() + 180.0F));
         matrices.translate(position3.x, position3.y, position3.z);
         matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-client.getYaw()));
         matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
         matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(this.gvylif(speed)));
         Entry entry = matrices.peek().copy();
         Identifier identifier = ParticleTextures.getTargetRenderTexture(selectedTexture);
         float value2 = anim * this.brrun;
         Vector4i vector4i = this.handleMethod52(red, value2);
         WorldShapeRenderer.drawTexture(entry, identifier, -value / 2.0F, -value / 2.0F, value, value, vector4i, false, true);
         matrices.pop();
      }
   }

      private void utuxpc(VertexMatrixRenderer event, LivingEntity currentTarget, float anim, float red, float speed) {

      if (event != null && currentTarget != null) {
         boolean enabled = this.u26(currentTarget);
         if (!(anim <= 0.01F) || enabled) {
            Vec3d position = RenderGeometry.interpolate(currentTarget);
            float height = Math.max(0.9F, currentTarget.getHeight());
            float value = this.mcmhjy();
            float value2 = this.controlMethod32(currentTarget) * (0.82F + anim * 0.18F) * value;
            float value3 = Math.max(0.13F, value2 * 0.38F);
            float value4 = enabled ? 0F : anim;
            Vec3d position2 = new Vec3d(position.x, position.y + height * 0.5F, position.z);
            Matrix4f matrix = event.getStack().peek().getPositionMatrix();
            EulerRotation moduleData6 = this.ddd(speed);
            boolean enabled2 = this.dcw(currentTarget);
            if (enabled2) {
               RenderSystem.disableDepthTest();
            } else {
               RenderSystem.enableDepthTest();
            }

            RenderSystem.depthMask(false);
            RenderSystem.enableBlend();
            RenderSystem.disableCull();
            RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            if (value4 > 0.02F) {
               this.ijgfgs(bufferBuilder, matrix, position2, value2, moduleData6, value3, value4, red);
            }

            this.ixqvob(bufferBuilder, matrix, currentTarget, red);
            BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
            RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
            RenderSystem.setShaderTexture(0, ParticleTextures.BLOOM);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
            CameraBasis client = this.fwqaci(MinecraftClient.getInstance().gameRenderer.getCamera());
            BufferBuilder bufferBuilder2 = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            if (value4 > 0.02F) {
               this.startMethod530(bufferBuilder2, matrix, client, position2, value2, moduleData6, value3, value4, red);
            }

            this.removeMethod88(bufferBuilder2, matrix, client, currentTarget, red);
            BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
            RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderStateGuard.restoreWorldDefaults();
         }
      }
   }

      private boolean dcw(LivingEntity currentTarget) {

      return MinecraftClient.getInstance().player != null
         && currentTarget != null
         && currentTarget.isAlive()
         && !currentTarget.isRemoved()
         && !this.d19
         && MinecraftClient.getInstance().player.canSee(currentTarget);
   }

      private float controlMethod32(LivingEntity currentTarget) {

      float height = Math.max(0.9F, currentTarget.getHeight());
      float width = Math.max(0.45F, currentTarget.getWidth());
      float value = MathHelper.clamp(Math.max(width * 0.55F, height * 0.18F), 0.28F, 0.42F);
      return value * MathHelper.clamp(this.removeField42.getValue(), 0.35F, 2.0F);
   }

      private float apycnp() {

      return 0.062F * MathHelper.clamp(this.t16.getValue(), 0.35F, 2.0F);
   }

      private void dcz() {

      if ("Cube".equalsIgnoreCase(this.targetEspType.getSelected())) {
         this.zskjl = System.currentTimeMillis();
      }
   }

      private float mcmhjy() {

      if (this.zskjl <= 0L) {
         return 1F;
      } else {
         float value = (float)(System.currentTimeMillis() - this.zskjl) / 520.0F;
         if (value >= 1F) {
            this.zskjl = 0L;
            return 1F;
         } else {
            float value2 = (float)Math.sin(Math.PI * MathHelper.clamp(value, 0F, 1F));
            return 1F - this.qllvqu(value2) * 0.08F;
         }
      }
   }

      private void b22() {

      this.zskjl = 0L;
   }

      private CameraBasis fwqaci(Camera camera) {

      Vector3f position = new Vector3f(1F, 0F, 0F).rotate(camera.getRotation());
      Vector3f position2 = new Vector3f(0F, 1F, 0F).rotate(camera.getRotation());
      return new CameraBasis(new Vec3d(position.x, position.y, position.z).normalize(), new Vec3d(position2.x, position2.y, position2.z).normalize());
   }

      private EulerRotation ddd(float speed) {

      float value = 0.85F + (float)Math.sqrt(this.transformMethod890(speed)) * 0.45F;
      float value2 = this.processField30 * 60.0F * value;
      float value3 = value2 / 90.0F;
      int index = (int)Math.floor(value3);
      float value4 = value3 - index;
      float value5 = MathHelper.clamp((value4 - 0.62F) / 0.38F, 0F, 1F);
      EulerRotation moduleData6 = this.dde(index);
      EulerRotation moduleData62 = this.dde(index + 1);
      float value6 = this.qllvqu(value5);
      return new EulerRotation(
         this.rebztr(value6, moduleData6.yaw(), moduleData62.yaw()), this.rebztr(value6, moduleData6.pitch(), moduleData62.pitch()), this.rebztr(value6, moduleData6.roll(), moduleData62.roll())
      );
   }

      private EulerRotation dde(int side) {

      int index = Math.floorDiv(side + 2, 3);
      int index2 = Math.floorDiv(side + 1, 3);
      int index3 = Math.floorDiv(side, 3);
      return new EulerRotation(index * 90.0F, index2 * 90.0F, index3 * 90.0F);
   }

      private float rebztr(float delta, float start, float end) {

      return start + MathHelper.wrapDegrees(end - start) * delta;
   }

      private void ijgfgs(BufferBuilder buffer, Matrix4f matrix, Vec3d center, float halfSize, EulerRotation rotation, float cornerLength, float alpha, float red) {

      float value = this.apycnp() * (0.82F + alpha * 0.18F);
      ModulePosition modulePosition = this.calculateMethod67(rotation.yaw(), rotation.pitch(), rotation.roll());

      for (byte byteValue = -1; byteValue <= 1; byteValue += 2) {
         for (byte byteValue2 = -1; byteValue2 <= 1; byteValue2 += 2) {
            for (byte byteValue3 = -1; byteValue3 <= 1; byteValue3 += 2) {
               int index = (byteValue > 0 ? 1 : 0) + (byteValue2 > 0 ? 2 : 0) + (byteValue3 > 0 ? 4 : 0);
               int index2 = ColorUtils.multAlpha(this.processMethod200(index, 8, red), alpha * (byteValue2 > 0 ? 1F : 0.78F));
               Vec3d position = center.add(modulePosition.x().multiply(byteValue * halfSize))
                  .add(modulePosition.y().multiply(byteValue2 * halfSize))
                  .add(modulePosition.z().multiply(byteValue3 * halfSize));
               this.bbdixk(buffer, matrix, position, modulePosition, byteValue, byteValue2, byteValue3, cornerLength, value, index2);
            }
         }
      }
   }

      private void startMethod530(
      BufferBuilder buffer, Matrix4f matrix, CameraBasis billboard, Vec3d center, float halfSize, EulerRotation rotation, float cornerLength, float alpha, float red
   ) {

      float value = this.apycnp() * (0.82F + alpha * 0.18F);
      float value2 = MathHelper.clamp(value * 4.25F, 0.08F, 0.42F);
      ModulePosition modulePosition = this.calculateMethod67(rotation.yaw(), rotation.pitch(), rotation.roll());

      for (byte byteValue = -1; byteValue <= 1; byteValue += 2) {
         for (byte byteValue2 = -1; byteValue2 <= 1; byteValue2 += 2) {
            for (byte byteValue3 = -1; byteValue3 <= 1; byteValue3 += 2) {
               int index = (byteValue > 0 ? 1 : 0) + (byteValue2 > 0 ? 2 : 0) + (byteValue3 > 0 ? 4 : 0);
               int index2 = ColorUtils.multAlpha(this.processMethod200(index, 8, red), alpha * (byteValue2 > 0 ? 0.2F : 0.16F));
               Vec3d position = center.add(modulePosition.x().multiply(byteValue * halfSize))
                  .add(modulePosition.y().multiply(byteValue2 * halfSize))
                  .add(modulePosition.z().multiply(byteValue3 * halfSize));
               this.getMethod31(buffer, matrix, billboard, position, modulePosition, byteValue, byteValue2, byteValue3, cornerLength, value, value2, index2);
            }
         }
      }
   }

      private Vec3d setMethod21(Vec3d local, double cos, double sin) {

      return new Vec3d(local.x * cos - local.z * sin, local.y, local.x * sin + local.z * cos);
   }

      private Vec3d convertMethod60(Vec3d local, float yaw, float pitch, float roll) {

      double value = Math.toRadians(yaw);
      double value2 = Math.toRadians(pitch);
      double value3 = Math.toRadians(roll);
      double value4 = Math.cos(value);
      double value5 = Math.sin(value);
      double value6 = local.x * value4 - local.z * value5;
      double y2 = local.y;
      double value7 = local.x * value5 + local.z * value4;
      double value8 = Math.cos(value2);
      double value9 = Math.sin(value2);
      double value10 = y2 * value8 - value7 * value9;
      double value11 = y2 * value9 + value7 * value8;
      double value12 = Math.cos(value3);
      double value13 = Math.sin(value3);
      double value14 = value6 * value12 - value10 * value13;
      double value15 = value6 * value13 + value10 * value12;
      return new Vec3d(value14, value15, value11);
   }

      private ModulePosition calculateMethod67(float yaw, float pitch, float roll) {

      return new ModulePosition(
         this.convertMethod60(new Vec3d(1, 0, 0), yaw, pitch, roll).normalize(),
         this.convertMethod60(new Vec3d(0, 1, 0), yaw, pitch, roll).normalize(),
         this.convertMethod60(new Vec3d(0, 0, 1), yaw, pitch, roll).normalize()
      );
   }

      private void bbdixk(BufferBuilder buffer, Matrix4f matrix, Vec3d corner, ModulePosition basis, int sx, int sy, int sz, float cornerLength, float thickness, int color) {

      float value = thickness * 0.5F;
      int index = ColorUtils.multAlpha(color, 1F);
      this.processMethod43(buffer, matrix, corner, basis.x(), basis.y(), basis.z(), value, value, value, index);
      this.handleMethod950(buffer, matrix, corner, corner.subtract(basis.x().multiply(sx * cornerLength)), basis.y(), basis.z(), value, color);
      this.handleMethod950(buffer, matrix, corner, corner.subtract(basis.y().multiply(sy * cornerLength)), basis.x(), basis.z(), value, color);
      this.handleMethod950(buffer, matrix, corner, corner.subtract(basis.z().multiply(sz * cornerLength)), basis.x(), basis.y(), value, color);
   }

      private void getMethod31(
      BufferBuilder buffer,
      Matrix4f matrix,
      CameraBasis billboard,
      Vec3d corner,
      ModulePosition basis,
      int sx,
      int sy,
      int sz,
      float cornerLength,
      float thickness,
      float glowSize,
      int color
   ) {

      float value = thickness * 0.5F;
      this.ddok(
         buffer, matrix, billboard, corner, corner.subtract(basis.x().multiply(sx * cornerLength)), basis.y(), basis.z(), sy, sz, value, glowSize, color
      );
      this.ddok(
         buffer, matrix, billboard, corner, corner.subtract(basis.y().multiply(sy * cornerLength)), basis.x(), basis.z(), sx, sz, value, glowSize, color
      );
      this.ddok(
         buffer, matrix, billboard, corner, corner.subtract(basis.z().multiply(sz * cornerLength)), basis.x(), basis.y(), sx, sy, value, glowSize, color
      );
   }

      private void handleMethod950(BufferBuilder buffer, Matrix4f matrix, Vec3d start, Vec3d end, Vec3d sideAxisA, Vec3d sideAxisB, float halfThickness, int color) {

      Vec3d position = end.subtract(start);
      if (!(position.lengthSquared() < 1E-6)) {
         Vec3d position2 = sideAxisA.normalize().multiply(halfThickness);
         Vec3d position3 = sideAxisB.normalize().multiply(halfThickness);
         Vec3d position4 = start.add(position2).add(position3);
         Vec3d position5 = start.subtract(position2).add(position3);
         Vec3d position6 = start.subtract(position2).subtract(position3);
         Vec3d position7 = start.add(position2).subtract(position3);
         Vec3d position8 = end.add(position2).add(position3);
         Vec3d position9 = end.subtract(position2).add(position3);
         Vec3d position10 = end.subtract(position2).subtract(position3);
         Vec3d position11 = end.add(position2).subtract(position3);
         this.validateMethod17(buffer, matrix, position4, position8, position9, position5, color);
         this.validateMethod17(buffer, matrix, position5, position9, position10, position6, color);
         this.validateMethod17(buffer, matrix, position6, position10, position11, position7, color);
         this.validateMethod17(buffer, matrix, position7, position11, position8, position4, color);
         this.validateMethod17(buffer, matrix, position4, position5, position6, position7, color);
         this.validateMethod17(buffer, matrix, position8, position11, position10, position9, color);
      }
   }

      private void ddok(
      BufferBuilder buffer,
      Matrix4f matrix,
      CameraBasis billboard,
      Vec3d start,
      Vec3d end,
      Vec3d sideAxisA,
      Vec3d sideAxisB,
      int sideSignA,
      int sideSignB,
      float halfThickness,
      float glowSize,
      int color
   ) {

      Vec3d position = end.subtract(start);
      double value = position.length();
      if (!(value < 1E-6)) {
         Vec3d position2 = sideAxisA.normalize().multiply(sideSignA).add(sideAxisB.normalize().multiply(sideSignB)).normalize();
         Vec3d position3 = position2.multiply(halfThickness * 0.25F);
         int index = Math.max(3, MathHelper.ceil(value / Math.max(0.025F, glowSize * 0.38F)));

         for (int index2 = 0; index2 < index; index2++) {
            float value2 = index == 1 ? 0.5F : (float)index2 / (index - 1);
            float value3 = 0.72F + 0.28F * (float)Math.sin(Math.PI * value2);
            Vec3d position4 = start.lerp(end, value2).add(position3);
            this.tpzsst(buffer, matrix, billboard, position4, glowSize, ColorUtils.multAlpha(color, value3));
         }
      }
   }

      private void processMethod43(
      BufferBuilder buffer, Matrix4f matrix, Vec3d center, Vec3d axisX, Vec3d axisY, Vec3d axisZ, float halfX, float halfY, float halfZ, int color
   ) {

      Vec3d position = axisX.normalize().multiply(halfX);
      Vec3d position2 = axisY.normalize().multiply(halfY);
      Vec3d position3 = axisZ.normalize().multiply(halfZ);
      Vec3d position4 = center.subtract(position).subtract(position2).subtract(position3);
      Vec3d position5 = center.subtract(position).subtract(position2).add(position3);
      Vec3d position6 = center.subtract(position).add(position2).subtract(position3);
      Vec3d position7 = center.subtract(position).add(position2).add(position3);
      Vec3d position8 = center.add(position).subtract(position2).subtract(position3);
      Vec3d position9 = center.add(position).subtract(position2).add(position3);
      Vec3d position10 = center.add(position).add(position2).subtract(position3);
      Vec3d position11 = center.add(position).add(position2).add(position3);
      this.validateMethod17(buffer, matrix, position4, position8, position10, position6, color);
      this.validateMethod17(buffer, matrix, position9, position5, position7, position11, color);
      this.validateMethod17(buffer, matrix, position5, position4, position6, position7, color);
      this.validateMethod17(buffer, matrix, position8, position9, position11, position10, color);
      this.validateMethod17(buffer, matrix, position6, position10, position11, position7, color);
      this.validateMethod17(buffer, matrix, position5, position9, position8, position4, color);
   }

      private void validateMethod17(BufferBuilder buffer, Matrix4f matrix, Vec3d p1, Vec3d p2, Vec3d p3, Vec3d p4, int color) {

      buffer.vertex(matrix, (float)p1.x, (float)p1.y, (float)p1.z).color(color);
      buffer.vertex(matrix, (float)p2.x, (float)p2.y, (float)p2.z).color(color);
      buffer.vertex(matrix, (float)p3.x, (float)p3.y, (float)p3.z).color(color);
      buffer.vertex(matrix, (float)p4.x, (float)p4.y, (float)p4.z).color(color);
   }

      private void tpzsst(BufferBuilder buffer, Matrix4f matrix, CameraBasis billboard, Vec3d center, float size, int color) {

      Vec3d position = billboard.right().multiply(size * 0.5F);
      Vec3d position2 = billboard.up().multiply(size * 0.5F);
      Vec3d position3 = center.subtract(position).add(position2);
      Vec3d position4 = center.add(position).add(position2);
      Vec3d position5 = center.add(position).subtract(position2);
      Vec3d position6 = center.subtract(position).subtract(position2);
      buffer.vertex(matrix, (float)position3.x, (float)position3.y, (float)position3.z).texture(0F, 1F).color(color);
      buffer.vertex(matrix, (float)position4.x, (float)position4.y, (float)position4.z).texture(1F, 1F).color(color);
      buffer.vertex(matrix, (float)position5.x, (float)position5.y, (float)position5.z).texture(1F, 0F).color(color);
      buffer.vertex(matrix, (float)position6.x, (float)position6.y, (float)position6.z).texture(0F, 0F).color(color);
   }

      private void ds(LivingEntity attackedEntity) {

      if ("Cube".equalsIgnoreCase(this.targetEspType.getSelected())
         && attackedEntity != null) {
         long timestamp = System.currentTimeMillis();
         if (this.convertField75 != attackedEntity.getId() || timestamp - this.g20 >= 120L) {
            Vec3d position = RenderGeometry.interpolate(attackedEntity);
            float height = Math.max(0.9F, attackedEntity.getHeight());
            float value = this.controlMethod32(attackedEntity);
            this.g20 = timestamp;
            this.convertField75 = attackedEntity.getId();
            this.i21 = new Vec3d(position.x, position.y + height * 0.5F, position.z);
            this.convertField740 = position.y + 0.035;
            this.validateField260 = value;
            this.jkepg = value;
            this.xxvug = value;
            EulerRotation moduleData6 = this.ddd(this.parseMethod38());
            this.rn0 = moduleData6.yaw();
            this.jqxxn = moduleData6.pitch();
            this.sailx = moduleData6.roll();
            ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();
            ModulePosition modulePosition = this.calculateMethod67(this.rn0, this.jqxxn, this.sailx);

            for (int index = 0; index < this.ajrho.length; index++) {
               int index2 = (index & 1) != 0 ? 1 : -1;
               int index3 = (index & 2) != 0 ? 1 : -1;
               int index4 = (index & 4) != 0 ? 1 : -1;
               Vec3d position2 = modulePosition.x().multiply(index2).add(modulePosition.z().multiply(index4)).normalize();
               Vec3d position3 = modulePosition.z().multiply(index2).subtract(modulePosition.x().multiply(index4)).normalize();
               double value2 = threadLocalRandom.nextDouble(0.55, 1.35);
               double value3 = threadLocalRandom.nextDouble(-0.75F, 0.75);
               double value4 = threadLocalRandom.nextDouble(0.55, 1.35) + (index3 > 0 ? 0.12 : 0);
               this.ajrho[index] = position2.multiply(value2).add(position3.multiply(value3)).add(0, value4, 0);
               this.erse[index] = threadLocalRandom.nextFloat() * 300.0F - 150.0F;
               this.rt[index] = threadLocalRandom.nextFloat() * 360.0F - 180.0F;
               this.pvnrk[index] = threadLocalRandom.nextFloat() * 360.0F - 180.0F;
            }
         }
      }
   }

      private void ddt(LivingEntity targetEntity) {

      if (targetEntity != null && (this.convertField75 != targetEntity.getId() || this.g20 <= 0L)) {
         this.ds(targetEntity);
      }
   }

      private boolean u26(LivingEntity currentTarget) {

      if (currentTarget != null && this.g20 > 0L && this.convertField75 == currentTarget.getId()) {
         long timestamp = System.currentTimeMillis() - this.g20;
         long timestamp2 = 1500L;
         return timestamp >= 0L && timestamp <= timestamp2;
      } else {
         return false;
      }
   }

      private void ixqvob(BufferBuilder buffer, Matrix4f matrix, LivingEntity currentTarget, float red) {

      if (currentTarget != null && this.g20 > 0L && this.convertField75 == currentTarget.getId()) {
         long timestamp = System.currentTimeMillis() - this.g20;
         long timestamp2 = 1500L;
         if (timestamp >= 0L && timestamp <= timestamp2) {
            float value = (float)timestamp / 1000.0F;
            float value2 = MathHelper.clamp((float)timestamp / 850.0F, 0F, 1F);
            float value3 = timestamp <= 850L ? 0F : (float)(timestamp - 850L) / 650.0F;
            float value4 = 1F - this.qllvqu(value2) * 0.22F;
            float value5 = value4 * (1F - this.qllvqu(value3)) * 0.95F;
            if (!(value5 <= 0.02F)) {
               float value6 = Math.max(0.16F, this.validateField260 * 0.38F);
               float value7 = this.apycnp() * (0.96F - 0.18F * value3);

               for (byte byteValue = -1; byteValue <= 1; byteValue += 2) {
                  for (byte byteValue2 = -1; byteValue2 <= 1; byteValue2 += 2) {
                     for (byte byteValue3 = -1; byteValue3 <= 1; byteValue3 += 2) {
                        int index = (byteValue > 0 ? 1 : 0) + (byteValue2 > 0 ? 2 : 0) + (byteValue3 > 0 ? 4 : 0);
                        int index2 = ColorUtils.multAlpha(this.processMethod200(index, 8, red), value5 * (byteValue2 > 0 ? 1F : 0.78F));
                        Vec3d position = this.ajrho[index] == null ? Vec3d.ZERO : this.ajrho[index];
                        Vec3d position2 = new Vec3d(byteValue * this.validateField260, byteValue2 * this.xxvug, byteValue3 * this.jkepg);
                        Vec3d position3 = this.i21.add(this.convertMethod60(position2, this.rn0, this.jqxxn, this.sailx));
                        Vec3d position4 = this.ddx(position3, position, value, this.convertField740);
                        float value8 = this.rn0 + this.erse[index] * value;
                        float value9 = this.jqxxn + this.rt[index] * value;
                        float value10 = this.sailx + this.pvnrk[index] * value;
                        ModulePosition modulePosition = this.calculateMethod67(value8, value9, value10);
                        this.bbdixk(buffer, matrix, position4, modulePosition, byteValue, byteValue2, byteValue3, value6, value7, index2);
                     }
                  }
               }
            }
         } else {
            this.convertMethod75();
         }
      }
   }

      private void removeMethod88(BufferBuilder buffer, Matrix4f matrix, CameraBasis billboard, LivingEntity currentTarget, float red) {

      if (currentTarget != null && this.g20 > 0L && this.convertField75 == currentTarget.getId()) {
         long timestamp = System.currentTimeMillis() - this.g20;
         long timestamp2 = 1500L;
         if (timestamp >= 0L && timestamp <= timestamp2) {
            float value = (float)timestamp / 1000.0F;
            float value2 = MathHelper.clamp((float)timestamp / 850.0F, 0F, 1F);
            float value3 = timestamp <= 850L ? 0F : (float)(timestamp - 850L) / 650.0F;
            float value4 = 1F - this.qllvqu(value2) * 0.22F;
            float value5 = value4 * (1F - this.qllvqu(value3)) * 0.3F;
            if (!(value5 <= 0.01F)) {
               float value6 = Math.max(0.16F, this.validateField260 * 0.38F);
               float value7 = this.apycnp() * (0.96F - 0.18F * value3);
               float value8 = MathHelper.clamp(value7 * 4.25F, 0.08F, 0.42F);

               for (byte byteValue = -1; byteValue <= 1; byteValue += 2) {
                  for (byte byteValue2 = -1; byteValue2 <= 1; byteValue2 += 2) {
                     for (byte byteValue3 = -1; byteValue3 <= 1; byteValue3 += 2) {
                        int index = (byteValue > 0 ? 1 : 0) + (byteValue2 > 0 ? 2 : 0) + (byteValue3 > 0 ? 4 : 0);
                        int index2 = ColorUtils.multAlpha(this.processMethod200(index, 8, red), value5 * (byteValue2 > 0 ? 1F : 0.78F));
                        Vec3d position = this.ajrho[index] == null ? Vec3d.ZERO : this.ajrho[index];
                        Vec3d position2 = new Vec3d(byteValue * this.validateField260, byteValue2 * this.xxvug, byteValue3 * this.jkepg);
                        Vec3d position3 = this.i21.add(this.convertMethod60(position2, this.rn0, this.jqxxn, this.sailx));
                        Vec3d position4 = this.ddx(position3, position, value, this.convertField740);
                        float value9 = this.rn0 + this.erse[index] * value;
                        float value10 = this.jqxxn + this.rt[index] * value;
                        float value11 = this.sailx + this.pvnrk[index] * value;
                        ModulePosition modulePosition = this.calculateMethod67(value9, value10, value11);
                        this.getMethod31(buffer, matrix, billboard, position4, modulePosition, byteValue, byteValue2, byteValue3, value6, value7, value8, index2);
                     }
                  }
               }
            }
         }
      }
   }

      private Vec3d ddx(Vec3d start, Vec3d velocity, float elapsedSeconds, double groundY) {

      double value = 4.2;
      double value2 = elapsedSeconds;
      double value3 = start.y + velocity.y * elapsedSeconds - 0.5 * value * elapsedSeconds * elapsedSeconds;
      if (value3 <= groundY) {
         double value4 = Math.max(0, start.y - groundY);
         double value5 = (velocity.y + Math.sqrt(Math.max(0, velocity.y * velocity.y + 2.0 * value * value4))) / value;
         value5 = MathHelper.clamp(value5, 0, elapsedSeconds);
         double value6 = elapsedSeconds - value5;
         double value7 = velocity.y - value * value5;
         double value8 = Math.max(0, -value7 * 0.28);
         double value9 = groundY + value8 * value6 - 0.5 * value * value6 * value6;
         value3 = Math.max(groundY, value9);
         value2 = value5 + (1 - Math.exp(-value6 * 4.6)) / 4.6;
      }

      return new Vec3d(start.x + velocity.x * value2, value3, start.z + velocity.z * value2);
   }

      private void convertMethod75() {

      this.g20 = 0L;
      this.convertField75 = -1;
      this.i21 = Vec3d.ZERO;
      this.convertField740 = 0;
      this.validateField260 = 0F;
      this.xxvug = 0F;
      this.jkepg = 0F;
      this.rn0 = 0F;
      this.jqxxn = 0F;
      this.sailx = 0F;

      for (int index = 0; index < this.ajrho.length; index++) {
         this.ajrho[index] = null;
         this.erse[index] = 0F;
         this.rt[index] = 0F;
         this.pvnrk[index] = 0F;
      }
   }

      private void dz(VertexMatrixRenderer event, LivingEntity currentTarget, float anim, float red, float speed) {

      if (event != null && currentTarget != null && MinecraftClient.getInstance().player != null && !(anim <= 0.01F)) {
         Vec3d position = RenderGeometry.interpolate(currentTarget);
         float height = Math.max(0.9F, currentTarget.getHeight());
         float width = Math.max(0.45F, currentTarget.getWidth());
         float value = MathHelper.clamp(this.esu.getValue(), 0.3F, 2.0F);
         float value2 = MathHelper.clamp(height * 0.5F, 0.58F, 0.92F) * value * anim;
         float value3 = value2 / 16.0F;
         float value4 = Math.max(0.1F, value3 * 1.35F);
         float value5 = (width * 1.1F + this.v29.getValue()) * (0.78F + anim * 0.22F);
         float value6 = MathHelper.clamp(this.sw1.getValue(), 0.05F, 1F);
         float value7 = (float)position.y + height * 0.5F - value2 * 0.5F;
         float value8 = value2 * 0.5F;
         double value9 = this.parseMethod67(speed);
         Matrix4f matrix = event.getStack().peek().getPositionMatrix();
         Vec3d client = MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getPos();
         RenderSystem.enableDepthTest();
         RenderSystem.depthMask(true);
         RenderSystem.enableBlend();
         RenderSystem.disableCull();
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
         RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
         BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);

         for (int index = 0; index < 4; index++) {
            double value10 = value9 + index * (Math.PI / 2);
            float value11 = (float)Math.cos(value10);
            float value12 = (float)Math.sin(value10);
            float value13 = -value12;
            float value14 = value11;
            float value15 = (float)position.x + value11 * value5;
            float value16 = (float)position.z + value12 * value5;
            int index2 = ColorUtils.multAlpha(this.processMethod200(index * 90, 360, red), 0.96F * anim * value6);
            int index3 = index2;

            for (int index4 = 0; index4 < destroyField531.length; index4++) {
               for (int index5 = 0; index5 < destroyField531[index4].length; index5++) {
                  if (destroyField531[index4][index5]) {
                     float value17 = (index5 - 8.0F) * value3;
                     float value18 = value17 + value3;
                     float value19 = (15 - index4) * value3;
                     float value20 = value19 + value3;
                     if (index5 == 0 || !destroyField531[index4][index5 - 1]) {
                        this.qvrite(
                           bufferBuilder,
                           matrix,
                           value15,
                           value7,
                           value16,
                           value13,
                           value14,
                           value11,
                           value12,
                           value17,
                           value19,
                           -value4 * 0.5F,
                           value17,
                           value19,
                           value4 * 0.5F,
                           value17,
                           value20,
                           value4 * 0.5F,
                           value17,
                           value20,
                           -value4 * 0.5F,
                           value8,
                           index3
                        );
                     }

                     if (index5 == destroyField531[index4].length - 1 || !destroyField531[index4][index5 + 1]) {
                        this.qvrite(
                           bufferBuilder,
                           matrix,
                           value15,
                           value7,
                           value16,
                           value13,
                           value14,
                           value11,
                           value12,
                           value18,
                           value19,
                           -value4 * 0.5F,
                           value18,
                           value20,
                           -value4 * 0.5F,
                           value18,
                           value20,
                           value4 * 0.5F,
                           value18,
                           value19,
                           value4 * 0.5F,
                           value8,
                           index3
                        );
                     }

                     if (index4 == 0 || !destroyField531[index4 - 1][index5]) {
                        this.qvrite(
                           bufferBuilder,
                           matrix,
                           value15,
                           value7,
                           value16,
                           value13,
                           value14,
                           value11,
                           value12,
                           value17,
                           value20,
                           -value4 * 0.5F,
                           value17,
                           value20,
                           value4 * 0.5F,
                           value18,
                           value20,
                           value4 * 0.5F,
                           value18,
                           value20,
                           -value4 * 0.5F,
                           value8,
                           index3
                        );
                     }

                     if (index4 == destroyField531.length - 1 || !destroyField531[index4 + 1][index5]) {
                        this.qvrite(
                           bufferBuilder,
                           matrix,
                           value15,
                           value7,
                           value16,
                           value13,
                           value14,
                           value11,
                           value12,
                           value17,
                           value19,
                           -value4 * 0.5F,
                           value18,
                           value19,
                           -value4 * 0.5F,
                           value18,
                           value19,
                           value4 * 0.5F,
                           value17,
                           value19,
                           value4 * 0.5F,
                           value8,
                           index3
                        );
                     }
                  }
               }
            }
         }

         BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
         BufferBuilder bufferBuilder2 = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);

         for (int index6 = 0; index6 < 4; index6++) {
            double value21 = value9 + index6 * (Math.PI / 2);
            float value22 = (float)Math.cos(value21);
            float value23 = (float)Math.sin(value21);
            float value24 = -value23;
            float value25 = value22;
            float value26 = (float)position.x + value22 * value5;
            float value27 = (float)position.z + value23 * value5;
            int index7 = ColorUtils.multAlpha(this.processMethod200(index6 * 90, 360, red), 0.96F * anim * value6);
            boolean enabled = this.validateMethod71(client, value26, value27, value22, value23);
            float value28 = enabled ? value4 * 0.5F : -value4 * 0.5F;
            int index8 = index7;

            for (HorizontalSpan moduleRange3 : runField51) {
               float value29 = (moduleRange3.xStart() - 8.0F) * value3;
               float value30 = (moduleRange3.xEnd() - 8.0F) * value3;
               float value31 = (15 - moduleRange3.row()) * value3;
               float value32 = value31 + value3;
               if (enabled) {
                  this.qvrite(
                     bufferBuilder2,
                     matrix,
                     value26,
                     value7,
                     value27,
                     value24,
                     value25,
                     value22,
                     value23,
                     value29,
                     value31,
                     value28,
                     value30,
                     value31,
                     value28,
                     value30,
                     value32,
                     value28,
                     value29,
                     value32,
                     value28,
                     value8,
                     index8
                  );
               } else {
                  this.qvrite(
                     bufferBuilder2,
                     matrix,
                     value26,
                     value7,
                     value27,
                     value24,
                     value25,
                     value22,
                     value23,
                     value30,
                     value31,
                     value28,
                     value29,
                     value31,
                     value28,
                     value29,
                     value32,
                     value28,
                     value30,
                     value32,
                     value28,
                     value8,
                     index8
                  );
               }
            }
         }

         BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
         if (this.esx.isValue()) {
            RenderSystem.setShader(ShaderProgramKeys.RENDERTYPE_LINES);
            RenderSystem.lineWidth(2.8F);
            BufferBuilder bufferBuilder3 = Tessellator.getInstance().begin(DrawMode.LINES, VertexFormats.LINES);

            for (int index9 = 0; index9 < 4; index9++) {
               double value33 = value9 + index9 * (Math.PI / 2);
               float value34 = (float)Math.cos(value33);
               float value35 = (float)Math.sin(value33);
               float value36 = -value35;
               float value37 = (float)position.x + value34 * value5;
               float value38 = (float)position.z + value35 * value5;
               int index10 = ColorUtils.multAlpha(this.processMethod200(index9 * 90, 360, red), 0.98F * anim * value6);
               this.runMethod40(bufferBuilder3, matrix, value37, value7, value38, value36, value34, value34, value35, value3, value4, value8, index10);
            }

            BufferRenderer.drawWithGlobalProgram(bufferBuilder3.end());
         }

         RenderSystem.depthMask(true);
         RenderStateGuard.restoreWorldDefaults();
      }
   }

      private boolean validateMethod71(Vec3d cameraPos, float centerX, float centerZ, float radialX, float radialZ) {

      float value = (float)cameraPos.x - centerX;
      float value2 = (float)cameraPos.z - centerZ;
      return value * radialX + value2 * radialZ >= 0F;
   }

      private void runMethod40(
      BufferBuilder bufferBuilder,
      Matrix4f matrix,
      float baseX,
      float baseY,
      float baseZ,
      float tangentX,
      float tangentZ,
      float radialX,
      float radialZ,
      float pixelSize,
      float thickness,
      float rotationPivotY,
      int color
   ) {

      float value = -thickness * 0.5F;
      float value2 = thickness * 0.5F;

      for (int index = 0; index < destroyField531.length; index++) {
         for (int index2 = 0; index2 < destroyField531[index].length; index2++) {
            if (destroyField531[index][index2]) {
               float value3 = (index2 - 8.0F) * pixelSize;
               float value4 = value3 + pixelSize;
               float value5 = (15 - index) * pixelSize;
               float value6 = value5 + pixelSize;
               if (index2 == 0 || !destroyField531[index][index2 - 1]) {
                  this.removeMethod53(
                     bufferBuilder,
                     matrix,
                     baseX,
                     baseY,
                     baseZ,
                     tangentX,
                     tangentZ,
                     radialX,
                     radialZ,
                     value3,
                     value5,
                     value3,
                     value6,
                     value,
                     value2,
                     rotationPivotY,
                     color
                  );
               }

               if (index2 == destroyField531[index].length - 1 || !destroyField531[index][index2 + 1]) {
                  this.removeMethod53(
                     bufferBuilder,
                     matrix,
                     baseX,
                     baseY,
                     baseZ,
                     tangentX,
                     tangentZ,
                     radialX,
                     radialZ,
                     value4,
                     value5,
                     value4,
                     value6,
                     value,
                     value2,
                     rotationPivotY,
                     color
                  );
               }

               if (index == 0 || !destroyField531[index - 1][index2]) {
                  this.removeMethod53(
                     bufferBuilder,
                     matrix,
                     baseX,
                     baseY,
                     baseZ,
                     tangentX,
                     tangentZ,
                     radialX,
                     radialZ,
                     value3,
                     value6,
                     value4,
                     value6,
                     value,
                     value2,
                     rotationPivotY,
                     color
                  );
               }

               if (index == destroyField531.length - 1 || !destroyField531[index + 1][index2]) {
                  this.removeMethod53(
                     bufferBuilder,
                     matrix,
                     baseX,
                     baseY,
                     baseZ,
                     tangentX,
                     tangentZ,
                     radialX,
                     radialZ,
                     value3,
                     value5,
                     value4,
                     value5,
                     value,
                     value2,
                     rotationPivotY,
                     color
                  );
               }
            }
         }
      }
   }

      private void removeMethod53(
      BufferBuilder bufferBuilder,
      Matrix4f matrix,
      float baseX,
      float baseY,
      float baseZ,
      float tangentX,
      float tangentZ,
      float radialX,
      float radialZ,
      float x1,
      float y1,
      float x2,
      float y2,
      float zMin,
      float zMax,
      float rotationPivotY,
      int color
   ) {

      this.deeg(bufferBuilder, matrix, baseX, baseY, baseZ, tangentX, tangentZ, radialX, radialZ, x1, y1, zMax, x2, y2, zMax, rotationPivotY, color);
      this.deeg(bufferBuilder, matrix, baseX, baseY, baseZ, tangentX, tangentZ, radialX, radialZ, x1, y1, zMin, x2, y2, zMin, rotationPivotY, color);
      this.deeg(bufferBuilder, matrix, baseX, baseY, baseZ, tangentX, tangentZ, radialX, radialZ, x1, y1, zMin, x1, y1, zMax, rotationPivotY, color);
      this.deeg(bufferBuilder, matrix, baseX, baseY, baseZ, tangentX, tangentZ, radialX, radialZ, x2, y2, zMin, x2, y2, zMax, rotationPivotY, color);
   }

      private void qvrite(
      BufferBuilder bufferBuilder,
      Matrix4f matrix,
      float baseX,
      float baseY,
      float baseZ,
      float tangentX,
      float tangentZ,
      float radialX,
      float radialZ,
      float x1,
      float y1,
      float z1,
      float x2,
      float y2,
      float z2,
      float x3,
      float y3,
      float z3,
      float x4,
      float y4,
      float z4,
      float rotationPivotY,
      int color
   ) {

      float value = this.destroyMethod220(x1, y1, rotationPivotY);
      float value2 = this.degb(x1, y1, rotationPivotY);
      float value3 = this.destroyMethod220(x2, y2, rotationPivotY);
      float value4 = this.degb(x2, y2, rotationPivotY);
      float value5 = this.destroyMethod220(x3, y3, rotationPivotY);
      float value6 = this.degb(x3, y3, rotationPivotY);
      float value7 = this.destroyMethod220(x4, y4, rotationPivotY);
      float value8 = this.degb(x4, y4, rotationPivotY);
      this.eh(
         bufferBuilder,
         matrix,
         baseX + tangentX * value + radialX * z1,
         baseY + value2,
         baseZ + tangentZ * value + radialZ * z1,
         baseX + tangentX * value3 + radialX * z2,
         baseY + value4,
         baseZ + tangentZ * value3 + radialZ * z2,
         baseX + tangentX * value5 + radialX * z3,
         baseY + value6,
         baseZ + tangentZ * value5 + radialZ * z3,
         baseX + tangentX * value7 + radialX * z4,
         baseY + value8,
         baseZ + tangentZ * value7 + radialZ * z4,
         color
      );
   }

      private void deeg(
      BufferBuilder bufferBuilder,
      Matrix4f matrix,
      float baseX,
      float baseY,
      float baseZ,
      float tangentX,
      float tangentZ,
      float radialX,
      float radialZ,
      float x1,
      float y1,
      float z1,
      float x2,
      float y2,
      float z2,
      float rotationPivotY,
      int color
   ) {

      float value = this.destroyMethod220(x1, y1, rotationPivotY);
      float value2 = this.degb(x1, y1, rotationPivotY);
      float value3 = this.destroyMethod220(x2, y2, rotationPivotY);
      float value4 = this.degb(x2, y2, rotationPivotY);
      float value5 = baseX + tangentX * value + radialX * z1;
      float value6 = baseY + value2;
      float value7 = baseZ + tangentZ * value + radialZ * z1;
      float value8 = baseX + tangentX * value3 + radialX * z2;
      float value9 = baseY + value4;
      float value10 = baseZ + tangentZ * value3 + radialZ * z2;
      float value11 = value8 - value5;
      float value12 = value9 - value6;
      float value13 = value10 - value7;
      float value14 = value11 * value11 + value12 * value12 + value13 * value13;
      if (value14 > 1E-6F) {
         float value15 = (float)(1 / Math.sqrt(value14));
         value11 *= value15;
         value12 *= value15;
         value13 *= value15;
      } else {
         value11 = 0F;
         value12 = 1F;
         value13 = 0F;
      }

      bufferBuilder.vertex(matrix, value5, value6, value7).color(color).normal(value11, value12, value13);
      bufferBuilder.vertex(matrix, value8, value9, value10).color(color).normal(value11, value12, value13);
   }

      private float destroyMethod220(float x, float BooleanSetting, float pivotY) {

      float value = BooleanSetting - pivotY;
      return x * sphvd - value * ql0;
   }

      private float degb(float x, float BooleanSetting, float pivotY) {

      float value = BooleanSetting - pivotY;
      return x * ql0 + value * sphvd + pivotY;
   }

      private void eh(
      BufferBuilder bufferBuilder,
      Matrix4f matrix,
      float x1,
      float y1,
      float z1,
      float x2,
      float y2,
      float z2,
      float x3,
      float y3,
      float z3,
      float x4,
      float y4,
      float z4,
      int color
   ) {

      bufferBuilder.vertex(matrix, x1, y1, z1).color(color);
      bufferBuilder.vertex(matrix, x2, y2, z2).color(color);
      bufferBuilder.vertex(matrix, x3, y3, z3).color(color);
      bufferBuilder.vertex(matrix, x4, y4, z4).color(color);
   }

      private int hjfgkd(int color, float factor) {

      int index = color >>> 24;
      int index2 = Math.min(255, Math.max(0, (int)((color >> 16 & 0xFF) * factor)));
      int index3 = Math.min(255, Math.max(0, (int)((color >> 8 & 0xFF) * factor)));
      int index4 = Math.min(255, Math.max(0, (int)((color & 0xFF) * factor)));
      return index << 24 | index2 << 16 | index3 << 8 | index4;
   }

      private void uahkmv(
      MatrixStack matrix,
      LivingEntity currentTarget,
      float anim,
      float red,
      boolean whiteOutline,
      boolean fillEnabled,
      float outlineWidth,
      float radius,
      float speed
   ) {

      ColorUtils.UI_CONTEXT.set(false);
      Vec3d position = RenderGeometry.interpolate(currentTarget);
      float height = currentTarget.getHeight();
      double client = MinecraftClient.getInstance().player.squaredDistanceTo(position.x, position.y, position.z);
      float value = (float)Math.max(0.5, Math.min(2.0, 10.0 / Math.sqrt(client)));
      float width = outlineWidth * value;
      float value2 = this.dcr(speed);
      boolean enabled = value2 > 0.5F;
      double value3 = enabled ? (value2 - 0.5F) * 2.0 : 1 - value2 * 2.0;
      value3 = value3 < 0.5 ? 2.0 * value3 * value3 : 1 - Math.pow(-2.0F * value3 + 2.0, 2.0) / 2.0;
      double value4 = height / 1.7F * (value3 > 0.5 ? 1 - value3 : value3) * (enabled ? -1F : 1);
      GL11.glDepthMask(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      RenderSystem.enableDepthTest();
      RenderSystem.enableBlend();
      RenderSystem.disableCull();
      RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
      RenderSystem.lineWidth(1F);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      float width2 = currentTarget.getWidth() * radius;
      if (fillEnabled) {
         GL11.glDepthMask(false);
         BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
         int index = this.processMethod200(0, 360, red);
         int index2 = ColorUtils.multAlpha(index, 0.15F * anim);
         bufferBuilder.vertex(matrix.peek().getPositionMatrix(), (float)position.x, (float)(position.y + height * value3), (float)position.z)
            .color(index2);

         for (int index3 = 0; index3 <= 360; index3++) {
            int index4 = this.processMethod200(index3, 360, red);
            int index5 = ColorUtils.multAlpha(index4, 0.1F * anim);
            float value5 = ckuyl[index3];
            float value6 = destroyField17[index3];
            bufferBuilder.vertex(
                  matrix.peek().getPositionMatrix(),
                  (float)(position.x + value5 * width2),
                  (float)(position.y + height * value3),
                  (float)(position.z + value6 * width2)
               )
               .color(index5);
         }

         BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      }

      BufferBuilder bufferBuilder2 = Tessellator.getInstance().begin(DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);

      for (int index6 = 0; index6 <= 360; index6++) {
         int index7 = this.processMethod200(index6, 360, red);
         float value7 = ckuyl[index6];
         float value8 = destroyField17[index6];
         int index8 = ColorUtils.multAlpha(index7, 0.45F * anim);
         bufferBuilder2.vertex(
               matrix.peek().getPositionMatrix(),
               (float)(position.x + value7 * width2),
               (float)(position.y + height * value3),
               (float)(position.z + value8 * width2)
            )
            .color(index8);
         float value9 = (float)(value4 * 0.5);
         int index9 = ColorUtils.multAlpha(index7, 0.25F * anim);
         bufferBuilder2.vertex(
               matrix.peek().getPositionMatrix(),
               (float)(position.x + value7 * width2),
               (float)(position.y + height * value3 + value9),
               (float)(position.z + value8 * width2)
            )
            .color(index9);
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
      bufferBuilder2 = Tessellator.getInstance().begin(DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);

      for (int index10 = 0; index10 <= 360; index10++) {
         int index11 = this.processMethod200(index10, 360, red);
         float value10 = ckuyl[index10];
         float value11 = destroyField17[index10];
         float value12 = (float)(value4 * 0.5);
         int index12 = ColorUtils.multAlpha(index11, 0.25F * anim);
         bufferBuilder2.vertex(
               matrix.peek().getPositionMatrix(),
               (float)(position.x + value10 * width2),
               (float)(position.y + height * value3 + value12),
               (float)(position.z + value11 * width2)
            )
            .color(index12);
         int index13 = ColorUtils.multAlpha(index11, 0F);
         bufferBuilder2.vertex(
               matrix.peek().getPositionMatrix(),
               (float)(position.x + value10 * width2),
               (float)(position.y + height * value3 + (float)value4),
               (float)(position.z + value11 * width2)
            )
            .color(index13);
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
      RenderSystem.setShader(ShaderProgramKeys.RENDERTYPE_LINES);
      RenderSystem.lineWidth(width);
      bufferBuilder2 = Tessellator.getInstance().begin(DrawMode.LINES, VertexFormats.LINES);
      Entry entry = matrix.peek();
      int index14 = whiteOutline ? ColorUtils.multAlpha(-1, 0.9F * anim) : 0;

      for (int index15 = 0; index15 < 360; index15++) {
         int index16;
         int index17;
         if (whiteOutline) {
            index16 = index14;
            index17 = index14;
         } else {
            int index18 = this.processMethod200(index15, 360, red);
            int index19 = this.processMethod200(index15 + 1, 360, red);
            index16 = ColorUtils.multAlpha(index18, 0.9F * anim);
            index17 = ColorUtils.multAlpha(index19, 0.9F * anim);
         }

         float value13 = ckuyl[index15];
         float value14 = destroyField17[index15];
         float value15 = ckuyl[index15 + 1];
         float value16 = destroyField17[index15 + 1];
         float value17 = (float)(position.x + value13 * width2);
         float value18 = (float)(position.y + height * value3);
         float value19 = (float)(position.z + value14 * width2);
         float value20 = (float)(position.x + value15 * width2);
         float value21 = (float)(position.z + value16 * width2);
         float value22 = value17 - value20;
         float value23 = value19 - value21;
         float value24 = MathHelper.inverseSqrt(value22 * value22 + value23 * value23);
         value22 *= value24;
         value23 *= value24;
         bufferBuilder2.vertex(entry, value17, value18, value19).color(index16).normal(entry, value22, 0F, value23);
         bufferBuilder2.vertex(entry, value20, value18, value21).color(index17).normal(entry, value22, 0F, value23);
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
      GL11.glDepthMask(true);
      GL11.glDisable(2848);
      GL11.glHint(3154, 4352);
      ColorUtils.UI_CONTEXT.set(true);
   }

      private void ek(
      LivingEntity currentTarget,
      float anim,
      float red,
      int length,
      float startSize,
      float endSize,
      float speed,
      float brightness,
      String trajectory,
      int ghostCount
   ) {

      Camera client = MinecraftClient.getInstance().getEntityRenderDispatcher().camera;
      Vec3d position = client.getPos();
      Vec3d position2 = RenderGeometry.interpolate(currentTarget).subtract(position);
      double value = this.parseMethod67(speed);
      float height = currentTarget.getHeight() / 2.0F + 0.1F;
      float width = currentTarget.getWidth();
      float value2 = width * 1.6F * 0.7F;
      int index = Math.max(1, Math.min(6, ghostCount));
      float value3 = 3.0F;
      float value4 = (float)(System.currentTimeMillis() % (long)(value3 * 1000.0F)) / (value3 * 1000.0F);
      int index2 = this.addMethod92(value4, red);
      int index3 = Math.max(1, length);
      byte byteValue = 5;
      int index4 = Math.max(1, index3 * byteValue);
      double value5 = Math.toRadians(this.t17(index3));
      MatrixStack matrices = new MatrixStack();
      Identifier identifier = ParticleTextures.BLOOM;

      for (int index5 = 0; index5 < index; index5++) {
         for (int index6 = 0; index6 <= index4; index6++) {
            float value6 = (float)index6 / index4;
            float value7 = value6 * index3;
            double value8 = Math.toRadians(360.0 / index) * index5;
            float value9;
            float value10;
            float value11;
            switch (trajectory) {
               case "Helix":
                  double value12 = value + value8 - value5 * value6;
                  double value13 = Math.sin(value * 1.35 - value7 * 0.35 - index5 * 0.25) / 2.0;
                  value9 = (float)(position2.x + Math.cos(value12) * value2);
                  value10 = (float)(position2.y + height + value13);
                  value11 = (float)(position2.z + Math.sin(value12) * value2);
                  break;
               case "Orbit":
                  int index7 = index5 / 3;
                  int index8 = (index + 2) / 3;
                  double value14 = index7 * Math.PI * 2.0 / index8;
                  double value15 = value + value14 - value5 * value6;
                  double value16 = Math.sin(value15) * value2;
                  double value17 = Math.cos(value15) * value2;
                  double value18 = 0;
                  double value19 = 0;
                  double value20 = 0;
                  switch (index5 % 3) {
                     case 0:
                        value18 = value16;
                        value19 = value17;
                        value20 = -value17;
                        break;
                     case 1:
                        value18 = -value16;
                        value19 = value16;
                        value20 = -value17;
                        break;
                     case 2:
                        value18 = value16;
                        value19 = -value17;
                        value20 = -value17;
                  }

                  value9 = (float)(position2.x + value18);
                  value10 = (float)(position2.y + height + value19);
                  value11 = (float)(position2.z + value20);
                  break;
               case "Chaos":
                  double value21 = value8 + value * 0.25;
                  double value22 = value8 * 1.618 + value * 0.3;
                  double value23 = value8 * 2.618 + value * 0.2;
                  double value24 = Math.cos(value21);
                  double value25 = Math.sin(value21);
                  double value26 = Math.cos(value22);
                  double value27 = Math.sin(value22);
                  double value28 = Math.cos(value23);
                  double value29 = Math.sin(value23);
                  double value30 = value + value8 - value5 * value6;
                  double value31 = value30 * 2.0 + index5;
                  double value32 = Math.cos(value31) * value2;
                  double value33 = Math.sin(value31) * value2;
                  double value34 = 0;
                  double value35 = value33 * value24 - value34 * value25;
                  double value36 = value33 * value25 + value34 * value24;
                  double value37 = value32 * value26 + value36 * value27;
                  value36 = -value32 * value27 + value36 * value26;
                  double value38 = value37 * value28 - value35 * value29;
                  value35 = value37 * value29 + value35 * value28;
                  value9 = (float)(position2.x + value38);
                  value10 = (float)(position2.y + height + value35);
                  value11 = (float)(position2.z + value36);
                  break;
               default:
                  double value39 = value + value8 - value5 * value6;
                  double value40 = Math.sin(value * 1.35 - value7 * 0.35 - index5 * 0.25) / 2.0;
                  value9 = (float)(position2.x + Math.cos(value39) * value2);
                  value10 = (float)(position2.y + height + value40);
                  value11 = (float)(position2.z + Math.sin(value39) * value2);
            }

            float value41 = 1F - value6;
            matrices.push();
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(client.getYaw() + 180.0F));
            matrices.translate(value9, value10, value11);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-client.getYaw()));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
            Entry entry = matrices.peek().copy();
            float value42 = brightness / 100.0F;
            float value43 = value41 * value41 * value42;
            int index9 = index2 >> 16 & 0xFF;
            int index10 = index2 >> 8 & 0xFF;
            int index11 = index2 & 0xFF;
            index9 = (int)(index9 + (255 - index9) * value43);
            index10 = (int)(index10 + (255 - index10) * value43);
            index11 = (int)(index11 + (255 - index11) * value43);
            int index12 = 0xFF000000 | index9 << 16 | index10 << 8 | index11;
            int index13 = ColorUtils.multAlpha(index12, value41 * anim);
            float value44 = MathHelper.lerp(value6, startSize, endSize) * anim;
            if (value44 <= 0.01F) {
               matrices.pop();
            } else {
               deut(entry, identifier, value44, index13);
               matrices.pop();
            }
         }
      }
   }

      private Vector4i handleMethod52(float red, float anim) {

      int index = this.setMethod52(this.getVisualColor(), red);
      return new Vector4i(index, index, index, index);
   }

      private Color executeMethod32(int color1, int color2, float factor) {

      int index = color1 >> 24 & 0xFF;
      int index2 = color1 >> 16 & 0xFF;
      int index3 = color1 >> 8 & 0xFF;
      int index4 = color1 & 0xFF;
      int index5 = color2 >> 24 & 0xFF;
      int index6 = color2 >> 16 & 0xFF;
      int index7 = color2 >> 8 & 0xFF;
      int index8 = color2 & 0xFF;
      int index9 = (int)(index + (index5 - index) * factor);
      int index10 = (int)(index2 + (index6 - index2) * factor);
      int index11 = (int)(index3 + (index7 - index3) * factor);
      int index12 = (int)(index4 + (index8 - index4) * factor);
      return new Color(index9 << 24 | index10 << 16 | index11 << 8 | index12, true);
   }

      private int processMethod200(int segmentIndex, int totalSegments, float red) {

      return this.setMethod52(this.getVisualColor(), red);
   }

      private int addMethod92(float colorProgress, float red) {

      return this.setMethod52(this.getVisualColor(), red);
   }

      private int setMethod52(int baseColor, float red) {

      if (!(red <= 0F) && this.colorOnHit.isValue()) {
         int index = this.parseMethod380();
         float value = 1F - (float)Math.pow(1F - red, 3.0);
         int index2 = baseColor >> 16 & 0xFF;
         int index3 = baseColor >> 8 & 0xFF;
         int index4 = baseColor & 0xFF;
         int index5 = index >> 16 & 0xFF;
         int index6 = index >> 8 & 0xFF;
         int index7 = index & 0xFF;
         int index8 = (int)(index2 + (index5 - index2) * value);
         int index9 = (int)(index3 + (index6 - index3) * value);
         int index10 = (int)(index4 + (index7 - index4) * value);
         return baseColor & 0xFF000000 | index8 << 16 | index9 << 8 | index10;
      } else {
         return baseColor;
      }
   }

      private float eq(NumberSetting setting, float min, float max) {

      float value = setting.getValue();
      if (value > 2.0F) {
         value /= 100.0F;
         setting.setValue(value);
      }

      float value2 = MathHelper.clamp(value, min, max);
      if (value2 != value) {
         setting.setValue(value2);
      }

      return value2;
   }

      private int handleMethod51() {

      int index = MathHelper.clamp(this.processField910.getInt(), 1, 20);
      if (index != this.processField910.getInt()) {
         this.processField910.setValue(index);
      }

      return index;
   }

      private String es0() {

      String text = this.gecnb.getSelected();
      boolean enabled = "Worm".equalsIgnoreCase(text)
         || "Double".equalsIgnoreCase(text)
         || "Rockstar".equalsIgnoreCase(text);
      boolean enabled2 = text == null || this.gecnb.getValues() == null;
      if (!enabled2) {
         enabled2 = true;

         for (String text2 : this.gecnb.getValues()) {
            if (text2.equalsIgnoreCase(text)) {
               enabled2 = false;
               break;
            }
         }
      }

      if (!enabled && !enabled2) {
         return text;
      } else {
         this.gecnb.setSelected("Orbit");
         return "Orbit";
      }
   }

      private float t17(int length) {

      return MathHelper.clamp(length * 8.5F, 18.0F, 360.0F);
   }

      private static void deut(Entry entry, Identifier textureId, float size, int color) {

      float value = MathHelper.clamp((color >>> 24 & 0xFF) / 255.0F * 1.1F, 0F, 1F);
      if (!(value <= 0F)) {
         int index = 0xFF000000 | color & 16777215;
         float value2 = Math.max(size * 2.9F, 0.65F);
         float value3 = Math.max(size * 0.72F, 0.1F);
         WorldParticleBatcher.queueTexturedParticle(entry.getPositionMatrix(), ParticleTextures.BLOOM, value2, value * 0.08F, index, false, null);
         WorldParticleBatcher.queueTexturedParticle(entry.getPositionMatrix(), textureId, size, value, index, false, null);
         WorldParticleBatcher.queueTexturedParticle(entry.getPositionMatrix(), textureId, value3, value * 0.32F, -1, false, null);
      }
   }

      private int computeMethod46(int color1, int color2, float factor) {

      int index = color1 >> 24 & 0xFF;
      int index2 = color1 >> 16 & 0xFF;
      int index3 = color1 >> 8 & 0xFF;
      int index4 = color1 & 0xFF;
      int index5 = color2 >> 24 & 0xFF;
      int index6 = color2 >> 16 & 0xFF;
      int index7 = color2 >> 8 & 0xFF;
      int index8 = color2 & 0xFF;
      int index9 = (int)(index + (index5 - index) * factor);
      int index10 = (int)(index2 + (index6 - index2) * factor);
      int index11 = (int)(index3 + (index7 - index3) * factor);
      int index12 = (int)(index4 + (index8 - index4) * factor);
      return index9 << 24 | index10 << 16 | index11 << 8 | index12;
   }

      private void baekvw() {

      if (this.destroyField97 != null) {
         this.x20();
      }
   }

      private void x20() {

      if (this.colorOnHit.isValue() && this.destroyField97 != null) {
         float value = 0.3F;
         float value2 = 0.08F;
         float value3 = 1F;
         int index = this.destroyField97.hurtTime;
         if (index <= this.xbocl && (index <= 0 || this.xbocl != 0)) {
            if (index > 0) {
               this.convertField81 = Math.min(value3, this.convertField81 + value * 0.5F);
            } else {
               this.convertField81 = Math.max(0F, this.convertField81 - value2);
            }
         } else {
            this.convertField81 = Math.min(value3, this.convertField81 + value);
         }

         this.xbocl = index;
      } else {
         this.convertField81 = 0F;
         this.xbocl = 0;
      }
   }

      private void silakg() {

      this.controlMethod2();
   }

      private void controlMethod2() {

      if (this.colorOnHit.isValue() && this.destroyField97 != null) {
         int index = this.destroyField97.hurtTime;
         if (index > this.controlField430 || index > 0 && this.controlField430 == 0) {
            this.tt = System.currentTimeMillis();
         }

         this.controlField430 = index;
      } else {
         this.hkvvkj();
      }
   }

      private void hkvvkj() {

      this.swchf = 0F;
      this.tt = 0L;
      this.controlField430 = 0;
   }

      private int yavyyn(int color1, int color2, float progress) {

      progress = Math.max(0F, Math.min(1F, progress));
      int index = color1 >> 16 & 0xFF;
      int index2 = color1 >> 8 & 0xFF;
      int index3 = color1 & 0xFF;
      int index4 = color1 >> 24 & 0xFF;
      int index5 = color2 >> 16 & 0xFF;
      int index6 = color2 >> 8 & 0xFF;
      int index7 = color2 & 0xFF;
      int index8 = color2 >> 24 & 0xFF;
      float value = progress * progress * (3.0F - 2.0F * progress);
      int index9 = (int)(index + (index5 - index) * value);
      int index10 = (int)(index2 + (index6 - index2) * value);
      int index11 = (int)(index3 + (index7 - index3) * value);
      int index12 = (int)(index4 + (index8 - index4) * value);
      return index12 << 24 | index9 << 16 | index10 << 8 | index11;
   }

      private void fgqirt() {

      if (this.destroyField97 != null) {
         this.zvjexz();
      }
   }

      private void zvjexz() {

      if (this.colorOnHit.isValue() && this.destroyField97 != null) {
         float value = 0.3F;
         float value2 = 0.08F;
         float value3 = 1F;
         int index = this.destroyField97.hurtTime;
         if (index <= this.gxpqk && (index <= 0 || this.gxpqk != 0)) {
            if (index > 0) {
               this.w22 = Math.min(value3, this.w22 + value * 0.5F);
            } else {
               this.w22 = Math.max(0F, this.w22 - value2);
            }
         } else {
            this.w22 = Math.min(value3, this.w22 + value);
         }

         this.gxpqk = index;
      } else {
         this.w22 = 0F;
         this.gxpqk = 0;
      }
   }

      private void runMethod41(VertexMatrixRenderer event, float anim, float red) {

      if (this.destroyField97 != null && !(anim <= 0F)) {
         Camera client = MinecraftClient.getInstance().getEntityRenderDispatcher().camera;
         Vec3d position = RenderGeometry.interpolate(this.destroyField97);
         Vec3d position2 = position.subtract(client.getPos());
         float width = this.destroyField97.getWidth() * 1.45F * 1F + (1F - anim) / 2.5F;
         float value = Math.max(0.5F, 0.8F - 0.1F * anim);
         float value2 = this.gvylif(this.parseMethod38());
         int angleStep = 3;
         float value3 = 1F + this.w22 * 0.3F;
         float value4 = 0.4F * this.r19.getValue() * value3;
         float value5 = 1F * this.r19.getValue() * value3;
         Identifier identifier = ParticleTextures.BLOOM;
         MatrixStack matrices = new MatrixStack();

         for (int angle = 0; angle < 360; angle += angleStep) {
            if ((int)(angle / 45.0F) % 2 != 0) {
               double value6 = Math.toRadians(angle + value2);
               float value7 = (float)(Math.sin(value6) * width * value);
               float value8 = (float)(Math.cos(value6) * width * value);
               double value9 = Math.toRadians(value2);
               float value10 = (float)((1 - Math.cos(value9)) / 2.0);
               float height = this.destroyField97.getHeight() * value10;
               float value11 = (float)(position2.x + value7);
               float value12 = (float)(position2.y + height);
               float value13 = (float)(position2.z + value8);
               matrices.push();
               matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
               matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(client.getYaw() + 180.0F));
               matrices.translate(value11, value12, value13);
               matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-client.getYaw()));
               matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
               int index = this.checkMethod21(angle * 3);
               if (this.w22 > 0F) {
                  int index2 = this.parseMethod380();
                  index = this.yavyyn(index, index2, this.w22);
               }

               matrices.push();
               WorldParticleBatcher.queueTexturedParticle(matrices, identifier, value5, anim * 0.1F, index, false, null);
               matrices.pop();
               matrices.push();
               WorldParticleBatcher.queueTexturedParticle(matrices, identifier, value4, anim, index, false, null);
               matrices.pop();
               matrices.pop();
            }
         }
      }
   }

      private void svquie(VertexMatrixRenderer event, float interpolatedAlpha, float red) {

      float value = Math.max(this.vcgyu.getValue(), interpolatedAlpha);
      if (!(value <= 0F)) {
         LivingEntity livingEntity = this.destroyField20 != null ? this.destroyField20 : this.destroyField97;
         if (livingEntity != null) {
            Camera client = MinecraftClient.getInstance().getEntityRenderDispatcher().camera;
            Vec3d position = RenderGeometry.interpolate(livingEntity);
            float width = livingEntity.getWidth() * 1.65F * 1F;
            float height = Math.max(0.1F, livingEntity.getHeight() - 0.15F);
            float value2 = this.computeMethod81(value);
            float value3 = Math.max(0.5F, 0.7F - 0.2F * value2);
            int index = this.pymspc();
            float value4 = this.gvylif(this.parseMethod38());
            Identifier identifier = ParticleTextures.FIREFLY_GLOW;
            MatrixStack matrices = new MatrixStack();
            matrices.multiplyPositionMatrix(event.getStack().peek().getPositionMatrix());
            matrices.push();
            matrices.translate(position.x, position.y, position.z);

            for (int angle = 0; angle < 360; angle += 2) {
               double value5 = Math.toRadians(angle + value4);
               float value6 = (float)(Math.cos(value5) * width * value3);
               float value7 = (float)(Math.sin(value5) * width * value3);
               float value8 = 0.2F;

               for (int index2 = 0; index2 < 15; index2++) {
                  float value9 = height / 1.7F + height / 2.0F * (float)Math.cos(Math.toRadians(value4 / 1.5F + index2 * 2.0F));
                  matrices.push();
                  matrices.translate(value6, value9, value7);
                  matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-client.getYaw()));
                  matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
                  int index3 = (int)(255.0F * value2 * (index2 / 15.0F) * 0.05F);
                  int index4 = this.parseMethod0(index, 0.1F + index2 / 15.0F * 0.22F);
                  index4 = this.fxoljm(index4 & 16777215 | index3 << 24);
                  this.ifvrro(matrices.peek().getPositionMatrix(), identifier, value8, index4);
                  matrices.pop();
               }
            }

            matrices.pop();
            matrices.push();
            matrices.translate(position.x, position.y, position.z);

            for (int angle = 0; angle < 360; angle += 2) {
               double value10 = Math.toRadians(angle + value4);
               float value11 = (float)(Math.cos(value10) * width * value3);
               float value12 = (float)(Math.sin(value10) * width * value3);
               float value13 = height / 1.75F + height / 2.0F * (float)Math.cos(Math.toRadians(value4 / 1.5F + 30.0F));
               float value14 = 0.2F;
               matrices.push();
               matrices.translate(value11, value13, value12);
               matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-client.getYaw()));
               matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
               int index5 = (int)(255.0F * value2 * 0.2F);
               int index6 = this.parseMethod0(index, 0.35F);
               index6 = this.fxoljm(index6 & 16777215 | index5 << 24);
               this.ifvrro(matrices.peek().getPositionMatrix(), identifier, value14, index6);
               matrices.pop();
            }

            matrices.pop();
         }
      }
   }

      private void ifvrro(Matrix4f matrix, Identifier texture, float size, int color) {

      float value = MathHelper.clamp((color >>> 24 & 0xFF) / 255.0F / 0.72F, 0F, 1F);
      if (!(value <= 0F)) {
         WorldParticleBatcher.queueTexturedParticle(matrix, texture, size, value, 0xFF000000 | color & 16777215, false, null);
      }
   }

      private int fxoljm(int color) {

      if (!this.colorOnHit.isValue()) {
         return color;
      } else {
         float value = 0F;
         long timestamp = System.currentTimeMillis() - this.tt;
         if (this.tt > 0L && timestamp < 350L) {
            float value2 = (float)timestamp / 350.0F;
            value = 1F - this.computeMethod81(value2);
         }

         this.swchf = MathHelper.lerp(0.1F, this.swchf, value);
         if (this.swchf < 0.05F) {
            return color;
         } else {
            int index = color >> 16 & 0xFF;
            int index2 = color >> 8 & 0xFF;
            int index3 = color & 0xFF;
            int index4 = color >> 24 & 0xFF;
            int index5 = this.parseMethod380();
            int index6 = MathHelper.lerp(this.swchf, index, index5 >> 16 & 0xFF);
            int index7 = MathHelper.lerp(this.swchf, index2, index5 >> 8 & 0xFF);
            int index8 = MathHelper.lerp(this.swchf, index3, index5 & 0xFF);
            return index4 << 24 | index6 << 16 | index7 << 8 | index8;
         }
      }
   }

      private int parseMethod0(int color, float amount) {

      float value = MathHelper.clamp(amount, 0F, 1F);
      int index = color >> 24 & 0xFF;
      int index2 = color >> 16 & 0xFF;
      int index3 = color >> 8 & 0xFF;
      int index4 = color & 0xFF;
      int index5 = MathHelper.lerp(value, index2, 255);
      int index6 = MathHelper.lerp(value, index3, 255);
      int index7 = MathHelper.lerp(value, index4, 255);
      return index << 24 | index5 << 16 | index6 << 8 | index7;
   }

      private int pymspc() {

      return this.getVisualColor();
   }

      private float computeMethod81(float t) {

      return 1F - (float)Math.pow(1F - t, 3.0);
   }

      private float rvbkia(float t) {

      return 1F - (1F - t) * (1F - t);
   }

      private void dfm(
      VertexMatrixRenderer event,
      LivingEntity target,
      float distance,
      float size,
      float speed,
      float anim,
      boolean whiteCrystals,
      boolean upDirection,
      float glowTransparency,
      String rotationStyle,
      String positionStyle
   ) {

      if (target != null && target.isAlive() && !(anim <= 0F) && event != null) {
         if (this.j27.isEmpty()) {
            this.updateMethod84(target, size);
         }

         if (RenderSystem.isOnRenderThread()) {
            RenderSystem.enableDepthTest();
            RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
            Vec3d position = RenderGeometry.interpolate(target);
            boolean client = MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().player.canSee(target);
            if (anim > 0.01F && !this.j27.isEmpty()) {
               if (this.transformField34.isValue()) {
                  for (int index = 0; index < this.j27.size(); index++) {
                     VectorModuleSupport vectorModuleSupport = this.j27.get(index);
                     this.deleteMethod960(
                        event,
                        vectorModuleSupport,
                        target,
                        position,
                        client,
                        index,
                        anim,
                        distance,
                        size,
                        speed,
                        whiteCrystals,
                        upDirection,
                        glowTransparency,
                        rotationStyle,
                        positionStyle
                     );
                  }
               } else {
                  this.xqkewr(
                     event, target, position, client, anim, distance, size, speed, whiteCrystals, upDirection, glowTransparency, rotationStyle, positionStyle
                  );
               }
            }

            RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
         }
      }
   }

      private void updateMethod84(LivingEntity target, float size) {

      this.j27.clear();
      boolean enabled = target instanceof PlayerEntity;
      float height = enabled ? 1.8F : target.getHeight();
      float width = enabled ? 0.6F : target.getWidth();
      float value = enabled ? 0.5F : height * 0.3F;
      this.j27.add(new VectorModuleSupport(new Vector3f(0F, value, 0F), new Vector3f(0F, 0F, 0F), size));
      this.j27.add(new VectorModuleSupport(new Vector3f(0F, -value, 0F), new Vector3f(0F, 0F, 0F), size));

      for (int index = 0; index < 17; index++) {
         float value2 = (float)(index * 2 * Math.PI / 17.0);
         float value3 = enabled ? 1F : width;
         float value4 = enabled ? 1F + (float)Math.sin(value2 * 3.0F) * 0.9F : height * 0.5F + (float)Math.sin(value2 * 3.0F) * height * 0.45F;
         Vector3f position = new Vector3f((float)(Math.cos(value2) * value3), value4, (float)(Math.sin(value2) * value3));
         Vector3f position2 = new Vector3f((float)(Math.sin(value2) * 30.0), value2 * 180.0F / (float) Math.PI, (float)(Math.cos(value2) * 30.0));
         this.j27.add(new VectorModuleSupport(position, position2, size));
      }
   }

      private void dfom(LivingEntity target) {

      if (target != null) {
         long timestamp = System.currentTimeMillis();
         float value = Math.min((float)(timestamp - this.mpgsl) / 1000.0F, 0.1F);
         this.mpgsl = timestamp;
         this.processField30 += value;
         this.p20 += value * 20.0F;
         if (target.isAlive()) {
            this.processField100 = 1F - target.getHealth() / target.getMaxHealth();
         } else if (this.processField100 < 1F) {
            this.processField100 += 3.0F * value;
         }

         this.processField100 = MathHelper.clamp(this.processField100, 0F, 1F);
         if (target.hurtTime > this.m25) {
            this.initField40 = 1F;
            this.dcz();
         }

         this.m25 = target.hurtTime;
         if (this.initField40 > 0F) {
            this.initField40 -= 1.8F * value;
         }

         this.initField40 = MathHelper.clamp(this.initField40, 0F, 1F);
         this.baekvw();
         this.silakg();
         this.fgqirt();
      }
   }

      private void xqkewr(
      VertexMatrixRenderer event,
      LivingEntity target,
      Vec3d targetPos,
      boolean canSee,
      float anim,
      float distance,
      float size,
      float speed,
      boolean whiteCrystals,
      boolean upDirection,
      float glowTransparency,
      String rotationStyle,
      String positionStyle
   ) {

      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.enableBlend();
      RenderSystem.disableCull();
      RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_CONSTANT_ALPHA);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
      int index = (int)this.crystalNumSides.getValue();

      for (int index2 = 0; index2 < this.j27.size(); index2++) {
         MatrixColorStyle matrixColorStyle = this.rtbjsm(
            event.getStack(),
            this.j27.get(index2),
            target,
            targetPos,
            index2,
            anim,
            distance,
            size,
            speed,
            whiteCrystals,
            upDirection,
            rotationStyle,
            positionStyle
         );
         if (matrixColorStyle != null) {
            this.ismtut(bufferBuilder, matrixColorStyle.matrix(), matrixColorStyle.color(), index, false, matrixColorStyle.finalAnim(), size);
            if (this.owpnd.isValue()) {
               this.stopMethod71(event.getStack(), matrixColorStyle.glowColor(), canSee, event, matrixColorStyle.glowPosition(), matrixColorStyle.finalAnim(), size, glowTransparency);
            }
         }
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderStateGuard.restoreWorldDefaults();
   }

      private void deleteMethod960(
      VertexMatrixRenderer event,
      VectorModuleSupport crystal,
      LivingEntity target,
      Vec3d targetPos,
      boolean canSee,
      int crystalIndex,
      float anim,
      float distance,
      float size,
      float speed,
      boolean whiteCrystals,
      boolean upDirection,
      float glowTransparency,
      String rotationStyle,
      String positionStyle
   ) {

      if (event != null && crystal != null) {
         MatrixColorStyle matrixColorStyle = this.rtbjsm(
            event.getStack(), crystal, target, targetPos, crystalIndex, anim, distance, size, speed, whiteCrystals, upDirection, rotationStyle, positionStyle
         );
         if (matrixColorStyle != null) {
            this.createMethod68(matrixColorStyle.matrix(), matrixColorStyle.color(), (int)this.crystalNumSides.getValue(), true, false, matrixColorStyle.finalAnim(), size);
            if (this.owpnd.isValue()) {
               this.stopMethod71(event.getStack(), matrixColorStyle.glowColor(), canSee, event, matrixColorStyle.glowPosition(), matrixColorStyle.finalAnim(), size, glowTransparency);
            }
         }
      }
   }

      private MatrixColorStyle rtbjsm(
      MatrixStack matrixStack,
      VectorModuleSupport crystal,
      LivingEntity target,
      Vec3d targetPos,
      int crystalIndex,
      float anim,
      float distance,
      float size,
      float speed,
      boolean whiteCrystals,
      boolean upDirection,
      String rotationStyle,
      String positionStyle
   ) {

      if (matrixStack != null && crystal != null) {
         float value = 1F;
         if (!this.d19) {
            long timestamp = System.currentTimeMillis();
            long timestamp2 = timestamp - this.tn1;
            float value2 = Math.min(1F, (float)timestamp2 / 300.0F);
            value = (float)Math.pow(value2, 0.6);
         }

         float value3 = crystal.size * anim;
         if (this.initField40 > 0F) {
            value3 *= 1F + this.initField40 * 0.5F;
         }

         if (this.processField100 > 0F) {
            value3 *= 1F - this.processField100 * 0.3F;
         }

         matrixStack.push();
         boolean enabled = target instanceof PlayerEntity;
         float height = enabled ? 1.8F : target.getHeight();
         float width = enabled ? 0.6F : target.getWidth();
         double value4 = this.parseMethod67(speed);
         float value5 = (float)(crystalIndex * 2 * Math.PI / this.j27.size());
         float value6 = (enabled ? 0.6F : width) * distance * 1.5F;
         float value7 = 1.2F - 0.5F * anim;
         float value8 = value6 * value7;
         float value9;
         if ("Flat".equalsIgnoreCase(positionStyle)) {
            float value10 = (float)Math.abs(Math.sin(crystalIndex));
            value9 = 0.1F + (enabled ? 1.8F : height) * value10;
         } else {
            value9 = enabled ? 1F + (float)Math.sin(value5 * 3.0F) * 0.9F : height * 0.5F + (float)Math.sin(value5 * 3.0F) * height * 0.45F;
         }

         float value11 = (float)(Math.cos(value5) * value8);
         float value12 = (float)(Math.sin(value5) * value8);
         float value13;
         float value14;
         float value15;
         switch (rotationStyle) {
            case "Spiral":
               float value16 = (float)Math.cos(-value4);
               float value17 = (float)Math.sin(-value4);
               value13 = value11 * value16 - value12 * value17;
               value14 = value11 * value17 + value12 * value16;
               value15 = value9 + (float)Math.sin(value4 + crystalIndex) * 0.3F;
               break;
            case "Wave":
               float value18 = (float)Math.cos(-value4);
               float value19 = (float)Math.sin(-value4);
               value13 = value11 * value18 - value12 * value19;
               value14 = value11 * value19 + value12 * value18;
               float value20 = (float)Math.sin(value4 * 2.0 + crystalIndex * 0.5) * 0.4F;
               value15 = value9 + value20;
               break;
            default:
               float value21 = (float)Math.cos(-value4);
               float value22 = (float)Math.sin(-value4);
               value13 = value11 * value21 - value12 * value22;
               value14 = value11 * value22 + value12 * value21;
               value15 = value9;
         }

         matrixStack.translate(targetPos.x + value13, targetPos.y + value15, targetPos.z + value14);
         float value23 = (float)Math.atan2(value13, value14);
         matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(value23 * 180.0F / (float) Math.PI));
         if (upDirection) {
            matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0F));
         } else {
            float value24 = (float)Math.sqrt(value13 * value13 + value14 * value14);
            float value25 = (float)Math.atan2(value15, value24) * 180.0F / (float) Math.PI;
            if (value15 > 1F) {
               matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-value25 - 45.0F));
            } else {
               matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-value25));
            }
         }

         matrixStack.scale(size, size, size);
         int index;
         int index2;
         if (whiteCrystals) {
            index = -1;
            index2 = this.runMethod95(crystal.position);
         } else {
            index = this.runMethod95(crystal.position);
            index2 = index;
         }

         if (this.colorOnHit.isValue() && this.initField40 > 0F) {
            int index3 = this.parseMethod380();
            float value26 = this.initField40;
            float value27 = 1F - (float)Math.pow(1F - value26, 3.0);
            int index4 = index >> 16 & 0xFF;
            int index5 = index >> 8 & 0xFF;
            int index6 = index & 0xFF;
            int index7 = index3 >> 16 & 0xFF;
            int index8 = index3 >> 8 & 0xFF;
            int index9 = index3 & 0xFF;
            int index10 = MathHelper.lerp(value27, index4, index7);
            int index11 = MathHelper.lerp(value27, index5, index8);
            int index12 = MathHelper.lerp(value27, index6, index9);
            index = index & 0xFF000000 | index10 << 16 | index11 << 8 | index12;
            index4 = index2 >> 16 & 0xFF;
            index5 = index2 >> 8 & 0xFF;
            index6 = index2 & 0xFF;
            index10 = MathHelper.lerp(value27, index4, index7);
            index11 = MathHelper.lerp(value27, index5, index8);
            index12 = MathHelper.lerp(value27, index6, index9);
            index2 = index2 & 0xFF000000 | index10 << 16 | index11 << 8 | index12;
         }

         float value28 = anim;
         if (!this.d19 && value < 1F) {
            value28 = anim * value;
         }

         if (value28 < 1F) {
            float value29 = this.qllvqu(value28);
            int index13 = (int)(255.0F * value29);
            if (!whiteCrystals) {
               float value30 = 0.3F + 0.7F * value29;
               index = ColorUtils.multDark(index, value30);
            }

            index = index & 16777215 | index13 << 24;
         }

         Matrix4f matrix = new Matrix4f(matrixStack.peek().getPositionMatrix());
         Vec3d position2 = new Vec3d(targetPos.x + value13, targetPos.y + value15, targetPos.z + value14);
         matrixStack.pop();
         return new MatrixColorStyle(matrix, index, index2, position2, value28);
      } else {
         return null;
      }
   }

      private void createMethod68(Matrix4f crystalMatrix, int color, int sides, boolean filled, boolean outline, float anim, float size) {

      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.enableBlend();
      RenderSystem.disableCull();

      try {
         boolean enabled = this.transformField34.isValue();
         Object object = null;
         boolean enabled2 = false;
         if (enabled) {
            String text = this.ta0.getSelected();
            switch (text) {
               case "Wave":
                  object = ShaderRegistry.highlighterShaderWave;
                  break;
               case "Audio":
                  object = ShaderRegistry.highlighterShaderAudio;
                  break;
               case "Plasma":
                  object = ShaderRegistry.highlighterShaderPlasma;
                  break;
               case "Fractal":
                  object = ShaderRegistry.highlighterShaderFractal;
                  break;
               case "Tunnel":
                  object = ShaderRegistry.highlighterShaderTunnel;
                  break;
               case "Particles":
                  object = ShaderRegistry.highlighterShaderParticles;
            }

            if (object != null) {
               try {
                  float value = (color >> 16 & 0xFF) / 255.0F;
                  float value2 = (color >> 8 & 0xFF) / 255.0F;
                  float value3 = (color & 0xFF) / 255.0F;
                  float value4 = (color >> 24 & 0xFF) / 255.0F;
                  float value5 = 500.0F / this.lmmwt.getValue();
                  float value6 = 5.0F / this.c26.getValue();
                  if (object instanceof WaveOutlineShader) {
                     ((WaveOutlineShader)object)
                        .updateUniforms(this.p20, value5, value6, value, value2, value3, value, value2, value3, value, value2, value3, value, value2, value3, value4);
                  } else if (object instanceof AudioOutlineShader) {
                     ((AudioOutlineShader)object)
                        .updateUniforms(this.p20, value5, value6, value, value2, value3, value, value2, value3, value, value2, value3, value, value2, value3, value4);
                  } else if (object instanceof PlasmaOutlineShader) {
                     ((PlasmaOutlineShader)object)
                        .updateUniforms(this.p20, value5, value6, value, value2, value3, value, value2, value3, value, value2, value3, value, value2, value3, value4);
                  } else if (object instanceof FractalOutlineShader) {
                     ((FractalOutlineShader)object)
                        .updateUniforms(this.p20, value5, value6, value, value2, value3, value, value2, value3, value, value2, value3, value, value2, value3, value4);
                  } else if (object instanceof TunnelOutlineShader) {
                     ((TunnelOutlineShader)object)
                        .updateUniforms(this.p20, value5, value6, value, value2, value3, value, value2, value3, value, value2, value3, value, value2, value3, value4);
                  } else if (object instanceof ParticleOutlineShader) {
                     ((ParticleOutlineShader)object)
                        .updateUniforms(this.p20, value5, value6, value, value2, value3, value, value2, value3, value, value2, value3, value, value2, value3, value4);
                  }

                  RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
                  ((BaseShaderRenderer)object).use();
                  enabled2 = true;
               } catch (Exception exception) {
                  enabled2 = false;
               }
            }
         }

         if (!enabled2) {
            RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_CONSTANT_ALPHA);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
         }

         Tessellator tessellator = Tessellator.getInstance();
         DrawMode drawMode = filled ? DrawMode.TRIANGLES : DrawMode.LINES;
         VertexFormat vertexFormat = enabled2 ? VertexFormats.POSITION_TEXTURE_COLOR : VertexFormats.POSITION_COLOR;
         BufferBuilder bufferBuilder = tessellator.begin(drawMode, vertexFormat);
         this.ismtut(bufferBuilder, crystalMatrix, color, sides, enabled2, anim, size);

         try {
            BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
         } catch (Exception exception2) {
         }
      } finally {
         RenderStateGuard.restoreWorldDefaults();
      }
   }

      private void ismtut(BufferBuilder bufferBuilder, Matrix4f crystalMatrix, int color, int sides, boolean shaderApplied, float anim, float size) {

      float value = size * 1.2F;
      float value2 = size * 0.8F;

      for (int index = 0; index < sides; index++) {
         float value3 = (float)((Math.PI * 2) * index / sides);
         float value4 = (float)((Math.PI * 2) * ((index + 1) % sides) / sides);
         float value5 = (float)(value2 * Math.cos(value3));
         float value6 = (float)(value2 * Math.sin(value3));
         float value7 = (float)(value2 * Math.cos(value4));
         float value8 = (float)(value2 * Math.sin(value4));
         float value9 = (float)index / sides;
         int index2 = shaderApplied ? (color >> 24 & 0xFF) << 24 | 16777215 : this.fmhyvn(color, value9, 0);
         this.manageMethod45(bufferBuilder, crystalMatrix, 0F, value, 0F, value5, 0F, value6, value7, 0F, value8, index2, anim, shaderApplied, value);
         int index3 = shaderApplied ? (color >> 24 & 0xFF) << 24 | 16777215 : this.fmhyvn(color, value9, 1);
         this.manageMethod45(bufferBuilder, crystalMatrix, 0F, -value, 0F, value7, 0F, value8, value5, 0F, value6, index3, anim, shaderApplied, value);
         int index4 = shaderApplied ? (color >> 24 & 0xFF) << 24 | 16777215 : this.fmhyvn(color, value9, 2);
         this.manageMethod45(bufferBuilder, crystalMatrix, value5, 0F, value6, value7, 0F, value8, value5, 0F, value6, index4, anim, shaderApplied, value);
         this.manageMethod45(bufferBuilder, crystalMatrix, value7, 0F, value8, value7, 0F, value8, value5, 0F, value6, index4, anim, shaderApplied, value);
      }
   }

      private void stopMethod71(
      MatrixStack matrixStack, int color, boolean canSee, VertexMatrixRenderer event, Vec3d crystalWorldPos, float anim, float size, float glowTransparency
   ) {

      Camera client = MinecraftClient.getInstance().getEntityRenderDispatcher().camera;
      Vec3d position = crystalWorldPos.subtract(client.getPos());
      MatrixStack matrices = new MatrixStack();
      matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(client.getYaw() + 180.0F));
      matrices.translate(position.x, position.y, position.z);
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-client.getYaw()));
      matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
      Entry entry = matrices.peek();
      float value = size * this.nazom.getValue();
      float value2 = glowTransparency * anim;
      int index = ColorUtils.multAlpha(color, value2);
      Vector4i vector4i = new Vector4i(index);
      Identifier identifier = ParticleTextures.BLOOM;
      WorldShapeRenderer.drawTexture(entry, identifier, -value / 2.0F, -value / 2.0F, value, value, vector4i, true, true);
   }

      private void manageMethod45(
      BufferBuilder bufferBuilder,
      Matrix4f matrix,
      float x1,
      float y1,
      float z1,
      float x2,
      float y2,
      float z2,
      float x3,
      float y3,
      float z3,
      int color,
      float anim,
      boolean useUv,
      float hPyramid
   ) {

      float value = (color >> 16 & 0xFF) / 255.0F;
      float value2 = (color >> 8 & 0xFF) / 255.0F;
      float value3 = (color & 0xFF) / 255.0F;
      if (useUv) {
         float value4 = (float)(Math.atan2(z1, x1) / (Math.PI * 2) + 0.5);
         float value5 = y1 / (hPyramid * 2.0F) + 0.5F;
         float value6 = (float)(Math.atan2(z2, x2) / (Math.PI * 2) + 0.5);
         float value7 = y2 / (hPyramid * 2.0F) + 0.5F;
         float value8 = (float)(Math.atan2(z3, x3) / (Math.PI * 2) + 0.5);
         float value9 = y3 / (hPyramid * 2.0F) + 0.5F;
         bufferBuilder.vertex(matrix, x1, y1, z1).texture(value4, value5).color(value, value2, value3, anim);
         bufferBuilder.vertex(matrix, x2, y2, z2).texture(value6, value7).color(value, value2, value3, anim);
         bufferBuilder.vertex(matrix, x3, y3, z3).texture(value8, value9).color(value, value2, value3, anim);
      } else {
         bufferBuilder.vertex(matrix, x1, y1, z1).color(value, value2, value3, anim);
         bufferBuilder.vertex(matrix, x2, y2, z2).color(value, value2, value3, anim);
         bufferBuilder.vertex(matrix, x3, y3, z3).color(value, value2, value3, anim);
      }
   }

      private float qllvqu(float t) {

      return t < 0.5F ? 2.0F * t * t : 1F - (float)Math.pow(-2.0F * t + 2.0F, 2.0) / 2.0F;
   }

      private int runMethod95(Vector3f position) {

      return this.getVisualColor();
   }

      private int parseMethod380() {

      return this.resolveVisualOrCustomColor(this.hitColorMode, this.hitColor);
   }

      private int fmhyvn(int baseColor, float gradientFactor, int faceType) {

      int index = baseColor >> 16 & 0xFF;
      int index2 = baseColor >> 8 & 0xFF;
      int index3 = baseColor & 0xFF;
      if (faceType == 0) {
         index = Math.min(255, (int)(index * (1.5F + gradientFactor * 0.8F)));
         index2 = Math.max(0, (int)(index2 * (0.6F + gradientFactor * 0.4F)));
         index3 = Math.max(0, (int)(index3 * (0.4F - gradientFactor * 0.2F)));
      } else if (faceType == 1) {
         index = Math.max(0, (int)(index * (0.4F - gradientFactor * 0.2F)));
         index2 = Math.max(0, (int)(index2 * (0.5F + gradientFactor * 0.3F)));
         index3 = Math.min(255, (int)(index3 * (1.5F + gradientFactor * 0.8F)));
      } else {
         index = Math.max(0, (int)(index * (0.7F + Math.sin(gradientFactor * Math.PI * 2.0) * 0.3F)));
         index2 = Math.min(255, (int)(index2 * (1.3F + Math.cos(gradientFactor * Math.PI * 2.0) * 0.5)));
         index3 = Math.max(0, (int)(index3 * (0.6F + Math.sin(gradientFactor * Math.PI * 3.0) * 0.2F)));
      }

      float value = 0.7F + 0.3F * (float)Math.sin(gradientFactor * Math.PI * 4.0);
      index = (int)(index * value);
      index2 = (int)(index2 * value);
      index3 = (int)(index3 * value);
      index = Math.max(0, Math.min(255, index));
      index2 = Math.max(0, Math.min(255, index2));
      index3 = Math.max(0, Math.min(255, index3));
      return 0xFF000000 | index << 16 | index2 << 8 | index3;
   }

   static {
      for (int angle = 0; angle <= 360; angle++) {
         destroyField17[angle] = (float)Math.sin(Math.toRadians(angle));
         ckuyl[angle] = (float)Math.cos(Math.toRadians(angle));
      }
   }

}
