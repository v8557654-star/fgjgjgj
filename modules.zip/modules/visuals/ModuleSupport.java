package winvi.noxiumvisuals.modules.visuals;

import java.util.List;
public final class ModuleSupport {
      public final int wgxkv;
      public final List<TextModuleSupport> parseField9;

   public ModuleSupport(int wrapWidth, List<TextModuleSupport> entries) {
      this.wgxkv = wrapWidth;
      this.parseField9 = entries;
   }

}
