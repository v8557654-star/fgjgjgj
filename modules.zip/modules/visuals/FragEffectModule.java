package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.FragEffectBurst;
import winvi.noxiumvisuals.modules.visuals.FragEffectFragment;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.EntityEventProvider;
import winvi.noxiumvisuals.systems.events.AttackEntityEvent;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.TextEventRenderer;
import winvi.noxiumvisuals.systems.events.FovEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
import winvi.noxiumvisuals.utils.render.UiRenderUtils;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
import winvi.noxiumvisuals.utils.render.MatrixEntityRenderer;
public final class FragEffectModule extends Module {
      private static final Identifier efl = Identifier.of("noxiumvisual", "textures/wfubox433/fbot7ap.png");
      private final BooleanSetting m21;
      private final NumberSetting tieqw;
      private final NumberSetting wwlqr;
      private final List<FragEffectBurst> removeField64;
      private static final long ghzyk = 3500L;
      private final Random ycqzs;
      private long efsh;
      private LivingEntity royri;
      private long efu;
      private int v27;
      private long ujqti;
      private boolean transformField10;
      private boolean fy0;

   public FragEffectModule() {
      super(
         "Frag Effect",
         "Kill flash and fragment burst",
         ModuleCategory.VISUAL
      );
      this.m21 = new BooleanSetting(
            "Players Only",
            "Trigger only after killing players"
         )
         .setValue(true);
      this.tieqw = new NumberSetting(
            "Particles",
            "Amount of fragments"
         )
         .setValue(220.0F)
         .range(60.0F, 500.0F);
      this.wwlqr = new NumberSetting(
            "Duration",
            "Effect duration in seconds"
         )
         .setValue(1.15F)
         .range(0.45F, 2.5F);
      this.removeField64 = new ArrayList<>();
      this.ycqzs = new Random();
      this.v27 = -2147483648;
      this.m21.withTranslation("frageffect.playersonly", "frageffect.playersonly.desc");
      this.tieqw.withTranslation("frageffect.particles", "frageffect.particles.desc");
      this.wwlqr.withTranslation("frageffect.duration", "frageffect.duration.desc");
      this.setup(new ModuleSetting[]{this.m21, this.tieqw, this.wwlqr});
   }

      @Override
   public void activate() {
      this.destroyMethod27();
      super.activate();
   }

      @Override
   public void deactivate() {
      this.removeField64.clear();
      this.efsh = 0L;
      this.royri = null;
      this.efu = 0L;
      this.v27 = -2147483648;
      this.ujqti = 0L;
      super.deactivate();
   }

   @EventHandler
      public void onAttack(AttackEntityEvent event) {
      if (this.isState() && event.getEntity() instanceof LivingEntity livingEntity && this.initMethod9(livingEntity)) {
         this.royri = livingEntity;
         this.efu = System.currentTimeMillis() + 3500L;
      }
   }

   @EventHandler
      public void onEntityDeath(EntityEventProvider event) {
      if (this.isState() && MinecraftClient.getInstance().player != null && event.getEntity() instanceof LivingEntity livingEntity && this.initMethod9(livingEntity)) {
         long timestamp = System.currentTimeMillis();
         boolean enabled = this.royri == livingEntity && timestamp <= this.efu;
         boolean client = livingEntity.getRecentDamageSource() != null && livingEntity.getRecentDamageSource().getAttacker() == MinecraftClient.getInstance().player;
         if (enabled || client) {
            this.avqris(livingEntity, timestamp);
         }
      }
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (!this.transformField10) {
         this.destroyMethod27();
      }

      long timestamp = System.currentTimeMillis();
      this.removeField64.removeIf(burst -> {
         return timestamp - burst.startedAt() >= burst.durationMs();
      });
      if (this.royri != null) {
         if (timestamp > this.efu) {
            this.royri = null;
            this.efu = 0L;
         } else {
            if (!this.royri.isAlive() || this.royri.getHealth() <= 0F || this.royri.isRemoved()) {
               this.avqris(this.royri, timestamp);
            }
         }
      }
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState() && !this.removeField64.isEmpty()) {
         long timestamp = System.currentTimeMillis();
         Iterator iterator2 = this.removeField64.iterator();

         while (iterator2.hasNext()) {
            FragEffectBurst moduleRange6 = (FragEffectBurst)iterator2.next();
            float value = MathHelper.clamp((float)(timestamp - moduleRange6.startedAt()) / (float)moduleRange6.durationMs(), 0F, 1F);
            if (value >= 1F) {
               iterator2.remove();
            } else {
               float value2 = Math.min(1F, value * 3.0F) * (1F - value);

               for (FragEffectFragment colorModuleStyle2 : moduleRange6.fragments()) {
                  double value3 = colorModuleStyle2.yaw() + colorModuleStyle2.turn() * value;
                  double value4 = MathHelper.lerp(value, colorModuleStyle2.startRadius(), colorModuleStyle2.endRadius());
                  Vec3d position = moduleRange6.origin().add(Math.sin(value3) * value4, colorModuleStyle2.yOffset() * value, Math.cos(value3) * value4);
                  float value5 = colorModuleStyle2.colorMix();
                  int index = this.tsgbkr(-16185079, -1, value5);
                  index = ColorUtils.multAlpha(index, value2 * (0.55F + value5 * 0.45F));
                  WorldShapeRenderer.drawLine(position, position.add(0, 0.012, 0), index, 2.0F, true);
               }
            }
         }
      }
   }

   @EventHandler
      public void onDraw(TextEventRenderer event) {
      if (this.isState() && this.efsh != 0L) {
         long timestamp = System.currentTimeMillis();
         float value = this.validateMethod11(timestamp);
         if (value >= 1F) {
            this.efsh = 0L;
         } else {
            float value2 = this.calculateMethod5(value);
            int index = Math.round(255.0F * (1F - value2 / 1.25F));
            int color = ColorUtils.getColor(255, index, index, Math.round(190.0F * value2));
            float width = MatrixEntityRenderer.getVirtualWidth();
            float height = MatrixEntityRenderer.getVirtualHeight();
            float value3 = this.removeMethod14(MathHelper.clamp(value / 0.42F, 0F, 1F));
            float value4 = 1F - value3;
            float value5 = width * 0.38F * value4;
            float value6 = height * 0.38F * value4;
            this.destroyMethod27();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.depthMask(false);
            UiRenderUtils.drawTexturedQuad(
               event.getDrawContext().getMatrices(), efl, -value5, width + value5, -value6, height + value6, 0F, 1F, 0F, 1F, color
            );
            RenderSystem.depthMask(true);
            RenderSystem.disableBlend();
         }
      }
   }

   @EventHandler
      public void onFov(FovEvent event) {
      if (this.isState() && this.efsh != 0L) {
         float value = this.calculateMethod5(this.validateMethod11(System.currentTimeMillis()));
         if (!(value <= 0.001F)) {
            float value2 = event.getFov() * (1F - value * 0.28F);
            event.setFov(MathHelper.clamp(value2, 3.0F, 110.0F));
            event.cancel();
         }
      }
   }

      public float getPostProcessStrength() {
      if (this.isState() && this.efsh != 0L) {
         float value = this.calculateMethod5(this.validateMethod11(System.currentTimeMillis()));
         return this.removeMethod14(MathHelper.clamp((value - 0.25F) / 0.55F, 0F, 1F));
      } else {
         return 0F;
      }
   }

      @Override
   public boolean hasWorldRenderWork() {
      return this.isState() && !this.removeField64.isEmpty();
   }

      private boolean initMethod9(LivingEntity entity) {
      return entity != null
         && entity != MinecraftClient.getInstance().player
         && EntityVisibilityFilter.shouldRender(entity)
         && (!this.m21.isValue() || entity instanceof PlayerEntity);
   }

      private void avqris(LivingEntity entity, long now) {
      if (entity != null && (this.v27 != entity.getId() || now - this.ujqti >= 750L)) {
         this.v27 = entity.getId();
         this.ujqti = now;
         this.efsh = now;
         this.removeField64.add(this.zuhpgd(entity, now));
         if (this.royri == entity) {
            this.royri = null;
            this.efu = 0L;
         }
      }
   }

      private float validateMethod11(long now) {
      float value = Math.max(1F, this.wwlqr.getValue() * 1000.0F);
      return MathHelper.clamp((float)(now - this.efsh) / value, 0F, 1F);
   }

      private float calculateMethod5(float progress) {
      if (progress <= 0.22F) {
         float value = MathHelper.clamp(progress / 0.22F, 0F, 1F);
         return 1F - (float)Math.pow(1F - value, 3.0);
      } else {
         float value2 = MathHelper.clamp((progress - 0.22F) / 0.78F, 0F, 1F);
         return 1F - this.removeMethod14(value2);
      }
   }

      private float removeMethod14(float progress) {
      return progress * progress * (3.0F - 2.0F * progress);
   }

      private void destroyMethod27() {
      if (!this.transformField10) {
         if (!RenderSystem.isOnRenderThread()) {
            if (!this.fy0) {
               this.fy0 = true;
               RenderSystem.recordRenderCall(this::destroyMethod27);
            }
         } else {
            this.fy0 = false;
            MinecraftClient.getInstance().getTextureManager().getTexture(efl).setFilter(true, false);
            this.transformField10 = true;
         }
      }
   }

      private FragEffectBurst zuhpgd(LivingEntity entity, long now) {
      Vec3d height = entity.getPos().add(0, entity.getHeight() * 0.48, 0);
      int index = Math.max(1, (int)this.tieqw.getValue());
      ArrayList arrayList = new ArrayList(index);

      for (int index2 = 0; index2 < index; index2++) {
         double value = 6.283185307179586 * index2 / index;
         double value2 = 0.22 + this.ycqzs.nextDouble() * 0.3;
         double value3 = value2 + 0.12 + this.ycqzs.nextDouble() * 0.28;
         double value4 = Math.toRadians(this.ycqzs.nextDouble() * 36.0);
         double value5 = (this.ycqzs.nextDouble() - 0.5) * 0.22;
         arrayList.add(new FragEffectFragment(value, value2, value3, value4, value5, this.ycqzs.nextFloat()));
      }

      return new FragEffectBurst(height, now, (long)(this.wwlqr.getValue() * 1000.0F), arrayList);
   }

      private int tsgbkr(int from, int to, float progress) {
      progress = MathHelper.clamp(progress, 0F, 1F);
      int index = MathHelper.lerp(progress, from >> 16 & 0xFF, to >> 16 & 0xFF);
      int index2 = MathHelper.lerp(progress, from >> 8 & 0xFF, to >> 8 & 0xFF);
      int index3 = MathHelper.lerp(progress, from & 0xFF, to & 0xFF);
      return 0xFF000000 | index << 16 | index2 << 8 | index3;
   }

   static {
      int index = 0;
   }
}
