package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.AttackEntityEvent;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.EntityVisibilityFilter;
import winvi.noxiumvisuals.utils.render.ShaderRegistry;
import winvi.noxiumvisuals.utils.render.ParticleOutlineShader;
import winvi.noxiumvisuals.utils.render.FractalOutlineShader;
import winvi.noxiumvisuals.utils.render.PlasmaOutlineShader;
import winvi.noxiumvisuals.utils.render.TunnelOutlineShader;
import winvi.noxiumvisuals.utils.render.AudioOutlineShader;
import winvi.noxiumvisuals.utils.render.WaveOutlineShader;
import winvi.noxiumvisuals.utils.render.BaseShaderRenderer;
import winvi.noxiumvisuals.utils.render.RenderStateGuard;
public class HitBoxModule extends Module {
      static final long HIT_HIGHLIGHT_DURATION_MS = 450L;
      private static final String ehf = "Fill + Outline";
      private static final String convertField690 = "Outline";
      private static final float jsebs = 10.0F;
      private final List<Entity> i18;
      private final ChoiceSetting convertField24;
      private final MultiSelectSetting pagni;
      private final ChoiceSetting kcnmx;
      private final ColorSetting m23;
      private final NumberSetting ehnb;
      private final NumberSetting checkField7;
      private final BooleanSetting arzvc;
      private final NumberSetting hq0;
      private final BooleanSetting r18;
      private final ChoiceSetting formatField220;
      private final NumberSetting cwidp;
      private float damxm;
      private long removeField32;
      private final Map<Integer, Long> ehw;

   public HitBoxModule() {
      super(
         "HitBox",
         "Highlights entity hitboxes",
         ModuleCategory.VISUAL
      );
      this.i18 = new ArrayList<>();
      this.convertField24 = new ChoiceSetting(
            "Render Mode",
            "Rendering mode"
         )
         .value(
            "Fill + Outline",
            "Outline"
         )
         .selected("Fill + Outline");
      this.pagni = new MultiSelectSetting(
            "Highlight",
            "Special color override modes"
         )
         .value(
            "On Hit",
            "In Range",
            "On Aim"
         )
         .selected("On Hit");
      this.kcnmx = new ChoiceSetting(
            "Highlight Color Source",
            "Special highlight color source"
         )
         .value(
            "Visual Color",
            "Custom"
         )
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .selected("Custom")
         .visible(() -> {
            return !this.pagni.getSelected().isEmpty();
         });
      this.m23 = new ColorSetting(
            "Hit Color",
            "Custom special highlight color"
         )
         .setColor(-44976)
         .visible(() -> {
            return !this.pagni.getSelected().isEmpty() && this.kcnmx.isSelected("Custom");
         });
      this.ehnb = new NumberSetting(
            "Alpha",
            "Box transparency"
         )
         .setValue(0.33F)
         .range(0.1F, 1F)
         .visible(() -> {
            return !this.convertField24.getSelected().equals("Outline");
         });
      this.checkField7 = new NumberSetting(
            "Padding",
            "Box padding"
         )
         .setValue(0.08F)
         .range(0F, 0.2F)
         .visible(() -> {
            return false;
         });
      this.arzvc = new BooleanSetting(
            "Dashed Outline",
            "Use dashed outline"
         )
         .setValue(false);
      this.hq0 = new NumberSetting(
            "Dash Density",
            "Dash density (higher = more dashes)"
         )
         .setValue(1F)
         .range(0.5F, 3.0F)
         .visible(() -> {
            return this.arzvc.isValue();
         });
      this.r18 = new BooleanSetting(
            "Use Shader",
            "Use shader effect for fill"
         )
         .setValue(false)
         .visible(() -> {
            return !this.convertField24.getSelected().equals("Outline");
         });
      this.formatField220 = new ChoiceSetting(
            "Shader Type",
            "Shader effect type"
         )
         .value(
            "Wave",
            "Plasma",
            "Fractal",
            "Tunnel",
            "Particles"
         )
         .visible(
            () -> {
               return this.r18.isValue()
                  && !this.convertField24.getSelected().equals("Outline");
            }
         );
      this.cwidp = new NumberSetting(
            "Shader Speed",
            "Shader animation speed"
         )
         .setValue(1F)
         .range(0.1F, 5.0F)
         .visible(
            () -> {
               return this.r18.isValue()
                  && !this.convertField24.getSelected().equals("Outline");
            }
         );
      this.damxm = 0F;
      this.removeField32 = System.nanoTime();
      this.ehw = new HashMap<>();
      this.showVisualColorSettings();
      this.convertField24.withTranslation("hitbox.rendermode", "hitbox.rendermode.desc");
      this.pagni.withTranslation("hitbox.highlightmode", "hitbox.highlightmode.desc");
      this.kcnmx.withTranslation("hitbox.highlightcolorsource", "hitbox.highlightcolorsource.desc");
      this.m23.withTranslation("hitbox.highlightcolor", "hitbox.highlightcolor.desc");
      this.ehnb.withTranslation("hitbox.alpha", "hitbox.alpha.desc");
      this.checkField7.withTranslation("hitbox.padding", "hitbox.padding.desc");
      this.arzvc.withTranslation("hitbox.dashedoutline", "hitbox.dashedoutline.desc");
      this.hq0.withTranslation("hitbox.dashdensity", "hitbox.dashdensity.desc");
      this.r18.withTranslation("hitbox.useshader", "hitbox.useshader.desc");
      this.formatField220.withTranslation("hitbox.shadertype", "hitbox.shadertype.desc");
      this.cwidp.withTranslation("hitbox.shaderspeed", "hitbox.shaderspeed.desc");
      this.setup(
         new ModuleSetting[]{
            this.convertField24, this.pagni, this.kcnmx, this.m23, this.ehnb, this.checkField7, this.arzvc, this.hq0, this.r18, this.formatField220, this.cwidp
         }
      );
   }

   @EventHandler
      public void onTick(ClientTickEvent e) {
      if (!this.ehw.isEmpty()) {
         long timestamp = System.currentTimeMillis();
         Iterator iterator2 = this.ehw.entrySet().iterator();

         while (iterator2.hasNext()) {
            if (timestamp - (Long)((Entry)iterator2.next()).getValue() > 450L) {
               iterator2.remove();
            }
         }
      }

      if (MinecraftClient.getInstance().world != null && MinecraftClient.getInstance().world.getTime() % 5L == 0L) {
         this.i18.clear();

         for (PlayerEntity player2 : MinecraftClient.getInstance().world.getPlayers()) {
            if (this.mfbohr(player2)) {
               this.i18.add(player2);
            }
         }

         for (Entity entity : MinecraftClient.getInstance().world.getEntities()) {
            if (entity != null && entity != MinecraftClient.getInstance().player && !(entity instanceof PlayerEntity) && this.cuq(entity)) {
               this.i18.add(entity);
            }
         }
      }
   }

      private boolean mfbohr(PlayerEntity player) {
      if (player == null) {
         return false;
      } else {
         return player == MinecraftClient.getInstance().player ? false : EntityVisibilityFilter.shouldRender(player);
      }
   }

      private boolean cuq(Entity entity) {
      return entity != null && EntityVisibilityFilter.shouldRender(entity) && !entity.isInvisible();
   }

   @EventHandler
      public void onAttack(AttackEntityEvent event) {
      if (this.isState() && event.getEntity() != null && this.pagni.isSelected("On Hit")) {
         this.ehw.put(event.getEntity().getId(), System.currentTimeMillis());
      }
   }

      private boolean cur(PlayerEntity player) {
      ItemStack itemStack = player.getEquippedStack(EquipmentSlot.HEAD);
      ItemStack itemStack2 = player.getEquippedStack(EquipmentSlot.CHEST);
      ItemStack itemStack3 = player.getEquippedStack(EquipmentSlot.LEGS);
      ItemStack itemStack4 = player.getEquippedStack(EquipmentSlot.FEET);
      return !itemStack.isEmpty() && !itemStack2.isEmpty() && !itemStack3.isEmpty() && !itemStack4.isEmpty();
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer e) {
      if (this.isState() && !this.i18.isEmpty()) {
         this.i18.removeIf(entity -> {
            return entity instanceof PlayerEntity && !EntityVisibilityFilter.shouldRender(entity);
         });
         if (!this.i18.isEmpty()) {
            long timestamp = System.nanoTime();
            float value = (float)(timestamp - this.removeField32) / 1E9F;
            this.removeField32 = timestamp;
            this.damxm += value * 20.0F;
            float value2 = tcbpoj(e.getPartialTicks());
            Vec3d client2 = MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getPos();
            Matrix4f matrix = e.getStack().peek().getPositionMatrix();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            Tessellator tessellator = Tessellator.getInstance();
            String text = this.convertField24.getSelected();
            boolean enabled = this.cvhu(text);
            boolean enabled2 = this.awisju(text);
            if (enabled) {
               RenderSystem.depthMask(false);
               RenderSystem.enableDepthTest();
               RenderSystem.disableCull();
               if (this.r18.isValue()) {
                  this.uy(e, this.i18, value2, client2);
               } else {
                  BufferBuilder bufferBuilder = tessellator.begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);

                  for (Entity entity2 : this.i18) {
                     if (entity2 != null) {
                        double x = MathHelper.lerp(value2, entity2.prevX, entity2.getX());
                        double y = MathHelper.lerp(value2, entity2.prevY, entity2.getY());
                        double z = MathHelper.lerp(value2, entity2.prevZ, entity2.getZ());
                        float value3 = (float)client2.distanceTo(new Vec3d(x, y, z));
                        if (!(value3 < 1F)) {
                           Box box = entity2.getDimensions(entity2.getPose()).getBoxAt(x, y, z);
                           box = box.expand(0.001);
                           this.removeMethod62(bufferBuilder, matrix, box, client2, entity2);
                        }
                     }
                  }

                  BuiltBuffer builtBuffer = bufferBuilder.endNullable();
                  if (builtBuffer != null) {
                     BufferRenderer.drawWithGlobalProgram(builtBuffer);
                  }
               }

               RenderSystem.depthMask(true);
            }

            if (enabled2) {
               RenderSystem.enableBlend();
               RenderSystem.defaultBlendFunc();
               RenderSystem.setShader(ShaderProgramKeys.RENDERTYPE_LINES);
               RenderSystem.lineWidth(2.0F);
               RenderSystem.enableDepthTest();
               RenderSystem.disableCull();
               BufferBuilder bufferBuilder2 = tessellator.begin(DrawMode.LINES, VertexFormats.LINES);
               net.minecraft.client.util.math.MatrixStack.Entry entry = e.getStack().peek();
               int index = 0;

               for (Entity entity3 : this.i18) {
                  if (entity3 != null) {
                     double x2 = MathHelper.lerp(value2, entity3.prevX, entity3.getX());
                     double y2 = MathHelper.lerp(value2, entity3.prevY, entity3.getY());
                     double z2 = MathHelper.lerp(value2, entity3.prevZ, entity3.getZ());
                     float value4 = (float)client2.distanceTo(new Vec3d(x2, y2, z2));
                     if (!(value4 < 1F)) {
                        int index2 = Math.abs(entity3.getUuid().hashCode()) % 100;
                        int index3 = this.updateMethod75(entity3, 255);
                        Box box2 = entity3.getDimensions(entity3.getPose()).getBoxAt(x2, y2, z2);
                        box2 = box2.expand(0.002);
                        boolean enabled3 = this.arzvc.isValue();
                        if (enabled3) {
                           this.uw(bufferBuilder2, entry, box2, index3, this.hq0.getValue(), client2);
                        } else {
                           this.mglaim(bufferBuilder2, entry, box2, index3, client2);
                        }

                        index++;
                     }
                  }
               }

               BuiltBuffer builtBuffer2 = bufferBuilder2.endNullable();
               if (builtBuffer2 != null) {
                  BufferRenderer.drawWithGlobalProgram(builtBuffer2);
               }
            }

            RenderSystem.disableBlend();
         }
      }
   }

      private static float tcbpoj(float tickDelta) {
      return !Float.isFinite(tickDelta) ? 1F : MathHelper.clamp(tickDelta, 0F, 1F);
   }

      private void removeMethod62(BufferBuilder buffer, Matrix4f matrix, Box box, Vec3d cameraPos, Entity entity) {
      float value = (float)box.minX;
      float value2 = (float)box.minY;
      float value3 = (float)box.minZ;
      float value4 = (float)box.maxX;
      float value5 = (float)box.maxY;
      float value6 = (float)box.maxZ;
      float value7 = this.ehnb.getValue();
      int index = (int)(value7 * 255.0F);
      int index2 = this.updateMethod75(entity, index);
      buffer.vertex(matrix, value, value2, value3).color(index2);
      buffer.vertex(matrix, value4, value2, value3).color(index2);
      buffer.vertex(matrix, value4, value2, value6).color(index2);
      buffer.vertex(matrix, value, value2, value6).color(index2);
      buffer.vertex(matrix, value, value5, value3).color(index2);
      buffer.vertex(matrix, value, value5, value6).color(index2);
      buffer.vertex(matrix, value4, value5, value6).color(index2);
      buffer.vertex(matrix, value4, value5, value3).color(index2);
      buffer.vertex(matrix, value, value2, value3).color(index2);
      buffer.vertex(matrix, value, value5, value3).color(index2);
      buffer.vertex(matrix, value4, value5, value3).color(index2);
      buffer.vertex(matrix, value4, value2, value3).color(index2);
      buffer.vertex(matrix, value, value2, value6).color(index2);
      buffer.vertex(matrix, value4, value2, value6).color(index2);
      buffer.vertex(matrix, value4, value5, value6).color(index2);
      buffer.vertex(matrix, value, value5, value6).color(index2);
      buffer.vertex(matrix, value, value2, value3).color(index2);
      buffer.vertex(matrix, value, value2, value6).color(index2);
      buffer.vertex(matrix, value, value5, value6).color(index2);
      buffer.vertex(matrix, value, value5, value3).color(index2);
      buffer.vertex(matrix, value4, value2, value3).color(index2);
      buffer.vertex(matrix, value4, value5, value3).color(index2);
      buffer.vertex(matrix, value4, value5, value6).color(index2);
      buffer.vertex(matrix, value4, value2, value6).color(index2);
   }

      private void mglaim(BufferBuilder buffer, net.minecraft.client.util.math.MatrixStack.Entry entry, Box box, int color, Vec3d cameraPos) {
      float value = (float)box.minX;
      float value2 = (float)box.minY;
      float value3 = (float)box.minZ;
      float value4 = (float)box.maxX;
      float value5 = (float)box.maxY;
      float value6 = (float)box.maxZ;
      this.cuvs(buffer, entry, value, value2, value3, value4, value2, value3, color);
      this.cuvs(buffer, entry, value4, value2, value3, value4, value2, value6, color);
      this.cuvs(buffer, entry, value4, value2, value6, value, value2, value6, color);
      this.cuvs(buffer, entry, value, value2, value6, value, value2, value3, color);
      this.cuvs(buffer, entry, value, value5, value3, value4, value5, value3, color);
      this.cuvs(buffer, entry, value4, value5, value3, value4, value5, value6, color);
      this.cuvs(buffer, entry, value4, value5, value6, value, value5, value6, color);
      this.cuvs(buffer, entry, value, value5, value6, value, value5, value3, color);
      this.cuvs(buffer, entry, value, value2, value3, value, value5, value3, color);
      this.cuvs(buffer, entry, value4, value2, value3, value4, value5, value3, color);
      this.cuvs(buffer, entry, value4, value2, value6, value4, value5, value6, color);
      this.cuvs(buffer, entry, value, value2, value6, value, value5, value6, color);
   }

      private void cuvs(
      BufferBuilder buffer, net.minecraft.client.util.math.MatrixStack.Entry entry, float x1, float y1, float z1, float x2, float y2, float z2, int color
   ) {
      float value = x1 - x2;
      float value2 = y1 - y2;
      float value3 = z1 - z2;
      float value4 = value * value + value2 * value2 + value3 * value3;
      if (!(value4 <= 1E-8F)) {
         float value5 = MathHelper.inverseSqrt(value4);
         value *= value5;
         value2 *= value5;
         value3 *= value5;
         buffer.vertex(entry, x1, y1, z1).color(color).normal(entry, value, value2, value3);
         buffer.vertex(entry, x2, y2, z2).color(color).normal(entry, value, value2, value3);
      }
   }

      private void uw(BufferBuilder buffer, net.minecraft.client.util.math.MatrixStack.Entry entry, Box box, int color, float density, Vec3d cameraPos) {
      float value = 0.1F / density;
      float value2 = 0.05F / density;
      float value3 = (color >> 16 & 0xFF) / 255.0F;
      float value4 = (color >> 8 & 0xFF) / 255.0F;
      float value5 = (color & 0xFF) / 255.0F;
      float value6 = (color >> 24 & 0xFF) / 255.0F;
      double value7 = box.minX;
      double value8 = box.minY;
      double value9 = box.minZ;
      double value10 = box.maxX;
      double value11 = box.maxY;
      double value12 = box.maxZ;
      this.hasMethod21(buffer, entry, value7, value8, value9, value10, value8, value9, value3, value4, value5, value6, value, value2);
      this.hasMethod21(buffer, entry, value10, value8, value9, value10, value8, value12, value3, value4, value5, value6, value, value2);
      this.hasMethod21(buffer, entry, value10, value8, value12, value7, value8, value12, value3, value4, value5, value6, value, value2);
      this.hasMethod21(buffer, entry, value7, value8, value12, value7, value8, value9, value3, value4, value5, value6, value, value2);
      this.hasMethod21(buffer, entry, value7, value11, value9, value10, value11, value9, value3, value4, value5, value6, value, value2);
      this.hasMethod21(buffer, entry, value10, value11, value9, value10, value11, value12, value3, value4, value5, value6, value, value2);
      this.hasMethod21(buffer, entry, value10, value11, value12, value7, value11, value12, value3, value4, value5, value6, value, value2);
      this.hasMethod21(buffer, entry, value7, value11, value12, value7, value11, value9, value3, value4, value5, value6, value, value2);
      this.hasMethod21(buffer, entry, value7, value8, value9, value7, value11, value9, value3, value4, value5, value6, value, value2);
      this.hasMethod21(buffer, entry, value10, value8, value9, value10, value11, value9, value3, value4, value5, value6, value, value2);
      this.hasMethod21(buffer, entry, value10, value8, value12, value10, value11, value12, value3, value4, value5, value6, value, value2);
      this.hasMethod21(buffer, entry, value7, value8, value12, value7, value11, value12, value3, value4, value5, value6, value, value2);
   }

      private void hasMethod21(
      BufferBuilder buffer,
      net.minecraft.client.util.math.MatrixStack.Entry entry,
      double x1,
      double y1,
      double z1,
      double x2,
      double y2,
      double z2,
      float r,
      float g,
      float b,
      float a,
      float dashLength,
      float gapLength
   ) {
      double value = x2 - x1;
      double value2 = y2 - y1;
      double value3 = z2 - z1;
      double value4 = Math.sqrt(value * value + value2 * value2 + value3 * value3);
      double value5 = dashLength + gapLength;
      int index = (int)(value4 / value5);

      for (int index2 = 0; index2 <= index; index2++) {
         double value6 = index2 * value5 / value4;
         double value7 = Math.min((index2 * value5 + dashLength) / value4, 1);
         if (!(value7 < 0)) {
            if (value6 >= 1) {
               break;
            }

            value6 = Math.max(value6, 0);
            float value8 = (float)(x1 + value * value6);
            float value9 = (float)(y1 + value2 * value6);
            float value10 = (float)(z1 + value3 * value6);
            float value11 = (float)(x1 + value * value7);
            float value12 = (float)(y1 + value2 * value7);
            float value13 = (float)(z1 + value3 * value7);
            float value14 = value8 - value11;
            float value15 = value9 - value12;
            float value16 = value10 - value13;
            float value17 = value14 * value14 + value15 * value15 + value16 * value16;
            if (!(value17 <= 1E-8F)) {
               float value18 = MathHelper.inverseSqrt(value17);
               value14 *= value18;
               value15 *= value18;
               value16 *= value18;
               int index3 = (int)(a * 255.0F) << 24 | (int)(r * 255.0F) << 16 | (int)(g * 255.0F) << 8 | (int)(b * 255.0F);
               buffer.vertex(entry, value8, value9, value10).color(index3).normal(entry, value14, value15, value16);
               buffer.vertex(entry, value11, value12, value13).color(index3).normal(entry, value14, value15, value16);
            }
         }
      }
   }

      private void uy(VertexMatrixRenderer e, List<Entity> entities, float tickDelta, Vec3d cameraPos) {
      Object object = null;
      String text = this.formatField220.getSelected();

      object = switch (text) {
         case "Wave" -> ShaderRegistry.highlighterShaderWave;
         case "Audio" -> ShaderRegistry.highlighterShaderAudio;
         case "Plasma" -> ShaderRegistry.highlighterShaderPlasma;
         case "Fractal" -> ShaderRegistry.highlighterShaderFractal;
         case "Tunnel" -> ShaderRegistry.highlighterShaderTunnel;
         case "Particles" -> ShaderRegistry.highlighterShaderParticles;
         default -> ShaderRegistry.highlighterShaderWave;
      };
      if (object != null) {
         RenderSystem.enableBlend();
         RenderSystem.enableDepthTest();
         RenderSystem.disableCull();
         RenderSystem.depthMask(false);
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
         Matrix4f matrix = RenderStateGuard.pushModelView(e.getStack().peek().getPositionMatrix());

         try {
            this.uz0((BaseShaderRenderer)object, entities, tickDelta, cameraPos, this.getVisualColor(), this.ehnb.getValue(), false);
            this.uz0(
               (BaseShaderRenderer)object, entities, tickDelta, cameraPos, this.resolveVisualOrCustomColor(this.kcnmx, this.m23), this.ehnb.getValue(), true
            );
         } finally {
            RenderStateGuard.popModelView(matrix);
            RenderStateGuard.restoreWorldDefaults();
         }
      }
   }

      private void uz0(BaseShaderRenderer program, List<Entity> entities, float tickDelta, Vec3d cameraPos, int color, float alpha, boolean highlighted) {
      float value = (color >> 16 & 0xFF) / 255.0F;
      float value2 = (color >> 8 & 0xFF) / 255.0F;
      float value3 = (color & 0xFF) / 255.0F;
      float value4 = 500.0F / this.cwidp.getValue();
      float value5 = 0.5F;
      this.cvaq(program, value, value2, value3, alpha, value4, value5);
      program.use();
      BufferBuilder bufferBuilder = null;
      Matrix4f matrix = new Matrix4f();

      for (Entity entity : entities) {
         if (entity != null && this.cvdu(entity) == highlighted) {
            double x = MathHelper.lerp(tickDelta, entity.prevX, entity.getX());
            double y = MathHelper.lerp(tickDelta, entity.prevY, entity.getY());
            double z = MathHelper.lerp(tickDelta, entity.prevZ, entity.getZ());
            float value6 = (float)cameraPos.distanceTo(new Vec3d(x, y, z));
            if (!(value6 < 1F)) {
               if (bufferBuilder == null) {
                  bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
               }

               Box box = entity.getDimensions(entity.getPose()).getBoxAt(x, y, z).expand(0.001);
               this.rvtgco(bufferBuilder, matrix, box, value, value2, value3, alpha);
            }
         }
      }

      if (bufferBuilder != null) {
         BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      }
   }

      private void cvaq(BaseShaderRenderer program, float red, float green, float blue, float alpha, float shaderSpeed, float shaderScale) {
      if (program instanceof WaveOutlineShader) {
         ((WaveOutlineShader)program)
            .updateUniforms(this.damxm, shaderSpeed, shaderScale, red, green, blue, red, green, blue, red, green, blue, red, green, blue, alpha);
      } else if (program instanceof AudioOutlineShader) {
         ((AudioOutlineShader)program)
            .updateUniforms(this.damxm, shaderSpeed, shaderScale, red, green, blue, red, green, blue, red, green, blue, red, green, blue, alpha);
      } else if (program instanceof PlasmaOutlineShader) {
         ((PlasmaOutlineShader)program)
            .updateUniforms(this.damxm, shaderSpeed, shaderScale, red, green, blue, red, green, blue, red, green, blue, red, green, blue, alpha);
      } else if (program instanceof FractalOutlineShader) {
         ((FractalOutlineShader)program)
            .updateUniforms(this.damxm, shaderSpeed, shaderScale, red, green, blue, red, green, blue, red, green, blue, red, green, blue, alpha);
      } else if (program instanceof TunnelOutlineShader) {
         ((TunnelOutlineShader)program)
            .updateUniforms(this.damxm, shaderSpeed, shaderScale, red, green, blue, red, green, blue, red, green, blue, red, green, blue, alpha);
      } else if (program instanceof ParticleOutlineShader) {
         ((ParticleOutlineShader)program)
            .updateUniforms(this.damxm, shaderSpeed, shaderScale, red, green, blue, red, green, blue, red, green, blue, red, green, blue, alpha);
      }
   }

      private void rvtgco(BufferBuilder buffer, Matrix4f matrix, Box box, float red, float green, float blue, float alpha) {
      float value = (float)box.minX;
      float value2 = (float)box.minY;
      float value3 = (float)box.minZ;
      float value4 = (float)box.maxX;
      float value5 = (float)box.maxY;
      float value6 = (float)box.maxZ;
      buffer.vertex(matrix, value, value2, value3).texture(0F, 0F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value4, value2, value3).texture(1F, 0F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value4, value2, value6).texture(1F, 1F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value, value2, value6).texture(0F, 1F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value, value5, value3).texture(0F, 0F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value, value5, value6).texture(0F, 1F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value4, value5, value6).texture(1F, 1F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value4, value5, value3).texture(1F, 0F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value, value2, value3).texture(0F, 0F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value, value5, value3).texture(0F, 1F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value4, value5, value3).texture(1F, 1F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value4, value2, value3).texture(1F, 0F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value, value2, value6).texture(0F, 0F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value4, value2, value6).texture(1F, 0F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value4, value5, value6).texture(1F, 1F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value, value5, value6).texture(0F, 1F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value, value2, value3).texture(0F, 0F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value, value2, value6).texture(1F, 0F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value, value5, value6).texture(1F, 1F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value, value5, value3).texture(0F, 1F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value4, value2, value3).texture(0F, 0F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value4, value5, value3).texture(0F, 1F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value4, value5, value6).texture(1F, 1F).color(red, green, blue, alpha);
      buffer.vertex(matrix, value4, value2, value6).texture(1F, 0F).color(red, green, blue, alpha);
   }

      private int updateMethod75(Entity entity, int alpha) {
      return this.cvdu(entity)
         ? ColorUtils.replAlpha(this.resolveVisualOrCustomColor(this.kcnmx, this.m23), alpha)
         : this.getVisualColor() & 16777215 | alpha << 24;
   }

      private boolean cvdu(Entity entity) {
      if (entity != null && MinecraftClient.getInstance().player != null) {
         if (this.pagni.isSelected("On Hit") && this.ehw.containsKey(entity.getId())) {
            return true;
         } else {
            return this.pagni.isSelected("On Aim")
                  && entity instanceof PlayerEntity
                  && entity != MinecraftClient.getInstance().player
                  && this.vf(entity)
                  && this.cve0(entity)
               ? true
               : this.pagni.isSelected("In Range")
                  && entity instanceof PlayerEntity
                  && entity != MinecraftClient.getInstance().player
                  && this.vf(entity);
         }
      } else {
         return false;
      }
   }

      private boolean cve0(Entity entity) {
      return MinecraftClient.getInstance().crosshairTarget instanceof EntityHitResult entityHitResult && entityHitResult.getEntity() == entity;
   }

      private boolean vf(Entity entity) {
      Vec3d client = MinecraftClient.getInstance().player.getEyePos();
      Box box = entity.getBoundingBox();
      double value = MathHelper.clamp(client.x, box.minX, box.maxX);
      double value2 = MathHelper.clamp(client.y, box.minY, box.maxY);
      double value3 = MathHelper.clamp(client.z, box.minZ, box.maxZ);
      double value4 = this.mlgjem();
      return client.squaredDistanceTo(value, value2, value3) <= value4 * value4;
   }

      private double mlgjem() {
      try {
         return Math.max(0.1, MinecraftClient.getInstance().player.getEntityInteractionRange());
      } catch (Throwable throwable) {
         return 3.0;
      }
   }

      private boolean cvhu(String mode) {
      return "Fill + Outline".equals(mode)
         || "Both".equals(mode)
         || "Fill".equals(mode);
   }

      private boolean awisju(String mode) {
      return "Outline".equals(mode)
         || "Fill + Outline".equals(mode)
         || "Both".equals(mode)
         || "Fill".equals(mode);
   }

}
