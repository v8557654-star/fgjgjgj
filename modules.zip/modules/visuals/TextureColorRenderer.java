package winvi.noxiumvisuals.modules.visuals;

import java.util.Arrays;
import net.minecraft.block.AirBlock;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import winvi.noxiumvisuals.modules.particles.ParticleTrailModule;
import winvi.noxiumvisuals.utils.ClientPosition;
import winvi.noxiumvisuals.utils.ParticlePhysics;
import winvi.noxiumvisuals.utils.render.RenderMath;
public class TextureColorRenderer {
   private final ParticleTrailModule this$0;
      private static final float w26 = 0.6F;
      private static final float x25 = 1.8F;
      public final Vec3d basePosition;
      public final Identifier textureId;
      public final int[] gradientColors;
      public final long creationTime;
      public final String physics;
      public final float spawnWidth;
      public final float lifetimeOffset;
      public final Mutable collisionCheckPos;
      public float size;
      public double x;
      public double y;
      public double z;
      public double px;
      public double py;
      public double pz;
      public double motionX;
      public double motionY;
      public double motionZ;

      private float controlMethod45() {
      return 0.02F * ParticleTrailModule.particleSize.getValue();
   }

      private float zwxuny() {
      return 0.06F * ParticleTrailModule.particleSize.getValue();
   }

   public TextureColorRenderer(final ParticleTrailModule particleTrailModule, Vec3d position, Identifier textureId, String physics, float spawnWidth, long creationTimeMs) {
      this.this$0 = particleTrailModule;
      this.collisionCheckPos = new Mutable();
      this.basePosition = position;
      this.textureId = textureId;
      this.creationTime = creationTimeMs;
      this.physics = physics;
      this.spawnWidth = spawnWidth;
      this.size = this.controlMethod45();
      this.lifetimeOffset = (particleTrailModule.startField4.nextFloat() - 0.5F) * 0.6F;
      this.initializePosition();
      this.initializeMotion();
      this.gradientColors = new int[4];
      Arrays.fill(this.gradientColors, particleTrailModule.getVisualColor());
   }

      public void initializePosition() {
      float width = this.spawnWidth > 0F ? this.spawnWidth : 1F;
      double value = (this.this$0.startField4.nextFloat() - 0.5F) * 0.6F * width;
      double value2 = this.this$0.startField4.nextFloat() * 1.8F;
      double value3 = (this.this$0.startField4.nextFloat() - 0.5F) * 0.6F * width;
      this.x = this.basePosition.x + value;
      this.y = this.basePosition.y + value2;
      this.z = this.basePosition.z + value3;
      this.px = this.x;
      this.py = this.y;
      this.pz = this.z;
   }

      public void initializeMotion() {
      if (this.physics.equals("Default")) {
         float value = ParticleTrailModule.particleSpread.getValue();
         float value2 = value > 0F ? value * 1E-4F : 0F;
         this.motionX = (this.this$0.startField4.nextFloat() - 0.5F) * value2;
         this.motionY = (this.this$0.startField4.nextFloat() - 0.5F) * value2;
         this.motionZ = (this.this$0.startField4.nextFloat() - 0.5F) * value2;
      } else if (this.physics.equals("Fall")) {
         this.motionX = RenderMath.random(-0.03F, 0.03F);
         this.motionY = RenderMath.random(-0.02F, 0.02F);
         this.motionZ = RenderMath.random(-0.03F, 0.03F);
      } else if (this.physics.equals("Fly")) {
         this.motionX = RenderMath.random(-0.04F, 0.04F);
         this.motionY = RenderMath.random(0.02F, 0.06F);
         this.motionZ = RenderMath.random(-0.04F, 0.04F);
      }
   }

      public void update() {
      this.px = this.x;
      this.py = this.y;
      this.pz = this.z;
      if (this.physics.equals("Default")) {
         float value = ParticleTrailModule.particleGravity.getValue();
         ClientPosition clientPosition = ParticlePhysics.drift(
            (float)this.x,
            (float)this.y,
            (float)this.z,
            (float)this.motionX,
            (float)this.motionY,
            (float)this.motionZ,
            1F,
            ParticleTrailModule.particleSpread.getValue() > 0F ? -5.0E-6F * value : 0F
         );
         this.x = clientPosition.x();
         this.y = clientPosition.y();
         this.z = clientPosition.z();
         this.motionX = clientPosition.motionX();
         this.motionY = clientPosition.motionY();
         this.motionZ = clientPosition.motionZ();
      } else if (this.physics.equals("Fall")) {
         ClientPosition clientPosition2 = ParticlePhysics.bounce(
            (float)this.x, (float)this.y, (float)this.z, (float)this.motionX, (float)this.motionY, (float)this.motionZ, 1F, 0.0018F
         );
         this.x = clientPosition2.x();
         this.y = clientPosition2.y();
         this.z = clientPosition2.z();
         this.motionX = clientPosition2.motionX();
         this.motionY = clientPosition2.motionY();
         this.motionZ = clientPosition2.motionZ();
      } else if (this.physics.equals("Fly")) {
         ClientPosition clientPosition3 = ParticlePhysics.drift(
            (float)this.x, (float)this.y, (float)this.z, (float)this.motionX, (float)this.motionY, (float)this.motionZ, 1F, 0.003F
         );
         this.x = clientPosition3.x();
         this.y = clientPosition3.y();
         this.z = clientPosition3.z();
         this.motionX = clientPosition3.motionX();
         this.motionY = clientPosition3.motionY();
         this.motionZ = clientPosition3.motionZ();
      }
   }

      private boolean branwo(double x, double y, double z) {
      if (ParticleTrailModule.s23.world == null) {
         return false;
      } else {
         this.collisionCheckPos.set((int)x, (int)y, (int)z);
         return !(ParticleTrailModule.s23.world.getBlockState(this.collisionCheckPos).getBlock() instanceof AirBlock);
      }
   }

      public void updateSize(float age, float lifetime) {
      float value = this.controlMethod45();
      float value2 = this.zwxuny();
      float value3 = age + this.lifetimeOffset;
      float value4 = 0.15F;
      float value5 = Math.min(0.5F, lifetime * 0.3F);
      if (value3 < value4) {
         this.size = value + (value2 - value) * (value3 / value4);
      } else if (value3 > lifetime - value5) {
         float value6 = (value3 - (lifetime - value5)) / value5;
         this.size = value2 * (1F - value6);
      } else {
         this.size = value2;
      }
   }

      public Vec3d getPosition() {
      return new Vec3d(this.x, this.y, this.z);
   }

      public Vec3d getInterpolatedPosition(float tickDelta) {
      double value = this.px + (this.x - this.px) * tickDelta;
      double value2 = this.py + (this.y - this.py) * tickDelta;
      double value3 = this.pz + (this.z - this.pz) * tickDelta;
      return new Vec3d(value, value2, value3);
   }

}
