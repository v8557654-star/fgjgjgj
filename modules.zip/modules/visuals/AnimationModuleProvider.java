package winvi.noxiumvisuals.modules.visuals;

public class AnimationModuleProvider {
      private final String cb;
      private final float kgfbr;
      private final float ecd;
      private final float stopField31;
      private final float kgrhh;
      private final boolean cg0;
      private final float hasField470;
      private final ModuleData opsmt;
      private final ModuleData j19;
      private final boolean eckr;
      public static final AnimationModuleProvider BLOCK_HIT = new AnimationModuleProvider(
      "Block Hit",
      0.5F,
      1F,
      0.5F,
      0F,
      true,
      2.0F,
      new ModuleData(
         0F,
         -0.05F,
         -0.7F,
         1.05F,
         -0.7F,
         -1.1F,
         -120.0F,
         -135.0F,
         -60.0F
      ),
      new ModuleData(
         0F,
         -0.05F,
         -0.7F,
         1.05F,
         -0.7F,
         -1.1F,
         -120.0F,
         -180.0F,
         -60.0F
      )
   );
      public static final AnimationModuleProvider BONK = new AnimationModuleProvider(
      "Bonk",
      0.4F,
      0.54F,
      0.58F,
      1F,
      true,
      2.0F,
      new ModuleData(
         0F,
         -0.4F,
         -0.65F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         -0.4F,
         -0.65F,
         0F,
         0F,
         0F,
         -45.0F,
         0F,
         0F
      )
   );
      public static final AnimationModuleProvider ROTATE_360 = new AnimationModuleProvider(
      "Rotate 360",
      0.43F,
      0.61F,
      0.57F,
      1F,
      false,
      2.0F,
      new ModuleData(
         0F,
         -0.4F,
         -0.65F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         -0.4F,
         -0.65F,
         0F,
         0F,
         0F,
         -360.0F,
         0F,
         0F
      )
   );
      public static final AnimationModuleProvider FROM_ME = new AnimationModuleProvider(
      "From Me",
      0.42F,
      0.87F,
      0.58F,
      0.1F,
      true,
      2.0F,
      new ModuleData(
         0F,
         0F,
         -1.1F,
         0.2F,
         0F,
         -0.1F,
         -135.0F,
         45.0F,
         60.0F
      ),
      new ModuleData(
         0F,
         0F,
         -1.1F,
         0.2F,
         0F,
         -0.3F,
         -180.0F,
         45.0F,
         60.0F
      )
   );
      public static final AnimationModuleProvider VANILLA_PLUS = new AnimationModuleProvider(
      "Vanilla+",
      0.42F,
      0F,
      0.58F,
      1F,
      true,
      1F,
      new ModuleData(
         0F,
         -0.26F,
         -0.36F,
         0.28F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         -0.26F,
         -0.36F,
         0.28F,
         0F,
         0F,
         -20.0F,
         5.0F,
         5.0F
      )
   );
      public static final AnimationModuleProvider SWIPE = new AnimationModuleProvider(
      "Swipe",
      0.33F,
      0F,
      0.67F,
      1F,
      true,
      1.5F,
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      true
   );
      public static final AnimationModuleProvider DOWN = new AnimationModuleProvider(
      "Down",
      0.42F,
      0F,
      0.58F,
      1F,
      true,
      1.8F,
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      true
   );
      public static final AnimationModuleProvider SMOOTH = new AnimationModuleProvider(
      "Smooth",
      0.45F,
      0.05F,
      0.55F,
      0.95F,
      true,
      1.2F,
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      true
   );
      public static final AnimationModuleProvider SMOOTH2 = new AnimationModuleProvider(
      "Smooth2",
      0.37F,
      0.17F,
      0.63F,
      0.83F,
      true,
      1.4F,
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      true
   );
      public static final AnimationModuleProvider POWER = new AnimationModuleProvider(
      "Power",
      0.68F,
      0F,
      0.32F,
      1F,
      true,
      2.2F,
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      true
   );
      public static final AnimationModuleProvider FEAST = new AnimationModuleProvider(
      "Feast",
      0.25F,
      0.46F,
      0.45F,
      0.94F,
      true,
      1.6F,
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      true
   );
      public static final AnimationModuleProvider TWIST = new AnimationModuleProvider(
      "Twist",
      0.55F,
      0.09F,
      0.68F,
      0.53F,
      true,
      1.7F,
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      true
   );
      public static final AnimationModuleProvider FIRST = new AnimationModuleProvider(
      "First",
      0.17F,
      0.67F,
      0.83F,
      0.67F,
      true,
      1.3F,
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      true
   );
      public static final AnimationModuleProvider SECOND = new AnimationModuleProvider(
      "Second",
      0.65F,
      0.05F,
      0.36F,
      1F,
      true,
      1.9F,
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      true
   );
      public static final AnimationModuleProvider THIRD = new AnimationModuleProvider(
      "Third",
      0.11F,
      0F,
      0.5F,
      1F,
      true,
      2.0F,
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      true
   );
      public static final AnimationModuleProvider FOURTH = new AnimationModuleProvider(
      "Fourth",
      0.76F,
      0F,
      0.24F,
      1F,
      true,
      1.5F,
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      true
   );
      public static final AnimationModuleProvider FIFTH = new AnimationModuleProvider(
      "Fifth",
      0.39F,
      0.58F,
      0.57F,
      1F,
      true,
      1.8F,
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      new ModuleData(
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F,
         0F
      ),
      true
   );

   public AnimationModuleProvider(
      String name,
      float bezierStartX,
      float bezierStartY,
      float bezierEndX,
      float bezierEndY,
      boolean swingBack,
      float speed,
      ModuleData from,
      ModuleData to
   ) {
      this(name, bezierStartX, bezierStartY, bezierEndX, bezierEndY, swingBack, speed, from, to, false);
   }

   public AnimationModuleProvider(
      String name,
      float bezierStartX,
      float bezierStartY,
      float bezierEndX,
      float bezierEndY,
      boolean swingBack,
      float speed,
      ModuleData from,
      ModuleData to,
      boolean useLegacyAnimation
   ) {
      this.cb = name;
      this.kgfbr = bezierStartX;
      this.ecd = bezierStartY;
      this.stopField31 = bezierEndX;
      this.kgrhh = bezierEndY;
      this.cg0 = swingBack;
      this.hasField470 = speed;
      this.opsmt = from;
      this.j19 = to;
      this.eckr = useLegacyAnimation;
   }

      public String getName() {
      return this.cb;
   }

      public float getBezierStartX() {
      return this.kgfbr;
   }

      public float getBezierStartY() {
      return this.ecd;
   }

      public float getBezierEndX() {
      return this.stopField31;
   }

      public float getBezierEndY() {
      return this.kgrhh;
   }

      public boolean isSwingBack() {
      return this.cg0;
   }

      public float getSpeed() {
      return this.hasField470;
   }

      public ModuleData getFrom() {
      return this.opsmt;
   }

      public ModuleData getTo() {
      return this.j19;
   }

      public boolean isUseLegacyAnimation() {
      return this.eckr;
   }

}
