package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.Vec3d;
public record HitMarkerPoint(
   Vec3d position,
   long createdAt,
   float baseRotation
) {

      public Vec3d position() {
      return this.position;
   }

      public long createdAt() {
      return this.createdAt;
   }

      public float baseRotation() {
      return this.baseRotation;
   }

}
