package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.Vec3d;
public record TrajectoryBasis(
   Vec3d right,
   Vec3d axis,
   Vec3d depth
) {

      public Vec3d right() {
      return this.right;
   }

      public Vec3d axis() {
      return this.axis;
   }

      public Vec3d depth() {
      return this.depth;
   }

}
