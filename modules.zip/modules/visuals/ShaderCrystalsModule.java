package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.awt.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class ShaderCrystalsModule extends Module {
      private final NumberSetting ezalj;
      private final NumberSetting bilon;
      private final BooleanSetting executeField52;

   public ShaderCrystalsModule() {
      super(
         "ShaderCrystals",
         "Shader Crystals",
         ModuleCategory.VISUAL
      );
      this.ezalj = new NumberSetting(
            "Glow Radius",
            "Glow radius"
         )
         .setValue(8.0F)
         .range(1F, 20.0F);
      this.bilon = new NumberSetting(
            "Alpha",
            "Shader alpha"
         )
         .setValue(0.75F)
         .range(0.05F, 1F);
      this.executeField52 = new BooleanSetting(
            "Thin Outline",
            "Thin outline mode"
         )
         .setValue(false);
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{this.ezalj, this.bilon, this.executeField52});
   }

      public boolean shouldRenderEntity(Entity entity) {
      return this.isState() && entity != null && MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null
         ? entity instanceof EndCrystalEntity && !entity.isRemoved() && entity.isAlive()
         : false;
   }

      public Color getColor() {
      return this.lchhku(this.getVisualColor());
   }

      public Color getOutlineColor() {
      return this.getColor();
   }

      public int getColorMode() {
      return 0;
   }

      public Color getThemeGradientColor1() {
      return this.getColor();
   }

      public Color getThemeGradientColor2() {
      return this.getColor();
   }

      public Color getThemeGradientColor3() {
      return this.getColor();
   }

      public Color getThemeGradientColor4() {
      return this.getColor();
   }

      public int getThemeGradientColorCount() {
      return 1;
   }

      public float getThemeGradientPhase() {
      return 0F;
   }

      public float getGlowRadius() {
      return this.ezalj.getValue();
   }

      public float getGlowAlphaMult() {
      return this.getColor().getAlpha() / 255.0F * this.bilon.getValue();
   }

      public int getGlowThinOutline() {
      return this.executeField52.isValue() ? 1 : 0;
   }

      private Color lchhku(int rgb) {
      return new Color(rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF, rgb >> 24 & 0xFF);
   }

   static {
      int index = 0;
   }
}
