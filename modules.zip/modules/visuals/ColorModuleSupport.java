package winvi.noxiumvisuals.modules.visuals;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.visuals.PickBlowupModule;
public final class ColorModuleSupport {
      public final Vec3d bdvaa;
      public final long dgsgb;
      public final int stopField12;
      public final List<PickFragment> manageField750 = new ArrayList<>(48);

   public ColorModuleSupport(final PickBlowupModule pickBlowupModule, Vec3d origin, long startedAt, int color) {
      this.bdvaa = origin;
      this.dgsgb = startedAt;
      this.stopField12 = color;

      for (int index = 0; index < 48; index++) {
         double value = pickBlowupModule.nu0.nextDouble() * 3.141592653589793 * 2.0;
         double value2 = 0.025 + pickBlowupModule.nu0.nextDouble() * 0.08;
         double value3 = 0.28 + pickBlowupModule.nu0.nextDouble() * 0.4;
         double value4 = 0.24 + pickBlowupModule.nu0.nextDouble() * 0.72;
         double value5 = (pickBlowupModule.nu0.nextDouble() - 0.5) * 2.2;
         float value6 = pickBlowupModule.nu0.nextFloat() * 0.24F;
         float value7 = 0.2F + pickBlowupModule.nu0.nextFloat() * 0.65F;
         this.manageField750.add(new PickFragment(value, value2, value3, value4, value5, value6, value7));
      }
   }

}
