package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.text.Text;
public record StableTagEntry(
   Text text,
   long capturedAt
) {

      public Text text() {
      return this.text;
   }

      public long capturedAt() {
      return this.capturedAt;
   }

   static {
      int index = 0;
   }
}
