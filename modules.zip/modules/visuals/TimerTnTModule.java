package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.TntEntity;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.WorldTextRenderer;
public class TimerTnTModule extends Module {
      private static final int dawus = -22016;
      private static final int z27 = -46261;
      private final List<TntEntity> a15;
      private final Comparator<TntEntity> ogjpm;
      private final NumberSetting calculateField34;
      private final NumberSetting gwbbs;
      private final NumberSetting transformField800;

   public TimerTnTModule() {
      super("TimerTnT", ModuleCategory.VISUAL);
      this.a15 = new ArrayList<>();
      this.ogjpm = (first, second) -> {
         return Double.compare(MinecraftClient.getInstance().player.squaredDistanceTo(second), MinecraftClient.getInstance().player.squaredDistanceTo(first));
      };
      this.calculateField34 = new NumberSetting(
            "Size",
            "World-space scale of TNT timers"
         )
         .range(0.5F, 1.5F)
         .setValue(1F);
      this.gwbbs = new NumberSetting(
            "Opacity",
            "Timer background opacity"
         )
         .range(0.2F, 1F)
         .setValue(0.92F);
      this.transformField800 = new NumberSetting(
            "Distance",
            "Maximum TNT timer render distance"
         )
         .range(16, 128)
         .setValue(64.0F);
      this.showVisualColorSettings();
      this.setup(new ModuleSetting[]{this.calculateField34, this.gwbbs, this.transformField800});
   }

      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         double value = this.transformField800.getValue() * this.transformField800.getValue();
         this.a15.clear();

         for (Entity entity : MinecraftClient.getInstance().world.getEntities()) {
            if (entity instanceof TntEntity tntEntity && tntEntity.isAlive() && MinecraftClient.getInstance().player.squaredDistanceTo(tntEntity) <= value) {
               this.a15.add(tntEntity);
            }
         }

         this.a15.sort(this.ogjpm);
         float value2 = event.getPartialTicks();

         for (TntEntity tntEntity2 : this.a15) {
            float value3 = Math.max(0F, (tntEntity2.getFuse() - value2) / 20.0F);
            Vec3d height = tntEntity2.getLerpedPos(value2).add(0, tntEntity2.getHeight() + 0.45, 0);
            WorldTextRenderer.render(
               event,
               height,
               "TNT",
               this.a16(value3),
               ColorUtils.getText(),
               this.mmxdzk(value3),
               0.0105F * this.calculateField34.getValue(),
               this.gwbbs.getValue()
            );
         }
      }
   }

      private String a16(float seconds) {
      int index = Math.max(0, Math.round(seconds * 100.0F));
      int index2 = index / 100;
      int index3 = index % 100;
      return index2 + "." + (index3 < 10 ? "0" : "") + index3 + "s";
   }

      private int mmxdzk(float seconds) {
      if (seconds <= 1F) {
         return -46261;
      } else {
         return seconds <= 3.0F ? ColorUtils.overCol(-22016, -46261, (3.0F - seconds) / 2.0F) : this.getVisualColor();
      }
   }

}
