package winvi.noxiumvisuals.modules.visuals;

public class AnimationModuleSupport {
      public long hitTime;
      public float animationProgress;
      public float fadeInProgress;

   public AnimationModuleSupport(long hitTime) {
      this.hitTime = hitTime;
      this.animationProgress = 1F;
      this.fadeInProgress = 0F;
   }

   static {
      int index = 0;
   }
}
