package winvi.noxiumvisuals.modules.visuals;

public record FragEffectFragment(
   double yaw,
   double startRadius,
   double endRadius,
   double turn,
   double yOffset,
   float colorMix
) {

      public double yaw() {
      return this.yaw;
   }

      public double startRadius() {
      return this.startRadius;
   }

      public double endRadius() {
      return this.endRadius;
   }

      public double turn() {
      return this.turn;
   }

      public double yOffset() {
      return this.yOffset;
   }

      public float colorMix() {
      return this.colorMix;
   }

   static {
      int index = 0;
   }
}
