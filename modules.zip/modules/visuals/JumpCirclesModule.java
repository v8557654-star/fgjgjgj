package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL30C;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.JumpCircleRenderer;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
import winvi.noxiumvisuals.utils.render.WorldPointTrail;
import winvi.noxiumvisuals.utils.render.EnergyRingShader;
import winvi.noxiumvisuals.utils.render.JumpWaveShader;
import winvi.noxiumvisuals.utils.render.ShaderFramebufferRegistry;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
public class JumpCirclesModule extends Module {
      public final ChoiceSetting h18;
      public final ChoiceSetting kcvsh;
      public final NumberSetting nezqg;
      public final NumberSetting kk;
      public final NumberSetting kl;
      public final NumberSetting km3;
      public final NumberSetting ekn;
      public final NumberSetting controlField450;
      public final NumberSetting runField270;
      public final NumberSetting computeField46;
      public final NumberSetting avxmq;
      public final NumberSetting removeField251;
      public final ChoiceSetting transformField380;
      public final ChoiceSetting usods;
      public final ColorSetting calculateField461;
      public final NumberSetting controlField911;
      public final NumberSetting bsznp;
      public final NumberSetting wcuzl;
      public final SettingGroup setField25;
      public static final List<JumpCircleRenderer> updateField700 = new ArrayList<>();
      public static final int handleField93 = 4;
      public static final long elcz = 150L;
      public final Matrix4f jutvb;
      public final WorldPointTrail le;
      public JumpWaveShader validateField370;
      public boolean elgd;
      public EnergyRingShader ezxfq;
      public boolean hasField65;
      public boolean processField6;
      public long elk;

   public JumpCirclesModule() {
      super("Jump Circles", ModuleCategory.VISUAL);
      this.h18 = new ChoiceSetting(
            "Style",
            "Circle style"
         )
         .value(ParticleTextures.getAvailableCircleTextureNames())
         .selected("SHOCKWAVE");
      this.h18.withTranslation("jumpcircles.style", "jumpcircles.style.desc");
      this.kcvsh = new ChoiceSetting(
            "Animation",
            "Animation preset"
         )
         .value(
            "Smooth",
            "Bounce",
            "Elastic",
            "Pop"
         )
         .selected("Bounce")
         .visible(() -> {
            return !this.usdnlt() && !this.joldze();
         });
      this.kcvsh.withTranslation("jumpcircles.animation", "jumpcircles.animation.desc");
      this.nezqg = new NumberSetting(
            "Live Time",
            "Circle lifetime"
         )
         .setValue(1F)
         .range(1F, 10.0F)
         .visible(() -> {
            return !this.joldze();
         });
      this.nezqg.withTranslation("jumpcircles.livetime", "jumpcircles.livetime.desc");
      this.kk = new NumberSetting(
            "Scale",
            "Circle size"
         )
         .setValue(50.0F)
         .range(10.0F, 50.0F)
         .visible(() -> {
            return !this.usdnlt() && !this.joldze();
         });
      this.kk.withTranslation("jumpcircles.scale", "jumpcircles.scale.desc");
      this.kl = new NumberSetting(
            "Spin Speed",
            "Circle rotation speed"
         )
         .setValue(3.0F)
         .range(1F, 10.0F)
         .visible(() -> {
            return !this.usdnlt() && !this.joldze();
         });
      this.kl.withTranslation("jumpcircles.spinspeed", "jumpcircles.spinspeed.desc");
      this.km3 = new NumberSetting(
            "Texture Stretch",
            "Wave-like stretching of textured circles"
         )
         .setValue(0.45F)
         .range(0F, 1.5F)
         .visible(
            () -> {
               return !this.usdnlt()
                  && !this.joldze()
                  && this.h18 != null
                  && !this.h18.isSelected("CIRCLE");
            }
         );
      this.km3.withTranslation("jumpcircles.texturestretch", "jumpcircles.texturestretch.desc");
      this.ekn = new NumberSetting(
            "Lifetime",
            "Lifetime of the expanding energy ring"
         )
         .setValue(800.0F)
         .range(200.0F, 3000.0F)
         .visible(this::joldze);
      this.ekn.withTranslation("jumpcircles.energylifetime", "jumpcircles.energylifetime.desc");
      this.controlField450 = new NumberSetting(
            "Radius",
            "Maximum radius of the energy ring"
         )
         .setValue(1.5F)
         .range(0.5F, 5.0F)
         .visible(this::joldze);
      this.controlField450.withTranslation("jumpcircles.energyradius", "jumpcircles.energyradius.desc");
      this.runField270 = new NumberSetting(
            "Circle Size",
            "Maximum size of the glowing circle"
         )
         .setValue(3.2F)
         .range(1F, 7.0F)
         .visible(this::lmdixx);
      this.runField270.withTranslation("jumpcircles.shockwaveradius", "jumpcircles.shockwaveradius.desc");
      this.computeField46 = new NumberSetting(
            "Circle Width",
            "Thickness of the glowing circle"
         )
         .setValue(0.48F)
         .range(0.15F, 1.25F)
         .visible(this::lmdixx);
      this.computeField46.withTranslation("jumpcircles.shockwavewidth", "jumpcircles.shockwavewidth.desc");
      this.avxmq = new NumberSetting(
            "Glow Brightness",
            "Brightness of the shockwave light"
         )
         .setValue(1.15F)
         .range(0.15F, 2.5F)
         .visible(this::lmdixx);
      this.avxmq.withTranslation("jumpcircles.shockwaveglow", "jumpcircles.shockwaveglow.desc");
      this.removeField251 = new NumberSetting(
            "Glow Spread",
            "Width of the soft light around the wave"
         )
         .setValue(1.35F)
         .range(0.5F, 3.0F)
         .visible(this::lmdixx);
      this.removeField251.withTranslation("jumpcircles.shockwaveglowspread", "jumpcircles.shockwaveglowspread.desc");
      this.transformField380 = new ChoiceSetting(
            "Circle Animation",
            "Expansion animation of the glowing circle"
         )
         .value(
            "Smooth",
            "Bounce",
            "Elastic",
            "Pulse"
         )
         .selected("Smooth")
         .visible(this::lmdixx);
      this.transformField380.withTranslation("jumpcircles.circleanimation", "jumpcircles.circleanimation.desc");
      this.usods = new ChoiceSetting(
            "Shockwave Color Source",
            "Shockwave light color source"
         )
         .value(
            "Visual Color",
            "Custom"
         )
         .displayFormatter(Module::getVisualColorSourceDisplayName)
         .selected("Custom")
         .visible(this::lmdixx);
      this.usods.withTranslation("jumpcircles.shockwavecolorsource", "jumpcircles.shockwavecolorsource.desc");
      this.calculateField461 = new ColorSetting(
            "Shockwave Color",
            "Custom shockwave light color"
         )
         .setColor(-11162881)
         .visible(() -> {
            return this.lmdixx() && this.usods.isSelected("Custom");
         });
      this.calculateField461.withTranslation("jumpcircles.shockwavecolor", "jumpcircles.shockwavecolor.desc");
      this.controlField911 = new NumberSetting(
            "Block Wave Radius",
            "Maximum radius of the block distortion"
         )
         .setValue(6.0F)
         .range(2.0F, 12.0F)
         .visible(this::cxhh);
      this.controlField911.withTranslation("jumpcircles.blockwaveradius", "jumpcircles.blockwaveradius.desc");
      this.bsznp = new NumberSetting(
            "Block Wave Width",
            "Spacing and width of trailing distortions"
         )
         .setValue(0.7F)
         .range(0.25F, 1.8F)
         .visible(this::cxhh);
      this.bsznp.withTranslation("jumpcircles.blockwavewidth", "jumpcircles.blockwavewidth.desc");
      this.wcuzl = new NumberSetting(
            "Block Distortion",
            "Strength of pure block stretching"
         )
         .setValue(8.0F)
         .range(1F, 18.0F)
         .visible(this::cxhh);
      this.wcuzl.withTranslation("jumpcircles.blockwavestrength", "jumpcircles.blockwavestrength.desc");
      this.setField25 = new SettingGroup(
            "Visual Settings",
            "Visual settings for jump circles"
         )
         .settings(
            this.h18,
            this.kcvsh,
            this.nezqg,
            this.kk,
            this.kl,
            this.km3,
            this.ekn,
            this.controlField450,
            this.runField270,
            this.computeField46,
            this.avxmq,
            this.removeField251,
            this.transformField380,
            this.usods,
            this.calculateField461,
            this.controlField911,
            this.bsznp,
            this.wcuzl
         )
         .setValue(true);
      this.setField25.withTranslation("jumpcircles.visualsettings", "jumpcircles.visualsettings.desc");
      this.jutvb = new Matrix4f();
      this.le = new WorldPointTrail();
      this.processField6 = true;
      this.showVisualColorSettings(() -> {
         return !this.lmdixx();
      });
      this.setup(new ModuleSetting[]{this.setField25});
   }

      @Override
   public void deactivate() {
      super.deactivate();
      updateField700.clear();
      this.le.clear();
      this.processField6 = true;
      this.elk = 0L;
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (this.isState() && MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         boolean client = MinecraftClient.getInstance().player.isOnGround();
         if (this.processField6 && !client && MinecraftClient.getInstance().player.getVelocity().y > 0) {
            this.onLocalPlayerJump(MinecraftClient.getInstance().player);
         }

         this.processField6 = client;
      } else {
         this.processField6 = true;
      }
   }

   @EventHandler
      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (this.isState()) {
         this.render(event.getStack(), event.getPartialTicks());
      }
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         long timestamp = System.currentTimeMillis();
         if (this.joldze()) {
            updateField700.clear();
            this.le.render(MinecraftClient.getInstance().gameRenderer.getCamera(), this.d18(), this.controlField450.getValue(), this.getVisualColor());
            return;
         }

         this.le.clear();
         tfgdmz(timestamp);
         if (this.usdnlt()) {
            return;
         }

         Vec3d client = MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getPos();

         for (JumpCircleRenderer shaderTextureRenderer2 : updateField700) {
            shaderTextureRenderer2.render(matrixStack, client.x, client.y, client.z, timestamp);
         }
      }
   }

      public void onLocalPlayerJump(PlayerEntity player) {
      if (this.isState() && player != null && player == MinecraftClient.getInstance().player && MinecraftClient.getInstance().world != null) {
         long timestamp = System.currentTimeMillis();
         if (timestamp - this.elk >= 150L) {
            this.elk = timestamp;
            if (this.joldze()) {
               updateField700.clear();
               this.le.add(player.getPos(), this.ekn.getValue());
            } else {
               this.le.clear();
               updateField700.add(new JumpCircleRenderer(this, player.getPos(), player));
            }
         }
      }
   }

      public void renderCircles(MatrixStack matrixStack, float tickDelta) {
      if (!this.isState()) {
         updateField700.clear();
      } else {
         double x2 = MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getPos().x;
         double y2 = MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getPos().y;
         double z2 = MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getPos().z;
         long timestamp = System.currentTimeMillis();
         if (!this.joldze()) {
            this.le.clear();
            tfgdmz(timestamp);
            if (!this.usdnlt()) {
               for (JumpCircleRenderer shaderTextureRenderer2 : updateField700) {
                  shaderTextureRenderer2.render(matrixStack, x2, y2, z2, timestamp);
               }
            }
         }
      }
   }

      public boolean hasActiveShockwave() {
      return this.isState()
         && this.usdnlt()
         && !updateField700.isEmpty()
         && MinecraftClient.getInstance().player != null
         && MinecraftClient.getInstance().world != null;
   }

      public void renderShockwavePostProcess() {
      if (this.hasActiveShockwave() && !MinecraftClient.getInstance().gameRenderer.isRenderingPanorama()) {
         long timestamp = System.currentTimeMillis();
         tfgdmz(timestamp);
         if (!updateField700.isEmpty()) {
            JumpWaveShader renderRenderer12 = this.cxc();
            if (renderRenderer12 != null) {
               ShaderFramebufferRegistry.checkFramebuffers();
               Framebuffer client = MinecraftClient.getInstance().getFramebuffer();
               SimpleFramebuffer simpleFramebuffer = ShaderFramebufferRegistry.getCopyFbo();
               if (client != null && simpleFramebuffer != null && simpleFramebuffer.getDepthAttachment() > 0) {
                  this.setMethod401(client, simpleFramebuffer);
                  client.beginWrite(false);
                  RenderSystem.viewport(0, 0, client.textureWidth, client.textureHeight);
                  RenderSystem.disableBlend();
                  RenderSystem.disableDepthTest();
                  RenderSystem.depthMask(false);
                  RenderSystem.disableCull();
                  this.cxf(0, simpleFramebuffer.getColorAttachment(), true);
                  this.cxf(1, simpleFramebuffer.getDepthAttachment(), false);
                  int index = this.lmdixx() ? this.resolveVisualOrCustomColor(this.usods, this.calculateField461) : this.getVisualColor();
                  renderRenderer12.bind();
                  int index2 = this.wz0(renderRenderer12, timestamp);
                  renderRenderer12.setUniform1i("SceneTexture", 0);
                  renderRenderer12.setUniform1i("DepthTexture", 1);
                  renderRenderer12.setUniform2f("Resolution", client.textureWidth, client.textureHeight);
                  renderRenderer12.setUniform1i("WaveCount", index2);
                  this.jutvb.set(WorldShapeRenderer.lastProjMat).mul(WorldShapeRenderer.lastWorldSpaceMatrix.getPositionMatrix()).invert();
                  renderRenderer12.setUniformMatrix4f("InvViewProjection", false, this.jutvb);
                  renderRenderer12.setUniform4f(
                     "GlowColor",
                     ColorUtils.redf(index),
                     ColorUtils.greenf(index),
                     ColorUtils.bluef(index),
                     1F
                  );
                  renderRenderer12.setUniform1f(
                     "GlowStrength", this.lmdixx() ? this.avxmq.getValue() : 0F
                  );
                  renderRenderer12.setUniform1f(
                     "GlowSpread",
                     this.lmdixx() ? this.removeField251.getValue() : 1F
                  );
                  renderRenderer12.setUniform1i("EffectMode", this.cxhh() ? 1 : 0);
                  ShaderFramebufferRegistry.drawFullScreenQuad();
                  renderRenderer12.unbind();
                  RenderSystem.activeTexture(33985);
                  RenderSystem.bindTexture(0);
                  RenderSystem.activeTexture(33984);
                  RenderSystem.bindTexture(0);
                  RenderSystem.enableCull();
                  RenderSystem.depthMask(true);
                  RenderSystem.enableDepthTest();
                  RenderSystem.defaultBlendFunc();
               }
            }
         }
      }
   }

      public int wz0(JumpWaveShader shader, long now) {
      int index = 0;
      float value = Math.max(0.05F, this.nezqg.getValue());
      int index2 = Math.max(0, updateField700.size() - 4);

      for (int index3 = index2; index3 < updateField700.size(); index3++) {
         JumpCircleRenderer shaderTextureRenderer2 = updateField700.get(index3);
         float value2 = MathHelper.clamp((float)(now - shaderTextureRenderer2.stopField95) / 1000.0F / value, 0F, 1F);
         if (!(value2 >= 1F)) {
            float value3 = this.lmdixx() ? this.kbnqri(value2) : 1F - (float)Math.pow(1F - value2, 1.350000023841858);
            float value4 = this.executeMethod201(value2);
            Vec3d position = shaderTextureRenderer2.fsddrl();
            float value5 = this.cxhh() ? this.controlField911.getValue() : this.runField270.getValue();
            float value6 = this.cxhh() ? this.bsznp.getValue() : this.computeField46.getValue();
            float value7 = this.cxhh() ? this.wcuzl.getValue() : 0F;
            shader.setUniform4f("Wave" + index, (float)position.x, (float)position.y, (float)position.z, value5 * value3);
            shader.setUniform4f("Params" + index, value6, value7, value4, 1F);
            index++;
         }
      }

      return index;
   }

      public float kbnqri(float progress) {
      float value = MathHelper.clamp(progress, 0F, 1F);
      String text = this.transformField380.getSelected();

      return switch (text) {
         case "Bounce" -> {
            float value2 = value - 1F;
            float value3 = 1.45F;
            yield 1F + (value3 + 1F) * value2 * value2 * value2 + value3 * value2 * value2;
         }
         case "Elastic" -> {
            if (!(value <= 0F) && !(value >= 1F)) {
               float value4 = 2.0943952F;
               yield (float)(Math.pow(2.0, -10.0F * value) * Math.sin((value * 10.0F - 0.75F) * value4) + 1);
            } else {
               yield value;
            }
         }
         case "Pulse" -> {
            float value5 = 1F - (float)Math.pow(1F - value, 3.0);
            float value6 = (float)Math.sin(value * 3.141592653589793 * 4.0) * (1F - value) * 0.055F;
            yield Math.max(0F, value5 + value6);
         }
         default -> value * value * (3.0F - 2.0F * value);
      };
   }

      public float executeMethod201(float progress) {
      float value = (float)Math.pow(Math.max(0, Math.sin(3.141592653589793 * progress)), 0.6800000071525574);
      if (this.lmdixx() && this.transformField380.isSelected("Pulse")) {
         float value2 = 0.72F + 0.28F * (0.5F + 0.5F * (float)Math.sin(progress * 3.141592653589793 * 6.0));
         value *= value2;
      }

      return value;
   }

      public JumpWaveShader cxc() {
      if (this.validateField370 == null && !this.elgd) {
         try {
            this.validateField370 = new JumpWaveShader();
         } catch (RuntimeException runtimeException) {
            this.elgd = true;
            System.err
               .println(
                  "Failed to initialize Jump Circles shockwave shader!"
               );
            runtimeException.printStackTrace();
         }
      }

      return this.validateField370;
   }

      public EnergyRingShader d18() {
      if (this.ezxfq == null && !this.hasField65) {
         try {
            this.ezxfq = new EnergyRingShader();
         } catch (RuntimeException runtimeException) {
            this.hasField65 = true;
            System.err.println("Failed to initialize Energy Ring shader!");
            runtimeException.printStackTrace();
         }
      }

      return this.ezxfq;
   }

      public void setMethod401(Framebuffer source, SimpleFramebuffer target) {
      GlStateManager._glBindFramebuffer(36008, source.fbo);
      GlStateManager._glBindFramebuffer(36009, target.fbo);
      GL30C.glBlitFramebuffer(0, 0, source.textureWidth, source.textureHeight, 0, 0, target.textureWidth, target.textureHeight, 16640, 9728);
   }

      public void cxf(int unit, int texture, boolean linear) {
      RenderSystem.activeTexture(33984 + unit);
      RenderSystem.bindTexture(texture);
      GlStateManager._texParameter(3553, 10241, linear ? 9729 : 9728);
      GlStateManager._texParameter(3553, 10240, linear ? 9729 : 9728);
      GlStateManager._texParameter(3553, 10242, 33071);
      GlStateManager._texParameter(3553, 10243, 33071);
   }

      public boolean lmdixx() {
      return this.h18 != null && this.h18.isSelected("SHOCKWAVE");
   }

      public boolean cxhh() {
      return this.h18 != null && this.h18.isSelected("BLOCK_WAVE");
   }

      public boolean joldze() {
      return this.h18 != null && this.h18.isSelected("ENERGY");
   }

      public boolean usdnlt() {
      return this.lmdixx() || this.cxhh();
   }

      public static void tfgdmz(long currentTimeMs) {
      for (int index = updateField700.size() - 1; index >= 0; index--) {
         if (updateField700.get(index).isExpired(currentTimeMs)) {
            updateField700.remove(index);
         }
      }
   }

      public float calculateMethod42(float progress) {
      String text = this.kcvsh.getSelected();

      return switch (text) {
         case "Bounce" -> {
            float value = 7.5625F;
            float value2 = 2.75F;
            if (progress < 1F / value2) {
               yield value * progress * progress;
            } else if (progress < 2.0F / value2) {
               float value3 = progress - 1.5F / value2;
               yield value * value3 * value3 + 0.75F;
            } else if (progress < 2.5F / value2) {
               float value4 = progress - 2.25F / value2;
               yield value * value4 * value4 + 0.9375F;
            } else {
               float value5 = progress - 2.625F / value2;
               yield value * value5 * value5 + 0.984375F;
            }
         }
         case "Elastic" -> {
            if (progress != 0F && progress != 1F) {
               float value6 = 2.0943952F;
               yield (float)(Math.pow(2.0, -10.0F * progress) * Math.sin((progress * 10.0F - 0.75) * value6) + 1);
            } else {
               yield progress;
            }
         }
         case "Pop" -> progress < 0.5F
            ? (float)(Math.pow(2.0, 20.0F * progress - 10.0F) * Math.sin((20.0F * progress - 11.125) * 3.141592653589793 / 4.5))
            : (float)(1 - Math.pow(2.0, -20.0F * progress + 10.0F) * Math.sin((20.0F * progress - 11.125) * 3.141592653589793 / 4.5));
         default -> progress;
      };
   }

      public Identifier isMethod840() {
      return ParticleTextures.getJumpCircleTexture(this.h18.getSelected());
   }

      public static Color convertMethod340(Color start, Color end, float t) {
      int index = (int)(start.getRed() + t * (end.getRed() - start.getRed()));
      int index2 = (int)(start.getGreen() + t * (end.getGreen() - start.getGreen()));
      int index3 = (int)(start.getBlue() + t * (end.getBlue() - start.getBlue()));
      return new Color(index, index2, index3);
   }

   static {
      int index = 0;
   }
}
