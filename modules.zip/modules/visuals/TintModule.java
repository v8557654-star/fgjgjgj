package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public class TintModule extends Module {
      private static TintModule lbwnt;
      private final NumberSetting pzhzf;
      private final NumberSetting h20;
      private final NumberSetting parseField850;
      private final BooleanSetting ynypc;
      private final NumberSetting processField21;
      private float eule;
      private long um0;

   public TintModule() {
      super("Tint", ModuleCategory.VISUAL);
      this.pzhzf = new NumberSetting(
            "Health Threshold",
            "Health where the edge glow starts"
         )
         .setValue(4.0F)
         .range(1F, 10.0F);
      this.h20 = new NumberSetting(
            "Glow Strength",
            "Maximum opacity of the low-health glow"
         )
         .setValue(0.8F)
         .range(0.15F, 1F);
      this.parseField850 = new NumberSetting(
            "Glow Width",
            "Width of the edge vignette"
         )
         .setValue(28.0F)
         .range(8.0F, 64.0F);
      this.ynypc = new BooleanSetting(
            "Pulse",
            "Subtly pulse the glow at critical health"
         )
         .setValue(true);
      this.processField21 = new NumberSetting(
            "Pulse Speed",
            "Speed of the critical-health pulse"
         )
         .setValue(1F)
         .range(0.25F, 2.5F)
         .visible(this.ynypc::isValue);
      this.showVisualColorSettings();
      lbwnt = this;
      this.pzhzf.withTranslation("tint.threshold", "tint.threshold.desc");
      this.h20.withTranslation("tint.strength", "tint.strength.desc");
      this.parseField850.withTranslation("tint.width", "tint.width.desc");
      this.ynypc.withTranslation("tint.pulse", "tint.pulse.desc");
      this.processField21.withTranslation("tint.pulsespeed", "tint.pulsespeed.desc");
      this.setup(new ModuleSetting[]{this.pzhzf, this.h20, this.parseField850, this.ynypc, this.processField21});
   }

      public static void render(DrawContext context) {
      TintModule tintModule = lbwnt;
      if (tintModule != null) {
         tintModule.removeMethod9(context);
      }
   }

      private void removeMethod9(DrawContext context) {
      long timestamp = System.currentTimeMillis();
      float value = this.um0 == 0L ? 0.016666668F : Math.min((float)(timestamp - this.um0) / 1000.0F, 0.05F);
      this.um0 = timestamp;
      float value2 = 0F;
      if (this.isState() && MinecraftClient.getInstance().player != null && !MinecraftClient.getInstance().player.isDead()) {
         float value3 = Math.max(0.1F, this.pzhzf.getValue());
         value2 = MathHelper.clamp((value3 - MinecraftClient.getInstance().player.getHealth()) / value3, 0F, 1F);
      }

      float value4 = 1F - (float)Math.exp(-value * (value2 > this.eule ? 9.5F : 6.0F));
      this.eule = MathHelper.lerp(value4, this.eule, value2);
      if (!(this.eule <= 0.002F)) {
         float value5 = 1F;
         if (this.ynypc.isValue() && this.eule > 0.35F) {
            double value6 = timestamp / 1000.0 * 3.141592653589793 * 2.0 * this.processField21.getValue();
            value5 = 0.88F + (float)Math.sin(value6) * 0.12F * this.eule;
         }

         int index = Math.max(1, Math.round(this.parseField850.getValue()));
         int width = context.getScaledWindowWidth();
         int height = context.getScaledWindowHeight();
         int index2 = this.getVisualColor() & 16777215;
         float value7 = 185.0F * this.h20.getValue() * this.eule * value5;

         for (int index3 = 0; index3 < index; index3++) {
            float value8 = (float)index3 / index;
            int index4 = MathHelper.clamp(Math.round(value7 * (1F - value8) * (1F - value8)), 0, 255);
            if (index4 > 0) {
               int index5 = index4 << 24 | index2;
               context.fill(index3, index3, width - index3, index3 + 1, index5);
               context.fill(index3, height - index3 - 1, width - index3, height - index3, index5);
               context.fill(index3, index3 + 1, index3 + 1, height - index3 - 1, index5);
               context.fill(width - index3 - 1, index3 + 1, width - index3, height - index3 - 1, index5);
            }
         }
      }
   }

}
