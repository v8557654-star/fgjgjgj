package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import winvi.noxiumvisuals.modules.particles.DamageParticleModule;
import winvi.noxiumvisuals.utils.MsdfFont;
import winvi.noxiumvisuals.utils.TextureFontFactory;
import winvi.noxiumvisuals.utils.render.MsdfTextRenderer;
import winvi.noxiumvisuals.utils.ParticleInstance;
import winvi.noxiumvisuals.utils.render.WorldParticleBatcher;
import winvi.noxiumvisuals.utils.ParticleCameraRenderer;
import winvi.noxiumvisuals.utils.render.RenderMath;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
public class DamageIndicatorParticle extends ParticleInstance {
   private final DamageParticleModule this$0;
      long time;
      float damage;
      float alpha;
      private final long executeField64;
      private final String gfe;
      private final boolean startField260;

   public DamageIndicatorParticle(final DamageParticleModule this$0, float x, float y, float z, float damage, boolean isText) {
      super(x, y, z);
      this.this$0 = this$0;
      this.alpha = 1F;
      this.damage = damage;
      this.startField260 = isText;
      this.time = System.currentTimeMillis();
      this.executeField64 = (long)(this$0.lvmsk.getValue() * 1000.0F);
      if (isText) {
         if (this$0.drc.length > 0) {
            this.gfe = this$0.drc[DamageParticleModule.transformField67.nextInt(this$0.drc.length)];
         } else {
            this.gfe = "";
         }
      } else {
         this.gfe = String.format("-%.2f", damage);
      }

      float value = this$0.m19.getValue();
      if (isText) {
         this.motionX = RenderMath.random(-0.05F, 0.05F) * value;
         this.motionY = RenderMath.random(0.03F, 0.08F) * value;
         this.motionZ = RenderMath.random(-0.05F, 0.05F) * value;
      } else {
         this.motionX = RenderMath.random(-0.02F, 0.02F) * value;
         this.motionY = 0.05F * value;
         this.motionZ = RenderMath.random(-0.02F, 0.02F) * value;
      }
   }

      @Override
   public boolean update(long currentTime, boolean isVisible) {
      this.px = this.x;
      this.py = this.y;
      this.pz = this.z;
      this.x = this.x + this.motionX;
      this.y = this.y + this.motionY;
      this.z = this.z + this.motionZ;
      this.motionY -= 0.003F;
      this.motionX *= 0.98F;
      this.motionZ *= 0.98F;
      long timestamp = currentTime - this.time;
      float value = Math.min(1F, (float)timestamp / (float)this.executeField64);
      return value >= 1F;
   }

      public void render(MatrixStack matrixStack, float tickDelta) {
      if (this.this$0.isState()) {
         long timestamp = System.currentTimeMillis();
         long timestamp2 = timestamp - this.time;
         float value = Math.min(1F, (float)timestamp2 / (float)this.executeField64);
         float value2 = 1F;
         float value3 = this.this$0.skxal.getValue();
         if (value < 0.15F) {
            value2 = value / 0.15F;
         } else if (value > 0.8F) {
            float value4 = (1F - value) / 0.2F;
            if (this.this$0.getField70.getSelected().equals("ALPHA")) {
               value2 = value4;
            } else if (this.this$0.getField70.getSelected().equals("SCALE")) {
               value3 = this.this$0.skxal.getValue() * value4;
            }
         }

         if (!(value2 <= 0.01F) && !(value3 <= 0.01F)) {
            if (ParticleCameraRenderer.isParticleVisible(this.getX(), this.getY(), this.getZ(), 1F)) {
               double value5 = MathHelper.lerp(tickDelta, this.px, this.x);
               double value6 = MathHelper.lerp(tickDelta, this.py, this.y);
               double value7 = MathHelper.lerp(tickDelta, this.pz, this.z);
               matrixStack.push();
               matrixStack.translate(value5, value6, value7);
               matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getYaw()));
               MsdfFont textureVertexRenderer6 = null;
               float value8 = 16.0F;
               float value9;
               if (this.this$0.manageField80.isValue()) {
                  value9 = MinecraftClient.getInstance().textRenderer.getWidth(this.gfe);
                  float value10 = 9.0F;
               } else {
                  try {
                     textureVertexRenderer6 = TextureFontFactory.getBold();
                     value9 = MsdfTextRenderer.getWidth(textureVertexRenderer6, value8, this.gfe);
                     float height = MsdfTextRenderer.getHeight(textureVertexRenderer6, value8);
                  } catch (Exception exception) {
                     value9 = MinecraftClient.getInstance().textRenderer.getWidth(this.gfe);
                     float value11 = 9.0F;
                  }
               }

               matrixStack.scale(-0.025F * value3, -0.025F * value3, 0.025F * value3);
               int index = this.this$0.getVisualColor();
               int index2 = index >> 16 & 0xFF;
               int index3 = index >> 8 & 0xFF;
               int index4 = index & 0xFF;
               int index5 = index2 << 16 | index3 << 8 | index4 | (int)(255.0F * value2) << 24;
               float value12 = value9 * 2.0F;
               matrixStack.push();
               matrixStack.translate(0F, 0F, -0.01F);
               int index6 = (int)(30.0F * value2);
               int index7 = index2 << 16 | index3 << 8 | index4 | index6 << 24;
               WorldParticleBatcher.queueTexturedParticle(
                  matrixStack, ParticleTextures.FIREFLY, value12, value2 * this.this$0.validateField94.getValue(), index7, false, null
               );
               matrixStack.pop();
               if (!this.this$0.manageField80.isValue() && textureVertexRenderer6 != null) {
                  MsdfTextRenderer.drawCenteredString(textureVertexRenderer6, value8, matrixStack, this.gfe, 0F, 0F, index5);
               } else {
                  WorldParticleBatcher.queueTextParticle(matrixStack.peek().getPositionMatrix(), this.gfe, -value9 / 2.0F, 0F, index5);
               }

               matrixStack.pop();
            }
         }
      }
   }

   static {
      int index = 0;
   }
}
