package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
public class BlockPositionRenderRenderer {
      public final BlockPos blockPos;
      public final Box outlineBox;
      public final Box renderBox;
      public final Box cullBox;

   public BlockPositionRenderRenderer(BlockPos blockPos, Box outlineBox, Box renderBox) {
      this.blockPos = blockPos;
      this.outlineBox = outlineBox;
      this.renderBox = renderBox;
      this.cullBox = outlineBox.expand(0.12);
   }

   static {
      int index = 0;
   }
}
