package winvi.noxiumvisuals.modules.visuals;

public class ColorModuleProvider {
      private String dnv;
      private int penmi;

      public String getQuery() {
      return this.dnv;
   }

      public int getColor() {
      return this.penmi;
   }

      public void setQuery(String query) {
      this.dnv = query;
   }

      public void setColor(int color) {
      this.penmi = color;
   }

   public ColorModuleProvider(String query, int color) {
      this.dnv = query;
      this.penmi = color;
   }

}
