package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.ModuleRange;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.EventHandler;
import winvi.noxiumvisuals.systems.events.ClientTickEvent;
import winvi.noxiumvisuals.utils.render.ColorUtils;
public class HitTintModule extends Module {
      private static final int jk0 = 6;
      private static final long eplgd = 70L;
      private static HitTintModule cmltk;
      private final NumberSetting ejn;
      private final NumberSetting controlField380;
      private final NumberSetting removeField370;
      private final NumberSetting ejq;
      private final NumberSetting ejrn;
      private final BooleanSetting aqzrh;
      private final List<ModuleRange> processField930;
      private float caurm;
      private int dkyeq;
      private long wjlqv;

   public HitTintModule() {
      super("Hit Tint", ModuleCategory.VISUAL);
      this.ejn = new NumberSetting(
            "Radius",
            "Distance of the indicator from the crosshair"
         )
         .range(60, 220)
         .setValue(118.0F);
      this.controlField380 = new NumberSetting(
            "Arc Length",
            "Angular width of the damage indicator"
         )
         .range(90, 220)
         .setValue(180.0F);
      this.removeField370 = new NumberSetting(
            "Thickness",
            "Thickness of the bright arc core"
         )
         .range(1F, 7.0F)
         .setValue(2.6F);
      this.ejq = new NumberSetting(
            "Duration",
            "Time the indicator remains visible"
         )
         .range(300, 1400)
         .setValue(720.0F);
      this.ejrn = new NumberSetting(
            "Opacity",
            "Maximum indicator opacity"
         )
         .range(0.2F, 1F)
         .setValue(0.9F);
      this.aqzrh = new BooleanSetting(
            "Glow",
            "Draw a soft halo around the arc"
         )
         .setValue(true);
      this.processField930 = new ArrayList<>(6);
      this.caurm = Float.NaN;
      this.showVisualColorSettings();
      cmltk = this;
      this.setup(new ModuleSetting[]{this.ejn, this.controlField380, this.removeField370, this.ejq, this.ejrn, this.aqzrh});
   }

      public static void render(DrawContext context) {
      HitTintModule hitTintModule = cmltk;
      if (hitTintModule != null && hitTintModule.isState()) {
         hitTintModule.cwi(context);
      }
   }

      @Override
   public void activate() {
      this.updateMethod820();
   }

      @Override
   public void deactivate() {
      this.updateMethod820();
   }

   @EventHandler
      public void onTick(ClientTickEvent event) {
      if (MinecraftClient.getInstance().player != null
         && MinecraftClient.getInstance().world != null
         && !MinecraftClient.getInstance().player.isDead()) {
         float client = MinecraftClient.getInstance().player.getHealth() + MinecraftClient.getInstance().player.getAbsorptionAmount();
         int client2 = MinecraftClient.getInstance().player.hurtTime;
         if (Float.isNaN(this.caurm)) {
            this.caurm = client;
            this.dkyeq = client2;
         } else {
            float value = Math.max(0F, this.caurm - client);
            boolean enabled = client2 > this.dkyeq && client2 >= 7;
            long timestamp = System.currentTimeMillis();
            if ((value > 0.01F || enabled) && timestamp - this.wjlqv >= 70L) {
               this.dijjid(this.initMethod83(), value, timestamp);
               this.wjlqv = timestamp;
            }

            this.caurm = client;
            this.dkyeq = client2;
         }
      } else {
         this.updateMethod820();
      }
   }

      private void cwi(DrawContext context) {
      if (!this.processField930.isEmpty() && MinecraftClient.getInstance().player != null && !MinecraftClient.getInstance().options.hudHidden) {
         long timestamp = System.currentTimeMillis();
         float value = this.ejq.getValue();
         float width = context.getScaledWindowWidth() * 0.5F;
         float height = context.getScaledWindowHeight() * 0.5F;
         float value2 = Math.max(28.0F, Math.min(width, height) - 10.0F);
         float value3 = Math.min(this.ejn.getValue(), value2);
         float client = MinecraftClient.getInstance().gameRenderer.getCamera().getYaw();
         int index = this.getVisualColor();
         MatrixStack matrices = context.getMatrices();
         Matrix4f matrix = matrices.peek().getPositionMatrix();
         BufferBuilder bufferBuilder = null;
         int index2 = 0;
         Iterator iterator2 = this.processField930.iterator();

         while (iterator2.hasNext()) {
            ModuleRange moduleRange = (ModuleRange)iterator2.next();
            float value4 = (float)(timestamp - moduleRange.startedAt()) / value;
            if (value4 >= 1F) {
               iterator2.remove();
            } else {
               float value5 = this.cwpf(MathHelper.clamp(value4 / 0.12F, 0F, 1F));
               float value6 = 1F - this.cwpf(MathHelper.clamp((value4 - 0.22F) / 0.78F, 0F, 1F));
               float value7 = value5 * value6 * this.ejrn.getValue() * moduleRange.strength();
               if (!(value7 <= 0.004F)) {
                  float value8 = 1F - (float)Math.pow(1F - Math.min(value4 / 0.24F, 1F), 3.0);
                  float value9 = value3 - (1F - value8) * 7.0F;
                  float value10 = this.removeField370.getValue() * (1.18F - 0.18F * value8);
                  float value11 = moduleRange.directional() ? MathHelper.wrapDegrees(moduleRange.worldYaw() - client) : 180.0F;
                  float value12 = moduleRange.directional() ? this.controlField380.getValue() : 180.0F;
                  if (bufferBuilder == null) {
                     bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
                  }

                  index2 += this.qknjyp(bufferBuilder, matrix, width, height, value9, value11, value12, value10, value7, index, true);
               }
            }
         }

         if (index2 != 0 && bufferBuilder != null) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableCull();
            RenderSystem.disableDepthTest();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
         }
      }
   }

      private int qknjyp(
      BufferBuilder buffer,
      Matrix4f matrix,
      float centerX,
      float centerY,
      float radius,
      float direction,
      float length,
      float coreThickness,
      float alpha,
      int color,
      boolean fadeEdges
   ) {
      int index = Math.max(20, Math.min(72, Math.round(length / 2.5F)));
      float value = coreThickness * 0.5F;
      float value2 = this.aqzrh.isValue() ? Math.max(4.0F, coreThickness * 2.35F) : 1.15F;
      float[] floatArray = new float[]{-value - value2, -value, value, value + value2};
      float[] floatArray2 = new float[]{0F, 1F, 0.86F, 0F};
      int index2 = color & 16777215;
      int index3 = ColorUtils.overCol(color | 0xFF000000, -1, 0.22F) & 16777215;
      float value3 = direction - length * 0.5F;
      byte byteValue = 0;

      for (int index4 = 0; index4 < index; index4++) {
         float value4 = (float)index4 / index;
         float value5 = (index4 + 1F) / index;
         float value6 = fadeEdges ? this.trugot(value4) : 1F;
         float value7 = fadeEdges ? this.trugot(value5) : 1F;
         float value8 = (float)Math.toRadians(value3 + length * value4);
         float value9 = (float)Math.toRadians(value3 + length * value5);

         for (int index5 = 0; index5 < floatArray.length - 1; index5++) {
            float value10 = radius + floatArray[index5];
            float value11 = radius + floatArray[index5 + 1];
            int index6 = index5 == 1 ? index3 : index2;
            int index7 = index5 == 0 ? index3 : index2;
            int index8 = this.cwqk(index6, alpha * floatArray2[index5] * value6);
            int index9 = this.cwqk(index6, alpha * floatArray2[index5] * value7);
            int index10 = this.cwqk(index7, alpha * floatArray2[index5 + 1] * value7);
            int index11 = this.cwqk(index7, alpha * floatArray2[index5 + 1] * value6);
            this.wk0(buffer, matrix, centerX, centerY, value10, value8, index8);
            this.wk0(buffer, matrix, centerX, centerY, value10, value9, index9);
            this.wk0(buffer, matrix, centerX, centerY, value11, value9, index10);
            this.wk0(buffer, matrix, centerX, centerY, value11, value8, index11);
            byteValue += 4;
         }
      }

      return byteValue;
   }

      private void wk0(BufferBuilder buffer, Matrix4f matrix, float centerX, float centerY, float radius, float angle, int color) {
      float value = centerX + (float)Math.sin(angle) * radius;
      float value2 = centerY - (float)Math.cos(angle) * radius;
      buffer.vertex(matrix, value, value2, 0F).color(color);
   }

      private void dijjid(Float direction, float damage, long now) {
      float value = damage <= 0.01F ? 0.78F : MathHelper.clamp(0.68F + damage / 12.0F, 0.72F, 1F);
      this.processField930.add(new ModuleRange(direction == null ? 0F : direction, direction != null, value, now));

      while (this.processField930.size() > 6) {
         this.processField930.remove(0);
      }
   }

      private Float initMethod83() {
      DamageSource client = MinecraftClient.getInstance().player.getRecentDamageSource();
      if (client == null) {
         return null;
      } else {
         Entity entity = client.getAttacker();
         if (!this.deleteMethod69(entity)) {
            entity = client.getSource();
         }

         if (!this.deleteMethod69(entity)) {
            return null;
         } else {
            double x = entity.getX() - MinecraftClient.getInstance().player.getX();
            double z = entity.getZ() - MinecraftClient.getInstance().player.getZ();
            return x * x + z * z < 1E-5 ? null : (float)(Math.toDegrees(Math.atan2(z, x)) - 90.0);
         }
      }
   }

      private boolean deleteMethod69(Entity entity) {
      return entity != null && entity != MinecraftClient.getInstance().player;
   }

      private float trugot(float progress) {
      float value = (float)Math.sin(3.141592653589793 * MathHelper.clamp(progress, 0F, 1F));
      return (float)Math.pow(Math.max(0F, value), 0.7200000286102295);
   }

      private float cwpf(float value) {
      return value * value * (3.0F - 2.0F * value);
   }

      private int cwqk(int rgb, float alpha) {
      int index = MathHelper.clamp(Math.round(alpha * 255.0F), 0, 255);
      return index << 24 | rgb;
   }

      private void updateMethod820() {
      this.processField930.clear();
      this.caurm = Float.NaN;
      this.dkyeq = 0;
      this.wjlqv = 0L;
   }

}
