package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.Vec3d;
public record ModulePosition(
   Vec3d x,
   Vec3d y,
   Vec3d z
) {

      public Vec3d x() {
      return this.x;
   }

      public Vec3d y() {
      return this.y;
   }

      public Vec3d z() {
      return this.z;
   }

}
