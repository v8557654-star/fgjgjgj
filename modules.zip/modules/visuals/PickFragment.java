package winvi.noxiumvisuals.modules.visuals;

public record PickFragment(
   double angle,
   double startRadius,
   double endRadius,
   double lift,
   double turn,
   float delay,
   float whiteMix
) {

      public double angle() {
      return this.angle;
   }

      public double startRadius() {
      return this.startRadius;
   }

      public double endRadius() {
      return this.endRadius;
   }

      public double lift() {
      return this.lift;
   }

      public double turn() {
      return this.turn;
   }

      public float delay() {
      return this.delay;
   }

      public float whiteMix() {
      return this.whiteMix;
   }

}
