package winvi.noxiumvisuals.modules.visuals;

public record ModuleData(
   float anchorX,
   float anchorY,
   float anchorZ,
   float moveX,
   float moveY,
   float moveZ,
   float rotateX,
   float rotateY,
   float rotateZ
) {
      public static ModuleData ZERO = new ModuleData(
      0F,
      0F,
      0F,
      0F,
      0F,
      0F,
      0F,
      0F,
      0F
   );

      public float anchorX() {
      return this.anchorX;
   }

      public float anchorY() {
      return this.anchorY;
   }

      public float anchorZ() {
      return this.anchorZ;
   }

      public float moveX() {
      return this.moveX;
   }

      public float moveY() {
      return this.moveY;
   }

      public float moveZ() {
      return this.moveZ;
   }

      public float rotateX() {
      return this.rotateX;
   }

      public float rotateY() {
      return this.rotateY;
   }

      public float rotateZ() {
      return this.rotateZ;
   }

   static {
      int index = 0;
   }
}
