package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import org.joml.Matrix4f;
import org.joml.Vector4i;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.ModuleBounds;
import winvi.noxiumvisuals.modules.visuals.ModelModuleData;
import winvi.noxiumvisuals.modules.visuals.TextureModuleData;
import winvi.noxiumvisuals.modules.visuals.ColorModuleStyle;
import winvi.noxiumvisuals.modules.visuals.ItemStackModelData;
import winvi.noxiumvisuals.modules.visuals.PredictionBounds;
import winvi.noxiumvisuals.modules.visuals.ScreenPoint;
import winvi.noxiumvisuals.modules.visuals.VoxelSpan;
import winvi.noxiumvisuals.modules.visuals.PredictionBox;
import winvi.noxiumvisuals.modules.visuals.MatrixModuleStyle;
import winvi.noxiumvisuals.modules.visuals.ColorModuleBounds;
import winvi.noxiumvisuals.modules.visuals.TrajectoryBasis;
import winvi.noxiumvisuals.modules.visuals.CollisionBounds;
import winvi.noxiumvisuals.modules.visuals.TrajectoryCache;
import winvi.noxiumvisuals.modules.visuals.ProjectileType;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.PacketRenderRenderer;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
public class PredictonModule extends Module {
      static final float TRIDENT_THROW_SPEED = 2.5F;
      static final double TRIDENT_GRAVITY = 0.05;
      static final float TRIDENT_AIR_DRAG = 0.99F;
      static final float TRIDENT_WATER_DRAG = 0.6F;
      static final float THROWN_ITEM_SPEED = 1.5F;
      static final double THROWN_ITEM_GRAVITY = 0.03;
      static final float THROWN_ITEM_WATER_DRAG = 0.8F;
      static final float POTION_SPEED = 0.5F;
      static final double POTION_GRAVITY = 0.05;
      static final float EXPERIENCE_BOTTLE_SPEED = 0.7F;
      static final double EXPERIENCE_BOTTLE_GRAVITY = 0.07;
      static final float BOW_FULL_SPEED = 3.0F;
      static final float CROSSBOW_ARROW_SPEED = 3.15F;
      static final float CROSSBOW_FIREWORK_SPEED = 1.6F;
      static final float CROSSBOW_PROJECTILE_SPREAD = 10.0F;
      static final float PITCH_UP_OFFSET = -20.0F;
      static final float VANILLA_TRIDENT_CENTER_Y = 11.5F;
      static final float TRIDENT_MODEL_SIZE = 1.5F;
      static final float LINE_SURFACE_OFFSET = 0.015F;
      static final float MODEL_SURFACE_OFFSET = 0.08F;
      static final float MODEL_SMOOTHING = 0.32F;
      static final double MODEL_SMOOTH_RESET_DISTANCE = 9.0;
      static final int MAX_PIXEL_TEXTURE_SIZE = 64;
      static final ItemStack DEFAULT_ARROW_STACK = new ItemStack(Items.ARROW);
      static final PredictionBox[] VANILLA_TRIDENT_PARTS;
      private NumberSetting isField25;
      private BooleanSetting kwoiv;
      private NumberSetting x19;
      private NumberSetting yvjld;
      private NumberSetting xvpzz;
      private BooleanSetting oa0;
      private NumberSetting eobz;
      private NumberSetting initField60;
      private ChoiceSetting eodw;
      private Map<String, ColorModuleBounds> cfijn;
      private Vec3d getField81;
      private Vec3d formatField820;
      private Vec3d ofian;
      private String oi0;
      private final List<TrajectoryCache> j26;
      private final Mutable eokz;
      private final Predicate<Entity> destroyField38;

   public PredictonModule() {
      super(
         "Predicton",
         "Shows the predicted trident trajectory",
         ModuleCategory.VISUAL
      );
      this.isField25 = new NumberSetting(
            "Steps",
            "Prediction simulation steps"
         )
         .setValue(90.0F)
         .range(20.0F, 160.0F);
      this.kwoiv = new BooleanSetting(
            "Show Line",
            "Draw prediction trajectory line"
         )
         .setValue(true);
      this.x19 = new NumberSetting(
            "Line Width",
            "Trajectory line width"
         )
         .setValue(2.0F)
         .range(1F, 5.0F)
         .visible(() -> {
            return this.kwoiv.isValue();
         });
      this.yvjld = new NumberSetting(
            "Model Size",
            "Impact model size"
         )
         .setValue(0.85F)
         .range(0.4F, 1.8F);
      this.xvpzz = new NumberSetting(
            "Transparency",
            "Prediction transparency"
         )
         .setValue(0.85F)
         .range(0.05F, 1F);
      this.oa0 = new BooleanSetting(
            "Glow",
            "Glow at the predicted impact point"
         )
         .setValue(true);
      this.eobz = new NumberSetting(
            "Glow Size",
            "Impact glow size"
         )
         .setValue(1.1F)
         .range(0.3F, 2.5F)
         .visible(() -> {
            return this.oa0.isValue();
         });
      this.initField60 = new NumberSetting(
            "Glow Opacity",
            "Impact glow opacity"
         )
         .setValue(0.55F)
         .range(0.05F, 1F)
         .visible(() -> {
            return this.oa0.isValue();
         });
      this.eodw = new ChoiceSetting(
            "Model",
            "Prediction model"
         )
         .value(
            "Auto",
            "Custom",
            "Off"
         )
         .selected("Auto");
      this.cfijn = new HashMap<>();
      this.j26 = new ArrayList<>(3);
      this.eokz = new Mutable();
      this.destroyField38 = this::salnzi;
      this.showVisualColorSettings();
      this.isField25.withTranslation("predicton.steps", "predicton.steps.desc");
      this.kwoiv.withTranslation("predicton.showline", "predicton.showline.desc");
      this.x19.withTranslation("predicton.linewidth", "predicton.linewidth.desc");
      this.yvjld.withTranslation("predicton.modelsize", "predicton.modelsize.desc");
      this.xvpzz.withTranslation("predicton.transparency", "predicton.transparency.desc");
      this.oa0.withTranslation("predicton.glow", "predicton.glow.desc");
      this.eobz.withTranslation("predicton.glowsize", "predicton.glowsize.desc");
      this.initField60.withTranslation("predicton.glowopacity", "predicton.glowopacity.desc");
      this.eodw.withTranslation("predicton.model", "predicton.model.desc");
      this.setup(new ModuleSetting[]{this.isField25, this.kwoiv, this.x19, this.yvjld, this.xvpzz, this.oa0, this.eobz, this.initField60, this.eodw});
   }

      @Override
   public void onWorldRender(VertexMatrixRenderer event) {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null && PacketRenderRenderer.isFunTime()) {
         List list = this.computeMethod66();
         if (list.isEmpty()) {
            this.slgfcy();
            this.j26.clear();
         } else {
            boolean enabled = list.size() == 1;
            if (!enabled) {
               this.slgfcy();
            }

            boolean enabled2 = false;

            for (int index = 0; index < list.size(); index++) {
               ItemStackModelData itemStackModelData = (ItemStackModelData)list.get(index);
               ModelModuleData modelModuleData = this.xqrzsv(event.getPartialTicks(), itemStackModelData, index);
               if (modelModuleData.points().size() >= 2) {
                  enabled2 = true;
                  if (this.kwoiv.isValue()) {
                     this.getMethod83(event, modelModuleData);
                  }

                  if (!this.eodw.isSelected("Off")) {
                     ModelModuleData modelModuleData2 = enabled ? this.wpwhtj(modelModuleData, itemStackModelData) : modelModuleData;
                     if (this.oa0.isValue()) {
                        this.onwisa(modelModuleData2);
                     }

                     this.processMethod55(event, modelModuleData2, itemStackModelData);
                  }
               }
            }

            if (!enabled2) {
               this.slgfcy();
            }
         }
      } else {
         this.slgfcy();
         this.j26.clear();
      }
   }

      private List<ItemStackModelData> computeMethod66() {
      ItemStack client = MinecraftClient.getInstance().player.getMainHandStack();
      if (client.isOf(Items.TRIDENT)) {
         return List.of(new ItemStackModelData(client, 2.5F, 0.05, 0.99F, 0.6F, 0F, 0F, ProjectileType.TRIDENT));
      } else {
         ItemStack client2 = MinecraftClient.getInstance().player.getOffHandStack();
         if (client2.isOf(Items.TRIDENT)) {
            return List.of(new ItemStackModelData(client2, 2.5F, 0.05, 0.99F, 0.6F, 0F, 0F, ProjectileType.TRIDENT));
         } else {
            ItemStackModelData itemStackModelData = this.addMethod77(client);
            if (itemStackModelData != null) {
               return List.of(itemStackModelData);
            } else {
               itemStackModelData = this.addMethod77(client2);
               if (itemStackModelData != null) {
                  return List.of(itemStackModelData);
               } else {
                  List list = this.cze0(client);
                  return !list.isEmpty() ? list : this.cze0(client2);
               }
            }
         }
      }
   }

      private ItemStackModelData addMethod77(ItemStack stack) {
      if (stack.isEmpty()) {
         return null;
      } else if (stack.isOf(Items.ENDER_PEARL)) {
         return new ItemStackModelData(stack, 1.5F, 0.03, 0.99F, 0.8F, 0F, 0F, ProjectileType.PEARL);
      } else if (stack.isOf(Items.SNOWBALL)) {
         return new ItemStackModelData(stack, 1.5F, 0.03, 0.99F, 0.8F, 0F, 0F, ProjectileType.SNOWBALL);
      } else if (stack.isOf(Items.EGG)) {
         return new ItemStackModelData(stack, 1.5F, 0.03, 0.99F, 0.8F, 0F, 0F, ProjectileType.EGG);
      } else if (stack.isOf(Items.WIND_CHARGE)) {
         return new ItemStackModelData(stack, 1.5F, 0.03, 0.99F, 0.8F, 0F, 0F, ProjectileType.WIND_CHARGE);
      } else if (stack.isOf(Items.SPLASH_POTION) || stack.isOf(Items.LINGERING_POTION)) {
         return new ItemStackModelData(stack, 0.5F, 0.05, 0.99F, 0.8F, -20.0F, 0F, ProjectileType.POTION);
      } else {
         return stack.isOf(Items.EXPERIENCE_BOTTLE) ? new ItemStackModelData(stack, 0.7F, 0.07, 0.99F, 0.8F, -20.0F, 0F, ProjectileType.EXPERIENCE_BOTTLE) : null;
      }
   }

      private List<ItemStackModelData> cze0(ItemStack weaponStack) {
      if (weaponStack.isEmpty()) {
         return List.of();
      } else if (!weaponStack.isOf(Items.BOW)) {
         if (weaponStack.isOf(Items.CROSSBOW)) {
            ChargedProjectilesComponent chargedProjectilesComponent = (ChargedProjectilesComponent)weaponStack.getOrDefault(
               DataComponentTypes.CHARGED_PROJECTILES, ChargedProjectilesComponent.DEFAULT
            );
            if (chargedProjectilesComponent.isEmpty()) {
               return List.of();
            } else {
               List list = chargedProjectilesComponent.getProjectiles().isEmpty() ? List.of(DEFAULT_ARROW_STACK) : chargedProjectilesComponent.getProjectiles();
               ArrayList arrayList = new ArrayList(list.size());

               for (int index = 0; index < list.size(); index++) {
                  ItemStack itemStack = (ItemStack)list.get(index);
                  if (!itemStack.isEmpty()) {
                     boolean enabled = itemStack.isOf(Items.FIREWORK_ROCKET);
                     arrayList.add(
                        new ItemStackModelData(
                           itemStack,
                           enabled ? 1.6F : 3.15F,
                           enabled ? 0 : 0.05,
                           0.99F,
                           0.6F,
                           0F,
                           this.czfb(index, list.size()),
                           enabled ? ProjectileType.FIREWORK : ProjectileType.ARROW
                        )
                     );
                  }
               }

               return arrayList;
            }
         } else {
            return List.of();
         }
      } else {
         boolean client = MinecraftClient.getInstance().player.isUsingItem()
            && MinecraftClient.getInstance().player.getActiveItem().isOf(Items.BOW);
         float client2 = client ? BowItem.getPullProgress(MinecraftClient.getInstance().player.getItemUseTime()) : 1F;
         if (client2 <= 0.1F) {
            return List.of();
         } else {
            ItemStack itemStack2 = this.convertMethod820(weaponStack);
            return List.of(new ItemStackModelData(itemStack2, client2 * 3.0F, 0.05, 0.99F, 0.6F, 0F, 0F, ProjectileType.ARROW));
         }
      }
   }

      private float czfb(int index, int projectileCount) {
      if (projectileCount <= 1) {
         return 0F;
      } else {
         float value = 20.0F / (projectileCount - 1);
         float value2 = (projectileCount - 1) % 2 * value / 2.0F;
         float value3 = index % 2 == 0 ? 1F : -1F;
         return value2 + value3 * ((index + 1) / 2) * value;
      }
   }

      private ItemStack convertMethod820(ItemStack weaponStack) {
      ItemStack client = MinecraftClient.getInstance().player.getProjectileType(weaponStack);
      return client.isEmpty() ? DEFAULT_ARROW_STACK : client;
   }

      private ModelModuleData xqrzsv(float tickDelta, ItemStackModelData profile, int profileIndex) {
      int index = MathHelper.clamp((int)this.isField25.getValue(), 20, 160);
      Vec3d client = MinecraftClient.getInstance().player.getEyePos().add(0, -0.1F, 0);
      float client2 = MinecraftClient.getInstance().player.getPitch(tickDelta) + profile.pitchOffset();
      float client3 = MinecraftClient.getInstance().player.getYaw(tickDelta);
      long client4 = MinecraftClient.getInstance().world.getTime();
      TrajectoryCache moduleSupport4;
      if (profileIndex < this.j26.size()) {
         moduleSupport4 = this.j26.get(profileIndex);
      } else {
         moduleSupport4 = new TrajectoryCache();
         this.j26.add(moduleSupport4);
      }

      if (moduleSupport4.ouzoia(MinecraftClient.getInstance().world, client4, client, client2, client3, index, profile)) {
         return moduleSupport4.validateField36;
      } else {
         ModelModuleData modelModuleData = this.vrvthc(profile, index, client, client2, client3);
         moduleSupport4.smcdyz(MinecraftClient.getInstance().world, client4, client, client2, client3, index, profile, modelModuleData);
         return modelModuleData;
      }
   }

      private ModelModuleData vrvthc(ItemStackModelData profile, int maxSteps, Vec3d position, float pitch, float yaw) {
      ArrayList arrayList = new ArrayList(maxSteps + 1);
      Vec3d position2 = this.zofxkr(pitch, yaw);
      if (profile.spreadOffset() != 0F) {
         position2 = this.calculateMethod82(position2, this.zofxkr(pitch - 90.0F, yaw), profile.spreadOffset());
      }

      Vec3d position3 = position2.normalize().multiply(profile.speed());
      Vec3d position4 = position3.normalize();
      Vec3d position5 = position4.multiply(-1F);
      boolean enabled = false;
      arrayList.add(position);

      for (int index = 0; index < maxSteps; index++) {
         Vec3d position6 = position.add(position3);
         HitResult hitResult = this.czm(position, position6);
         if (hitResult != null && hitResult.getType() != Type.MISS) {
            arrayList.add(hitResult.getPos());
            position4 = position3.normalize();
            position5 = this.czkr(hitResult, position3);
            enabled = true;
            break;
         }

         position = position6;
         arrayList.add(position6);
         this.eokz.set((int)Math.floor(position6.x), (int)Math.floor(position6.y), (int)Math.floor(position6.z));
         float client = MinecraftClient.getInstance().world.getFluidState(this.eokz).isIn(FluidTags.WATER)
            ? profile.waterDrag()
            : profile.airDrag();
         position3 = position3.multiply(client).add(0, -profile.gravity(), 0);
         position4 = position3.normalize();
         if (position6.y < MinecraftClient.getInstance().world.getBottomY() - 8.0) {
            break;
         }
      }

      return new ModelModuleData(arrayList, position4, position5, enabled);
   }

      private Vec3d calculateMethod82(Vec3d vector, Vec3d axis, float degrees) {
      if (!(Math.abs(degrees) < 0.001F) && !(axis.lengthSquared() < 1E-4)) {
         Vec3d position = axis.normalize();
         double value = Math.toRadians(degrees);
         double value2 = Math.cos(value);
         double value3 = Math.sin(value);
         double value4 = position.dotProduct(vector);
         return vector.multiply(value2).add(position.crossProduct(vector).multiply(value3)).add(position.multiply(value4 * (1 - value2)));
      } else {
         return vector;
      }
   }

      private Vec3d czkr(HitResult hitResult, Vec3d velocity) {
      if (hitResult instanceof BlockHitResult blockHitResult) {
         return new Vec3d(blockHitResult.getSide().getOffsetX(), blockHitResult.getSide().getOffsetY(), blockHitResult.getSide().getOffsetZ()).normalize();
      } else {
         return velocity.lengthSquared() > 1E-4 ? velocity.normalize().multiply(-1F) : new Vec3d(0, 1, 0);
      }
   }

      private Vec3d zofxkr(float pitch, float yaw) {
      float value = (float)Math.cos(-yaw * 0.017453292F - 3.141592653589793);
      float value2 = (float)Math.sin(-yaw * 0.017453292F - 3.141592653589793);
      float value3 = (float)(-Math.cos(-pitch * 0.017453292F));
      float value4 = (float)Math.sin(-pitch * 0.017453292F);
      return new Vec3d(value2 * value3, value4, value * value3);
   }

      private HitResult czm(Vec3d from, Vec3d to) {
      BlockHitResult client = MinecraftClient.getInstance()
         .world
         .raycast(new RaycastContext(from, to, ShapeType.COLLIDER, FluidHandling.NONE, MinecraftClient.getInstance().player));
      Vec3d position = client.getType() == Type.MISS ? to : client.getPos();
      Box box = new Box(
            Math.min(from.x, position.x),
            Math.min(from.y, position.y),
            Math.min(from.z, position.z),
            Math.max(from.x, position.x),
            Math.max(from.y, position.y),
            Math.max(from.z, position.z)
         )
         .expand(1);
      EntityHitResult client2 = ProjectileUtil.raycast(
         MinecraftClient.getInstance().player, from, position, box, this.destroyField38, from.squaredDistanceTo(position)
      );
      return (HitResult)(client2 != null ? client2 : client);
   }

      private boolean salnzi(Entity entity) {
      return entity != MinecraftClient.getInstance().player
         && !entity.isSpectator()
         && entity.canHit()
         && entity.getRootVehicle() != MinecraftClient.getInstance().player.getRootVehicle();
   }

      private void getMethod83(VertexMatrixRenderer event, ModelModuleData prediction) {
      List list = prediction.points();
      int index = this.getVisualColor();
      float value = MathHelper.clamp(this.xvpzz.getValue(), 0.05F, 1F);
      int index2 = list.size() - 1;

      for (int index3 = 0; index3 < index2; index3++) {
         Vec3d position = this.mtvlfo(prediction, index3);
         Vec3d position2 = this.mtvlfo(prediction, index3 + 1);
         float value2 = 0.25F + 0.75F * (index3 + 1) / index2;
         int index4 = ColorUtils.multAlpha(index, value * value2);
         WorldShapeRenderer.drawLine(position, position2, index4, MathHelper.clamp(this.x19.getValue(), 1F, 5.0F), false);
      }
   }

      private void onwisa(ModelModuleData prediction) {
      Camera client = MinecraftClient.getInstance().gameRenderer.getCamera();
      Vec3d position = prediction.eae().add(this.qquayr(prediction));
      Vec3d position2 = position.subtract(client.getPos());
      MatrixStack matrices = new MatrixStack();
      matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(client.getYaw() + 180.0F));
      matrices.translate(position2.x, position2.y, position2.z);
      matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-client.getYaw()));
      matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(client.getPitch()));
      float value = Math.max(0.1F, this.yvjld.getValue() * this.eobz.getValue());
      int index = ColorUtils.multAlpha(this.getVisualColor(), this.xvpzz.getValue() * this.initField60.getValue());
      WorldShapeRenderer.drawTexture(matrices.peek(), ParticleTextures.BLOOM, -value * 0.5F, -value * 0.5F, value, value, new Vector4i(index), true, true);
   }

      private Vec3d mtvlfo(ModelModuleData prediction, int index) {
      List list = prediction.points();
      Vec3d position = (Vec3d)list.get(index);
      return prediction.hit() && index == list.size() - 1 ? position.add(prediction.surfaceNormal().multiply(0.014999999664723873)) : position;
   }

      private void processMethod55(VertexMatrixRenderer event, ModelModuleData prediction, ItemStackModelData profile) {
      switch (profile.modelType()) {
         case TRIDENT:
            this.initMethod390(event, prediction);
            break;
         case ARROW:
         case PEARL:
         case SNOWBALL:
         case EGG:
         case WIND_CHARGE:
         case POTION:
         case EXPERIENCE_BOTTLE:
         case FIREWORK:
         case VOXEL:
            this.vvhjhj(event, prediction, profile.modelStack());
      }
   }

      private ModelModuleData wpwhtj(ModelModuleData prediction, ItemStackModelData profile) {
      Vec3d position = prediction.points().get(prediction.points().size() - 1);
      Vec3d client = prediction.direction().lengthSquared() > 1E-4
         ? prediction.direction().normalize()
         : MinecraftClient.getInstance().player.getRotationVec(1F).normalize();
      Vec3d position2 = prediction.surfaceNormal().lengthSquared() > 1E-4 ? prediction.surfaceNormal().normalize() : client.multiply(-1F);
      String text = this.kurkzj(profile);
      boolean enabled = this.getField81 == null
         || this.formatField820 == null
         || this.ofian == null
         || this.oi0 == null
         || !this.oi0.equals(text)
         || this.getField81.squaredDistanceTo(position) > 81.0;
      if (enabled) {
         this.getField81 = position;
         this.formatField820 = client;
         this.ofian = position2;
         this.oi0 = text;
      } else {
         this.getField81 = this.getField81.lerp(position, 0.3199999928474426);
         this.formatField820 = this.getMethod86(this.formatField820.lerp(client, 0.3199999928474426), client);
         this.ofian = this.getMethod86(this.ofian.lerp(position2, 0.3199999928474426), position2);
      }

      return new ModelModuleData(prediction.points(), this.formatField820, this.ofian, prediction.hit(), this.getField81);
   }

      private String kurkzj(ItemStackModelData profile) {
      Identifier identifier = Registries.ITEM.getId(profile.modelStack().getItem());
      return profile.modelType() + ":" + identifier + ":" + profile.spreadOffset();
   }

      private Vec3d getMethod86(Vec3d value, Vec3d fallback) {
      return value.lengthSquared() > 1E-4 ? value.normalize() : fallback;
   }

      private void slgfcy() {
      this.getField81 = null;
      this.formatField820 = null;
      this.ofian = null;
      this.oi0 = null;
   }

      private MatrixModuleStyle czw(VertexMatrixRenderer event, ModelModuleData prediction, ItemStack stack, ColorModuleBounds itemModel) {
      Vec3d client = prediction.direction().lengthSquared() > 1E-4
         ? prediction.direction().normalize()
         : MinecraftClient.getInstance().player.getRotationVec(event.getPartialTicks()).normalize();
      Vec3d position = prediction.eae();
      float value = 0.85F * MathHelper.clamp(this.yvjld.getValue(), 0.4F, 1.8F);
      float width2 = value / Math.max(itemModel.width(), itemModel.height());
      Vec3d position2 = this.qquayr(prediction);
      TrajectoryBasis moduleData7;
      Vec3d position3;
      if (this.handleMethod46(stack)) {
         moduleData7 = this.destroyMethod88(client);
         ScreenPoint moduleData5 = this.hasMethod13(itemModel, width2);
         Vec3d position4 = position.add(position2);
         position3 = position4.subtract(moduleData7.right().multiply(moduleData5.x())).subtract(moduleData7.axis().multiply(moduleData5.y()));
      } else {
         moduleData7 = this.getMethod961(client);
         position3 = position.add(position2).subtract(moduleData7.depth().multiply(width2 * 0.5F));
      }

      return new MatrixModuleStyle(event.getStack().peek().getPositionMatrix(), position3, moduleData7, value, MathHelper.clamp(this.xvpzz.getValue(), 0.05F, 1F));
   }

      private Vec3d qquayr(ModelModuleData prediction) {
      return prediction.hit() ? prediction.surfaceNormal().multiply(0.07999999821186066) : Vec3d.ZERO;
   }

      private void vvhjhj(VertexMatrixRenderer event, ModelModuleData prediction, ItemStack stack) {
      if (!stack.isEmpty()) {
         ColorModuleBounds colorModuleBounds = this.controlMethod531(stack);
         if (!colorModuleBounds.pixels().isEmpty()) {
            MatrixModuleStyle matrixModuleStyle = this.czw(event, prediction, stack, colorModuleBounds);
            if (matrixModuleStyle != null) {
               float width2 = matrixModuleStyle.scale() / Math.max(colorModuleBounds.width(), colorModuleBounds.height());
               float value = this.handleMethod46(stack) ? width2 * 1.6F : width2;
               RenderSystem.enableDepthTest();
               RenderSystem.enableBlend();
               RenderSystem.disableCull();
               RenderSystem.depthMask(true);
               RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
               RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
               BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);

               for (VoxelSpan moduleRange4 : colorModuleBounds.faceRuns()) {
                  this.dai(bufferBuilder, matrixModuleStyle.matrix(), matrixModuleStyle.origin(), matrixModuleStyle.basis(), colorModuleBounds, moduleRange4, width2, value, matrixModuleStyle.alpha());
               }

               for (VoxelSpan moduleRange42 : colorModuleBounds.topRuns()) {
                  this.aj(bufferBuilder, matrixModuleStyle.matrix(), matrixModuleStyle.origin(), matrixModuleStyle.basis(), colorModuleBounds, moduleRange42, width2, value, matrixModuleStyle.alpha(), true);
               }

               for (VoxelSpan moduleRange43 : colorModuleBounds.bottomRuns()) {
                  this.aj(bufferBuilder, matrixModuleStyle.matrix(), matrixModuleStyle.origin(), matrixModuleStyle.basis(), colorModuleBounds, moduleRange43, width2, value, matrixModuleStyle.alpha(), false);
               }

               for (VoxelSpan moduleRange44 : colorModuleBounds.leftRuns()) {
                  this.sprblv(bufferBuilder, matrixModuleStyle.matrix(), matrixModuleStyle.origin(), matrixModuleStyle.basis(), colorModuleBounds, moduleRange44, width2, value, matrixModuleStyle.alpha(), true);
               }

               for (VoxelSpan moduleRange45 : colorModuleBounds.rightRuns()) {
                  this.sprblv(bufferBuilder, matrixModuleStyle.matrix(), matrixModuleStyle.origin(), matrixModuleStyle.basis(), colorModuleBounds, moduleRange45, width2, value, matrixModuleStyle.alpha(), false);
               }

               BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
               RenderSystem.lineWidth(3.0F);
               BufferBuilder bufferBuilder2 = Tessellator.getInstance().begin(DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

               for (VoxelSpan moduleRange46 : colorModuleBounds.topRuns()) {
                  this.meilwt(bufferBuilder2, matrixModuleStyle.matrix(), matrixModuleStyle.origin(), matrixModuleStyle.basis(), colorModuleBounds, moduleRange46, width2, value, matrixModuleStyle.alpha(), true);
               }

               for (VoxelSpan moduleRange47 : colorModuleBounds.bottomRuns()) {
                  this.meilwt(bufferBuilder2, matrixModuleStyle.matrix(), matrixModuleStyle.origin(), matrixModuleStyle.basis(), colorModuleBounds, moduleRange47, width2, value, matrixModuleStyle.alpha(), false);
               }

               for (VoxelSpan moduleRange48 : colorModuleBounds.leftRuns()) {
                  this.isMethod96(bufferBuilder2, matrixModuleStyle.matrix(), matrixModuleStyle.origin(), matrixModuleStyle.basis(), colorModuleBounds, moduleRange48, width2, value, matrixModuleStyle.alpha(), true);
               }

               for (VoxelSpan moduleRange49 : colorModuleBounds.rightRuns()) {
                  this.isMethod96(bufferBuilder2, matrixModuleStyle.matrix(), matrixModuleStyle.origin(), matrixModuleStyle.basis(), colorModuleBounds, moduleRange49, width2, value, matrixModuleStyle.alpha(), false);
               }

               BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
               RenderSystem.lineWidth(1F);
               RenderSystem.defaultBlendFunc();
               RenderSystem.enableCull();
               RenderSystem.disableBlend();
            }
         }
      }
   }

      private ColorModuleBounds controlMethod531(ItemStack stack) {
      String text = this.destroyMethod370(stack);
      return this.cfijn.computeIfAbsent(text, ignored -> {
         return this.xuilwb(stack);
      });
   }

      private String destroyMethod370(ItemStack stack) {
      Identifier identifier = Registries.ITEM.getId(stack.getItem());
      return identifier.toString();
   }

      private boolean handleMethod46(ItemStack stack) {
      return stack.isOf(Items.ARROW) || stack.isOf(Items.TIPPED_ARROW) || stack.isOf(Items.SPECTRAL_ARROW);
   }

      private ColorModuleBounds xuilwb(ItemStack stack) {
      List list = this.dagw(stack);
      int index = 0;
      int index2 = 0;
      int[][] intArrayArray = null;

      for (TextureModuleData textureModuleData : (Iterable<TextureModuleData>)(Iterable<?>) (list)) {
         Resource client = (Resource)MinecraftClient.getInstance().getResourceManager().getResource(textureModuleData.texture()).orElse(null);
         if (client != null) {
            try (InputStream inputStream = client.getInputStream()) {
               NativeImage nativeImage = NativeImage.read(inputStream);

               try {
                  if (intArrayArray == null) {
                     index = Math.min(nativeImage.getWidth(), 64);
                     index2 = Math.min(nativeImage.getHeight(), 64);
                     intArrayArray = new int[index2][index];
                  }

                  for (int index3 = 0; index3 < index2; index3++) {
                     for (int index4 = 0; index4 < index; index4++) {
                        int width = index4 * nativeImage.getWidth() / index;
                        int height = index3 * nativeImage.getHeight() / index2;
                        int color = nativeImage.getColorArgb(width, height);
                        int index5 = color >>> 24 & 0xFF;
                        if (index5 != 0) {
                           int index6 = intArrayArray[index3][index4] >>> 24;
                           intArrayArray[index3][index4] = Math.max(index6, index5) << 24;
                        }
                     }
                  }
               } catch (Throwable throwable) {
                  if (nativeImage != null) {
                     try {
                        nativeImage.close();
                     } catch (Throwable throwable2) {
                        throwable.addSuppressed(throwable2);
                     }
                  }

                  throw throwable;
               }

               if (nativeImage != null) {
                  nativeImage.close();
               }
            } catch (IOException ioexception) {
            }
         }
      }

      if (intArrayArray != null && index > 0 && index2 > 0) {
         ArrayList arrayList = new ArrayList(index * index2);

         for (int index7 = 0; index7 < index2; index7++) {
            for (int index8 = 0; index8 < index; index8++) {
               int index9 = intArrayArray[index7][index8];
               if ((index9 >>> 24 & 0xFF) > 0) {
                  arrayList.add(new ColorModuleStyle(index8, index7, index9));
               }
            }
         }

         return new ColorModuleBounds(
            index,
            index2,
            intArrayArray,
            arrayList,
            this.zgvgbb(intArrayArray, index, index2),
            this.getMethod94(intArrayArray, index, index2, true),
            this.getMethod94(intArrayArray, index, index2, false),
            this.manageMethod270(intArrayArray, index, index2, true),
            this.manageMethod270(intArrayArray, index, index2, false)
         );
      } else {
         return ColorModuleBounds.empty();
      }
   }

      private List<VoxelSpan> zgvgbb(int[][] colors, int width, int height) {
      ArrayList arrayList = new ArrayList();

      for (int index = 0; index < height; index++) {
         int index2 = -1;

         for (int index3 = 0; index3 <= width; index3++) {
            boolean width2 = index3 < width && this.u25(colors, width, height, index3, index);
            if (width2 && index2 == -1) {
               index2 = index3;
            } else if (!width2 && index2 != -1) {
               arrayList.add(new VoxelSpan(index, index2, index3 - 1));
               index2 = -1;
            }
         }
      }

      return arrayList;
   }

      private List<VoxelSpan> getMethod94(int[][] colors, int width, int height, boolean top) {
      ArrayList arrayList = new ArrayList();
      int index = top ? -1 : 1;

      for (int index2 = 0; index2 < height; index2++) {
         int index3 = -1;

         for (int index4 = 0; index4 <= width; index4++) {
            boolean width2 = index4 < width && this.u25(colors, width, height, index4, index2) && !this.u25(colors, width, height, index4, index2 + index);
            if (width2 && index3 == -1) {
               index3 = index4;
            } else if (!width2 && index3 != -1) {
               arrayList.add(new VoxelSpan(index2, index3, index4 - 1));
               index3 = -1;
            }
         }
      }

      return arrayList;
   }

      private List<VoxelSpan> manageMethod270(int[][] colors, int width, int height, boolean left) {
      ArrayList arrayList = new ArrayList();
      int index = left ? -1 : 1;

      for (int index2 = 0; index2 < width; index2++) {
         int index3 = -1;

         for (int index4 = 0; index4 <= height; index4++) {
            boolean width2 = index4 < height && this.u25(colors, width, height, index2, index4) && !this.u25(colors, width, height, index2 + index, index4);
            if (width2 && index3 == -1) {
               index3 = index4;
            } else if (!width2 && index3 != -1) {
               arrayList.add(new VoxelSpan(index2, index3, index4 - 1));
               index3 = -1;
            }
         }
      }

      return arrayList;
   }

      private List<TextureModuleData> dagw(ItemStack stack) {
      if (stack.isOf(Items.TIPPED_ARROW)) {
         return List.of(new TextureModuleData(this.mrpcnv("tipped_arrow_head")), new TextureModuleData(this.mrpcnv("tipped_arrow_base")));
      } else if (stack.isOf(Items.SPECTRAL_ARROW)) {
         return List.of(new TextureModuleData(this.mrpcnv("spectral_arrow")));
      } else if (stack.isOf(Items.SPLASH_POTION)) {
         return List.of(new TextureModuleData(this.mrpcnv("potion_overlay")), new TextureModuleData(this.mrpcnv("splash_potion")));
      } else if (stack.isOf(Items.LINGERING_POTION)) {
         return List.of(new TextureModuleData(this.mrpcnv("potion_overlay")), new TextureModuleData(this.mrpcnv("lingering_potion")));
      } else {
         Identifier identifier = Registries.ITEM.getId(stack.getItem());
         return List.of(new TextureModuleData(Identifier.of(identifier.getNamespace(), "textures/item/" + identifier.getPath() + ".png")));
      }
   }

      private Identifier mrpcnv(String path) {
      return Identifier.ofVanilla("textures/item/" + path + ".png");
   }

      private void dai(
      BufferBuilder buffer,
      Matrix4f matrix,
      Vec3d origin,
      TrajectoryBasis basis,
      ColorModuleBounds model,
      VoxelSpan run,
      float pixelSize,
      float depth,
      float alpha
   ) {
      ModuleBounds moduleBounds = this.n16(model, run, pixelSize, depth);
      int index = this.ycfcdu(alpha, 1F);
      int index2 = this.ycfcdu(alpha, 0.62F);
      this.transformMethod66(
         buffer,
         matrix,
         origin,
         basis,
         moduleBounds.minX(),
         moduleBounds.minY(),
         moduleBounds.maxZ(),
         moduleBounds.maxX(),
         moduleBounds.minY(),
         moduleBounds.maxZ(),
         moduleBounds.maxX(),
         moduleBounds.maxY(),
         moduleBounds.maxZ(),
         moduleBounds.minX(),
         moduleBounds.maxY(),
         moduleBounds.maxZ(),
         index
      );
      this.transformMethod66(
         buffer,
         matrix,
         origin,
         basis,
         moduleBounds.minX(),
         moduleBounds.maxY(),
         moduleBounds.minZ(),
         moduleBounds.maxX(),
         moduleBounds.maxY(),
         moduleBounds.minZ(),
         moduleBounds.maxX(),
         moduleBounds.minY(),
         moduleBounds.minZ(),
         moduleBounds.minX(),
         moduleBounds.minY(),
         moduleBounds.minZ(),
         index2
      );
   }

      private void aj(
      BufferBuilder buffer,
      Matrix4f matrix,
      Vec3d origin,
      TrajectoryBasis basis,
      ColorModuleBounds model,
      VoxelSpan run,
      float pixelSize,
      float depth,
      float alpha,
      boolean top
   ) {
      ModuleBounds moduleBounds = this.n16(model, run, pixelSize, depth);
      float value = top ? moduleBounds.maxY() : moduleBounds.minY();
      int index = this.ycfcdu(alpha, 0.78F);
      if (top) {
         this.transformMethod66(
            buffer,
            matrix,
            origin,
            basis,
            moduleBounds.minX(),
            value,
            moduleBounds.minZ(),
            moduleBounds.minX(),
            value,
            moduleBounds.maxZ(),
            moduleBounds.maxX(),
            value,
            moduleBounds.maxZ(),
            moduleBounds.maxX(),
            value,
            moduleBounds.minZ(),
            index
         );
      } else {
         this.transformMethod66(
            buffer,
            matrix,
            origin,
            basis,
            moduleBounds.minX(),
            value,
            moduleBounds.maxZ(),
            moduleBounds.minX(),
            value,
            moduleBounds.minZ(),
            moduleBounds.maxX(),
            value,
            moduleBounds.minZ(),
            moduleBounds.maxX(),
            value,
            moduleBounds.maxZ(),
            index
         );
      }
   }

      private void sprblv(
      BufferBuilder buffer,
      Matrix4f matrix,
      Vec3d origin,
      TrajectoryBasis basis,
      ColorModuleBounds model,
      VoxelSpan run,
      float pixelSize,
      float depth,
      float alpha,
      boolean left
   ) {
      ModuleBounds moduleBounds = this.felgpy(model, run, pixelSize, depth);
      float value = left ? moduleBounds.minX() : moduleBounds.maxX();
      int index = this.ycfcdu(alpha, 0.78F);
      if (left) {
         this.transformMethod66(
            buffer,
            matrix,
            origin,
            basis,
            value,
            moduleBounds.minY(),
            moduleBounds.minZ(),
            value,
            moduleBounds.minY(),
            moduleBounds.maxZ(),
            value,
            moduleBounds.maxY(),
            moduleBounds.maxZ(),
            value,
            moduleBounds.maxY(),
            moduleBounds.minZ(),
            index
         );
      } else {
         this.transformMethod66(
            buffer,
            matrix,
            origin,
            basis,
            value,
            moduleBounds.minY(),
            moduleBounds.maxZ(),
            value,
            moduleBounds.minY(),
            moduleBounds.minZ(),
            value,
            moduleBounds.maxY(),
            moduleBounds.minZ(),
            value,
            moduleBounds.maxY(),
            moduleBounds.maxZ(),
            index
         );
      }
   }

      private void meilwt(
      BufferBuilder buffer,
      Matrix4f matrix,
      Vec3d origin,
      TrajectoryBasis basis,
      ColorModuleBounds model,
      VoxelSpan run,
      float pixelSize,
      float depth,
      float alpha,
      boolean top
   ) {
      ModuleBounds moduleBounds = this.n16(model, run, pixelSize, depth);
      float value = top ? moduleBounds.maxY() : moduleBounds.minY();
      int index = this.ycfcdu(alpha, 1.35F);
      this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds.minX(), value, moduleBounds.minZ(), moduleBounds.maxX(), value, moduleBounds.minZ(), index);
      this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds.minX(), value, moduleBounds.maxZ(), moduleBounds.maxX(), value, moduleBounds.maxZ(), index);
      this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds.minX(), value, moduleBounds.minZ(), moduleBounds.minX(), value, moduleBounds.maxZ(), index);
      this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds.maxX(), value, moduleBounds.minZ(), moduleBounds.maxX(), value, moduleBounds.maxZ(), index);
   }

      private void isMethod96(
      BufferBuilder buffer,
      Matrix4f matrix,
      Vec3d origin,
      TrajectoryBasis basis,
      ColorModuleBounds model,
      VoxelSpan run,
      float pixelSize,
      float depth,
      float alpha,
      boolean left
   ) {
      ModuleBounds moduleBounds = this.felgpy(model, run, pixelSize, depth);
      float value = left ? moduleBounds.minX() : moduleBounds.maxX();
      int index = this.ycfcdu(alpha, 1.35F);
      this.destroyMethod560(buffer, matrix, origin, basis, value, moduleBounds.minY(), moduleBounds.minZ(), value, moduleBounds.maxY(), moduleBounds.minZ(), index);
      this.destroyMethod560(buffer, matrix, origin, basis, value, moduleBounds.minY(), moduleBounds.maxZ(), value, moduleBounds.maxY(), moduleBounds.maxZ(), index);
      this.destroyMethod560(buffer, matrix, origin, basis, value, moduleBounds.minY(), moduleBounds.minZ(), value, moduleBounds.minY(), moduleBounds.maxZ(), index);
      this.destroyMethod560(buffer, matrix, origin, basis, value, moduleBounds.maxY(), moduleBounds.minZ(), value, moduleBounds.maxY(), moduleBounds.maxZ(), index);
   }

      private ModuleBounds n16(ColorModuleBounds model, VoxelSpan run, float pixelSize, float depth) {
      float width2 = (run.start() - model.width() * 0.5F) * pixelSize;
      float width3 = (run.end() + 1F - model.width() * 0.5F) * pixelSize;
      float height2 = (model.height() * 0.5F - run.fixed() - 1F) * pixelSize;
      float value = height2 + pixelSize;
      return new ModuleBounds(width2, height2, -depth * 0.5F, width3, value, depth * 0.5F);
   }

      private ModuleBounds felgpy(ColorModuleBounds model, VoxelSpan run, float pixelSize, float depth) {
      float width2 = (run.fixed() - model.width() * 0.5F) * pixelSize;
      float value = width2 + pixelSize;
      float height2 = (model.height() * 0.5F - run.start()) * pixelSize;
      float height3 = (model.height() * 0.5F - run.end() - 1F) * pixelSize;
      return new ModuleBounds(width2, height3, -depth * 0.5F, value, height2, depth * 0.5F);
   }

      private int ycfcdu(float alpha, float shade) {
      return this.iyycqf(ColorUtils.multAlpha(this.getVisualColor(), alpha), shade);
   }

      private void daq(
      BufferBuilder buffer,
      Matrix4f matrix,
      Vec3d origin,
      TrajectoryBasis basis,
      ColorModuleBounds model,
      ColorModuleStyle pixel,
      float pixelSize,
      float depth,
      float alpha
   ) {
      PredictionBounds moduleBounds3 = this.s25(model, pixel, pixelSize, depth);
      int index = this.sujzwq(pixel, alpha, 1F);
      int index2 = this.sujzwq(pixel, alpha, 0.62F);
      int index3 = this.sujzwq(pixel, alpha, 0.78F);
      this.transformMethod66(
         buffer,
         matrix,
         origin,
         basis,
         moduleBounds3.minX(),
         moduleBounds3.minY(),
         moduleBounds3.maxZ(),
         moduleBounds3.maxX(),
         moduleBounds3.minY(),
         moduleBounds3.maxZ(),
         moduleBounds3.maxX(),
         moduleBounds3.maxY(),
         moduleBounds3.maxZ(),
         moduleBounds3.minX(),
         moduleBounds3.maxY(),
         moduleBounds3.maxZ(),
         index
      );
      this.transformMethod66(
         buffer,
         matrix,
         origin,
         basis,
         moduleBounds3.minX(),
         moduleBounds3.maxY(),
         moduleBounds3.minZ(),
         moduleBounds3.maxX(),
         moduleBounds3.maxY(),
         moduleBounds3.minZ(),
         moduleBounds3.maxX(),
         moduleBounds3.minY(),
         moduleBounds3.minZ(),
         moduleBounds3.minX(),
         moduleBounds3.minY(),
         moduleBounds3.minZ(),
         index2
      );
      if (!this.mamaoy(model, pixel.x(), pixel.y() - 1)) {
         this.transformMethod66(
            buffer,
            matrix,
            origin,
            basis,
            moduleBounds3.minX(),
            moduleBounds3.maxY(),
            moduleBounds3.minZ(),
            moduleBounds3.minX(),
            moduleBounds3.maxY(),
            moduleBounds3.maxZ(),
            moduleBounds3.maxX(),
            moduleBounds3.maxY(),
            moduleBounds3.maxZ(),
            moduleBounds3.maxX(),
            moduleBounds3.maxY(),
            moduleBounds3.minZ(),
            index3
         );
      }

      if (!this.mamaoy(model, pixel.x(), pixel.y() + 1)) {
         this.transformMethod66(
            buffer,
            matrix,
            origin,
            basis,
            moduleBounds3.minX(),
            moduleBounds3.minY(),
            moduleBounds3.maxZ(),
            moduleBounds3.minX(),
            moduleBounds3.minY(),
            moduleBounds3.minZ(),
            moduleBounds3.maxX(),
            moduleBounds3.minY(),
            moduleBounds3.minZ(),
            moduleBounds3.maxX(),
            moduleBounds3.minY(),
            moduleBounds3.maxZ(),
            index3
         );
      }

      if (!this.mamaoy(model, pixel.x() - 1, pixel.y())) {
         this.transformMethod66(
            buffer,
            matrix,
            origin,
            basis,
            moduleBounds3.minX(),
            moduleBounds3.minY(),
            moduleBounds3.minZ(),
            moduleBounds3.minX(),
            moduleBounds3.minY(),
            moduleBounds3.maxZ(),
            moduleBounds3.minX(),
            moduleBounds3.maxY(),
            moduleBounds3.maxZ(),
            moduleBounds3.minX(),
            moduleBounds3.maxY(),
            moduleBounds3.minZ(),
            index3
         );
      }

      if (!this.mamaoy(model, pixel.x() + 1, pixel.y())) {
         this.transformMethod66(
            buffer,
            matrix,
            origin,
            basis,
            moduleBounds3.maxX(),
            moduleBounds3.minY(),
            moduleBounds3.maxZ(),
            moduleBounds3.maxX(),
            moduleBounds3.minY(),
            moduleBounds3.minZ(),
            moduleBounds3.maxX(),
            moduleBounds3.maxY(),
            moduleBounds3.minZ(),
            moduleBounds3.maxX(),
            moduleBounds3.maxY(),
            moduleBounds3.maxZ(),
            index3
         );
      }
   }

      private void nhhgvz(
      BufferBuilder buffer,
      Matrix4f matrix,
      Vec3d origin,
      TrajectoryBasis basis,
      ColorModuleBounds model,
      ColorModuleStyle pixel,
      float pixelSize,
      float depth,
      float alpha
   ) {
      PredictionBounds moduleBounds3 = this.s25(model, pixel, pixelSize, depth);
      int index = this.sujzwq(pixel, alpha, 1.35F);
      if (!this.mamaoy(model, pixel.x(), pixel.y() - 1)) {
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.minX(), moduleBounds3.maxY(), moduleBounds3.minZ(), moduleBounds3.maxX(), moduleBounds3.maxY(), moduleBounds3.minZ(), index);
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.minX(), moduleBounds3.maxY(), moduleBounds3.maxZ(), moduleBounds3.maxX(), moduleBounds3.maxY(), moduleBounds3.maxZ(), index);
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.minX(), moduleBounds3.maxY(), moduleBounds3.minZ(), moduleBounds3.minX(), moduleBounds3.maxY(), moduleBounds3.maxZ(), index);
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.maxX(), moduleBounds3.maxY(), moduleBounds3.minZ(), moduleBounds3.maxX(), moduleBounds3.maxY(), moduleBounds3.maxZ(), index);
      }

      if (!this.mamaoy(model, pixel.x(), pixel.y() + 1)) {
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.minX(), moduleBounds3.minY(), moduleBounds3.minZ(), moduleBounds3.maxX(), moduleBounds3.minY(), moduleBounds3.minZ(), index);
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.minX(), moduleBounds3.minY(), moduleBounds3.maxZ(), moduleBounds3.maxX(), moduleBounds3.minY(), moduleBounds3.maxZ(), index);
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.minX(), moduleBounds3.minY(), moduleBounds3.minZ(), moduleBounds3.minX(), moduleBounds3.minY(), moduleBounds3.maxZ(), index);
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.maxX(), moduleBounds3.minY(), moduleBounds3.minZ(), moduleBounds3.maxX(), moduleBounds3.minY(), moduleBounds3.maxZ(), index);
      }

      if (!this.mamaoy(model, pixel.x() - 1, pixel.y())) {
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.minX(), moduleBounds3.minY(), moduleBounds3.minZ(), moduleBounds3.minX(), moduleBounds3.maxY(), moduleBounds3.minZ(), index);
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.minX(), moduleBounds3.minY(), moduleBounds3.maxZ(), moduleBounds3.minX(), moduleBounds3.maxY(), moduleBounds3.maxZ(), index);
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.minX(), moduleBounds3.minY(), moduleBounds3.minZ(), moduleBounds3.minX(), moduleBounds3.minY(), moduleBounds3.maxZ(), index);
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.minX(), moduleBounds3.maxY(), moduleBounds3.minZ(), moduleBounds3.minX(), moduleBounds3.maxY(), moduleBounds3.maxZ(), index);
      }

      if (!this.mamaoy(model, pixel.x() + 1, pixel.y())) {
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.maxX(), moduleBounds3.minY(), moduleBounds3.minZ(), moduleBounds3.maxX(), moduleBounds3.maxY(), moduleBounds3.minZ(), index);
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.maxX(), moduleBounds3.minY(), moduleBounds3.maxZ(), moduleBounds3.maxX(), moduleBounds3.maxY(), moduleBounds3.maxZ(), index);
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.maxX(), moduleBounds3.minY(), moduleBounds3.minZ(), moduleBounds3.maxX(), moduleBounds3.minY(), moduleBounds3.maxZ(), index);
         this.destroyMethod560(buffer, matrix, origin, basis, moduleBounds3.maxX(), moduleBounds3.maxY(), moduleBounds3.minZ(), moduleBounds3.maxX(), moduleBounds3.maxY(), moduleBounds3.maxZ(), index);
      }
   }

      private PredictionBounds s25(ColorModuleBounds model, ColorModuleStyle pixel, float pixelSize, float depth) {
      float width2 = (pixel.x() - model.width() * 0.5F) * pixelSize;
      float value = width2 + pixelSize;
      float height2 = (model.height() * 0.5F - pixel.y() - 1F) * pixelSize;
      float value2 = height2 + pixelSize;
      return new PredictionBounds(width2, height2, -depth * 0.5F, value, value2, depth * 0.5F);
   }

      private boolean mamaoy(ColorModuleBounds model, int x, int y) {
      return x >= 0 && y >= 0 && x < model.width() && y < model.height() && (model.colors()[y][x] >>> 24 & 0xFF) > 0;
   }

      private boolean u25(int[][] colors, int width, int height, int x, int y) {
      return x >= 0 && y >= 0 && x < width && y < height && (colors[y][x] >>> 24 & 0xFF) > 0;
   }

      private void transformMethod66(
      BufferBuilder buffer,
      Matrix4f matrix,
      Vec3d origin,
      TrajectoryBasis basis,
      float x1,
      float y1,
      float z1,
      float x2,
      float y2,
      float z2,
      float x3,
      float y3,
      float z3,
      float x4,
      float y4,
      float z4,
      int color
   ) {
      Vec3d position = this.i20(origin, basis, x1, y1, z1);
      Vec3d position2 = this.i20(origin, basis, x2, y2, z2);
      Vec3d position3 = this.i20(origin, basis, x3, y3, z3);
      Vec3d position4 = this.i20(origin, basis, x4, y4, z4);
      this.vhpsqn(buffer, matrix, position, position2, position3, position4, color);
   }

      private void destroyMethod560(
      BufferBuilder buffer, Matrix4f matrix, Vec3d origin, TrajectoryBasis basis, float x1, float y1, float z1, float x2, float y2, float z2, int color
   ) {
      Vec3d position = this.i20(origin, basis, x1, y1, z1);
      Vec3d position2 = this.i20(origin, basis, x2, y2, z2);
      this.ebakqx(buffer, matrix, position, position2, color);
   }

      private int sujzwq(ColorModuleStyle pixel, float alpha, float shade) {
      float value = (pixel.color() >>> 24 & 0xFF) / 255.0F;
      return this.iyycqf(ColorUtils.multAlpha(this.getVisualColor(), alpha * value), shade);
   }

      private ScreenPoint hasMethod13(ColorModuleBounds model, float pixelSize) {
      float value = Float.NEGATIVE_INFINITY;
      float value2 = 0F;
      float value3 = 0F;

      for (ColorModuleStyle colorModuleStyle : model.pixels()) {
         PredictionBounds moduleBounds3 = this.s25(model, colorModuleStyle, pixelSize, pixelSize);
         float value4 = moduleBounds3.maxX() + moduleBounds3.maxY();
         if (value4 > value) {
            value = value4;
            value2 = moduleBounds3.maxX();
            value3 = moduleBounds3.maxY();
         }
      }

      return new ScreenPoint(value2, value3);
   }

      private void initMethod390(VertexMatrixRenderer event, ModelModuleData prediction) {
      Vec3d client = prediction.direction().lengthSquared() > 1E-4
         ? prediction.direction().normalize()
         : MinecraftClient.getInstance().player.getRotationVec(event.getPartialTicks()).normalize();
      float value = 0.06F;
      float value2 = 15.5F * value;
      TrajectoryBasis moduleData7 = this.isMethod720(client);
      Vec3d position = prediction.eae().add(this.qquayr(prediction)).subtract(moduleData7.axis().multiply(value2));
      Matrix4f matrix = event.getStack().peek().getPositionMatrix();
      int index = ColorUtils.multAlpha(this.getVisualColor(), MathHelper.clamp(this.xvpzz.getValue(), 0.05F, 1F));
      RenderSystem.enableDepthTest();
      RenderSystem.enableBlend();
      RenderSystem.disableCull();
      RenderSystem.depthMask(true);
      RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);

      for (PredictionBox moduleBounds4 : VANILLA_TRIDENT_PARTS) {
         this.dlnjoh(bufferBuilder, matrix, position, moduleData7, value, moduleBounds4, index);
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.lineWidth(2.0F);
      BufferBuilder bufferBuilder2 = Tessellator.getInstance().begin(DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

      for (PredictionBox moduleBounds42 : VANILLA_TRIDENT_PARTS) {
         this.be0(bufferBuilder2, matrix, position, moduleData7, value, moduleBounds42, index);
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
      RenderSystem.lineWidth(1F);
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }

      private TrajectoryBasis isMethod720(Vec3d axis) {
      Vec3d position = Math.abs(axis.y) > 0.92 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
      Vec3d position2 = position.crossProduct(axis).normalize();
      Vec3d position3 = axis.crossProduct(position2).normalize();
      return new TrajectoryBasis(position3, axis, position2.multiply(-1F));
   }

      private TrajectoryBasis getMethod961(Vec3d axis) {
      Vec3d position = axis.normalize();
      Vec3d position2 = Math.abs(position.y) > 0.92 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
      Vec3d position3 = position2.crossProduct(position).normalize();
      Vec3d position4 = position.crossProduct(position3).normalize();
      return new TrajectoryBasis(position3, position4, position);
   }

      private TrajectoryBasis destroyMethod88(Vec3d axis) {
      Vec3d position = axis.normalize();
      Vec3d position2 = new Vec3d(0, 1, 0).subtract(position.multiply(position.y));
      if (position2.lengthSquared() < 1E-4) {
         position2 = new Vec3d(1, 0, 0).subtract(position.multiply(position.x));
      }

      position2 = position2.normalize();
      Vec3d position3 = position.add(position2).normalize();
      Vec3d position4 = position.subtract(position2).normalize();
      Vec3d position5 = position4.crossProduct(position3).normalize();
      return new TrajectoryBasis(position3, position4, position5);
   }

      private void dlnjoh(BufferBuilder buffer, Matrix4f matrix, Vec3d origin, TrajectoryBasis basis, float unit, PredictionBox part, int color) {
      CollisionBounds moduleBounds5 = this.checkMethod220(part, unit);
      this.dbgy(buffer, matrix, origin, basis, moduleBounds5, color);
   }

      private void be0(BufferBuilder buffer, Matrix4f matrix, Vec3d origin, TrajectoryBasis basis, float unit, PredictionBox part, int color) {
      CollisionBounds moduleBounds5 = this.checkMethod220(part, unit);
      this.vqlapc(buffer, matrix, origin, basis, moduleBounds5, color);
   }

      private CollisionBounds checkMethod220(PredictionBox part, float unit) {
      float value = part.x() * unit;
      float width2 = (part.x() + part.width()) * unit;
      float height2 = (11.5F - part.y() - part.height()) * unit;
      float value2 = (11.5F - part.y()) * unit;
      float value3 = part.z() * unit;
      float value4 = (part.z() + part.depth()) * unit;
      return new CollisionBounds(value, height2, value3, width2, value2, value4);
   }

      private void dbgy(BufferBuilder buffer, Matrix4f matrix, Vec3d origin, TrajectoryBasis basis, CollisionBounds bounds, int color) {
      Vec3d position = this.i20(origin, basis, bounds.minX(), bounds.minY(), bounds.minZ());
      Vec3d position2 = this.i20(origin, basis, bounds.maxX(), bounds.minY(), bounds.minZ());
      Vec3d position3 = this.i20(origin, basis, bounds.maxX(), bounds.maxY(), bounds.minZ());
      Vec3d position4 = this.i20(origin, basis, bounds.minX(), bounds.maxY(), bounds.minZ());
      Vec3d position5 = this.i20(origin, basis, bounds.minX(), bounds.minY(), bounds.maxZ());
      Vec3d position6 = this.i20(origin, basis, bounds.maxX(), bounds.minY(), bounds.maxZ());
      Vec3d position7 = this.i20(origin, basis, bounds.maxX(), bounds.maxY(), bounds.maxZ());
      Vec3d position8 = this.i20(origin, basis, bounds.minX(), bounds.maxY(), bounds.maxZ());
      int index = this.iyycqf(color, 0.82F);
      int index2 = this.iyycqf(color, 0.68F);
      this.vhpsqn(buffer, matrix, position, position2, position3, position4, index2);
      this.vhpsqn(buffer, matrix, position5, position8, position7, position6, color);
      this.vhpsqn(buffer, matrix, position, position5, position6, position2, index);
      this.vhpsqn(buffer, matrix, position4, position3, position7, position8, index);
      this.vhpsqn(buffer, matrix, position2, position6, position7, position3, index);
      this.vhpsqn(buffer, matrix, position, position4, position8, position5, index);
   }

      private void vqlapc(BufferBuilder buffer, Matrix4f matrix, Vec3d origin, TrajectoryBasis basis, CollisionBounds bounds, int color) {
      Vec3d position = this.i20(origin, basis, bounds.minX(), bounds.minY(), bounds.minZ());
      Vec3d position2 = this.i20(origin, basis, bounds.maxX(), bounds.minY(), bounds.minZ());
      Vec3d position3 = this.i20(origin, basis, bounds.maxX(), bounds.maxY(), bounds.minZ());
      Vec3d position4 = this.i20(origin, basis, bounds.minX(), bounds.maxY(), bounds.minZ());
      Vec3d position5 = this.i20(origin, basis, bounds.minX(), bounds.minY(), bounds.maxZ());
      Vec3d position6 = this.i20(origin, basis, bounds.maxX(), bounds.minY(), bounds.maxZ());
      Vec3d position7 = this.i20(origin, basis, bounds.maxX(), bounds.maxY(), bounds.maxZ());
      Vec3d position8 = this.i20(origin, basis, bounds.minX(), bounds.maxY(), bounds.maxZ());
      this.ebakqx(buffer, matrix, position, position2, color);
      this.ebakqx(buffer, matrix, position2, position3, color);
      this.ebakqx(buffer, matrix, position3, position4, color);
      this.ebakqx(buffer, matrix, position4, position, color);
      this.ebakqx(buffer, matrix, position5, position6, color);
      this.ebakqx(buffer, matrix, position6, position7, color);
      this.ebakqx(buffer, matrix, position7, position8, color);
      this.ebakqx(buffer, matrix, position8, position5, color);
      this.ebakqx(buffer, matrix, position, position5, color);
      this.ebakqx(buffer, matrix, position2, position6, color);
      this.ebakqx(buffer, matrix, position3, position7, color);
      this.ebakqx(buffer, matrix, position4, position8, color);
   }

      private Vec3d i20(Vec3d origin, TrajectoryBasis basis, float x, float y, float z) {
      return origin.add(basis.right().multiply(x)).add(basis.axis().multiply(y)).add(basis.depth().multiply(z));
   }

      private void vhpsqn(BufferBuilder buffer, Matrix4f matrix, Vec3d a, Vec3d b, Vec3d c, Vec3d d, int color) {
      buffer.vertex(matrix, (float)a.x, (float)a.y, (float)a.z).color(color);
      buffer.vertex(matrix, (float)b.x, (float)b.y, (float)b.z).color(color);
      buffer.vertex(matrix, (float)c.x, (float)c.y, (float)c.z).color(color);
      buffer.vertex(matrix, (float)d.x, (float)d.y, (float)d.z).color(color);
   }

      private void ebakqx(BufferBuilder buffer, Matrix4f matrix, Vec3d start, Vec3d end, int color) {
      buffer.vertex(matrix, (float)start.x, (float)start.y, (float)start.z).color(color);
      buffer.vertex(matrix, (float)end.x, (float)end.y, (float)end.z).color(color);
   }

      private int iyycqf(int color, float factor) {
      int index = color >>> 24;
      int index2 = MathHelper.clamp((int)((color >> 16 & 0xFF) * factor), 0, 255);
      int index3 = MathHelper.clamp((int)((color >> 8 & 0xFF) * factor), 0, 255);
      int index4 = MathHelper.clamp((int)((color & 0xFF) * factor), 0, 255);
      return index << 24 | index2 << 16 | index3 << 8 | index4;
   }

      private int dbmz(int color, float alphaFactor) {
      int index = MathHelper.clamp((int)((color >>> 24 & 0xFF) * alphaFactor), 0, 255);
      return index << 24 | color & 16777215;
   }

   static {
      int index = 0;
      PredictionBox[] moduleBounds4Array = new PredictionBox[5];
      moduleBounds4Array[0] = new PredictionBox(
         -0.5F,
         2.0F,
         -0.5F,
         1F,
         25.0F,
         1F
      );
      moduleBounds4Array[1] = new PredictionBox(
         -1.5F,
         0F,
         -0.5F,
         3.0F,
         2.0F,
         1F
      );
      moduleBounds4Array[2] = new PredictionBox(
         -2.5F,
         -3.0F,
         -0.5F,
         1F,
         4.0F,
         1F
      );
      moduleBounds4Array[3] = new PredictionBox(
         -0.5F,
         -4.0F,
         -0.5F,
         1F,
         4.0F,
         1F
      );
      moduleBounds4Array[4] = new PredictionBox(
         1.5F,
         -3.0F,
         -0.5F,
         1F,
         4.0F,
         1F
      );
      VANILLA_TRIDENT_PARTS = moduleBounds4Array;
   }
}
