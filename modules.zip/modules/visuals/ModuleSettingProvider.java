package winvi.noxiumvisuals.modules.visuals;

public class ModuleSettingProvider {
      private int executeField551;
      private float destroyField30;
      private float rfshp;
      private float jwaqx;
      private final boolean pdpgt;
      private long yhsnd;

   public ModuleSettingProvider(int duration, float intensity, float speed) {
      this.executeField551 = duration;
      this.destroyField30 = intensity;
      this.rfshp = speed;
      this.jwaqx = 0F;
      this.pdpgt = false;
      this.yhsnd = System.currentTimeMillis();
   }

   public ModuleSettingProvider(int duration, float intensity, float speed, boolean isInfinite) {
      this.executeField551 = duration;
      this.destroyField30 = intensity;
      this.rfshp = speed;
      this.jwaqx = 0F;
      this.pdpgt = isInfinite;
      this.yhsnd = System.currentTimeMillis();
   }

      public boolean needsUpdate(float newIntensity, int newDuration, float newSpeed) {
      return this.destroyField30 != newIntensity || this.executeField551 != newDuration || this.rfshp != newSpeed;
   }

      public void updateSettings(float newIntensity, int newDuration, float newSpeed) {
      this.destroyField30 = newIntensity;
      this.executeField551 = newDuration;
      this.rfshp = newSpeed;
   }

      public void update() {
      long timestamp = System.currentTimeMillis();
      float value = Math.min((float)(timestamp - this.yhsnd) / 1000.0F, 0.1F);
      this.yhsnd = timestamp;
      this.jwaqx += value * 20.0F;
      if (this.pdpgt && this.jwaqx > 1000000.0F) {
         this.jwaqx = 0F;
      }
   }

      public boolean isFinished() {
      return !this.pdpgt && this.jwaqx >= this.executeField551;
   }

      public float getCurrentScale() {
      if (this.isFinished()) {
         return 1F;
      } else if (this.pdpgt) {
         float value = this.jwaqx * this.rfshp * 0.05F;
         float value2 = (float)Math.sin(value);
         return 1F - value2 * this.destroyField30;
      } else {
         float value3 = this.jwaqx / this.executeField551;
         float value4 = (float)Math.sin(value3 * 3.141592653589793);
         return 1F - value4 * this.destroyField30;
      }
   }

}
