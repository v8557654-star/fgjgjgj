package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
public class EntityPlayerProvider {
      public final long creationTime;
      public final Vec3d position;
      public final float pitch;
      public final float bodyYaw;
      public final float headYaw;
      public final float limbPos;
      public final float limbSpeed;

   public EntityPlayerProvider(PlayerEntity player, long creationTime, Vec3d position) {
      this.creationTime = creationTime;
      this.position = position;
      this.pitch = player.getPitch();
      this.bodyYaw = player.bodyYaw;
      this.headYaw = player.headYaw;
      this.limbPos = player.limbAnimator.getPos();
      this.limbSpeed = player.limbAnimator.getSpeed();
   }

      public boolean isExpired(long lifetimeMs, long currentTimeMs) {
      return currentTimeMs - this.creationTime > lifetimeMs;
   }

      public float getAlpha(long lifetimeMs, long currentTimeMs) {
      if (lifetimeMs <= 0L) {
         return 0F;
      } else {
         float value = MathHelper.clamp((float)(currentTimeMs - this.creationTime) / (float)lifetimeMs, 0F, 1F);
         float value2 = 1F - value;
         return value2 * value2;
      }
   }

}
