package winvi.noxiumvisuals.modules.visuals;

import java.util.Random;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.utils.EasingManager;
import winvi.noxiumvisuals.utils.ClientEasing;
import winvi.noxiumvisuals.utils.render.RenderMath;
public final class ColorRenderRenderer {
      private static final int transformField941 = 16;
      private final int[] tokjb = new int[16];
      private final int[] lm0 = new int[16];
      private final int[] kyvvw = new int[16];
      private final Random deleteField400;
      private final EasingManager lp2 = new EasingManager(0);
      private final float[] formatField271 = new float[48];
      private final int[] controlField510 = new int[16];
      private int calculateField650;
      private int gltr;
      private int runField23;
      private int sydcy;
      private float lw1;
      private float stopField78;
      private boolean ly0;

   public ColorRenderRenderer(int spawnX, int spawnY, int spawnZ, int steps, Random random) {
      this.deleteField400 = random;
      this.tokjb[0] = spawnX;
      this.lm0[0] = spawnY;
      this.kyvvw[0] = spawnZ;
      this.calculateField650 = 1;
      this.gltr = random.nextInt(4) * 90;
      this.runField23 = (random.nextInt(3) - 1) * 90;
      this.sydcy = steps;
      this.lp2.run(1, 0.6, ClientEasing.EASE_OUT_CUBIC);
   }

      public void tick(float speedMultiplier, String movementDirection) {
      this.lp2.update();
      if (this.sydcy == 0) {
         if (!this.ly0) {
            this.ly0 = true;
            this.lp2.run(0, 0.4, ClientEasing.EASE_IN_CUBIC);
         }
      } else {
         float value = Math.max(0.2F, speedMultiplier);
         if (this.lw1 > 0F) {
            this.lw1 -= value;
            if (this.lw1 < 0F) {
               this.lw1 = 0F;
            }
         } else {
            this.convertMethod650(movementDirection);
            this.stopField78 = this.lw1 = 1F + this.deleteField400.nextFloat() * 2.0F;
            int index = Math.max(1, Math.round(0.75F + value));
            this.initMethod68(index);
            this.sydcy--;
         }
      }
   }

      public boolean isDead() {
      return this.sydcy == 0 && this.lp2.get() < 0.01F && this.lp2.isFinished();
   }

      public float alpha() {
      return this.lp2.get();
   }

      public double squaredDistanceTo(Vec3d position) {
      if (this.calculateField650 == 0) {
         return 1.7976931348623157E308;
      } else {
         double x2 = this.tokjb[0] - position.x;
         double y2 = this.lm0[0] - position.y;
         double z2 = this.kyvvw[0] - position.z;
         return x2 * x2 + y2 * y2 + z2 * z2;
      }
   }

      public int fillRenderVertices(float partialTicks) {
      int index = this.calculateField650;

      for (int index2 = 0; index2 < index; index2++) {
         double value = this.tokjb[index2];
         double value2 = this.lm0[index2];
         double value3 = this.kyvvw[index2];
         if (index2 == index - 1 && index >= 2) {
            float value4 = this.stopField78 > 0F ? RenderMath.clamp(1F - this.lw1 / this.stopField78, 0F, 1F) : 1F;
            value = RenderMath.lerp((double)this.tokjb[index2 - 1], value, (double)value4);
            value2 = RenderMath.lerp((double)this.lm0[index2 - 1], value2, (double)value4);
            value3 = RenderMath.lerp((double)this.kyvvw[index2 - 1], value3, (double)value4);
         }

         int index3 = index2 * 3;
         this.formatField271[index3] = (float)value;
         this.formatField271[index3 + 1] = (float)value2;
         this.formatField271[index3 + 2] = (float)value3;
      }

      return index;
   }

      public float[] getRenderVertices() {
      return this.formatField271;
   }

      public int[] getRenderColors() {
      return this.controlField510;
   }

      private void convertMethod650(String movementDirection) {
      int index = this.runField23;

      for (int index2 = 0; index2 < 150 && Math.abs(index - this.runField23) != 90; index2++) {
         index = (this.deleteField400.nextInt(4) - 2) * 90;
      }

      int index3 = this.gltr;

      for (int index4 = 0; index4 < 5 && Math.abs(index3 - this.gltr) != 90; index4++) {
         index3 = this.deleteField400.nextInt(4) * 90;
      }

      if ("UP".equals(movementDirection) && index < 0) {
         index = this.deleteField400.nextBoolean() ? 0 : 90;
      } else if ("DOWN".equals(movementDirection) && index > 0) {
         index = this.deleteField400.nextBoolean() ? 0 : -90;
      }

      this.gltr = index3;
      this.runField23 = index;
   }

      private void initMethod68(int radius) {
      if (this.calculateField650 < 16) {
         double value = Math.toRadians(this.gltr);
         double value2 = Math.toRadians(this.runField23);
         double value3 = radius;
         int index = (int)(Math.sin(value2) * value3);
         if (value2 != 0) {
            value3 = 0;
         }

         int index2 = (int)(-(Math.sin(value) * value3));
         int index3 = (int)(Math.cos(value) * value3);
         int index4 = this.calculateField650 - 1;
         this.tokjb[this.calculateField650] = this.tokjb[index4] + index2;
         this.lm0[this.calculateField650] = this.lm0[index4] + index;
         this.kyvvw[this.calculateField650] = this.kyvvw[index4] + index3;
         this.calculateField650++;
      }
   }

   static {
      int index = 0;
   }
}
