package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.Identifier;
public record TextureModuleData(
   Identifier texture
) {

      public Identifier texture() {
      return this.texture;
   }

   static {
      int index = 0;
   }
}
