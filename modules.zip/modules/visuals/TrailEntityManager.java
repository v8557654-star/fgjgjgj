package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.particles.DashTrailModule;
public final class TrailEntityManager {
      public final PlayerEntity executeField0;
      public double wzlaw;
      public double v37;
      public double ggwe;
      public double convertField22;
      public double handleField930;
      public double ggzc;
      public double ha0;
      public double getField91;
      public double ghce;
      public final int wpgdd;

   public TrailEntityManager(final DashTrailModule dashTrailModule, PlayerEntity entity, Vec3d previous, float speedDash, float offsetTick, int removeTime) {
      this.executeField0 = entity;
      this.wpgdd = removeTime;
      this.wzlaw = entity.getX() - previous.x;
      this.v37 = entity.getY() - previous.y;
      this.ggwe = entity.getZ() - previous.z;
      double height = entity.getHeight();
      double value = dashTrailModule.ev0.getValue() * 0.006;
      this.convertField22 = previous.x - this.wzlaw * offsetTick + (-value + value * 2.0 * dashTrailModule.validateField0.nextDouble());
      this.handleField930 = previous.y - this.v37 * offsetTick + (height / 3.0 + height / 4.0 * dashTrailModule.validateField0.nextDouble() * 0.7);
      this.ggzc = previous.z - this.ggwe * offsetTick + (-value + value * 2.0 * dashTrailModule.validateField0.nextDouble());
      this.ha0 = this.convertField22;
      this.getField91 = this.handleField930;
      this.ghce = this.ggzc;
      this.wzlaw *= speedDash;
      this.v37 *= speedDash;
      this.ggwe *= speedDash;
   }

      public int dzgi() {
      int index = (int)Math.toDegrees(Math.atan2(this.ggwe, this.wzlaw) - 90.0);
      return index < 0 ? index + 360 : index;
   }

   static {
      int index = 0;
   }
}
