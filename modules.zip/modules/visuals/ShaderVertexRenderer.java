package winvi.noxiumvisuals.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.RenderWindowAccess;
public final class ShaderVertexRenderer implements RenderWindowAccess {
      public static final int calculateField33 = 5;
      public static final int handleField34 = 25;
      public static final float xckyb = 10.0F;
      public static final float eka = 33.333332F;
      public static final float tsyds = 50.0F;
      public static final float cmblx = 0.011F;
      public static final long d17 = 500L;
      public final Random ke2 = new Random();
      public final ModuleTransformer[] sjhld = new ModuleTransformer[25];
      public int aepxn = -2147483648;

   public ShaderVertexRenderer() {
      for (int index = 0; index < this.sjhld.length; index++) {
         this.sjhld[index] = new ModuleTransformer();
      }
   }

      public void render(VertexMatrixRenderer event, LivingEntity target, float alpha, int baseColor, int highlightColor, float size) {
      if (event != null && target != null && !(alpha <= 0.01F)) {
         long timestamp = System.currentTimeMillis();
         this.utizhv(target.getId(), timestamp);
         Vec3d height = target.getLerpedPos(event.getPartialTicks()).add(0, target.getHeight() + 0.12, 0);
         MatrixStack matrices = event.getStack();
         matrices.push();

         try {
            matrices.translate(height.x, height.y, height.z);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-MinecraftClient.getInstance().gameRenderer.getCamera().getYaw()));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(MinecraftClient.getInstance().gameRenderer.getCamera().getPitch()));
            float value = 0.011F * MathHelper.clamp(size, 0.5F, 2.0F);
            matrices.scale(-value, -value, value);
            Matrix4f matrix = matrices.peek().getPositionMatrix();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.disableCull();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
            this.addMethod66(bufferBuilder, matrix, baseColor, highlightColor, alpha, true, timestamp);
            BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
            RenderSystem.lineWidth(1.5F);
            BufferBuilder bufferBuilder2 = Tessellator.getInstance().begin(DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            this.t14(bufferBuilder2, matrix, baseColor, alpha);
            this.addMethod66(bufferBuilder2, matrix, baseColor, highlightColor, alpha, false, timestamp);
            BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
         } finally {
            matrices.pop();
            RenderSystem.lineWidth(1F);
            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
         }
      }
   }

      public void utizhv(int entityId, long now) {
      if (entityId != this.aepxn) {
         this.aepxn = entityId;

         for (ModuleTransformer moduleTransformer : this.sjhld) {
            moduleTransformer.reset(now + 100L + this.ke2.nextInt(700));
         }
      }
   }

      public void t14(BufferBuilder buffer, Matrix4f matrix, int baseColor, float alpha) {
      int index = ColorUtils.multAlpha(baseColor, alpha);
      this.fbjcou(buffer, matrix, 0F, 0F, index, -33.333332F, -50.0F, index);
      this.fbjcou(buffer, matrix, -33.333332F, -50.0F, index, 33.333332F, -50.0F, index);
      this.fbjcou(buffer, matrix, 33.333332F, -50.0F, index, 0F, 0F, index);
   }

      public void addMethod66(BufferBuilder buffer, Matrix4f matrix, int baseColor, int highlightColor, float alpha, boolean fill, long now) {
      float value = 10.0F;
      int index = 0;

      for (int index2 = 0; index2 < 5; index2++) {
         float value2 = -6.6666665F * index2;
         value -= 10.0F;

         for (int index3 = 0; index3 < index2 * 2 + 1; index3++) {
            float value3 = this.sjhld[index].sample(now, this.ke2);
            float value4 = Math.min(value3, 1F - value3) * 2.0F;
            float value5 = value4 * value4;
            float value6 = (float)Math.floorMod(now + (long)((index + value5) * 40.0F), 500L) / 500.0F;
            if (value6 > 0.5F) {
               value6 = 1F - value6;
            }

            float value7 = MathHelper.clamp(value5 + value6, 0F, 1F);
            int index4 = this.wv(baseColor, highlightColor, value7);
            int index5 = ColorUtils.multAlpha(index4, alpha * (fill ? 1F - value4 : 1F));
            float value8 = (float)Math.cos(value3 * 3.141592653589793);
            boolean enabled = (index3 & 1) == 1;
            float value9 = 6.6666665F;
            float value10;
            float value11;
            float value12;
            float value13;
            float value14;
            float value15;
            if (enabled) {
               value10 = value2 + value9 * value8;
               value11 = value;
               value12 = value2 - value9 * value8;
               value13 = value;
               value14 = value2;
               value15 = value - 10.0F;
            } else {
               value10 = value2 + value9 * value8;
               value11 = value - 10.0F;
               value12 = value2 - value9 * value8;
               value13 = value - 10.0F;
               value14 = value2;
               value15 = value;
            }

            if (fill) {
               this.cqirbn(buffer, matrix, value10, value11, index5);
               this.cqirbn(buffer, matrix, value12, value13, index5);
               this.cqirbn(buffer, matrix, value14, value15, index5);
            } else {
               this.fbjcou(buffer, matrix, value10, value11, index5, value12, value13, index5);
               this.fbjcou(buffer, matrix, value12, value13, index5, value14, value15, index5);
               this.fbjcou(buffer, matrix, value14, value15, index5, value10, value11, index5);
            }

            value2 += 6.6666665F;
            index++;
         }
      }
   }

      public int wv(int first, int second, float progress) {
      int index = Math.round((float)MathHelper.lerp(progress, first >>> 24, second >>> 24));
      int index2 = Math.round((float)MathHelper.lerp(progress, first >> 16 & 0xFF, second >> 16 & 0xFF));
      int index3 = Math.round((float)MathHelper.lerp(progress, first >> 8 & 0xFF, second >> 8 & 0xFF));
      int index4 = Math.round((float)MathHelper.lerp(progress, first & 0xFF, second & 0xFF));
      return index << 24 | index2 << 16 | index3 << 8 | index4;
   }

      public void fbjcou(BufferBuilder buffer, Matrix4f matrix, float x1, float y1, int color1, float x2, float y2, int color2) {
      this.cqirbn(buffer, matrix, x1, y1, color1);
      this.cqirbn(buffer, matrix, x2, y2, color2);
   }

      public void cqirbn(BufferBuilder buffer, Matrix4f matrix, float x, float y, int color) {
      buffer.vertex(matrix, x, y, 0F).color(color);
   }

      public static float transformMethod10(float progress) {
      progress = MathHelper.clamp(progress, 0F, 1F);
      return progress * progress * (3.0F - 2.0F * progress);
   }

}
