package winvi.noxiumvisuals.modules.visuals;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.DefaultedRegistry;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
public class EntityModuleFactory {
      public static final EntityType<ParticleEntityFactory> DOG;

      public static void register() {
      FabricDefaultAttributeRegistry.register(DOG, ParticleEntityFactory.createDogAttributes());
   }

   static {
      int index = 0;
      DefaultedRegistry defaultedRegistry = Registries.ENTITY_TYPE;
      Identifier identifier = Identifier.of("noxiumvisual", "dog");
      FabricEntityTypeBuilder fabricEntityTypeBuilder = FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, ParticleEntityFactory::new)
         .dimensions(EntityDimensions.fixed(0.6F, 0.85F));
      RegistryKey registryKey = RegistryKeys.ENTITY_TYPE;
      DOG = (EntityType<ParticleEntityFactory>)Registry.register(
         defaultedRegistry, identifier, fabricEntityTypeBuilder.build(RegistryKey.of(registryKey, Identifier.of("noxiumvisual", "dog")))
      );
   }
}
