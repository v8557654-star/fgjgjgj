package winvi.noxiumvisuals.modules.visuals;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import winvi.noxiumvisuals.modules.particles.DashTrailModule;
import winvi.noxiumvisuals.utils.render.WorldParticleBatcher;
import winvi.noxiumvisuals.utils.render.SmoothFloat;
import winvi.noxiumvisuals.utils.render.ParticleTextures;
import winvi.noxiumvisuals.utils.render.WorldShapeRenderer;
public final class DashTrailSegment {
   private final DashTrailModule this$0;
      public final SmoothFloat manageField8;
      public final long transformField420;
      public final TrailEntityManager ghgt;
      public final int juaqt;
      public final Identifier ogphk;
      public final float[] formatField65;
      public final List<TrailHandManager> startField621;

   public DashTrailSegment(final DashTrailModule dashTrailModule, TrailEntityManager base, int color, Identifier texture) {
      this.this$0 = dashTrailModule;
      this.manageField8 = new SmoothFloat(0F, 1F, 0.035F);
      this.transformField420 = System.currentTimeMillis();
      this.formatField65 = new float[]{0F, 0F};
      this.startField621 = new ArrayList<>();
      this.ghgt = base;
      this.juaqt = color;
      this.ogphk = texture;
      this.dzh();
   }

      public void dzh() {
      float client = MinecraftClient.getInstance().gameRenderer.getCamera().getPitch();
      if (Math.sqrt(this.ghgt.wzlaw * this.ghgt.wzlaw + this.ghgt.ggwe * this.ghgt.ggwe) < 5.0E-4) {
         this.formatField65[0] = this.this$0.validateField0.nextFloat() * 360.0F;
         this.formatField65[1] = client;
      } else {
         float value = this.ghgt.dzgi();
         this.formatField65[0] = value - 60.0F;
         float value2 = Math.abs(MathHelper.wrapDegrees(this.ghgt.executeField0.getYaw() - (value + 26.3F)));
         this.formatField65[1] = !(value2 < 10.0F) && !(value2 > 160.0F) ? client : -90.0F;
      }
   }

      public double zi(float tickDelta) {
      return MathHelper.lerp(tickDelta, this.ghgt.ha0, this.ghgt.convertField22);
   }

      public double adqhsz(float tickDelta) {
      return MathHelper.lerp(tickDelta, this.ghgt.getField91, this.ghgt.handleField930);
   }

      public double k19(float tickDelta) {
      return MathHelper.lerp(tickDelta, this.ghgt.ghce, this.ghgt.ggzc);
   }

      public float formatMethod36() {
      return Math.min((float)(System.currentTimeMillis() - this.transformField420) / this.ghgt.wpgdd, 1F);
   }

      public void sqrshd(DashTrailSegment next) {
      this.ghgt.ha0 = this.ghgt.convertField22;
      this.ghgt.getField91 = this.ghgt.handleField930;
      this.ghgt.ghce = this.ghgt.ggzc;
      boolean enabled = next != null && next.ghgt.executeField0.getId() == this.ghgt.executeField0.getId();
      this.ghgt.wzlaw = (enabled ? next.ghgt.wzlaw : this.ghgt.wzlaw) / 1.05;
      this.ghgt.v37 = (enabled ? next.ghgt.v37 : this.ghgt.v37) / 1.05;
      this.ghgt.ggwe = (enabled ? next.ghgt.ggwe : this.ghgt.ggwe) / 1.05;
      if (this.this$0.m20.isSelected("Fall")) {
         this.ghgt.v37 -= 0.0018;
      } else if (this.this$0.m20.isSelected("Fly")) {
         this.ghgt.v37 += 0.0012;
      } else {
         this.ghgt.v37 = this.ghgt.v37 - this.this$0.ew0.getValue() * 2.0E-5;
      }

      this.ghgt.convertField22 = this.ghgt.convertField22 + 5.0 * this.ghgt.wzlaw;
      this.ghgt.handleField930 = this.ghgt.handleField930 + 5.0 * this.ghgt.v37 / (this.ghgt.v37 < 0 ? 1 : 3.5);
      this.ghgt.ggzc = this.ghgt.ggzc + 5.0 * this.ghgt.ggwe;
      this.dzh();
      if (this.formatMethod36() < 0.3F && this.this$0.validateField0.nextInt(12) > 5) {
         this.startField621.add(new TrailHandManager(this.this$0));
         this.startField621.add(new TrailHandManager(this.this$0));
      }

      this.startField621.forEach(TrailHandManager::dzsr);
      this.startField621.removeIf(TrailHandManager::deybzo);
   }

      public void addMethod93(float stateAlpha, float tickDelta) {
      double value = this.zi(tickDelta);
      double value2 = this.adqhsz(tickDelta);
      double value3 = this.k19(tickDelta);

      for (TrailHandManager trailHandManager : this.startField621) {
         double value4 = trailHandManager.calculateMethod87(tickDelta);
         double value5 = trailHandManager.handleMethod77(tickDelta);
         double value6 = trailHandManager.dzv(tickDelta);
         float value7 = (float)(trailHandManager.zq() * this.manageField8.anim);
         float value8 = (float)DashTrailModule.sq0((double)value7);
         int index = DashTrailModule.transformMethod81(this.juaqt, 16777215, value8);
         int index2 = MathHelper.clamp((int)(255.0F * value8 / 1.33333F * stateAlpha), 0, 255);
         index = index2 << 24 | index & 16777215;
         Vec3d position = new Vec3d(value4 + value, value5 + value2, value6 + value3);
         Vec3d position2 = new Vec3d(-value4 + value, -value5 + value2, -value6 + value3);
         if (this.this$0.gvxtb.isValue()) {
            WorldShapeRenderer.drawLine(position, position2, index, 1.5F, true);
         }

         if (this.this$0.eepu.isValue()) {
            float value9 = 0.008F + 0.012F * value8;
            WorldShapeRenderer.drawLine(position.add(0, -value9, 0), position.add(0, value9, 0), index, 2.5F, true);
            WorldShapeRenderer.drawLine(position2.add(0, -value9, 0), position2.add(0, value9, 0), index, 2.5F, true);
         }
      }
   }

      public void dzox(Camera camera, float stateAlpha, float lighting, float tickDelta) {
      float value = this.manageField8.anim * stateAlpha;
      float value2 = 0.528F * value * this.this$0.handleField70.getValue();
      if (!(value2 <= 0.001F)) {
         double value3 = this.zi(tickDelta);
         double value4 = this.adqhsz(tickDelta);
         double value5 = this.k19(tickDelta);
         int index = DashTrailModule.transformMethod81(this.juaqt, 16777215, 0.45F);
         WorldParticleBatcher.queueOwnedTexturedParticle(
            this.this$0.jqqfrc(camera, value3, value4, value5, this.formatField65[0], this.formatField65[1], false), this.ogphk, value2, value, index, false, null
         );
         float value6 = (float)Math.sqrt(value2 * value2 * 2.0F);
         int index2 = DashTrailModule.transformMethod81(this.juaqt, 16777215, 0.15F);
         WorldParticleBatcher.queueOwnedTexturedParticle(
            this.this$0.jqqfrc(camera, value3, value4, value5, 0F, 0F, true), ParticleTextures.BLOOM, value6 / 1.75F, 0.21568628F * value, index2, false, null
         );
         if (lighting > 0F) {
            float value7 = value * lighting;
            float value8 = value6 * (1F + 6.0F * (1F - this.formatMethod36()) * value7) / 2.0F;
            WorldParticleBatcher.queueOwnedTexturedParticle(
               this.this$0.jqqfrc(camera, value3, value4, value5, 0F, 0F, true),
               ParticleTextures.BLOOM,
               value8,
               0.3529412F * value7,
               DashTrailModule.lgwnqo(index2, value7 / 4.0F),
               false,
               null
            );
         }
      }
   }

   static {
      int index = 0;
   }
}
