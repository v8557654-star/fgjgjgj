package winvi.noxiumvisuals.modules.visuals;

import org.joml.Vector3f;
public class VectorModuleSupport {
      public final Vector3f position;
      public final Vector3f rotation;
      public final float size;

   public VectorModuleSupport(Vector3f position, Vector3f rotation, float size) {
      this.position = position;
      this.rotation = rotation;
      this.size = size;
   }

   static {
      int index = 0;
   }
}
