package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
public final class CustomHandModule extends Module {
      private final NumberSetting transformField99;
      private final BooleanSetting dezgv;
      private final BooleanSetting isField45;
      private final BooleanSetting stopField96;
      private final BooleanSetting walkField;
      private final BooleanSetting sprintSwingField;
      private final BooleanSetting bodyViewField;
      private final BooleanSetting randomAttackField;

   public CustomHandModule() {
      super("Custom Hand", ModuleCategory.VISUAL);
      this.transformField99 = new NumberSetting(
            "Animation Speed",
            "Custom hand animation speed"
         )
         .setValue(5.5F)
         .range(0.5F, 7.0F);
      this.dezgv = new BooleanSetting(
            "Arm Physics",
            "Jump, landing and camera inertia"
         )
         .setValue(true);
      this.isField45 = new BooleanSetting(
            "Item Physics",
            "Physics for held items"
         )
         .setValue(true);
      this.stopField96 = new BooleanSetting(
            "Fall Arm Animation",
            "Hand movement while falling"
         )
         .setValue(true);
      this.walkField = new BooleanSetting(
            "Walk Animations",
            "Arm swing while walking and sprinting"
         )
         .setValue(true);
      this.sprintSwingField = new BooleanSetting(
            "Sprint Swing",
            "Wide arm swing while sprinting"
         )
         .setValue(true);
      this.bodyViewField = new BooleanSetting(
            "Body View",
            "First person body: torso, legs and their animations"
         )
         .setValue(false);
      this.randomAttackField = new BooleanSetting(
            "Random Attack",
            "Randomly pick one of four attack animations"
         )
         .setValue(true);
      this.setup(new ModuleSetting[]{
         this.transformField99, this.dezgv, this.isField45, this.stopField96, this.walkField, this.sprintSwingField, this.bodyViewField, this.randomAttackField
      });
   }

      public float getAnimationSpeed() {
      return this.transformField99.getValue();
   }

      public boolean hasArmPhysics() {
      return this.dezgv.isValue();
   }

      public boolean hasItemPhysics() {
      return this.isField45.isValue();
   }

      public boolean hasFallAnimation() {
      return this.stopField96.isValue();
   }

      public boolean hasWalkAnimations() {
      return this.walkField.isValue();
   }

      public boolean hasSprintSwing() {
      return this.sprintSwingField.isValue();
   }

      public boolean hasBodyView() {
      return this.bodyViewField.isValue();
   }

      public boolean hasRandomAttack() {
      return this.randomAttackField.isValue();
   }
}
