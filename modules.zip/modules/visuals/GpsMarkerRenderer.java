package winvi.noxiumvisuals.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.modules.world.GPSModule;
import winvi.noxiumvisuals.utils.MsdfFont;
import winvi.noxiumvisuals.utils.TextureFontFactory;
import winvi.noxiumvisuals.utils.render.MsdfTextRenderer;
import winvi.noxiumvisuals.utils.render.RenderWindowAccess;
import winvi.noxiumvisuals.utils.render.WorldToScreen;
public final class GpsMarkerRenderer implements RenderWindowAccess {
      private static final Identifier vulbh = Identifier.of("noxiumvisual", "textures/6jg7camfwj/fv1z4ods.png");
      private static final float i22 = 96.0F;

   private GpsMarkerRenderer() {
   }

      public static void render(DrawContext context, float partialTicks, GPSModule module) {
      if (module != null
         && module.isState()
         && MinecraftClient.getInstance().world != null
         && MinecraftClient.getInstance().player != null
         && !MinecraftClient.getInstance().options.hudHidden) {
         List list = BlockPositionModuleManager.getMarkers();
         if (!list.isEmpty()) {
            String client = MinecraftClient.getInstance().world.getRegistryKey().getValue().toString();
            Vec3d client2 = MinecraftClient.getInstance().player.getLerpedPos(partialTicks);
            float width = MinecraftClient.getInstance().getWindow().getScaledWidth();
            float height = MinecraftClient.getInstance().getWindow().getScaledHeight();
            float value = module.markerSize.getValue();
            MatrixStack matrices = context.getMatrices();

            for (BlockPositionHandRenderer blockPositionHandRenderer : (Iterable<BlockPositionHandRenderer>)(Iterable<?>) (list)) {
               if (client.equals(blockPositionHandRenderer.getDimension())) {
                  Vec3d position = WorldToScreen.worldSpaceToScreenSpace(blockPositionHandRenderer.toRenderPos());
                  if (!(position.z <= 0)
                     && !(position.z >= 1.1)
                     && !(position.x < -96.0F)
                     && !(position.x > width + 96.0F)
                     && !(position.y < -96.0F)
                     && !(position.y > height + 96.0F)) {
                     float x2 = (float)position.x;
                     float value2 = (float)position.y - value;
                     int index = module.getVisualColor();
                     g23(matrices, x2, value2, value, index);
                     float value3 = value2 + value + 2.0F;
                     trmnwv(matrices, TextureFontFactory.getSemibold(), blockPositionHandRenderer.getName(), 7.2F, x2, value3, -2828575);
                     if (module.showDistance.isValue()) {
                        int index2 = (int)Math.round(client2.distanceTo(blockPositionHandRenderer.toCenterPos()));
                        String text = index2 + " blocks";
                        trmnwv(matrices, TextureFontFactory.getRegular(), text, 7.0F, x2, value3 + 8.5F, -1);
                     }
                  }
               }
            }
         }
      }
   }

      private static void trmnwv(MatrixStack matrices, MsdfFont font, String text, float size, float centerX, float y, int color) {
      if (font != null && text != null && !text.isBlank()) {
         Matrix4f matrix = matrices.peek().getPositionMatrix();
         float width = MsdfTextRenderer.getWidth(font, size, text);
         float value = centerX - width / 2.0F;
         MsdfTextRenderer.renderText(font, text, size, color, matrix, value, y, 0F);
      }
   }

      private static void g23(MatrixStack matrices, float centerX, float topY, float size, int color) {
      RenderSystem.enableBlend();
      RenderSystem.disableCull();
      RenderSystem.disableDepthTest();
      RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
      RenderSystem.setShaderTexture(0, vulbh);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      Matrix4f matrix = matrices.peek().getPositionMatrix();
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
      bufferBuilder.vertex(matrix, centerX - size / 2.0F, topY + size, 0F).texture(0F, 1F).color(color);
      bufferBuilder.vertex(matrix, centerX + size / 2.0F, topY + size, 0F).texture(1F, 1F).color(color);
      bufferBuilder.vertex(matrix, centerX + size / 2.0F, topY, 0F).texture(1F, 0F).color(color);
      bufferBuilder.vertex(matrix, centerX - size / 2.0F, topY, 0F).texture(0F, 0F).color(color);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.enableDepthTest();
      RenderSystem.enableCull();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
   }

   static {
      int index = 0;
   }
}
