package winvi.noxiumvisuals.modules.visuals;

import winvi.noxiumvisuals.modules.visuals.*;
import winvi.noxiumvisuals.modules.world.*;
import winvi.noxiumvisuals.modules.particles.*;
import winvi.noxiumvisuals.modules.utils.*;
import winvi.noxiumvisuals.modules.client.*;
import winvi.noxiumvisuals.modules.manager.*;
import winvi.noxiumvisuals.modules.visuals.*;


import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import winvi.noxiumvisuals.modules.ModuleSetting;
import winvi.noxiumvisuals.modules.Module;
import winvi.noxiumvisuals.modules.ModuleCategory;
import winvi.noxiumvisuals.modules.visuals.SonarPulse;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.utils.render.ShaderFramebufferRegistry;
import winvi.noxiumvisuals.utils.render.FullscreenShaderPass;
public class SonarModule extends Module {
      private final MultiSelectSetting pzsxt;
      private final NumberSetting ihyau;
      private final NumberSetting convertField91;
      private final NumberSetting eozi;
      private final NumberSetting controlField451;
      private final NumberSetting b20;
      private static final int pc = 4;
      private final List<SonarPulse> epd;
      private SimpleFramebuffer tuluf;
      private int epfw;
      private int g19;
      private long rthnv;
      private long rbplw;
      private boolean epj;
      private boolean xhaep;
      private Vec3d controlField11;
      private final Matrix4f epmm;
      private final Matrix4f calculateField43;

   public SonarModule() {
      super(
         "Sonar",
         "Chunk scan wave",
         ModuleCategory.VISUAL
      );
      this.pzsxt = new MultiSelectSetting(
            "Triggers",
            "Events that start a scan"
         )
         .value(
            "Chunk Load",
            "Jump",
            "GUI Open",
            "Timer"
         )
         .selected("Chunk Load");
      this.ihyau = new NumberSetting(
            "Duration",
            "Scan wave duration"
         )
         .setValue(5.6F)
         .range(0.8F, 10.0F);
      this.convertField91 = new NumberSetting(
            "Brightness",
            "Scan wave brightness"
         )
         .setValue(1F)
         .range(0.1F, 1F);
      this.eozi = new NumberSetting(
            "Width",
            "Scan wave width"
         )
         .setValue(1F)
         .range(0.35F, 2.2F);
      this.controlField451 = new NumberSetting(
            "Sharpness",
            "Scan wave edge sharpness"
         )
         .setValue(24.0F)
         .range(4.0F, 80.0F);
      this.b20 = new NumberSetting(
            "Timer Delay",
            "Seconds between automatic scans"
         )
         .setValue(8.0F)
         .range(1F, 60.0F)
         .visible(() -> {
            return this.pzsxt.isSelected("Timer");
         });
      this.epd = new ArrayList<>(4);
      this.epfw = -1;
      this.g19 = -1;
      this.epj = true;
      this.xhaep = false;
      this.controlField11 = Vec3d.ZERO;
      this.epmm = new Matrix4f();
      this.calculateField43 = new Matrix4f();
      this.showVisualColorSettings();
      this.pzsxt.withTranslation("sonar.triggers", "sonar.triggers.desc");
      this.ihyau.withTranslation("sonar.duration", "sonar.duration.desc");
      this.convertField91.withTranslation("sonar.alpha", "sonar.alpha.desc");
      this.eozi.withTranslation("sonar.width", "sonar.width.desc");
      this.controlField451.withTranslation("sonar.sharpness", "sonar.sharpness.desc");
      this.b20.withTranslation("sonar.timerdelay", "sonar.timerdelay.desc");
      this.setup(new ModuleSetting[]{this.pzsxt, this.ihyau, this.convertField91, this.eozi, this.controlField451, this.b20});
   }

      @Override
   public void activate() {
      this.epj = MinecraftClient.getInstance().player == null || MinecraftClient.getInstance().player.isOnGround();
      this.xhaep = MinecraftClient.getInstance().currentScreen != null;
      this.rthnv = System.currentTimeMillis();
      this.rbplw = 0L;
      if (MinecraftClient.getInstance().player != null) {
         this.dbsu(MinecraftClient.getInstance().player.getPos());
      }

      super.activate();
   }

      @Override
   public void deactivate() {
      this.epd.clear();
      this.qnichz();
      super.deactivate();
   }

      @Override
   public void onTick() {
      if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().world != null) {
         long timestamp = System.currentTimeMillis();
         boolean client = MinecraftClient.getInstance().player.isOnGround();
         boolean client2 = MinecraftClient.getInstance().currentScreen != null;
         if (this.pzsxt.isSelected("Jump")
            && this.epj
            && !client
            && (MinecraftClient.getInstance().options.jumpKey.isPressed() || MinecraftClient.getInstance().player.getVelocity().y > 0.05)
            )
          {
            this.ueblxa(timestamp);
         }

         if (this.pzsxt.isSelected("GUI Open") && client2 && !this.xhaep) {
            this.ueblxa(timestamp);
         }

         if (this.pzsxt.isSelected("Timer")
            && (float)(timestamp - this.rthnv) >= this.b20.getValue() * 1000.0F) {
            this.dbsu(MinecraftClient.getInstance().player.getPos());
            this.rthnv = timestamp;
            this.rbplw = timestamp;
         }

         this.epj = client;
         this.xhaep = client2;
      } else {
         this.epj = true;
         this.xhaep = false;
      }
   }

      public void pingFromChunkLoad() {
      if (this.pzsxt.isSelected("Chunk Load")
         && MinecraftClient.getInstance().player != null) {
         this.ueblxa(System.currentTimeMillis());
      }
   }

      public void renderFromMixin(Matrix4f positionMatrix, Matrix4f projectionMatrix, Vec3d camPos) {
      if (MinecraftClient.getInstance().player != null
         && MinecraftClient.getInstance().world != null
         && !this.epd.isEmpty()
         && positionMatrix != null
         && projectionMatrix != null
         && camPos != null) {
         Framebuffer client = MinecraftClient.getInstance().getFramebuffer();
         if (client != null) {
            ShaderFramebufferRegistry.initShadersIfNeeded();
            if (ShaderFramebufferRegistry.isInitialized()) {
               FullscreenShaderPass shaderMatrixRenderer3 = ShaderFramebufferRegistry.getSonarShader();
               if (shaderMatrixRenderer3 != null) {
                  this.dbq(client.textureWidth, client.textureHeight);
                  if (this.tuluf != null) {
                     this.tuluf.copyDepthFrom(client);
                     Matrix4f matrix = this.epmm.set(positionMatrix).invert();
                     Matrix4f matrix2 = this.calculateField43.set(projectionMatrix).invert();
                     long timestamp = System.currentTimeMillis();
                     float value = this.ihyau.getValue() * 1000.0F;
                     float client2 = MinecraftClient.getInstance().gameRenderer.getFarPlaneDistance();
                     Iterator iterator2 = this.epd.iterator();

                     while (iterator2.hasNext()) {
                        SonarPulse moduleRange5 = (SonarPulse)iterator2.next();
                        float value2 = (float)(timestamp - moduleRange5.startTime());
                        float value3 = MathHelper.clamp(value2 / value, 0F, 1F);
                        if (value3 >= 1F) {
                           iterator2.remove();
                        } else {
                           float value4 = this.dnvstz(value3);
                           float value5 = this.ggtwld(0.35F, client2, this.hasMethod451(value4));
                           float value6 = this.ggtwld(0.35F, client2, this.ussbaf(value4));
                           float value7 = MathHelper.lerp(0.72F, value5, value6);
                           float value8 = this.gurvnt(0F, 0.16F, value3);
                           float value9 = 1F - this.gurvnt(0.72F, 1F, value3);
                           float value10 = MathHelper.clamp(this.convertField91.getValue() * value8 * value9, 0F, 1F);
                           if (!(value10 <= 0.002F)) {
                              float value11 = 0.86F + 0.14F * (float)Math.sin((timestamp - moduleRange5.startTime()) * 0.008);
                              float value12 = MathHelper.clamp(
                                 (7.0F + value7 * (0.16F * this.eozi.getValue())) * value11, 5.0F, Math.max(12.0F, client2 * 0.38F)
                              );
                              this.computeMethod7(
                                 shaderMatrixRenderer3,
                                 matrix,
                                 matrix2,
                                 camPos,
                                 client,
                                 moduleRange5.center(),
                                 value7,
                                 value12,
                                 this.controlField451.getValue(),
                                 this.addMethod970(this.formatMethod35(1.35F, 1.1F), value10),
                                 this.addMethod970(this.formatMethod35(1.05F, 1F), value10),
                                 this.addMethod970(this.formatMethod35(0.72F, 0.92F), value10),
                                 this.addMethod970(this.formatMethod35(1.75F, 0.65F), value10)
                              );
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

      private void computeMethod7(
      FullscreenShaderPass shader,
      Matrix4f invView,
      Matrix4f invProj,
      Vec3d camPos,
      Framebuffer framebuffer,
      Vec3d pulseCenter,
      float radius,
      float width,
      float sharp,
      int outerColor,
      int midColor,
      int innerColor,
      int scanlineColor
   ) {
      if (!(radius <= 0.001F) && !(width <= 0.001F)) {
         int index = this.tuluf.getDepthAttachment();
         if (index == 0 && MinecraftClient.getInstance().getFramebuffer() != null) {
            index = MinecraftClient.getInstance().getFramebuffer().getDepthAttachment();
         }

         if (index != 0) {
            framebuffer.beginWrite(false);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
            RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
            RenderSystem.disableDepthTest();
            RenderSystem.disableCull();
            RenderSystem.depthMask(false);
            RenderSystem.activeTexture(33984);
            RenderSystem.bindTexture(index);
            GL11.glTexParameteri(3553, 34892, 0);
            GL11.glTexParameteri(3553, 10241, 9728);
            GL11.glTexParameteri(3553, 10240, 9728);
            shader.bind();
            shader.setUniformMatrix4f("invViewMat", false, invView);
            shader.setUniformMatrix4f("invProjMat", false, invProj);
            shader.setUniform3f("pos", (float)camPos.x, (float)camPos.y, (float)camPos.z);
            shader.setUniform3f("center", (float)pulseCenter.x, (float)pulseCenter.y, (float)pulseCenter.z);
            shader.setUniform1f("radius", radius);
            shader.setUniform1f("width", width);
            shader.setUniform1f("sharpness", sharp);
            dmigjh(shader, "outerColor", outerColor);
            dmigjh(shader, "midColor", midColor);
            dmigjh(shader, "innerColor", innerColor);
            dmigjh(shader, "scanlineColor", scanlineColor);
            shader.setUniform1i("DebugMode", 0);
            shader.setUniform1i("depthTex", 0);
            shader.setUniform1f("time", (float)(System.currentTimeMillis() % 100000L) / 1000.0F);
            ShaderFramebufferRegistry.drawFullScreenQuad();
            shader.unbind();
            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
            RenderSystem.activeTexture(33984);
            RenderSystem.bindTexture(0);
         }
      }
   }

      private void dbq(int width, int height) {
      if (this.tuluf == null || this.epfw != width || this.g19 != height) {
         this.qnichz();
         this.tuluf = new SimpleFramebuffer(width, height, true);
         this.epfw = width;
         this.g19 = height;
      }
   }

      private void qnichz() {
      if (this.tuluf != null) {
         this.tuluf.delete();
         this.tuluf = null;
      }

      this.epfw = -1;
      this.g19 = -1;
   }

      private void dbsu(Vec3d position) {
      if (position != null) {
         if (this.epd.size() >= 4) {
            this.epd.remove(0);
         }

         this.epd.add(new SonarPulse(System.currentTimeMillis(), position));
         this.controlField11 = position;
      }
   }

      private void ueblxa(long now) {
      if (now - this.rbplw >= 180L && MinecraftClient.getInstance().player != null) {
         this.dbsu(MinecraftClient.getInstance().player.getPos());
         this.rbplw = now;
      }
   }

      private static void dmigjh(FullscreenShaderPass shader, String name, int color) {
      int index = color >>> 24 & 0xFF;
      shader.setUniform4f(name, (color >>> 16 & 0xFF) / 255.0F, (color >>> 8 & 0xFF) / 255.0F, (color & 0xFF) / 255.0F, (index == 0 ? 255 : index) / 255.0F);
   }

      private int addMethod970(int color, float alphaMul) {
      int index = color >> 24 & 0xFF;
      if (index == 0) {
         index = 255;
      }

      index = (int)(index * MathHelper.clamp(alphaMul, 0F, 1F));
      return color & 16777215 | index << 24;
   }

      private int formatMethod35(float brightnessMul, float saturationMul) {
      int index = this.getVisualColor();
      int index2 = index >> 24 & 0xFF;
      if (index2 == 0) {
         index2 = 255;
      }

      int index3 = index >> 16 & 0xFF;
      int index4 = index >> 8 & 0xFF;
      int index5 = index & 0xFF;
      float[] color = Color.RGBtoHSB(index3, index4, index5, null);
      int color2 = Color.HSBtoRGB(
         color[0], MathHelper.clamp(color[1] * saturationMul, 0F, 1F), MathHelper.clamp(color[2] * brightnessMul, 0F, 1F)
      );
      return index2 << 24 | color2 & 16777215;
   }

      private float hasMethod451(float t) {
      return 1F - (float)Math.pow(1F - t, 5.0);
   }

      private float ussbaf(float t) {
      return t < 0.5F ? 8.0F * t * t * t * t : 1F - (float)Math.pow(-2.0F * t + 2.0F, 4.0) / 2.0F;
   }

      private float ggtwld(float start, float end, float delta) {
      return start + (end - start) * delta;
   }

      private float gurvnt(float edge0, float edge1, float value) {
      float value2 = MathHelper.clamp((value - edge0) / Math.max(edge1 - edge0, 1E-4F), 0F, 1F);
      return value2 * value2 * (3.0F - 2.0F * value2);
   }

      private float dnvstz(float value) {
      float value2 = MathHelper.clamp(value, 0F, 1F);
      return value2 * value2 * value2 * (value2 * (value2 * 6.0F - 15.0F) + 10.0F);
   }

}
