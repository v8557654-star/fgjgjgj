package winvi.noxiumvisuals.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.render.ColorUtils;
public final class ShaderTextureRenderer {
      private static final Identifier wjwyw = Identifier.of("noxiumvisual", "textures/79c4n1xm9k/tv33pocn.png");
      private static final float transformField69 = 64.0F;
      private static final float jzdnu = 32.0F;
      private static final float startField11 = 0.125F;
      private static final float lmekf = 0.225F;
      private static final long mmsxl = 3200L;
      private static final long ntrvl = 675L;
      private final List<ShaderPulse> ewaf = new ArrayList<>();
      private Vec3d addField68 = Vec3d.ZERO;
      private Vec3d formatField16 = Vec3d.ZERO;
      private Entity ewdb;
      private ClientWorld ewev;
      private int wf0 = -2147483648;
      private long eaqmf;
      private int ewhx;
      private double ppamy;
      private double ewjh;
      private float convertField80;
      private float validateField43;
      private float wm0;
      private float tibgt;
      private float niiwr;
      private float computeField35 = 1F;
      private boolean wiexb;

      public void reset(MinecraftClient client) {
      this.ewev = client.world;
      this.ewdb = null;
      this.ewaf.clear();
      this.wf0 = -2147483648;
      this.eaqmf = 0L;
      this.ewhx = 0;
      this.ppamy = 0;
      this.ewjh = 0;
      this.niiwr = 0F;
      this.computeField35 = 1F;
      if (client.player != null && client.world != null) {
         float value = (float)Math.toRadians(client.player.getYaw());
         this.addField68 = client.player.getPos().add(-Math.sin(value) * 5.0, 0.5, Math.cos(value) * 5.0);
         this.formatField16 = this.addField68;
         this.convertField80 = this.validateField43 = client.player.getYaw();
         this.wm0 = this.tibgt = 0F;
         this.wiexb = true;
      } else {
         this.addField68 = this.formatField16 = Vec3d.ZERO;
         this.wiexb = false;
      }
   }

      public void clear() {
      this.ewev = null;
      this.addField68 = this.formatField16 = Vec3d.ZERO;
      this.ewdb = null;
      this.ewaf.clear();
      this.wf0 = -2147483648;
      this.eaqmf = 0L;
      this.ewhx = 0;
      this.ppamy = 0;
      this.ewjh = 0;
      this.wiexb = false;
   }

      public void focus(LivingEntity entity) {
      if (entity != null && entity.isAlive() && !entity.isInvisible()) {
         this.wf0 = entity.getId();
         this.eaqmf = System.currentTimeMillis() + 3200L;
         this.ewdb = entity;
      }
   }

      public void tick(MinecraftClient client) {
      if (client.player != null && client.world != null) {
         if (!this.wiexb || this.ewev != client.world) {
            this.reset(client);
         }

         if (this.addField68.squaredDistanceTo(client.player.getPos()) > 4900.0) {
            this.reset(client);
         }

         this.formatField16 = this.addField68;
         this.validateField43 = this.convertField80;
         this.tibgt = this.wm0;
         this.ewhx++;
         this.dgv(client);
         this.runMethod400();
         this.x21();
         this.executeMethod92();
         this.z28(client);
      } else {
         this.clear();
      }
   }

      public void render(VertexMatrixRenderer event, int trailTint, int textureTint, float opacity) {
      if (this.wiexb && event != null) {
         float value = MathHelper.clamp(event.getPartialTicks(), 0F, 1F);
         Vec3d position = this.formatField16.lerp(this.addField68, value);
         float value2 = MathHelper.lerpAngleDegrees(value, this.validateField43, this.convertField80);
         float value3 = MathHelper.lerp(value, this.tibgt, this.wm0);
         float value4 = this.fzlbym(value);
         MatrixStack matrices = event.getStack();
         matrices.push();
         matrices.translate(position.x, position.y + value4, position.z);
         matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-value2));
         matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(value3 + (-0.25F + this.niiwr * 0.75F) * 3.0F));
         this.hasMethod66(matrices, trailTint, opacity);
         this.huwpdb(matrices, textureTint, opacity);
         matrices.pop();
      }
   }

      private void dgv(MinecraftClient client) {
      long timestamp = System.currentTimeMillis();
      if (this.wf0 != -2147483648
         && timestamp < this.eaqmf
         && client.world.getEntityById(this.wf0) instanceof LivingEntity livingEntity
         && livingEntity.isAlive()
         && !livingEntity.isInvisible()
         && livingEntity.squaredDistanceTo(client.player) < 400.0) {
         this.ewdb = livingEntity;
      } else {
         this.wf0 = -2147483648;
         this.eaqmf = 0L;
         ItemEntity itemEntity = null;
         double value = 49.0;

         for (Entity entity : client.world.getEntities()) {
            if (entity instanceof ItemEntity itemEntity2 && !itemEntity2.isRemoved()) {
               double value2 = itemEntity2.getPos().squaredDistanceTo(this.addField68);
               if (value2 < value && itemEntity2.squaredDistanceTo(client.player) < 81.0) {
                  itemEntity = itemEntity2;
                  value = value2;
               }
            }
         }

         this.ewdb = (Entity)(itemEntity != null ? itemEntity : client.player);
      }
   }

      private void runMethod400() {
      if (this.ewdb == null) {
         this.ppamy /= 1.8;
         this.ewjh /= 1.8;
      } else {
         double x2 = this.addField68.x - this.ewdb.getX();
         double z2 = this.addField68.z - this.ewdb.getZ();
         double value = Math.sqrt(x2 * x2 + z2 * z2);
         double width = this.ewdb instanceof ItemEntity ? 0.5 : this.ewdb.getWidth() * 1.25;
         if (this.ewdb == MinecraftClient.getInstance().player) {
            width = 0.6 + this.ewdb.getVelocity().horizontalLength() * 5.0;
         }

         double value2 = MathHelper.clamp((value - width * 1.5) / width / 5.0, -0.4F, 1);
         double value3 = value2 < this.ppamy ? 0.5 : 0.1;
         if (this.ewdb instanceof ItemEntity) {
            value2 *= Math.abs(value2);
            value2 *= Math.abs(value2);
         }

         if (value - width < width) {
            this.ppamy /= 1.1;
         }

         this.ppamy = MathHelper.lerp(value3, this.ppamy, value2);
         double height = this.ewdb.getY() + (this.ewdb instanceof ItemEntity ? 0.1 : this.ewdb.getHeight() * 0.9);
         double y2 = height - this.addField68.y;
         double value4 = MathHelper.clamp((y2 - 0.05) / 2.5, -1F, 1);
         value4 *= Math.abs(value4) * 0.5;
         this.ewjh = MathHelper.lerp(0.5, this.ewjh, value4);
      }
   }

      private void x21() {
      boolean enabled = Math.abs(this.ppamy) > 0.02 || Math.abs(this.ewjh) > 0.05;
      float value = this.convertField80;
      float value2 = 0F;
      if (enabled) {
         value2 = (float)MathHelper.clamp((MathHelper.clamp(-this.ewjh, -1F, 0) + Math.abs(this.ppamy) / 4.0) * 180.0, -70.0F, 70.0);
         if (value2 < -10.0F && this.ewdb != null) {
            value = this.gy(this.ewdb.getPos());
         } else {
            Vec3d position = this.addField68.subtract(this.formatField16);
            if (position.horizontalLengthSquared() > 1E-7) {
               value = (float)Math.toDegrees(Math.atan2(-position.x, position.z));
            } else if (this.ewdb != null) {
               value = this.gy(this.ewdb.getPos());
            }
         }
      } else if (this.ewdb != null) {
         value = this.gy(this.ewdb.getPos());
      }

      float value3 = this.ewdb == null ? 0.2F : 0.15F;
      this.convertField80 = MathHelper.lerpAngleDegrees(value3, this.convertField80, value);
      this.wm0 = MathHelper.lerp(value3, this.wm0, value2);
   }

      private float gy(Vec3d target) {
      return (float)Math.toDegrees(Math.atan2(-(target.x - this.addField68.x), target.z - this.addField68.z));
   }

      private void z28(MinecraftClient client) {
      float value = this.ewdb == null ? this.convertField80 : this.gy(this.ewdb.getPos());
      double value2 = Math.toRadians(value);
      double value3 = -Math.sin(value2) * this.ppamy;
      double value4 = Math.cos(value2) * this.ppamy;
      Vec3d position = this.addField68.add(value3, 0, 0);
      if (this.spnhwz(client, position)) {
         this.addField68 = position;
      }

      Vec3d position2 = this.addField68.add(0, this.ewjh, 0);
      if (this.spnhwz(client, position2)) {
         this.addField68 = position2;
      } else if (this.ewjh <= 0.05 && this.spnhwz(client, this.addField68.add(0, 1, 0))) {
         this.addField68 = this.addField68.add(0, 0.05624999850988388, 0);
      }

      Vec3d position3 = this.addField68.add(0, 0, value4);
      if (this.spnhwz(client, position3)) {
         this.addField68 = position3;
      }
   }

      private boolean spnhwz(MinecraftClient client, Vec3d candidate) {
      BlockPos blockPos = BlockPos.ofFloored(candidate);

      for (int index = -1; index <= 1; index++) {
         for (int index2 = -1; index2 <= 1; index2++) {
            for (int index3 = -1; index3 <= 1; index3++) {
               BlockPos blockPos2 = blockPos.add(index, index2, index3);
               if (!client.world.getBlockState(blockPos2).getCollisionShape(client.world, blockPos2).isEmpty()) {
                  Box box = client.world.getBlockState(blockPos2).getCollisionShape(client.world, blockPos2).getBoundingBox().offset(blockPos2);
                  if (box.intersects(
                     candidate.x - 0.22499999403953552,
                     candidate.y - 0.22499999403953552,
                     candidate.z - 0.22499999403953552,
                     candidate.x + 0.22499999403953552,
                     candidate.y + 0.22499999403953552,
                     candidate.z + 0.22499999403953552
                  )) {
                     return false;
                  }
               }
            }
         }
      }

      return true;
   }

      private void executeMethod92() {
      long timestamp = System.currentTimeMillis();
      this.ewaf.removeIf(ring -> {
         return timestamp - ring.startedAt() >= 675L;
      });
      if (this.ewhx % 3 == 2) {
         this.ewaf.add(new ShaderPulse(timestamp));
      }
   }

      private float fzlbym(float delta) {
      float value = 0.015F + (float)Math.abs(this.ppamy) / 15.0F;
      this.niiwr = this.niiwr + this.computeField35 * value * Math.max(delta, 0.2F);
      if (this.niiwr >= 0.8F) {
         this.niiwr = 0.8F;
         this.computeField35 = -1F;
      } else if (this.niiwr <= 0.2F) {
         this.niiwr = 0.2F;
         this.computeField35 = 1F;
      }

      return this.niiwr * this.niiwr * value;
   }

      private void hasMethod66(MatrixStack matrices, int tint, float opacity) {
      if (!this.ewaf.isEmpty()) {
         matrices.push();
         matrices.translate(0, -0.15625F, 0);
         RenderSystem.enableBlend();
         RenderSystem.enableDepthTest();
         RenderSystem.depthMask(false);
         RenderSystem.disableCull();
         RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
         this.setMethod9(matrices, tint, opacity, 0.3F, 0.018F);
         this.setMethod9(matrices, tint, opacity, 0.5F, 0.008F);
         RenderSystem.defaultBlendFunc();
         this.setMethod9(matrices, tint, opacity, 0.95F, 0.003F);
         RenderSystem.depthMask(true);
         RenderSystem.enableCull();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableBlend();
         matrices.pop();
      }
   }

      private void setMethod9(MatrixStack matrices, int tint, float opacity, float layerAlpha, float halfThickness) {
      long timestamp = System.currentTimeMillis();
      Matrix4f matrix = matrices.peek().getPositionMatrix();
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);

      for (ShaderPulse moduleRange2 : this.ewaf) {
         float value = MathHelper.clamp((float)(timestamp - moduleRange2.startedAt()) / 675.0F, 0F, 1F);
         if (!(value >= 1F)) {
            float value2 = value < 0.5F ? value * 2.0F : (1F - value) * 2.0F;
            float value3 = MathHelper.lerp(value, 0.12F, 0.025F);
            float value4 = Math.max(0.001F, value3 - halfThickness);
            float value5 = value3 + halfThickness;
            float value6 = -0.1425F * value;
            int index = ColorUtils.multAlpha(tint, opacity * value2 * layerAlpha);
            int index2 = ColorUtils.multAlpha(tint, 0F);

            for (int index3 = 0; index3 < 48; index3++) {
               double value7 = 6.283185307179586 * index3 / 48.0;
               double value8 = 6.283185307179586 * (index3 + 1) / 48.0;
               float value9 = (float)Math.sin(value7);
               float value10 = (float)Math.cos(value7);
               float value11 = (float)Math.sin(value8);
               float value12 = (float)Math.cos(value8);
               bufferBuilder.vertex(matrix, value9 * value3, value6, value10 * value3).color(index);
               bufferBuilder.vertex(matrix, value11 * value3, value6, value12 * value3).color(index);
               bufferBuilder.vertex(matrix, value11 * value5, value6, value12 * value5).color(index2);
               bufferBuilder.vertex(matrix, value9 * value5, value6, value10 * value5).color(index2);
               bufferBuilder.vertex(matrix, value9 * value4, value6, value10 * value4).color(index2);
               bufferBuilder.vertex(matrix, value11 * value4, value6, value12 * value4).color(index2);
               bufferBuilder.vertex(matrix, value11 * value3, value6, value12 * value3).color(index);
               bufferBuilder.vertex(matrix, value9 * value3, value6, value10 * value3).color(index);
            }
         }
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
   }

      private void huwpdb(MatrixStack matrices, int textureTint, float opacity) {
      RenderSystem.enableBlend();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(true);
      RenderSystem.disableCull();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderTexture(0, wjwyw);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
      Matrix4f matrix = matrices.peek().getPositionMatrix();
      int index = ColorUtils.multAlpha(textureTint, MathHelper.clamp(opacity, 0F, 1F));
      this.hg0(bufferBuilder, matrix, 0.125F, 8, 8, index);
      this.hg0(bufferBuilder, matrix, 0.131875F, 40, 8, index);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.enableCull();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
      RenderSystem.disableBlend();
   }

      private void hg0(BufferBuilder buffer, Matrix4f matrix, float half, int sideU, int sideV, int color) {
      this.jevfll(buffer, matrix, -half, half, half, half, half, half, half, -half, half, -half, -half, half, sideU, sideV, 8.0F, 8.0F, color);
      this.jevfll(buffer, matrix, half, half, -half, -half, half, -half, -half, -half, -half, half, -half, -half, sideU + 16, sideV, 8.0F, 8.0F, color);
      this.jevfll(buffer, matrix, half, half, half, half, half, -half, half, -half, -half, half, -half, half, sideU + 8, sideV, 8.0F, 8.0F, color);
      this.jevfll(buffer, matrix, -half, half, -half, -half, half, half, -half, -half, half, -half, -half, -half, sideU - 8, sideV, 8.0F, 8.0F, color);
      this.jevfll(buffer, matrix, -half, half, -half, half, half, -half, half, half, half, -half, half, half, sideU, sideV - 8, 8.0F, 8.0F, color);
      this.jevfll(buffer, matrix, -half, -half, half, half, -half, half, half, -half, -half, -half, -half, -half, sideU + 8, sideV - 8, 8.0F, 8.0F, color);
   }

      private void jevfll(
      BufferBuilder buffer,
      Matrix4f matrix,
      float x1,
      float y1,
      float z1,
      float x2,
      float y2,
      float z2,
      float x3,
      float y3,
      float z3,
      float x4,
      float y4,
      float z4,
      float textureX,
      float textureY,
      float textureWidth,
      float textureHeight,
      int color
   ) {
      float value = textureX / 64.0F;
      float value2 = textureY / 32.0F;
      float width = (textureX + textureWidth) / 64.0F;
      float height = (textureY + textureHeight) / 32.0F;
      buffer.vertex(matrix, x1, y1, z1).texture(value, value2).color(color);
      buffer.vertex(matrix, x2, y2, z2).texture(width, value2).color(color);
      buffer.vertex(matrix, x3, y3, z3).texture(width, height).color(color);
      buffer.vertex(matrix, x4, y4, z4).texture(value, height).color(color);
   }

}
