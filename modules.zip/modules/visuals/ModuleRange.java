package winvi.noxiumvisuals.modules.visuals;

public record ModuleRange(
   float worldYaw,
   boolean directional,
   float strength,
   long startedAt
) {

      public float worldYaw() {
      return this.worldYaw;
   }

      public boolean directional() {
      return this.directional;
   }

      public float strength() {
      return this.strength;
   }

      public long startedAt() {
      return this.startedAt;
   }

}
