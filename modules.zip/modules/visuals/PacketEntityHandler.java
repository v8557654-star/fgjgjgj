package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket.Handler;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
public final class PacketEntityHandler implements Handler {
      public boolean executeField400;

   public PacketEntityHandler() {
   }

      public boolean updateMethod51(PlayerInteractEntityC2SPacket packet) {
      this.executeField400 = false;
      packet.handle(this);
      return this.executeField400;
   }

      public void interact(Hand hand) {
   }

      public void interactAt(Hand hand, Vec3d pos) {
   }

      public void attack() {
      this.executeField400 = true;
   }

   static {
      int index = 0;
   }
}
