package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
public record MatrixColorStyle(
   Matrix4f matrix,
   int color,
   int glowColor,
   Vec3d glowPosition,
   float finalAnim
) {

      public Matrix4f matrix() {
      return this.matrix;
   }

      public int color() {
      return this.color;
   }

      public int glowColor() {
      return this.glowColor;
   }

      public Vec3d glowPosition() {
      return this.glowPosition;
   }

      public float finalAnim() {
      return this.finalAnim;
   }

   static {
      int index = 0;
   }
}
