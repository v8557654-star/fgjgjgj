package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import winvi.noxiumvisuals.modules.particles.TrackParticleModule;
import winvi.noxiumvisuals.utils.ParticleInstance;
import winvi.noxiumvisuals.utils.render.WorldParticleBatcher;
import winvi.noxiumvisuals.utils.ParticleCameraRenderer;
import winvi.noxiumvisuals.utils.render.RenderMath;
public class TrackParticle extends ParticleInstance {
   private final TrackParticleModule this$0;
      float rotationAngle;
      float rotationSpeed;
      long time;
      Identifier texture;
      float particleScale;
      float drag;
      float lift;
      private final long ggh;
      protected final int[] gradientColors;

   public TrackParticle(
      final TrackParticleModule this$0,
      float x,
      float y,
      float z,
      float motionX,
      float motionY,
      float motionZ,
      float rotationAngle,
      float rotationSpeed,
      float drag,
      float lift
   ) {
      super(x, y, z);
      this.this$0 = this$0;
      this.ggh = (long)(this.this$0.duri.getValue() * 1000.0F);
      this.motionX = motionX;
      this.motionY = motionY;
      this.motionZ = motionZ;
      this.time = System.currentTimeMillis();
      this.rotationAngle = rotationAngle;
      this.rotationSpeed = rotationSpeed;
      this.drag = drag;
      this.lift = lift;
      this.particleScale = Math.max(1F, this$0.okoxi.getValue() * RenderMath.random(0.88F, 1.12F));
      this.gradientColors = (int[])this$0.dvb.clone();
      if (!this$0.gftnv.isEmpty()) {
         this.texture = this$0.gftnv.get(TrackParticleModule.vnkpm.nextInt(this$0.gftnv.size()));
      }
   }

      @Override
   public boolean update(long currentTime, boolean isVisible) {
      this.px = this.x;
      this.py = this.y;
      this.pz = this.z;
      this.x = this.x + this.motionX;
      this.y = this.y + this.motionY;
      this.z = this.z + this.motionZ;
      this.motionX = this.motionX * this.drag;
      this.motionZ = this.motionZ * this.drag;
      this.motionY = (this.motionY + this.lift) * this.drag;
      long timestamp = currentTime - this.time;
      float value = Math.min(1F, (float)timestamp / (float)this.ggh);
      return value >= 1F;
   }

      public boolean update() {
      return this.update(System.currentTimeMillis(), true);
   }

      public void render(MatrixStack matrixStack, float tickDelta, long currentTime, float frameFactor) {
      if (this.this$0.isState()) {
         long timestamp = currentTime - this.time;
         float value = Math.min(1F, (float)timestamp / (float)this.ggh);
         float value2 = this.particleScale;
         float value3 = 1F;
         String text = this.this$0.lxqns.getSelected();
         boolean enabled = "SCALE".equals(text);
         if (value < 0.15F) {
            value3 = value / 0.15F;
         }

         if (value >= 0.7F) {
            float value4 = 1F - (value - 0.7F) / 0.3F;
            if (enabled) {
               value2 = this.particleScale * value4;
            } else {
               value3 *= value4;
            }
         }

         if (value < 0.15F && enabled) {
            value3 = value / 0.15F;
         }

         if (!(value3 <= 0F) && !(value2 <= 0.01F)) {
            if (ParticleCameraRenderer.isParticleVisible(this.getX(), this.getY(), this.getZ(), value2 * 0.07F)) {
               float value5 = 0.07F;
               double value6 = MathHelper.lerp(tickDelta, this.px, this.x);
               double value7 = MathHelper.lerp(tickDelta, this.py, this.y);
               double value8 = MathHelper.lerp(tickDelta, this.pz, this.z);
               matrixStack.push();
               matrixStack.translate(value6, value7, value8);
               matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getYaw()));
               matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(MinecraftClient.getInstance().getEntityRenderDispatcher().camera.getPitch()));
               matrixStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(this.rotationAngle = this.rotationAngle + frameFactor * this.rotationSpeed));
               if (this.texture != null) {
                  WorldParticleBatcher.queueGhostParticle(matrixStack, this.texture, value5 * value2, value3, this.gradientColors[0], true, this.gradientColors);
               }

               matrixStack.pop();
            }
         }
      }
   }

   static {
      int index = 0;
   }
}
