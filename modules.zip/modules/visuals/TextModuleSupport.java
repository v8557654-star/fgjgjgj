package winvi.noxiumvisuals.modules.visuals;

import net.minecraft.text.OrderedText;
public final class TextModuleSupport {
      public final OrderedText eu;
      public float executeField550;

   public TextModuleSupport(OrderedText content) {
      this.eu = content;
   }

      public OrderedText convertMethod38() {
      return this.eu;
   }

      public float otnxbt() {
      return this.executeField550;
   }

}
