package winvi.noxiumvisuals.modules;

import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvent;
import winvi.noxiumvisuals.NoxiumVisuals;
import winvi.noxiumvisuals.modules.settings.DirectionSetting;
import winvi.noxiumvisuals.modules.settings.MultiSelectSetting;
import winvi.noxiumvisuals.modules.settings.SettingGroup;
import winvi.noxiumvisuals.modules.settings.TextSetting;
import winvi.noxiumvisuals.modules.settings.NumberSetting;
import winvi.noxiumvisuals.modules.settings.ColorSetting;
import winvi.noxiumvisuals.modules.settings.BezierCurveSetting;
import winvi.noxiumvisuals.modules.settings.KeybindSetting;
import winvi.noxiumvisuals.modules.settings.ChoiceSetting;
import winvi.noxiumvisuals.modules.settings.BooleanSetting;
import winvi.noxiumvisuals.modules.client.SoundsModule;
import winvi.noxiumvisuals.modules.manager.NotificationsModule;
import winvi.noxiumvisuals.systems.events.EventBus;
import winvi.noxiumvisuals.systems.events.VertexMatrixRenderer;
import winvi.noxiumvisuals.utils.RenderRenderer;
import winvi.noxiumvisuals.utils.QuadraticEaseOutAnimation;
import winvi.noxiumvisuals.utils.JsonFileRenderer;
import winvi.noxiumvisuals.utils.ClientType;
import winvi.noxiumvisuals.utils.render.ColorUtils;
import winvi.noxiumvisuals.utils.render.RenderWindowAccess;
public class Module extends RenderModuleRenderer implements RenderWindowAccess {
      private static long cud = 0L;
      private final String v0;
      private final String cw;
      private final ModuleCategory calculateField22;
      private final RenderRenderer destroyField62 = new QuadraticEaseOutAnimation().setMs(150).setValue(1);
      private final ChoiceSetting computeField73;
      private final ColorSetting daiy;
      private Consumer<Boolean> dbpq;
      private String dcmh;
      private Boolean ddc;
      private String[] de;
      public int key = -1;
      public int type = 1;
      public boolean state;
      public boolean favorite;
      private long addField4 = 0L;

   public Module(String name, ModuleCategory category) {
      this.v0 = name;
      this.calculateField22 = category;
      this.cw = name;
      this.computeField73 = parseMethod93(category);
      this.daiy = j(category, this.computeField73);
      this.xjaqwd();
   }

   public Module(String name, String visibleName, ModuleCategory category) {
      this.v0 = name;
      this.cw = visibleName;
      this.calculateField22 = category;
      this.computeField73 = parseMethod93(category);
      this.daiy = j(category, this.computeField73);
      this.xjaqwd();
   }

      private static ChoiceSetting parseMethod93(ModuleCategory category) {
      return !transformMethod33(category)
         ? null
         : new ChoiceSetting(
               "Color",
               "Color source for this visual"
            )
            .value(
               "Visual Color",
               "Custom"
            )
            .selected("Visual Color")
            .displayFormatter(Module::getVisualColorSourceDisplayName)
            .alias(
               "Theme",
               "Visual Color"
            );
   }

      private static ColorSetting j(ModuleCategory category, ChoiceSetting colorMode) {
      return !transformMethod33(category)
         ? null
         : new ColorSetting(
               "Custom Color",
               "Custom color for this visual"
            )
            .setColor(-8192064)
            .visible(() -> {
               return colorMode.isSelected("Custom");
            });
   }

      private void xjaqwd() {
      if (this.computeField73 != null && this.daiy != null) {
         this.computeField73.withTranslation("visual.common.color", "visual.common.color.desc");
         this.daiy.withTranslation("visual.common.customcolor", "visual.common.customcolor.desc");
         this.yibrlp(() -> {
            return false;
         });
         this.setup(new ModuleSetting[]{this.computeField73, this.daiy});
      }
   }

      protected final void showVisualColorSettings() {
      this.yibrlp(() -> {
         return true;
      });
   }

      protected final void showVisualColorSettings(Supplier<Boolean> visible) {
      this.yibrlp(visible);
   }

      private void yibrlp(Supplier<Boolean> visible) {
      if (this.computeField73 != null && this.daiy != null) {
         Supplier supplier = visible != null ? visible : () -> {
            return false;
         };
         this.computeField73.setVisible(supplier);
         this.daiy.setVisible(() -> {
            return (Boolean)supplier.get() && this.computeField73.isSelected("Custom");
         });
      }
   }

      public int getVisualColor() {
      return this.computeField73 != null && this.computeField73.isSelected("Custom")
         ? this.daiy.getColor()
         : ColorUtils.getVisualColor();
   }

      protected final int resolveVisualOrCustomColor(ChoiceSetting colorMode, ColorSetting customColor) {
      return colorMode != null && colorMode.isSelected("Custom") && customColor != null
         ? customColor.getColor()
         : ColorUtils.getVisualColor();
   }

      public static String getVisualColorSourceDisplayName(String value) {
      String text = "visual.common.color." + normalizeTranslationKey(value);
      return JsonFileRenderer.has(text) ? JsonFileRenderer.get(text) : value;
   }

      private static boolean transformMethod33(ModuleCategory category) {
      return category == ModuleCategory.VISUAL || category == ModuleCategory.WORLD || category == ModuleCategory.PARTICLES;
   }

      public String getTranslationPrefix() {
      if (this.dcmh == null) {
         this.dcmh = normalizeTranslationKey(this.v0);
      }

      return this.dcmh;
   }

      public String getLocalizedName() {
      return this.apup();
   }

      public String getLocalizedDescription() {
      for (String text : this.handleMethod76()) {
         if (JsonFileRenderer.has(text)) {
            return JsonFileRenderer.get(text);
         }
      }

      return this.q();
   }

      public String getDescriptionCategoryKey() {
      return switch (this.calculateField22) {
         case VISUAL -> "render";
         case MANAGER -> "manager";
         default -> this.calculateField22.name().toLowerCase(Locale.ROOT);
      };
   }

      public static String normalizeTranslationKey(String value) {
      if (value != null && !value.isEmpty()) {
         StringBuilder stringBuilder = new StringBuilder(value.length());

         for (int index = 0; index < value.length(); index++) {
            char character = Character.toLowerCase(value.charAt(index));
            if ((character < 'a' || character > 'z') && (character < '0' || character > '9')) {
               if (character == '+') {
                  stringBuilder.append("plus");
               }
            } else {
               stringBuilder.append(character);
            }
         }

         return stringBuilder.toString();
      } else {
         return "";
      }
   }

      private String[] handleMethod76() {
      if (this.de != null) {
         return this.de;
      } else {
         LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
         String text = this.getDescriptionCategoryKey();
         this.aoyr(linkedHashSet, text, this.v0);
         this.aoyr(linkedHashSet, text, this.cw);
         this.de = linkedHashSet.toArray(x$0 -> {
            return new String[x$0];
         });
         return this.de;
      }
   }

      private void aoyr(Set<String> keys, String categoryKey, String source) {
      if (source != null && !source.isEmpty()) {
         String text = source.toLowerCase(Locale.ROOT);
         String text2 = normalizeTranslationKey(source);
         keys.add("descriptions." + categoryKey + "." + text2);
         keys.add("descriptions." + categoryKey + "." + text.replace(" ", "_"));
         keys.add("descriptions." + categoryKey + "." + text.replace(" ", ""));
         keys.add("descriptions." + categoryKey + "." + text);
      }
   }

      private String apup() {
      return this.cw != null && !this.cw.isEmpty() && this.destroyMethod65() ? this.cw : this.v0;
   }

      private String q() {
      return this.cw != null && !this.cw.isEmpty() && !this.destroyMethod65() ? this.cw : "";
   }

      private boolean destroyMethod65() {
      if (this.ddc == null) {
         this.ddc = normalizeTranslationKey(this.cw).equals(this.getTranslationPrefix());
      }

      return this.ddc;
   }

      public void initializeDefaultValues() {
      for (ModuleSetting moduleProvider3 : this.settings()) {
         this.asd(moduleProvider3);
         if (moduleProvider3 instanceof SettingGroup moduleSettingProvider3 && moduleSettingProvider3.getSubSettings() != null) {
            for (ModuleSetting moduleProvider32 : moduleSettingProvider3.getSubSettings()) {
               this.asd(moduleProvider32);
            }
         }
      }
   }

      private void asd(ModuleSetting setting) {
      if (setting instanceof NumberSetting moduleSettingTransformer) {
         moduleSettingTransformer.setDefaultValue();
      } else if (setting instanceof BooleanSetting moduleSettingManager) {
         moduleSettingManager.setDefaultValue();
      } else if (setting instanceof ColorSetting colorRenderRenderer2) {
         colorRenderRenderer2.setDefaultValue();
      } else if (setting instanceof BezierCurveSetting moduleSettingProvider4) {
         moduleSettingProvider4.setDefaultValue();
      } else if (setting instanceof KeybindSetting moduleSettingProvider5) {
         moduleSettingProvider5.setDefaultKey();
      } else if (setting instanceof TextSetting textModuleProvider) {
         textModuleProvider.setDefaultText();
      } else if (setting instanceof SettingGroup moduleSettingProvider3) {
         moduleSettingProvider3.setDefaultValue();
      }
   }

      public void switchState() {
      this.setState(!this.state);
   }

      public void setState(boolean state) {
      this.destroyField62.setDirection(state ? ClientType.FORWARDS : ClientType.BACKWARDS);
      if (state != this.state) {
         if (state) {
            this.addField4 = ++cud;
         }

         this.state = state;
         this.hbluih();
         if (this.dbpq != null) {
            this.dbpq.accept(state);
         }

         this.formatMethod88();
      }
   }

      private void formatMethod88() {
      try {
         NoxiumVisuals noxiumVisuals = NoxiumVisuals.getInstance();
         if (noxiumVisuals != null && noxiumVisuals.getFileController() != null) {
            noxiumVisuals.getFileController().markDirty();
         }
      } catch (Exception exception) {
      }
   }

      private void hbluih() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null && client.world != null) {
         if (this.state) {
            this.manageMethod51(this.getLocalizedName() + " " + JsonFileRenderer.get("hud.notifications.enabled"), null);
            this.fjttbc();
            this.activate();
         } else {
            this.manageMethod51(this.getLocalizedName() + " " + JsonFileRenderer.get("hud.notifications.disabled"), null);
            this.manageMethod49();
            this.deactivate();
         }
      }

      this.x(this.state);
   }

      private void fjttbc() {
      try {
         SoundsModule soundsModule = NoxiumVisuals.getInstance().getModuleProvider().get(SoundsModule.class);
         if (soundsModule != null && soundsModule.isState()) {
            soundsModule.playEnableSound();
         }
      } catch (Exception exception) {
      }
   }

      private void manageMethod49() {
      try {
         SoundsModule soundsModule = NoxiumVisuals.getInstance().getModuleProvider().get(SoundsModule.class);
         if (soundsModule != null && soundsModule.isState()) {
            soundsModule.playDisableSound();
         }
      } catch (Exception exception) {
      }
   }

      private void x(boolean activate) {
      EventBus eventBus = NoxiumVisuals.getInstance().getEventManager();
      if (activate) {
         eventBus.register(this);
      } else {
         eventBus.unregister(this);
      }
   }

      public void activate() {
   }

      public void deactivate() {
   }

      public void onTick() {
   }

      public void onWorldRender(VertexMatrixRenderer event) {
   }

      public boolean hasWorldRenderWork() {
      return true;
   }

      public void setKey(int key) {
      this.key = key;
   }

      public int getKey() {
      return this.key;
   }

      public void setType(int type) {
      this.type = type;
   }

      public int getType() {
      return this.type;
   }

      private void manageMethod51(String message, SoundEvent sound) {
      NotificationsModule notificationsModule = NoxiumVisuals.getInstance().getModuleProvider().get(NotificationsModule.class);
      if (notificationsModule != null
         && notificationsModule.isState()
         && notificationsModule.notificationSettings.isSelected("Module Switch")) {
         String text = message.replaceAll("\\u00A7[0-9a-fk-or]", "");
         String text2 = JsonFileRenderer.get("hud.notifications.enabled");
         String text3 = JsonFileRenderer.get("hud.notifications.disabled");
         if (text.endsWith(" " + text2)) {
            notificationsModule.pushModuleNotification(text.substring(0, text.length() - text2.length() - 1), true, this.calculateField22);
         } else if (text.endsWith(" " + text3)) {
            notificationsModule.pushModuleNotification(text.substring(0, text.length() - text3.length() - 1), false, this.calculateField22);
         } else {
            notificationsModule.pushCustomNotification(text);
         }
      }
   }

      public void setFavorite(boolean favorite) {
      if (favorite != this.favorite) {
         this.favorite = favorite;
         this.formatMethod88();
      }
   }

      public void resetSettings() {
      for (ModuleSetting moduleProvider3 : this.settings()) {
         if (moduleProvider3 instanceof NumberSetting moduleSettingTransformer) {
            moduleSettingTransformer.reset();
         } else if (moduleProvider3 instanceof BooleanSetting moduleSettingManager) {
            moduleSettingManager.reset();
         } else if (moduleProvider3 instanceof ColorSetting colorRenderRenderer2) {
            colorRenderRenderer2.reset();
         } else if (moduleProvider3 instanceof BezierCurveSetting moduleSettingProvider4) {
            moduleSettingProvider4.reset();
         } else if (moduleProvider3 instanceof ChoiceSetting moduleSettingHandler2) {
            moduleSettingHandler2.reset();
         } else if (moduleProvider3 instanceof MultiSelectSetting moduleSettingHandler) {
            moduleSettingHandler.reset();
         } else if (moduleProvider3 instanceof SettingGroup moduleSettingProvider3 && moduleSettingProvider3.getSubSettings() != null) {
            for (ModuleSetting moduleProvider32 : moduleSettingProvider3.getSubSettings()) {
               if (moduleProvider32 instanceof NumberSetting moduleSettingTransformer2) {
                  moduleSettingTransformer2.reset();
               } else if (moduleProvider32 instanceof BooleanSetting moduleSettingManager2) {
                  moduleSettingManager2.reset();
               } else if (moduleProvider32 instanceof ColorSetting colorRenderRenderer22) {
                  colorRenderRenderer22.reset();
               } else if (moduleProvider32 instanceof BezierCurveSetting moduleSettingProvider42) {
                  moduleSettingProvider42.reset();
               } else if (moduleProvider32 instanceof ChoiceSetting moduleSettingHandler22) {
                  moduleSettingHandler22.reset();
               } else if (moduleProvider32 instanceof MultiSelectSetting moduleSettingHandler3) {
                  moduleSettingHandler3.reset();
               }
            }
         }
      }
   }

      public boolean hasModifiedSettings() {
      for (ModuleSetting moduleProvider3 : this.settings()) {
         if (moduleProvider3 instanceof NumberSetting moduleSettingTransformer && moduleSettingTransformer.isModified()) {
            return true;
         }

         if (moduleProvider3 instanceof BooleanSetting moduleSettingManager && moduleSettingManager.isModified()) {
            return true;
         }

         if (moduleProvider3 instanceof ColorSetting colorRenderRenderer2 && colorRenderRenderer2.isModified()) {
            return true;
         }

         if (moduleProvider3 instanceof BezierCurveSetting moduleSettingProvider4 && moduleSettingProvider4.isModified()) {
            return true;
         }

         if (moduleProvider3 instanceof ChoiceSetting moduleSettingHandler2 && moduleSettingHandler2.isModified()) {
            return true;
         }

         if (moduleProvider3 instanceof MultiSelectSetting moduleSettingHandler && moduleSettingHandler.isModified()) {
            return true;
         }

         if (moduleProvider3 instanceof KeybindSetting moduleSettingProvider5 && moduleSettingProvider5.isModified()) {
            return true;
         }

         if (moduleProvider3 instanceof TextSetting textModuleProvider && textModuleProvider.isModified()) {
            return true;
         }

         if (moduleProvider3 instanceof DirectionSetting moduleSettingProvider2 && moduleSettingProvider2.isModified()) {
            return true;
         }

         if (moduleProvider3 instanceof SettingGroup moduleSettingProvider3 && moduleSettingProvider3.getSubSettings() != null) {
            for (ModuleSetting moduleProvider32 : moduleSettingProvider3.getSubSettings()) {
               if (moduleProvider32 instanceof NumberSetting moduleSettingTransformer2 && moduleSettingTransformer2.isModified()) {
                  return true;
               }

               if (moduleProvider32 instanceof BooleanSetting moduleSettingManager2 && moduleSettingManager2.isModified()) {
                  return true;
               }

               if (moduleProvider32 instanceof ColorSetting colorRenderRenderer22 && colorRenderRenderer22.isModified()) {
                  return true;
               }

               if (moduleProvider32 instanceof BezierCurveSetting moduleSettingProvider42 && moduleSettingProvider42.isModified()) {
                  return true;
               }

               if (moduleProvider32 instanceof ChoiceSetting moduleSettingHandler22 && moduleSettingHandler22.isModified()) {
                  return true;
               }

               if (moduleProvider32 instanceof MultiSelectSetting moduleSettingHandler3 && moduleSettingHandler3.isModified()) {
                  return true;
               }

               if (moduleProvider32 instanceof KeybindSetting moduleSettingProvider52 && moduleSettingProvider52.isModified()) {
                  return true;
               }

               if (moduleProvider32 instanceof TextSetting textModuleProvider2 && textModuleProvider2.isModified()) {
                  return true;
               }

               if (moduleProvider32 instanceof DirectionSetting moduleSettingProvider22 && moduleSettingProvider22.isModified()) {
                  return true;
               }
            }
         }
      }

      return false;
   }

      public String getName() {
      return this.v0;
   }

      public String getVisibleName() {
      return this.cw;
   }

      public ModuleCategory getCategory() {
      return this.calculateField22;
   }

      public RenderRenderer getAnimation() {
      return this.destroyField62;
   }

      public ChoiceSetting getVisualColorMode() {
      return this.computeField73;
   }

      public ColorSetting getCustomVisualColor() {
      return this.daiy;
   }

      public Consumer<Boolean> getStateChangeCallback() {
      return this.dbpq;
   }

      public String getNormalizedName() {
      return this.dcmh;
   }

      public Boolean getEquivalentVisibleName() {
      return this.ddc;
   }

      public boolean isState() {
      return this.state;
   }

      public boolean isFavorite() {
      return this.favorite;
   }

      public long getLastEnableOrder() {
      return this.addField4;
   }

      public void setNormalizedName(String normalizedName) {
      this.dcmh = normalizedName;
   }

      public void setEquivalentVisibleName(Boolean equivalentVisibleName) {
      this.ddc = equivalentVisibleName;
   }

      public void setDescriptionKeys(String[] descriptionKeys) {
      this.de = descriptionKeys;
   }

      public void setLastEnableOrder(long lastEnableOrder) {
      this.addField4 = lastEnableOrder;
   }

      public void setStateChangeCallback(Consumer<Boolean> stateChangeCallback) {
      this.dbpq = stateChangeCallback;
   }

}
